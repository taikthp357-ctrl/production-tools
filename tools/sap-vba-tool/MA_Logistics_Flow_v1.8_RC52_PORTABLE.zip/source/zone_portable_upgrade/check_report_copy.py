"""Regression checks for Tra mã, including the real Tk controls and clipboard on Windows."""
from contextlib import ExitStack
from datetime import date
from pathlib import Path
import re
import sys
from types import SimpleNamespace
from unittest.mock import patch
import xml.etree.ElementTree as ET

import check_portable as cp

exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
_, entries, _ = cp.archive(exe.read_bytes())
modules = cp.pyz_entries(cp.payload(next(entry for entry in entries.values() if entry[3] == b'z')))
sys.meta_path.insert(0, cp.EmbeddedSource(modules))
import zone18
import zone_clipboard as clip
import zone_mail as mail
import zone_search as search
import zone_shift as shift
from zone_order_result import file_key
from zone_qty import OrderTable

DAY = date(2026, 11, 26)
CODES = ('BIW71004848', 'BIW71004712AA', 'BIW70004159', 'BIW70004160', 'BIW71004714AA', 'BIW70004151')
SOURCE = Path('261126_THEO DOI ORDER NVL_P_S6.xlsb')


def order(code, qty, slip='', station='Trạm A', plan=DAY):
    row = [None] * 35
    row[3:6] = [code, qty, station]
    row[9], row[11], row[24], row[26], row[27] = 'VF8NP', 'S6', 'Pending', plan, 'Chưa ra đơn'
    if slip:
        row[13:15] = ['1013370001', slip]
        row[27] = 'Đã ra đơn, chờ cấp'
    return row


def record(row, n):
    return (row[3], row[26], n, row, SOURCE, str(n))


def sample():
    header = [None] * 35
    for col, name in shift.FIELD_NAMES.items():
        header[col] = name
    rows = [order(code, quantity, number) for code, quantity, number in
            zip(CODES, (170, 110, 180, 280, 130, 280), ('26-05', '26-06', '26-32', '26-32', '26-33', '26-49'))]
    rows[0][4:6] = [100, 'Trạm A&B <1>']
    rows.insert(1, order(CODES[0], 70, '26-05', 'Trạm B'))
    rows.append(order(CODES[1], 15, plan=date(2026, 11, 27)))
    return OrderTable([tuple(header), *(tuple(row) for row in rows)])


def parse_html(data):
    offsets = dict((key.decode(), int(value)) for key, value in
                   re.findall(rb'(StartHTML|EndHTML|StartFragment|EndFragment):(\d+)', data))
    start, end = offsets['StartFragment'], offsets['EndFragment']
    assert data[offsets['StartHTML']:start].endswith(b'<!--StartFragment-->')
    assert data[end:offsets['EndHTML']].startswith(b'<!--EndFragment-->')
    assert data[offsets['EndHTML']-7:offsets['EndHTML']] == b'</html>'
    fragment = data[start:end].decode('utf-8')
    return ET.fromstring('<root>' + fragment + '</root>')


def table_rows(root):
    return [[cell.text or '' for cell in tr] for tr in root.findall('table/tbody/tr')]


def check_data():
    assert zone18.VERSION in ('1.8 RC42', '1.8 RC43', '1.8 RC44', '1.8 RC45', '1.8 RC46', '1.8 RC47', '1.8 RC48', '1.8 RC49', '1.8 RC50', '1.8 RC51', '1.8 RC52')
    table = sample()
    group = [record(r, i) for i, r in enumerate(table[1:3], 2)]
    assert search.group_summary(group) == ('170', '', '', '26-05', search.WAITING)
    mixed = order('BIWTEST', 12, '26-05 / 26-06')
    mixed[16:18] = ['1013370002', '26-06 / 26-07']
    info = search.row_info(mixed)
    assert info == ('', '', '26-05 / 26-06 / 26-07', '1013370001 / 1013370002', search.WAITING)
    mixed[27] = 'Đã ra đơn, chờ cấp 26-07'
    assert search.row_info(mixed)[-1] == search.WAITING
    mixed[15] = 4
    assert search.row_info(mixed)[:2] == ('4', '8')
    assert search.row_info(mixed)[-1] == 'Cấp một phần · '+search.WAITING
    assert search.group_summary([record(order('X', 12), 2), record(mixed, 3)])[:3] == ('24', '4', '20')

    for marker in ('Hết tồn', 'Hết tồn kho', 'Hết tồn kho MA'):
        empty = order('BIWTEST', 12)
        empty[13], empty[27] = marker, 'Hết tồn kho MA'
        assert search.row_info(empty) == ('', '', '', '', 'Hết tồn kho MA')
        empty[16:18] = ['1013370002', '26-08']
        empty[27] = search.WAITING
        assert search.row_info(empty)[-2:] == ('1013370002', search.WAITING)
    shared = order('BIWTEST', 12, '26-09')
    shared[13], shared[15], shared[22] = '1013370001/1013370002', 12, 12
    assert 'đối soát' in search.row_info(shared[:34])[-1]
    assert search.group_summary([record(shared, 2)])[-1] != 'Đã cấp đủ'
    shared[34] = '{"confirmed": true}'
    assert search.group_summary([record(shared, 2)])[-1] == 'Đã cấp đủ'
    zero = order('BIWTEST', 12, '26-08')
    zero[15], zero[22] = 0, 0
    assert search.row_info(zero)[:2] == ('0', '12') and search.row_info(zero)[-1] == search.WAITING
    zero[27] = 'Ra đơn cấp lại'
    assert search.row_info(zero)[-1] == 'Ra đơn cấp lại'
    zero[4], zero[24] = 0, 'Done'
    assert search.group_summary([record(zero, 2)]) == ('0', '0', '0', '26-08', 'Đã cấp đủ')
    broken = order('BIWTEST', 'lỗi')
    assert search.group_summary([record(mixed, 2), record(broken, 3)])[-1] == search.CHECK_QTY
    assert not any(search.group_summary([record(broken, 3)])[:3])

    plain, fragment = clip.table_formats([
        ('Báo cáo gửi SX/TL', search.SUMMARY_COLUMNS, [('26/11/2026', 'BIW<&', '130', '', '', '26-05', search.WAITING)]),
        ('Tổng hợp', ('Mã NVL', 'Ghi chú'), [('001', None)])])
    markup = parse_html(clip.windows_html(fragment))
    assert table_rows(markup)[0][1:6] == ['BIW<&', '130', '', '', '26-05']
    assert [node.text for node in markup.findall('p/strong')] == ['Báo cáo gửi SX/TL', 'Tổng hợp']
    assert len(markup.findall('table')) == 2 and '130\t\t\t26-05' in plain
    assert table_rows(markup)[1] == ['001', '']
    print('Passed status, grouped quantities, shared OB, duplicate slips, empty cells and UTF-8 byte offsets.')


def check_windows():
    import subprocess
    import tkinter as tk
    from tkinter import ttk
    import win32clipboard as wc
    from zone_report_ui import ReportPage

    def read_board():
        wc.OpenClipboard()
        try:
            markup = parse_html(wc.GetClipboardData(wc.RegisterClipboardFormat('HTML Format')))
            text = wc.GetClipboardData(wc.CF_UNICODETEXT)
        finally:
            wc.CloseClipboard()
        return markup, text

    table = sample()
    app = SimpleNamespace(is_running=False, out_mail=SimpleNamespace(prior_selected={}, messages=[]))
    page = SimpleNamespace(app=app, path=SOURCE, table=table, revision=1, password=None, stamp=1,
                           sources={file_key(SOURCE): 'đã lưu'}, pivots={})
    page.task = lambda label, work, done, *args, **kwargs: done(work())
    root = tk.Tk()
    errors = []
    root.report_callback_exception = lambda kind, exc, tb: errors.append(str(exc))
    try:
        root.geometry('1170x570')
        screen = search.SearchPage(root, page, lambda: None)
        screen.anchor.set(DAY.isoformat())
        screen.input.insert('1.0', '\n'.join(CODES))
        with ExitStack() as stack:
            stack.enter_context(patch.object(shift, 'read_order', return_value=(table, 1, 'đã lưu', None)))
            stack.enter_context(patch.object(mail, 'prior_files', return_value=([], [])))
            stack.enter_context(patch.object(shift, 'missing_history', return_value=()))
            screen.search()
            root.update()
            grid = screen.tree
            def descendants(parent):
                for child in parent.winfo_children():
                    yield child
                    yield from descendants(child)
            copy = next(w for w in descendants(root) if isinstance(w, ttk.Button) and w['text']=='Copy bảng')
            opt = next(w for w in descendants(root) if isinstance(w, ttk.Menubutton))
            menu = root.nametowidget(str(opt['menu']))
            assert len(grid.rows)==6 and not grid.selection()
            copy.invoke()
            doc, plain = read_board()
            assert table_rows(doc) == [list(row) for row in grid.rows]
            assert [c.text for c in doc.findall('table/thead/tr/th')] == list(search.SUMMARY_COLUMNS)
            assert all('chờ cấp 26-' not in row[-1] for row in grid.rows)
            assert '280\t\t\t26-32' in plain and '6 dòng' in grid.copy_notice.get()

            # The second process reads both formats from the system clipboard.
            subprocess.run([sys.executable, '-c',
                            "import win32clipboard as c;c.OpenClipboard();"
                            "assert c.IsClipboardFormatAvailable(c.RegisterClipboardFormat('HTML Format'));"
                            "assert '26-05' in c.GetClipboardData(c.CF_UNICODETEXT);c.CloseClipboard()"], check=True)
            x = sum(grid.widths[:1]) + 10
            for _ in range(2):grid.header.event_generate('<Button-1>',x=x,y=8)
            assert [r[1] for r in grid.rows]==sorted(CODES,reverse=True)
            chosen = [i for i,r in enumerate(grid.rows,1) if r[1] in (CODES[0],CODES[-1])]
            grid.selection_set(chosen)
            copy.invoke()
            assert table_rows(read_board()[0]) == [list(grid.rows[i-1]) for i in chosen]
            screen.future.set(True)
            screen.refilter()
            root.update()
            assert len(grid.rows)==7 and {grid.rows[i-1][1] for i in grid.selection()}=={CODES[0],CODES[-1]}
            assert grid.sort_order==(1,True)
            menu.invoke('Báo cáo SX/TL theo trạm')
            doc, plain = read_board()
            rows=table_rows(doc)
            assert len(rows)==3 and len(rows[0])==8 and 'S6' in doc.find('p/strong').text
            assert [(r[2],r[3]) for r in rows if r[1]==CODES[0]]==[('Trạm A&B <1>', '100'), ('Trạm B','70')]
            assert 'Trạm A&B <1>\t100\t\t\t26-05' in plain

            grid.active = (grid.selection()[0], 5)
            grid.focus_force()
            root.update()
            grid.event_generate('<Control-c>')
            root.update()
            assert root.clipboard_get() == grid.rows[grid.active[0]-1][5]
            grid.event_generate('<Control-Shift-C>')
            root.update()
            assert len(table_rows(read_board()[0]))==2
            screen.input.delete('1.0','end')
            screen.search()
            copy.invoke()
            assert not grid.rows and 'Chưa có dòng' in grid.copy_notice.get()
            screen.input.insert('1.0', CODES[0]+'\nMISSING9001')
            app.out_mail.messages=[dict(rows=[dict(material='MAIL9002',plan=DAY.isoformat())])]
            screen.input.insert('end','\nMAIL9002')
            screen.search()
            menu.invoke('Báo cáo SX/TL theo trạm')
            rows=table_rows(read_board()[0])
            assert any(r[1]=='MAIL9002' and r[-1]==search.MAIL_ONLY and not any(r[2:7]) for r in rows)
            assert any(r[1]=='MISSING9001' and 'chưa thấy mã' in r[-1] for r in rows)

            # Copying both shift tables uses the same native clipboard writer.
            def sheet(title):
                t=SimpleNamespace(title=title,headers=('Mã NVL','Ghi chú'),rows=[SimpleNamespace(values=('001',''))])
                return SimpleNamespace(table=t)
            report=SimpleNamespace(sheets=[sheet('Tình trạng'),sheet('Kết quả')],canvas=grid,page=SimpleNamespace(report_hint=tk.StringVar(root)))
            ReportPage.copy(report)
            assert [p.text for p in read_board()[0].findall('p/strong')]==['Tình trạng','Kết quả']
            assert not errors, errors
    finally:
        root.destroy()
    print('Passed Windows Tk buttons, menu, sorting, selection, refilter, Ctrl+C, Ctrl+Shift+C and cross-process clipboard.')


if __name__ == '__main__':
    check_data()
    if sys.platform == 'win32':
        check_windows()
