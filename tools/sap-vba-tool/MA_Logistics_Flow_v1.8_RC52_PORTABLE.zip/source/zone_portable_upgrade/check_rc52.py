"""Acceptance tests for MA Logistics Flow v1.8 RC52 (SearchPage old-partial toggle, FIFO merge & waiting order numbers)."""
from contextlib import ExitStack
from datetime import date
from pathlib import Path
import sys
import tempfile
import tkinter as tk
from types import SimpleNamespace as S
from unittest.mock import patch


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import zone18 as z
    import zone_mail as mail
    import zone_qty as qty_mod
    import zone_search as search
    import zone_shift as sh
    from zone_order_result import file_key

    assert z.VERSION == '1.8 RC52', z.VERSION

    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, kh, qty, issued=0, ob1='', sp1='', ob2='', sp2='', issued2=None,
               note='Chưa ra đơn', pack='EA', station='KV03'):
        r = [None] * 35
        r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = pack, mat, qty, station, '3093', '1005', '1006', 'VF5', 'S6'
        r[13], r[14], r[15] = ob1, sp1, (issued if issued else None)
        r[16], r[17], r[18] = ob2, sp2, issued2
        total = (issued or 0) + (issued2 or 0)
        r[22] = total if (issued or issued2 is not None) else None
        r[24] = 'Done' if total >= qty else 'Partial finished' if total > 0 else 'Pending'
        r[26], r[27] = kh, note
        return r

    # Rows covering:
    # - 25/11 Done (old_done)
    # - 25/11 Partial standard material (40 missing)
    # - 26/11 Partial standard material with Slot1 SP + Slot2 waiting OB without SP
    # - 26/11 Pure Pending Chưa ra đơn (must NEVER be hidden by old_done/old_partial)
    # - 27/11 Partial current KHSX (110 missing, unblocked)
    # - 27/11 Waiting order with OB1 only (no SP1 in Excel) + resolved via SQLite run_result
    # - 27/11 Waiting order with OB1 only (no SQLite slip) -> falls back to OB in SearchPage
    # - 27/11 Waiting order with legacy NOTE 'Đã ra đơn, chờ cấp 27-15'
    # - 27/11 Hết tồn kho MA (must stay blank Số đơn)
    rows_data = [
        mk_row('BIW3201DONE', '2026-11-25', 50, issued=50, ob1='1013360001', sp1='25-01', note=''),
        mk_row('BIW32012454AA', '2026-11-25', 310, issued=270, ob1='1013360002', sp1='25-02', note='Cấp một phần'),
        mk_row('BIW32013741AB', '2026-11-26', 310, issued=288, ob1='1013360003', sp1='26-01', ob2='1013370004', sp2='', issued2=None, note='Đã ra đơn, chờ cấp'),
        mk_row('BIW3201PEND', '2026-11-26', 20, issued=0, ob1='', sp1='', note='Chưa ra đơn'),
        mk_row('BIW32012454AA', '2026-11-27', 310, issued=200, ob1='1013370001', sp1='27-01', note='Cấp một phần'),
        mk_row('BIW32013855AB', '2026-11-27', 310, issued=0, ob1='1013370002', sp1='', note='Đã ra đơn, chờ cấp'),
        mk_row('BIW32015110AB', '2026-11-27', 210, issued=0, ob1='1013370003', sp1='', note='Đã ra đơn, chờ cấp'),
        mk_row('BIW32019999AA', '2026-11-27', 80, issued=0, ob1='', sp1='', note='Đã ra đơn, chờ cấp 27-15'),
        mk_row('BIW3201NONE', '2026-11-27', 40, issued=0, ob1='Hết tồn', sp1='', note='Hết tồn kho MA'),
    ]
    table = [header, *rows_data]

    # 1. Row/Group order number resolution including waiting OB / SQLite / NOTE / partial+waiting
    slip_lookup = ({('1013370002', 'BIW32013855AB'): '27-09'}, {})
    assert search.group_summary([(None, None, 7, rows_data[5], None, None)], slip_lookup) == ('310', '', '', '27-09', search.WAITING)
    assert search.group_summary([(None, None, 8, rows_data[6], None, None)], slip_lookup) == ('210', '', '', '1013370003', search.WAITING)
    assert search.group_summary([(None, None, 9, rows_data[7], None, None)], slip_lookup) == ('80', '', '', '27-15', search.WAITING)
    assert search.group_summary([(None, None, 4, rows_data[2], None, None)], slip_lookup) == ('310', '288', '22', '26-01 / 1013370004', 'Cấp một phần · Đã ra đơn, chờ cấp')
    # Row_info keeps dedicated OB column separate when include_ob_fallback=False, yet keeps NOTE/SQLite slips cleanly
    assert search.row_info(rows_data[6])[-2:] == ('1013370003', search.WAITING)
    assert search.row_info(rows_data[5], slip_lookup=slip_lookup)[-2:] == ('1013370002', search.WAITING)
    assert search.row_info(rows_data[5], slip_lookup=slip_lookup)[2] == '27-09'
    assert search.row_info(rows_data[8]) == ('', '', '', '', 'Hết tồn kho MA')

    # 2. Separate old_done & old_partial UI toggles + submit scope & FIFO OB merge
    with tempfile.TemporaryDirectory() as tmp:
        wb = Path(tmp) / '261127_THEO DOI ORDER NVL_P_S6.xlsb'
        wb.write_bytes(b'order-data')
        stamp = sh.signature(wb)
        otable = qty_mod.OrderTable(table)
        submitted = []
        zone_mgr = S(resolve_zone_tl=lambda mat, st, *a: ('Z1', 'TL1', True))
        cfg = {'plant': '3093', 'sloc_from': '1005', 'sloc_to': '1006', 'sap_system': 'PSV', 'sap_client': '908', 'ewm_warehouse': '1802'}
        root = tk.Tk()
        app = S(root=root, is_running=False, config=cfg, zone_mgr=zone_mgr, out_mail=S(prior_selected={}, messages=[]))
        page = S(app=app, path=wb, table=otable, revision=1, password=None, stamp=stamp,
                 sources={file_key(wb): 'File đã lưu'}, pivots={},
                 on_run=lambda cands, p, s: submitted.append((cands, p, s)))
        page.task = lambda label, work, done, *args, **kwargs: done(work())

        try:
            screen = search.SearchPage(root, page, lambda: None)
            screen.anchor.set('2026-11-27')
            screen.input.insert('1.0', 'BIW3201')
            with ExitStack() as stack:
                stack.enter_context(patch.object(mail, 'prior_files', return_value=([], [])))
                stack.enter_context(patch.object(sh, 'missing_history', return_value=()))
                stack.enter_context(patch.object(z, 'output_history', return_value=[{
                    'order_file': file_key(wb),
                    'order_obs': ['1013370002'],
                    'order_groups': [],
                    'order_requests': [],
                    'records': [{'ob': '1013370002', 'material': 'BIW32013855AB', 'who': '6000000001', 'who_numbers': {'6000000001': '27-09'}}],
                }]))
                screen.search()
                root.update()

                # Default: old_done=False and old_partial=False -> hides 25/11 Done + 25/11 Partial + 26/11 Partial
                assert screen.old_done.get() is False and screen.old_partial.get() is False
                shown_default = {(r[0], r[1]): r for r in screen.tree.rows}
                assert ('25/11/2026', 'BIW3201DONE') not in shown_default
                assert ('25/11/2026', 'BIW32012454AA') not in shown_default
                assert ('26/11/2026', 'BIW32013741AB') not in shown_default
                assert ('26/11/2026', 'BIW3201PEND') in shown_default
                assert ('27/11/2026', 'BIW32012454AA') in shown_default
                assert shown_default[('27/11/2026', 'BIW32013855AB')][5] == '27-09'
                assert shown_default[('27/11/2026', 'BIW32015110AB')][5] == '1013370003'
                assert shown_default[('27/11/2026', 'BIW32019999AA')][5] == '27-15'
                assert 'ẩn 1 đã cấp đủ ngày trước' in screen.hint.get()
                assert 'ẩn 2 cấp 1 phần ngày trước' in screen.hint.get()

                # Submit with old_partial=False -> only 27/11 partial (110 EA)
                idx_today = next(i for i, r in enumerate(screen.tree.rows, 1) if (r[0], r[1]) == ('27/11/2026', 'BIW32012454AA'))
                screen.tree.selection_set([idx_today])
                with patch.object(search.simpledialog, 'askfloat', return_value=110.0) as ask_q, \
                     patch.object(search.messagebox, 'askyesno', return_value=True) as ask_y:
                    screen.submit()
                    assert ask_q.call_args.kwargs['initialvalue'] == 110
                    assert 'KHSX 2026-11-27 · Tổng 110 EA' in ask_y.call_args.args[1]
                assert len(submitted[-1][0]) == 1 and submitted[-1][0][0]['kh'] == '2026-11-27' and submitted[-1][0][0]['qty'] == 110

                # Toggle old_done=True only -> Done appears, old partial still hidden
                screen.old_done.set(True)
                screen.refilter()
                root.update()
                shown_done = {(r[0], r[1]) for r in screen.tree.rows}
                assert ('25/11/2026', 'BIW3201DONE') in shown_done
                assert ('25/11/2026', 'BIW32012454AA') not in shown_done

                # Toggle old_done=False, old_partial=True -> old partial appears, Done hidden
                screen.old_done.set(False)
                screen.old_partial.set(True)
                screen.refilter()
                root.update()
                shown_partial = {(r[0], r[1]) for r in screen.tree.rows}
                assert ('25/11/2026', 'BIW3201DONE') not in shown_partial
                assert ('25/11/2026', 'BIW32012454AA') in shown_partial
                assert ('26/11/2026', 'BIW32013741AB') in shown_partial

                # Select BOTH 25/11 Partial (40) + 27/11 Partial (110) of standard material -> combines FIFO (150 EA) into 1 OB group
                idx_old = next(i for i, r in enumerate(screen.tree.rows, 1) if (r[0], r[1]) == ('25/11/2026', 'BIW32012454AA'))
                idx_new = next(i for i, r in enumerate(screen.tree.rows, 1) if (r[0], r[1]) == ('27/11/2026', 'BIW32012454AA'))
                screen.tree.selection_set([idx_old, idx_new])
                with patch.object(search.simpledialog, 'askfloat', return_value=150.0) as ask_q, \
                     patch.object(search.messagebox, 'askyesno', return_value=True) as ask_y:
                    screen.submit()
                    assert ask_q.call_args.kwargs['initialvalue'] == 150
                    assert 'Gom 2 ngày KHSX (2026-11-25, 2026-11-27) · Tổng 150 EA' in ask_y.call_args.args[1]
                merged_reqs = submitted[-1][0]
                assert [(r['kh'], r['qty']) for r in merged_reqs] == [('2026-11-25', 40), ('2026-11-27', 110)]
                groups, shortages, _ = core.AllocationEngine(zone_mgr, 5, 10).allocate(
                    merged_reqs,
                    [{'material': 'BIW32012454AA', 'batch': 'B1', 'bin': 'A1', 'unit': 'EA', 'available_qty': 500, 'allocated_qty': 0, 'sort_key': '1'}],
                )
                assert not shortages and len(groups) == 1, (groups, shortages)
                assert sum(line['qty'] for line in groups[0]['lines']) == 150
        finally:
            root.destroy()

    print('All RC52 acceptance tests (separate old-partial toggle, FIFO merge across old+new KHSX & waiting order/OB display) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
