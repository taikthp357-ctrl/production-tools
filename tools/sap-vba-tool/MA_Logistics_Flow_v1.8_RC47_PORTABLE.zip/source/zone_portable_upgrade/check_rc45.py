"""Acceptance tests for MA Logistics Flow v1.8 RC45 (BBGN SAP user config, receiver dept, <=5 rows & top-right slip number)."""
from contextlib import ExitStack, contextmanager
import os
from pathlib import Path
import sys
import tempfile
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as mb
from types import SimpleNamespace as S
from unittest.mock import patch


def make_fake_sheet():
    class FakeFont:
        def __init__(self):
            self.Bold = False
            self.Size = 10

    class FakeCell:
        def __init__(self, r, c, value=None):
            self.r, self.c = r, c
            self.Value2 = value
            self.NumberFormat = 'General'
            self.HorizontalAlignment = 0
            self.Font = FakeFont()
            self.MergeArea = self

        def Cells(self, r, c):
            return self

        def ClearContents(self):
            self.Value2 = None

    class FakeRange:
        def __init__(self, hidden_map, label):
            self.hidden_map = hidden_map
            self.label = label
            self.Value2 = None
            self.RowHeight = 18
            self.Top = 0 if label == '1' else 40
            self.Left = (int(label) - 1) * 50 if str(label).isdigit() else 0
            self.Width = 50

        @property
        def Hidden(self):
            return self.hidden_map.get(self.label, False)

        @Hidden.setter
        def Hidden(self, val):
            self.hidden_map[self.label] = bool(val)

        @property
        def MergeArea(self):
            return self

        def ClearContents(self):
            self.Value2 = None

    class FakeSheet:
        def __init__(self):
            self.cells = {}
            self.hidden_log = {}
            self.exported = []
            self.PageSetup = S(RightHeader='', Zoom=False, FitToPagesWide=1, FitToPagesTall=1, PrintArea='$A$2:$K$36')
            # Simulate red MẬT shape over col K (col 11, Left=500, Top=5)
            self.Shapes = [S(Top=5, Left=500, TopLeftCell=S(Column=11))]
            defaults = {
                (11, 11): 'Ghi chú (nếu có)',
                (12, 2): 'Mã Hàng Hóa (Part No.)',
                (12, 3): 'Tên/ Batch hoặc Serial',
                (4, 3): 'BÊN BÀN GIAO (Hand over party)',
                (4, 7): 'BÊN NHẬN BÀN GIAO (Take over party)',
                (5, 1): 'Họ và Tên (Full Name):',
                (6, 1): 'Mã NV (Employee code):',
                (7, 1): 'Bộ Phận (Department):',
                (8, 1): 'Chức vụ (Title):',
                (9, 1): 'Số điện thoại (Phone):',
            }
            for (r, c), v in defaults.items():
                self.cells[(r, c)] = FakeCell(r, c, v)

        def Cells(self, r, c):
            if (r, c) not in self.cells:
                self.cells[(r, c)] = FakeCell(r, c)
            return self.cells[(r, c)]

        def Range(self, addr):
            return FakeRange(self.hidden_log, addr)

        def Rows(self, label):
            return FakeRange(self.hidden_log, str(label))

        def Columns(self, c):
            return FakeRange(self.hidden_log, str(c))

        def ExportAsFixedFormat(self, fmt, path):
            self.exported.append((fmt, path))

    return FakeSheet()


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_bbbg as bbbg
    import zone_shift as sh
    import zone_workspace as ws

    assert z.VERSION in ('1.8 RC45', '1.8 RC46', '1.8 RC47'), z.VERSION

    # 1. Per-SAP-user profile resolution & mandatory receiver Department
    cfg = {
        'bbbg_users': {
            'TAIPT': {'name': 'Phạm Tiến Tài', 'emp_id': 'VN1234', 'dept': 'Kho NVL P', 'title': 'Nhân viên kho', 'phone': '0901234567'},
            'NVB': {'name': 'Nguyễn Văn B', 'emp_id': 'VN5678', 'dept': 'Kho P', 'title': 'Thủ kho', 'phone': '0987654321'},
        },
        'bbbg_default_sap_user': 'TAIPT',
        'bbbg_receiver': {'dept': 'Sản xuất VF7', 'name': '', 'emp_id': '', 'title': '', 'phone': ''},
    }
    uid, sender, recv = bbbg.resolve_parties(cfg, 'nvb')
    assert uid == 'NVB' and sender['name'] == 'Nguyễn Văn B' and sender['emp_id'] == 'VN5678'
    assert recv['dept'] == 'Sản xuất VF7' and recv['name'] == '' and recv['phone'] == ''
    try:
        bbbg.resolve_parties(cfg, 'TAIPT', {'dept': ''})
    except ValueError as exc:
        assert 'Bộ phận' in str(exc)
    else:
        raise AssertionError('Blank receiver department must fail closed')

    # 2. Render Excel form: top-right slip number BBBG-02 next to MẬT, party fill, hide surplus rows to max 5 for 1-2 items
    row_a = ['BATCH1', None, None, 'BIW71005023', 300, 'KV18Tuấn/Ban']
    row_b = ['BATCH2', None, None, 'BIW71005024', 50, 'KV18Tuấn/Ban']
    sheet_small = make_fake_sheet()
    @contextmanager
    def fake_book(*_a):
        yield S(Worksheets=[sheet_small])
    with patch.object(sh, 'excel_book', side_effect=fake_book):
        bbbg.render(Path('tpl.xlsb'), [(row_a, 300), (row_b, 50)], Path('BBBG-02.pdf'), 'BBBG-02', '2026-11-26', sender, recv)
    assert sheet_small.Cells(1, 10).Value2 == 'Số phiếu: BBBG-02'
    assert sheet_small.Cells(1, 10).Font.Bold and sheet_small.Cells(1, 10).HorizontalAlignment == -4152
    assert '$A$1:' in sheet_small.PageSetup.PrintArea
    assert [sheet_small.Cells(r, 3).Value2 for r in range(5, 10)] == ['Nguyễn Văn B', 'VN5678', 'Kho P', 'Thủ kho', '0987654321']
    assert sheet_small.Cells(7, 7).Value2 == 'Sản xuất VF7' and sheet_small.Cells(5, 7).Value2 == ''
    assert sheet_small.hidden_log.get('13:30') is False and sheet_small.hidden_log.get('18:30') is True

    # For 7 items, rows 13..19 stay visible and 20..30 get hidden
    sheet_seven = make_fake_sheet()
    @contextmanager
    def fake_book_seven(*_a):
        yield S(Worksheets=[sheet_seven])
    with patch.object(sh, 'excel_book', side_effect=fake_book_seven):
        bbbg.render(Path('tpl.xlsb'), [(row_a, 10) for _ in range(7)], Path('BBBG-03.pdf'), 'BBBG-03', '2026-11-26', sender, recv)
    assert sheet_seven.hidden_log.get('20:30') is True and '18:30' not in sheet_seven.hidden_log

    # 3. Windows Tk Config tab: Mail OD stays at index 3, BBGN config saves cleanly per SAP user & receiver dept
    with tempfile.TemporaryDirectory() as tmp:
        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': True, 'system': 'PSV', 'client': '908', 'user': 'TAI_SAP', 'tcode': 'SMEN'}))
            stack.enter_context(patch.object(mb, 'showinfo'))
            os.environ['LOCALAPPDATA'] = tmp
            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                cfg_book = next(w for w in app.tab_config.winfo_children() if isinstance(w, ttk.Notebook))
                assert cfg_book.tab(3, 'text') == 'Mail OD'
                bbbg_idx = next(i for i in range(cfg_book.index('end')) if cfg_book.tab(i, 'text') == 'BBGN')
                bbbg_tab = cfg_book.winfo_children()[bbbg_idx]
                entries = []
                def walk(w):
                    for c in w.winfo_children():
                        if isinstance(c, (ttk.Entry, ttk.Combobox)):
                            entries.append(c)
                        walk(c)
                walk(bbbg_tab)
                # Fill User SAP combobox & sender fields & receiver dept
                uid_combo = next(w for w in entries if isinstance(w, ttk.Combobox))
                uid_combo.set('TAI_SAP')
                sender_entries = [w for w in entries if not isinstance(w, ttk.Combobox)]
                # sender_entries[0] = template path, [1..5] = name/emp_id/dept/title/phone, [6] = receiver dept
                for widget, val in zip(sender_entries[1:7], ['Phạm Tài', 'MN999', 'Kho P', 'Chuyên viên', '0912345678', 'Sản xuất Body']):
                    widget.delete(0, 'end')
                    widget.insert(0, val)
                app._save_config()
                saved = core.ConfigManager.load_config()
                assert saved['bbbg_default_sap_user'] == 'TAI_SAP'
                assert saved['bbbg_users']['TAI_SAP']['name'] == 'Phạm Tài'
                assert saved['bbbg_users']['TAI_SAP']['phone'] == '0912345678'
                assert saved['bbbg_receiver']['dept'] == 'Sản xuất Body'
                assert not errors, errors
            finally:
                root.destroy()

    print('All RC45 acceptance tests (BBGN per-SAP-user config, mandatory receiver dept, <=5 visible rows & top-right slip number) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
