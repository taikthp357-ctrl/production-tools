"""Acceptance tests for MA Logistics Flow v1.8 RC46 (BBGN A4 Landscape, big slip note, footer strike/names)."""
from contextlib import ExitStack, contextmanager
import os
from pathlib import Path
import sys
import tempfile
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as mb
from types import SimpleNamespace as S
from unittest.mock import patch


def make_full_sheet():
    class FakeFont:
        def __init__(self):
            self.Bold = False
            self.Size = 10

    class FakeBorder:
        def __init__(self):
            self.LineStyle = -4142
            self.Weight = 2

    class FakeCell:
        def __init__(self, r, c, value=None, row_span=1):
            self.r, self.c = r, c
            self.Value2 = value
            self.NumberFormat = 'General'
            self.HorizontalAlignment = 0
            self.VerticalAlignment = 0
            self.WrapText = True
            self.Font = FakeFont()
            self.Row = r
            self.Rows = S(Count=row_span)
            self._borders = {5: FakeBorder()}
            self.MergeArea = self

        def Cells(self, r, c):
            return self

        def Borders(self, idx):
            return self._borders.setdefault(idx, FakeBorder())

        def ClearContents(self):
            self.Value2 = None

    class FakeRange:
        def __init__(self, hidden_map, height_map, label):
            self.hidden_map = hidden_map
            self.height_map = height_map
            self.label = label
            self.Value2 = None
            self.Top = 0 if label == '1' else 40
            self.Left = (int(label) - 1) * 50 if str(label).isdigit() else 0
            self.Width = 50

        @property
        def RowHeight(self):
            return self.height_map.get(self.label, 18)

        @RowHeight.setter
        def RowHeight(self, val):
            self.height_map[self.label] = val

        @property
        def Hidden(self):
            return self.hidden_map.get(self.label, False)

        @Hidden.setter
        def Hidden(self, val):
            self.hidden_map[self.label] = bool(val)

        @property
        def MergeArea(self):
            return self

        def ClearContents(self):
            self.Value2 = None

    class FakeSheet:
        def __init__(self):
            self.cells = {}
            self.hidden_log = {}
            self.row_heights = {}
            self.exported = []
            self.PageSetup = S(
                RightHeader='OLD', Zoom=True, FitToPagesWide=1, FitToPagesTall=1,
                PrintArea='$A$2:$M$45', PaperSize=1, Orientation=1,
                LeftMargin=54, RightMargin=54, TopMargin=54, BottomMargin=54,
                HeaderMargin=20, FooterMargin=20, CenterHorizontally=False, CenterVertically=False,
            )
            self.Shapes = [S(Top=5, Left=500, TopLeftCell=S(Column=11))]
            defaults = {
                (11, 11): ('Ghi chú (nếu có)', 1),
                (12, 2): ('Mã Hàng Hóa (Part No.)', 1),
                (12, 3): ('Tên/ Batch hoặc Serial', 1),
                (4, 3): ('BÊN BÀN GIAO (Hand over party)', 1),
                (4, 7): ('BÊN NHẬN BÀN GIAO (Take over party)', 1),
                (5, 1): ('Họ và Tên (Full Name):', 1),
                (6, 1): ('Mã NV (Employee code):', 1),
                (7, 1): ('Bộ Phận (Department):', 1),
                (8, 1): ('Chức vụ (Title):', 1),
                (9, 1): ('Số điện thoại (Phone):', 1),
                (33, 6): ('An ninh xác nhận\n(Security Signature)', 2),
                (34, 1): ('Người bàn giao (Handoverer)', 1),
                (34, 3): ('Phê duyệt (Approval)', 1),
                (35, 1): ('Họ và Tên:\n(Full name)', 1),
                (35, 3): ('Họ và Tên:\n(Full name)', 1),
                (35, 6): ('Họ và Tên:\n(Full name)', 1),
                (36, 1): (' ', 1),
            }
            for (r, c), (v, span) in defaults.items():
                self.cells[(r, c)] = FakeCell(r, c, v, span)

        def Cells(self, r, c):
            if (r, c) not in self.cells:
                self.cells[(r, c)] = FakeCell(r, c)
            return self.cells[(r, c)]

        def Range(self, addr):
            return FakeRange(self.hidden_log, self.row_heights, addr)

        def Rows(self, label):
            return FakeRange(self.hidden_log, self.row_heights, str(label))

        def Columns(self, c):
            return FakeRange(self.hidden_log, self.row_heights, str(c))

        def ExportAsFixedFormat(self, fmt, path):
            self.exported.append((fmt, path))

    return FakeSheet()


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_bbbg as bbbg
    import zone_shift as sh
    import zone_workspace as ws

    assert z.VERSION in ('1.8 RC46', '1.8 RC47'), z.VERSION

    row = ['LTV', None, None, 'BIW25111743AA', 50, 'CO2Kiểm']
    sender = {'name': 'Phạm Tiến Tài', 'emp_id': '3740570', 'dept': 'Kho', 'title': 'Data', 'phone': '0934243740'}

    # 1. Production issue -> A4 Landscape, tight margins, PrintArea A1:K36, Font Size 18 BBBG-03, strike Approval & Security, preserve C34/C35
    s_prod = make_full_sheet()
    @contextmanager
    def book_prod(*_a):
        yield S(Worksheets=[s_prod])
    with patch.object(sh, 'excel_book', side_effect=book_prod):
        bbbg.render(Path('t.xlsb'), [(row, 50)], Path('BBBG-03.pdf'), 'BBBG-03', '2026-11-26',
                    sender, {'dept': 'Sản xuất'}, internal_prod=True, approver_name='Nguyễn Duyệt')
    assert s_prod.PageSetup.PaperSize == 9 and s_prod.PageSetup.Orientation == 2
    assert s_prod.PageSetup.PrintArea == '$A$1:$K$36' and s_prod.PageSetup.LeftMargin == 14
    assert s_prod.Cells(1, 10).Value2 == 'Số phiếu: BBBG-03' and s_prod.Cells(1, 10).Font.Size == 18 and s_prod.Cells(1, 10).WrapText is False
    assert s_prod.Rows('1').RowHeight == 28
    assert s_prod.Cells(34, 3).Value2 == 'Phê duyệt (Approval)'
    assert s_prod.Cells(35, 3).Borders(5).LineStyle == 1 and s_prod.Cells(35, 6).Borders(5).LineStyle == 1
    assert s_prod.Cells(35, 1).Value2 == 'Họ và Tên:\n(Full name)'
    assert s_prod.Cells(35, 3).Value2 == 'Họ và Tên:\n(Full name)'

    # 2. Out-of-plant issue -> NO strike diagonal, Handoverer & Approval filled with configured names
    s_ext = make_full_sheet()
    @contextmanager
    def book_ext(*_a):
        yield S(Worksheets=[s_ext])
    with patch.object(sh, 'excel_book', side_effect=book_ext):
        bbbg.render(Path('t.xlsb'), [(row, 50)], Path('BBBG-04.pdf'), 'BBBG-04', '2026-11-26',
                    sender, {'dept': 'Nhà cung cấp ngoài'}, internal_prod=False, approver_name='Nguyễn Văn Duyệt')
    assert s_ext.Cells(35, 3).Borders(5).LineStyle == -4142 and s_ext.Cells(35, 6).Borders(5).LineStyle == -4142
    assert 'Phạm Tiến Tài' in s_ext.Cells(35, 1).Value2
    assert 'Nguyễn Văn Duyệt' in s_ext.Cells(35, 3).Value2

    # 3. resolve_footer validation when external issue lacks approver name
    try:
        bbbg.resolve_footer({}, 'Nhà cung cấp ngoài', 'Phạm Tiến Tài', internal_prod=False, approver_override='')
    except ValueError as exc:
        assert 'phê duyệt' in str(exc).casefold()
    else:
        raise AssertionError('External BBGN without approver must fail closed')

    # 4. Windows Tk Cấu hình -> BBGN persists bbbg_approver alongside SAP-user profile
    with tempfile.TemporaryDirectory() as tmp:
        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': False}))
            stack.enter_context(patch.object(mb, 'showinfo'))
            os.environ['LOCALAPPDATA'] = tmp
            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                cfg_book = next(w for w in app.tab_config.winfo_children() if isinstance(w, ttk.Notebook))
                bbbg_idx = next(i for i in range(cfg_book.index('end')) if cfg_book.tab(i, 'text') == 'BBGN')
                bbbg_tab = cfg_book.winfo_children()[bbbg_idx]
                entries = []
                def walk(w):
                    for c in w.winfo_children():
                        if isinstance(c, ttk.Entry) and not isinstance(c, ttk.Combobox):
                            entries.append(c)
                        walk(c)
                walk(bbbg_tab)
                # Last entry is Tên người phê duyệt (Approval)
                entries[-1].delete(0, 'end')
                entries[-1].insert(0, 'Trần Phê Duyệt')
                app._save_config()
                saved = core.ConfigManager.load_config()
                assert saved['bbbg_approver'] == 'Trần Phê Duyệt', saved
                assert not errors, errors
            finally:
                root.destroy()

    print('All RC46 acceptance tests (A4 Landscape, Font 18 BBBG number, C34/C35 intact, prod strike vs external approval/handover names) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
