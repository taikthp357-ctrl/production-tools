"""Track each ORDER request through its allocated groups and write verified receipts."""
from collections import defaultdict, deque
from contextlib import contextmanager
from decimal import Decimal
from pathlib import Path
import json
import os
import re

import zone_shift as sh


def group_sources(requests, groups):
    queues=defaultdict(deque)
    for r in requests:
        queues[(r['material'],r['station'])].append([r['line_id'],Decimal(str(r['qty']))])
    mapped=[]
    for g in groups:
        owners=[]
        for line in g['lines']:
            key=line['material'],line['station']
            left=Decimal(str(line['qty']))
            while left>0:
                if not queues[key]:
                    raise ValueError('Không ghép được phân bổ với mã và trạm nguồn ORDER.')
                cur=queues[key][0]
                take=min(cur[1],left)
                cur[1]-=take
                left-=take
                if cur[0] not in owners:
                    owners.append(cur[0])
                if not cur[1]:
                    queues[key].popleft()
        mapped.append(owners)
    if any(queues.values()):
        raise ValueError('Còn yêu cầu ORDER chưa có nhóm phân bổ.')
    return mapped


def file_key(path):
    return os.path.normcase(str(Path(path).resolve()))


def receipts(history,path):
    import zone18 as z
    latest={}
    out=[]
    for run in history:
        for r in run.get('records',[]):
            latest.setdefault((r['ob'],r['material']),r)
    for run in history:
        if run.get('order_file')!=file_key(path):
            continue
        posted=run.get('order_obs',[])
        for source in run.get('order_requests',[]):
            pairs=[]
            planned=[i for i,ids in enumerate(run['order_groups']) if source['line_id'] in ids]
            valid=bool(planned)
            for i in planned:
                if i>=len(posted):
                    valid=False
                    continue
                ob=posted[i]
                r=latest.get((ob,source['material']),{})
                whos=z.printable_whos([r])
                nums=r.get('who_numbers',{})
                num='/'.join(nums.get(w,'') for w in whos)
                if not whos or not all(z.valid_order_number(nums.get(w)) for w in whos):
                    valid=False
                pairs.append((ob,num))
            if pairs:
                out.append(dict(source=source,pairs=pairs,valid=valid,run=run['run_id'],mock=bool(run.get('is_mock'))))
    return out


def edits(table,items):
    # Compare the saved workbook again while Excel holds the write lock.
    lookup={key:(n,r) for n,r,key in sh.indexed(table)}
    changes={}
    for entry in items:
        src=entry['source']
        if entry['mock'] or not entry['valid']:
            raise ValueError('Chỉ ghi kết quả SAP thật có đủ OB và số đơn.')
        if src['origin'] not in lookup:
            raise ValueError(f'Dòng nguồn {src["row"]} đã đổi mã, SL hoặc thông tin ORDER.')
        n,r=lookup[src['origin']]
        if n in changes:
            raise ValueError(f'Chọn một lượt của dòng {n} mỗi lần ghi.')
        slots=[sh.clean(r[i]) for i in (13,14,16,17,19,20)]
        before=slots.copy()
        def tokens(v):
            return [t.strip() for t in v.split('/') if t.strip()]
        missing=[]
        for ob,num in dict.fromkeys(tuple(pair) for pair in entry['pairs']):
            occupied=[i for i in (0,2,4) if ob in tokens(slots[i])]
            if occupied:
                if len(occupied)!=1 or not set(tokens(num))<=set(tokens(slots[occupied[0]+1])):
                    raise ValueError(f'Dòng {n}: OB đã có với số đơn khác. Kiểm tra Excel.')
            else:
                missing.append((ob,num))
        if not missing:
            continue
        extra=src.get('mode') in (sh.EXTRA,sh.MODEL_ROUND,sh.FIFO,sh.SHORT_BOX)
        if (extra and (src.get('source_state')!=sh.state(r) or sh.round_open(r) or
                       src.get('slot_qty')!=[sh.clean(r[i]) for i in (15,18,21)])):
            raise ValueError(f'Dòng {n}: trạng thái cấp thùng đã đổi. Tải lại ORDER để đối soát.')
        if (slots!=list(src['slots']) or sh.norm(r[27])!=src['note'] or sh.clean(r[2])!=src['packing_value']
                or sh.clean(r[22])!=src['issued'] or (sh.state(r)=='done' and not extra)):
            raise ValueError(f'Dòng {n} vừa đổi OB, NOTE hoặc trạng thái. Chưa ghi dữ liệu.')
        for i in (0,2,4):
            if (slots[i+1] and not slots[i]) or (slots[i] and not slots[i+1] and not extra) or any(not re.fullmatch(r'10\d{8}',v) for v in tokens(slots[i])):
                raise ValueError(f'Dòng {n}: cặp OB/số phiếu cũ chưa đủ.')
        added=defaultdict(list)
        for ob,num in missing:
            if src['kind']=='Thường' and not extra:
                i=0
                if before[0]:
                    raise ValueError(f'Dòng thường {n} đã có OB1.')
            else:
                i=min((0,2,4),key=lambda k:len(tokens(slots[k])))
            added[i].append(ob)
            occupied=bool(slots[i])
            slots[i]='/'.join(filter(None,(slots[i],ob)))
            slots[i+1]=(slots[i+1]+'/' if occupied else '')+num
        changes[n]=[(col,val) for col,val,old in zip((14,15,17,18,20,21),slots,before) if val!=old]+[(28,'Đã ra đơn, chờ cấp')]
        if extra:
            tracked=[(13+i//2*3,float(r[15+i//2*3] or 0),obs) for i,obs in added.items()]
            marker={'qty':src['qty'],'slots':tracked,'shared_slot':any(before[i] or len(obs)>1 for i,obs in added.items())}
            if len(r)>34 and sh.clean(r[34]):
                original=json.loads(r[34])
                marker.update({key:original[key] for key in ('from','file','row','mail_row') if key in original})
            changes[n].append((35,json.dumps(marker,separators=(',',':'))))
    return changes


def open_workbook(path):
    from zone_excel_live import find
    return find(path)


@contextmanager
def writable_order(path,password):
    from zone_excel_live import order_access
    with order_access(path), _writable_order(path,password) as opened:
        yield opened


@contextmanager
def _writable_order(path,password):
    book=open_workbook(path)
    if book is None:
        with sh.excel(path,password,True) as (owned,sheet):
            yield owned,sheet,False
        return
    if book.ReadOnly:
        raise ValueError('File ORDER đang mở ở chế độ chỉ đọc.')
    excel=book.Application
    events,interactive=excel.EnableEvents,excel.Interactive
    try:
        excel.EnableEvents=False
        excel.Interactive=False
        yield book,sh.order_sheet(book),True
    finally:
        try:
            excel.Interactive=interactive
        finally:
            excel.EnableEvents=events


def write(path,password,items):
    with writable_order(path,password) as (book,sheet,shared):
        changes=edits(sh.values(sheet),items)
        pending=[]
        if any(col==35 for fields in changes.values() for col,_ in fields):
            header=sheet.Cells(1,35)
            if sh.clean(header.Value2)!=sh.TRACK:
                sh.check_tracking_space(sheet)
                pending.append((header,header.NumberFormat,header.Value2,sh.TRACK))
        for n,fields in changes.items():
            for col,val in fields:
                cell=sheet.Cells(n,col)
                if cell.HasFormula:
                    raise ValueError(f'Dòng {n}, cột {col} chứa công thức.')
                pending.append((cell,cell.NumberFormat,cell.Value2,val))
        applied=[]
        try:
            for cell,fmt,old,val in pending:
                applied.append((cell,fmt,old))
                cell.NumberFormat='@'
                cell.Value2=val
            if changes:
                sheet.Calculate()
                checked=sh.values(sheet)
                if any(sh.clean(checked[n-1][col-1])!=v for n,fields in changes.items() for col,v in fields):
                    raise ValueError('Giá trị Excel đọc lại khác bản xem trước.')
                book.Save()
        except Exception:
            if shared:
                for cell,fmt,old in reversed(applied):
                    cell.NumberFormat=fmt
                    cell.Value2=old
            raise
    return len(changes),sh.load(path,password)


def archived_cartons(previous,current,config):
    active={key for _,_,key in sh.indexed(current)}
    active.update(sh.tracking_origin(r) for _,r in sh.rows(current))
    return [line for line in sh.plan(previous,None,None,sh.EXTRA,config) if
            line['source_state']=='done' and not line['problem'] and line['origin'] not in active]


def import_cartons(path,password,expected,archive,archive_password,source_stamp,selected,config):
    from datetime import datetime
    from zone_mail import day
    source,stamp,source_kind,_=sh.read_order(archive,archive_password,False)
    if stamp!=source_stamp or 'chưa lưu' in source_kind:
        raise ValueError('File bàn giao đã đổi hoặc còn chỉnh sửa chưa lưu. Đọc lại ca trước.')
    now=datetime.now()
    with writable_order(path,password) as (book,sheet,shared):
        current=sh.values(sheet)
        if current!=expected:
            raise ValueError('ORDER hiện tại vừa thay đổi. Tải lại trước khi thêm yêu cầu.')
        eligible={r['origin']:r for r in archived_cartons(source,current,config)}
        if not selected or not set(selected)<=eligible.keys() or len(set(selected))!=len(selected):
            raise ValueError('Dòng đã được đưa vào ca này hoặc đã đổi điều kiện.')
        records=[]
        for key in selected:
            item=eligible[key]
            old=source[item['row']-1]
            fields={c:old[c-1] for c in range(1,13)}
            fields.update({5:item['qty'],11:sh.parsed_name(path)[1],27:old[26],28:'Chưa ra đơn',
                           29:(now.date()-day(0)).days,30:(now.hour*3600+now.minute*60+now.second)/86400,
                           31:'Bổ sung kho P',35:json.dumps({'from':key,'file':Path(archive).name,'row':item['row']},ensure_ascii=False)})
            records.append(fields)
        def validate(updated,first):
            for offset,key in enumerate(selected):
                item=eligible[key]
                r=updated[first+offset-1]
                if (sh.clean(r[3]).upper()!=item['material'] or r[4]!=item['qty'] or
                    str(day(r[26]))!=item['kh'] or sh.state(r)!='pending' or sh.packing(r[2])!=(True,item['pack']) or
                    any(sh.clean(r[i]) for i in (13,14,15,16,17,18,19,20,21)) or
                    json.loads(r[34]).get('from')!=key):
                    raise ValueError('Dòng thùng bổ sung chưa khớp sau khi tính Excel.')
        append_rows(book,sheet,shared,current,records,validate)
    return sh.load(path,password)

def confirm_shared_slots(path,password,expected,origins):
    with writable_order(path,password) as (book,sheet,shared):
        table=sh.values(sheet)
        if table!=expected:
            raise ValueError('ORDER đã thay đổi. Tải lại rồi đối chiếu các OB.')
        pending=[]
        for n,row,key in sh.indexed(table):
            if key in origins:
                if not sh.round_open(row) or sh.round_open(row,quantity_only=True):
                    raise ValueError(f'Dòng {n} chưa có đủ SL thực cấp cho lượt OB ghép.')
                marker=json.loads(row[34])
                marker['confirmed']=True
                cell=sheet.Cells(n,35)
                if cell.HasFormula:
                    raise ValueError('Ô theo dõi chứa công thức.')
                pending.append((cell,row[34],json.dumps(marker,ensure_ascii=False,separators=(',',':'))))
        if not pending or len(pending)!=len(origins):
            raise ValueError('Chọn đúng các dòng OB ghép đã đối chiếu.')
        try:
            for cell,old,new in pending:
                cell.Value2=new
            if any(cell.Value2!=new for cell,old,new in pending):
                raise ValueError('Không đọc lại được dấu xác nhận trong Excel.')
            book.Save()
        except Exception:
            if shared:
                for cell,old,new in pending:
                    cell.Value2=old
            raise
    return sh.load(path,password)


def append_rows(book,sheet,shared,current,records,validate):
    sh.check_tracking_space(sheet)
    owner=None
    for j in range(1,sheet.ListObjects.Count+1):
        obj=sheet.ListObjects.Item(j)
        if obj.HeaderRowRange.Row==1 and obj.Range.Column<=4<obj.Range.Column+obj.Range.Columns.Count:
            owner=obj
            break
    first=len(current)+1
    template=first-1
    if template<2:
        raise ValueError('ORDER hiện tại thiếu dòng mẫu để kế thừa công thức.')
    changes=[]
    added=[]
    def put(cell,value,formula=False,fmt=None):
        changes.append((cell,cell.FormulaR1C1 if cell.HasFormula else cell.Value2,bool(cell.HasFormula),cell.NumberFormat))
        if fmt is not None and cell.NumberFormat!=fmt:
            cell.NumberFormat=fmt
        if formula:
            cell.FormulaR1C1=value
        else:
            cell.Value2=value
    try:
        if sh.clean(sheet.Cells(1,35).Value2)!=sh.TRACK:
            put(sheet.Cells(1,35),sh.TRACK)
        for offset,fields in enumerate(records):
            n=first+offset
            if owner is not None and n>owner.HeaderRowRange.Row+owner.ListRows.Count:
                created=owner.ListRows.Add()
                added.append(created)
                if created.Range.Row!=n:
                    raise ValueError('Vị trí dòng thêm trong bảng Excel khác dự kiến.')
            # Derived columns can be prefilled below the last material in the workbook.
            derived={13,23,24,25,26}
            derived.update(c for c in (1,2,3) if sheet.Cells(template,c).HasFormula or sheet.Cells(n,c).HasFormula)
            for c in range(1,36):
                dest=sheet.Cells(n,c)
                if c in derived:
                    if not dest.HasFormula:
                        ref=sheet.Cells(template,c)
                        if sh.clean(dest.Value2) or not ref.HasFormula:
                            raise ValueError(f'Dòng {n}, cột {c} không có công thức mẫu an toàn.')
                        put(dest,ref.FormulaR1C1,True,ref.NumberFormat)
                elif dest.HasFormula or sh.clean(dest.Value2):
                    raise ValueError(f'Dòng đích {n}, cột {c} đã có dữ liệu. Kiểm tra vùng cuối ORDER.')
            for col,value in fields.items():
                if value is not None and col not in derived:
                    put(sheet.Cells(n,col),value,fmt='@' if isinstance(value,str) else sheet.Cells(template,col).NumberFormat)
        sheet.Calculate()
        updated=sh.values(sheet)
        validate(updated,first)
        book.Save()
    except Exception:
        if shared:
            for cell,value,formula,fmt in reversed(changes):
                cell.NumberFormat=fmt
                if formula:
                    cell.FormulaR1C1=value
                else:
                    cell.Value2=value
            for created in reversed(added):
                created.Delete()
            sheet.Calculate()
        raise


def append_mail_block(book,sheet,current,records,validate,progress):
    """Check destination in bulk, retain prefilled formulas and write column ranges."""
    sh.check_tracking_space(sheet)
    first=next((n+1 for n,r in reversed(list(enumerate(current[1:],2)))
                if sh.clean(r[3]) and sh.clean(r[4]) and any(sh.clean(r[i]) for i in (5,9,26))),2)
    last=first+len(records)-1
    if first<3:raise ValueError('Thiếu dòng mẫu ORDER.')
    def area(a,b,c,d):
        return sheet.Range(sheet.Cells(a,b),sheet.Cells(c,d))
    target=area(first,1,last,35)
    before=target.FormulaR1C1
    template=area(first-1,1,first-1,35).FormulaR1C1[0]
    derived={13,23,24,25,26}
    derived.update(c for c in (1,2,3) if str(template[c-1]).startswith('='))
    def address(c,n):
        return (chr(64+c) if c<=26 else 'A'+chr(64+c-26))+str(n)
    for offset,row in enumerate(before):
        for c,v in enumerate(row,1):
            if c not in derived and v not in ('',None):
                raise ValueError(f'ORDER!{address(c,first+offset)} đang có dữ liệu ({str(v)[:60]}). Kiểm tra vùng ghi trước khi thêm OD.')
    for offset,row in enumerate(before):
        for c,v in enumerate(row,1):
            if c in derived:
                if not str(v).startswith('=') and (v not in ('',None) or not str(template[c-1]).startswith('=')):
                    dest=address(c,first+offset)
                    if v not in ('',None):raise ValueError(f'ORDER!{dest} có giá trị cố định. Kiểm tra trước khi ghi.')
                    raise ValueError(f'ORDER!{dest} trống và ô mẫu {address(c,first-1)} thiếu công thức.')
            elif v not in ('',None):raise ValueError(f'Dòng đích {first+offset}, cột {c} đang có dữ liệu.')
    original={};owner=None;old_address=None
    for j in range(1,sheet.ListObjects.Count+1):
        obj=sheet.ListObjects.Item(j)
        if obj.HeaderRowRange.Row==1 and obj.Range.Column<=4<obj.Range.Column+obj.Range.Columns.Count:
            owner=obj;break
    header=sheet.Cells(1,35);old_header=header.Value2
    if old_header not in (None,'',sh.TRACK):raise ValueError('Cột AI đang có dữ liệu.')
    saved=False
    try:
        if owner is not None and last>owner.Range.Row+owner.Range.Rows.Count-1:
            if owner.ShowTotals:raise ValueError('Tắt dòng tổng của bảng ORDER trước khi thêm.')
            old_address=owner.Range.Address
            owner.Resize(area(1,owner.Range.Column,last,owner.Range.Column+owner.Range.Columns.Count-1))
        header.Value2=sh.TRACK
        for col in (3,24):
            source=sheet.Cells(first-1,col)
            destination=area(first,col,last,col)
            source.Copy()
            destination.PasteSpecial(Paste=-4122)
            book.Application.CutCopyMode=False
        for c in derived:
            for i,row in enumerate(before):
                if row[c-1] not in ('',None):continue
                if i and before[i-1][c-1] in ('',None):continue
                end=i+1
                while end<len(before) and before[end][c-1] in ('',None):end+=1
                area(first+i,c,first+end-1,c).FormulaR1C1=template[c-1]
        for start in range(0,len(records),100):
            block=records[start:start+100]
            for c in sorted(set().union(*(r.keys() for r in block))):
                dest=area(first+start,c,first+start+len(block)-1,c)
                vals=tuple((r.get(c),) for r in block)
                fmt=dest.NumberFormat
                if fmt is not None:
                    original[(start,c,len(block))]=fmt
                    dest.NumberFormat='@' if isinstance(vals[0][0],str) else sheet.Cells(first-1,c).NumberFormat
                dest.Value2=vals
            n=start+len(block)
            progress(f'Đã điền {n}/{len(records)} dòng · {n*100//len(records)}% bước ghi')
        progress('Đang tính công thức và đối chiếu dòng vừa điền…')
        sheet.Calculate()
        updated=sh.values(sheet)
        validate(updated,first)
        progress('Đang lưu Excel…')
        book.Save()
        saved=True
        return updated
    finally:
        if not saved:
            if old_address:owner.Resize(sheet.Range(old_address))
            target.FormulaR1C1=before
            for (start,c,count),fmt in original.items():area(first+start,c,first+start+count-1,c).NumberFormat=fmt
            header.Value2=old_header
