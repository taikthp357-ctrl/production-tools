"""Internal station handover slips using the approved bilingual Excel form."""
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from datetime import datetime
import os
from pathlib import Path
import re
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import zone_shift as sh
from zone_order_result import writable_order


SHARED_FORMS = Path(r'\\10.128.10.72\fvn$\03.Khối sản xuất\01.Nhà máy VinFast Hải Phòng\04.Xưởng lắp ráp kim loại - cơ khí NMHP\01. Lắp ráp kim loại\5.LOGISTIC\III. Internal\III. Kho P part\3. Theo doi hang nhap P\240101_FT-P')


def resolve_template(configured):
    if configured and Path(configured).is_file():
        return Path(configured)
    candidates = sorted((p for p in SHARED_FORMS.iterdir()
                         if re.fullmatch(r'(?:\d{6}_BBGN|BBBG_MAU|FVN_SX_KHO03\.08.*)\.xls[bmx]',p.name,re.I)),
                        key=lambda p:p.name)
    current = SHARED_FORMS / '261122_BBGN.xlsb'
    if current in candidates:
        return current
    if len(candidates)==1:
        return candidates[0]
    raise ValueError('Chọn mẫu trong mục Đổi mẫu. '+('Có nhiều mẫu phù hợp.' if candidates else 'Thư mục chung chưa có mẫu BBBG.'))


def qty_text(value):
    number = format(value,'f')
    return number.rstrip('0').rstrip('.') if '.' in number else number


def quantity(value):
    try:
        result=Decimal(str(value))
        if not result.is_finite() or result<=0:raise ValueError
    except (InvalidOperation,ValueError):
        raise ValueError('SL bàn giao phải lớn hơn 0.')
    return result


def pasted(text):
    items=[]
    for line in text.splitlines():
        cells=line.strip(' |\t').split()
        if not cells:continue
        cells=[v for v in cells if v!='|']
        if len(cells)<2 or not re.fullmatch(r'[A-Z]+[0-9][A-Z0-9]+',cells[0].upper()):
            raise ValueError('Dán mỗi dòng một mã NVL và số lượng ở cuối dòng.')
        items.append((cells[0].upper(),quantity(cells[-1])))
    return items


def render(template,rows,destination,number,day):
    with sh.excel_book(template,None) as book:
        sheet=next((s for s in book.Worksheets if 'partno' in sh.norm(s.Cells(12,2).Value2)),None)
        if sheet is None or 'batch' not in sh.norm(sheet.Cells(12,3).Value2) or 'ghichu' not in sh.norm(sheet.Cells(11,11).Value2):
            raise ValueError(f'{Path(template).name}: kiểm tra tiêu đề Mã hàng (B12), Batch (C12), Ghi chú (K11) trên sheet biểu mẫu.')
        sheet.PageSetup.RightHeader=number
        sheet.PageSetup.Zoom=False
        sheet.PageSetup.FitToPagesWide=1
        sheet.PageSetup.FitToPagesTall=1
        sheet.Cells(4,1).Value2='Ngày (Date): '+datetime.now().strftime('%d/%m/%Y %H:%M')
        sheet.Range('A13:K30').ClearContents()
        for addr in ('C34','C35'):
            sheet.Range(addr).MergeArea.ClearContents()
        for i,(row,qty) in enumerate(rows,13):
            sheet.Cells(i,7).NumberFormat='General'
            for col,value in ((1,i-12),(2,sh.clean(row[3])),(3,sh.clean(row[0])),(4,'/'),(5,'/'),
                              (6,'EA'),(7,float(qty)),(11,sh.clean(row[5]))):
                sheet.Cells(i,col).Value2=value
        sheet.ExportAsFixedFormat(0,str(destination.resolve()))


def issue(page,template,chosen,day,demo):
    from contextlib import nullcontext
    folder=page.path.parent/('BBBG_MO_PHONG' if demo else 'BBBG')/day
    folder.mkdir(parents=True,exist_ok=True)
    lock=folder/'.dang_lap'
    try:lock.mkdir()
    except FileExistsError:raise ValueError('Thư mục BBBG đang có lượt lập phiếu. Kiểm tra lượt đang chạy.')
    try:
        ctx=nullcontext((None,None,False)) if demo else writable_order(page.path,page.password)
        with ctx as (book,sheet,shared):
            current=page.table if demo else sh.values(sheet)
            indexed={key:(n,r) for n,r,key in sh.indexed(current)}
            groups=defaultdict(list)
            used={int(m[1]) for p in folder.glob('BBBG-*.pdf') if (m:=re.fullmatch(r'BBBG-(\d+)',p.stem))}
            for n,row in sh.rows(current):
                if str(sh.day(row[26]))==day:
                    used.update(int(m[1]) for col in (14,17,20) if (m:=re.fullmatch(r'BBBG-(\d+)',sh.clean(row[col]))))
            for key,qty in chosen.items():
                if key not in indexed:raise ValueError('Dòng ORDER đã thay đổi. Tải lại trước khi lập.')
                n,row=indexed[key]
                if row!=page._row_lookup[key] or str(sh.day(row[26]))!=day or sh.norm(row[27]) not in ('hettonkhoma','chilapbbbg'):
                    raise ValueError(f'Dòng {n} đã đổi hoặc chưa thuộc nhóm Hết tồn kho MA.')
                slot=next((j for j in (13,16,19) if not sh.clean(row[j]) and not sh.clean(row[j+1]) and row[j+2] in (None,'',0,'0')),None)
                if slot is None or not sh.clean(row[5]):raise ValueError(f'Dòng {n} thiếu trạm hoặc đã hết ô số phiếu.')
                if qty>quantity(row[4])-Decimal(str(row[22] or 0)):raise ValueError(f'Dòng {n}: SL vượt nhu cầu còn lại.')
                groups[sh.clean(row[5])].append((n,row,qty,slot))
            files=[];edits=[]
            try:
                for station,lines in groups.items():
                    for start in range(0,len(lines),18):
                        batch=lines[start:start+18]
                        seq=max(used,default=0)+1
                        used.add(seq)
                        number=f'BBBG-{seq:02d}'
                        path=folder/(number+'.pdf')
                        if path.exists():raise ValueError('Số BBBG vừa được sử dụng.')
                        files.append(path)
                        render(template,[(r,q) for _,r,q,_ in batch],path,number,day)
                        if not path.is_file() or path.stat().st_size<1:raise ValueError('Xuất PDF chưa hoàn tất.')
                        if demo:continue
                        for n,row,qty,slot in batch:
                            for col,value in ((slot+2,number),(28,'Đã ra đơn, chờ cấp')):
                                cell=sheet.Cells(n,col)
                                if cell.HasFormula:raise ValueError(f'Dòng {n} có công thức tại cột cần ghi.')
                                edits.append((cell,cell.Value2,value))
                for cell,old,value in edits:cell.Value2=value
                if edits:
                    sheet.Calculate()
                    if any(cell.Value2!=value for cell,_,value in edits):raise ValueError('Đọc lại số phiếu khác giá trị cần lưu.')
                    book.Save()
            except Exception:
                if shared:
                    for cell,old,_ in reversed(edits):cell.Value2=old
                for p in files:p.unlink(missing_ok=True)
                raise
            return files
    finally:lock.rmdir()


def open_form(page):
    if not page.path or page.app.is_running:return
    source=page.table
    day=page.kh.get()
    if day=="Cả file ca":
        messagebox.showinfo("Lập BBBG","Chọn một ngày KHSX để lập BBBG.",parent=page.app.root);return
    choices={k:r for k,r in page._row_lookup.items() if str(sh.day(r[26]))==day and sh.norm(r[27]) in ('hettonkhoma','chilapbbbg')}
    chosen={}
    win=tk.Toplevel(page.app.root)
    win.title('Lập BBBG theo trạm · '+day)
    bar=ttk.Frame(win);bar.pack(fill='x')
    default=SHARED_FORMS/'261122_BBGN.xlsb'
    template=tk.StringVar(value=page.app.config.get('bbbg_shared_template') or str(default))
    def browse():
        name=filedialog.askopenfilename(parent=win,filetypes=[('Mẫu Excel','*.xlsb *.xlsx *.xlsm')])
        if name:
            import sap_zone_core as core
            template.set(name);page.app.config['bbbg_shared_template']=name;core.ConfigManager.save_config(page.app.config)
    ttk.Button(bar,text='Đổi mẫu…',command=browse).pack(side='left')
    caption=tk.StringVar()
    def show_file(*_):
        caption.set('Mẫu: '+Path(template.get()).name+'    ·    ORDER: '+page.path.name)
    template.trace_add('write',show_file);show_file()
    ttk.Label(win,textvariable=caption,width=1).pack(fill='x')
    footer=ttk.Frame(win);footer.pack(side='bottom',fill='x')
    win.minsize(560,360)
    ttk.Label(win,text='Dán mã và SL ở cuối mỗi dòng. Bấm đúp dòng bên dưới để sửa SL.').pack(anchor='w')
    entry=tk.Text(win,height=4);entry.pack(fill='x')
    from zone_shift_ui import grid
    tree=grid(win,[('Mã NVL',135),('Trạm',180),('NCC',160),('SL bàn giao',105)])
    def refresh():
        tree.clear_rows()
        for k,q in chosen.items():
            r=choices[k];tree.append_row((r[3],r[5],r[0],qty_text(q)),key=k)
    selection=page.tree.selection()
    if selection:
        use_selection=messagebox.askyesnocancel('Nguồn lập BBBG',f'Lấy {len(selection)} dòng OD đang chọn?\nCó: dùng OD đang chọn. Không: dán mã và SL.',parent=win)
        if use_selection is None:
            win.destroy()
            return
        if not use_selection:selection=[]
    for n in selection:
        k=page.lines[n]['origin']
        if k in choices:
            r=choices[k];gap=Decimal(str(r[4]))-Decimal(str(r[22] or 0))
            if gap>0:chosen[k]=gap
    refresh()
    if selection and len(chosen)<len(selection):
        ttk.Label(win,text=f'{len(chosen)}/{len(selection)} dòng đủ điều kiện · chỉ lấy dòng hết tồn còn thiếu.').pack()
    def add():
        try:
            staged=dict(chosen)
            for code,q in pasted(entry.get('1.0','end')):
                keys=[k for k,r in choices.items() if sh.clean(r[3]).upper()==code]
                if not keys:raise ValueError(code+' chưa có dòng Hết tồn kho MA ở KHSX '+day)
                index=1
                if len(keys)>1:
                    prompt='\n'.join(f'{i}. {choices[k][9]} · {choices[k][5]} · SL OD {choices[k][4]}' for i,k in enumerate(keys,1))
                    index=simpledialog.askinteger(code,'Chọn dòng nhận SL '+str(q)+'\n'+prompt,minvalue=1,maxvalue=len(keys),parent=win)
                    if index is None:return
                staged[keys[index-1]]=q
            chosen.update(staged);refresh()
        except ValueError as exc:messagebox.showwarning('BBBG',str(exc),parent=win)
    def change(event):
        k=tree.identify_row(event.y)
        if not k:return
        v=simpledialog.askstring('BBBG','SL bàn giao',initialvalue=qty_text(chosen[k]),parent=win)
        if v is not None:
            try:chosen[k]=quantity(v);refresh()
            except ValueError as exc:messagebox.showwarning('BBBG',str(exc),parent=win)
    tree.bind('<Double-1>',change)
    ttk.Button(bar,text='Thêm mã dán',command=add).pack(side='left')
    def remove():
        for k in tree.selection():chosen.pop(k,None)
        refresh()
    ttk.Button(bar,text='Bỏ dòng chọn',command=remove).pack(side='left')
    def reopen():
        folder=page.path.parent/('BBBG_MO_PHONG' if page.app.mock_mode_var.get() else 'BBBG')/day
        if folder.is_dir():os.startfile(str(folder))
        else:messagebox.showinfo('BBBG','KHSX này chưa có thư mục phiếu.',parent=win)
    ttk.Button(bar,text='Phiếu đã lập',command=reopen).pack(side='left')
    def submit():
        if page.table is not source or not chosen or page.app.is_running:return
        demo=bool(page.app.mock_mode_var.get())
        mode='Xuất PDF mô phỏng' if demo else 'Xuất PDF và lưu số phiếu vào '+page.path.name
        if not messagebox.askyesno('Lập BBBG',mode+f' cho {len(chosen)} dòng?',parent=win):return
        configured=template.get()
        win.destroy()
        def ready(files):
            page.reload()
            os.startfile(str(files[0]))
            messagebox.showinfo('BBBG','Mở PDF để in. Các phiếu đã lưu ở\n'+str(files[0].parent)+'\n'+', '.join(p.name for p in files),parent=page.app.root)
        page.task('Đang lập BBBG…',lambda:issue(page,resolve_template(configured),chosen,day,demo),ready)
    ttk.Button(footer,text='Lập BBBG theo trạm…',command=submit).pack(anchor='e')
