from copy import deepcopy
from datetime import datetime, timedelta
from pathlib import Path
import threading
import tkinter as tk
from tkinter import ttk, filedialog, simpledialog, messagebox
import zone_mail as mail
import zone_arrival
import zone18 as z
import sap_zone_core as core


class MailPage:
    def __init__(self,app,parent,kind):
        self.app,self.kind=app,kind
        self.messages=[]
        self.display={}
        self.audit_pending=False
        self.audit_revision=None
        self.needs_paint=False
        self.password=None
        self.alert_signature=None
        self.history_cache={}
        self.session_observed={}
        self.timings={}
        self.scan_gaps={'rows':[],'range':None}
        self.prior_selected={}
        self.busy=False
        self.settings_key='mail_'+kind
        self.cfg=dict(app.config.get(self.settings_key,{}))
        self.timer=None
        panel=ttk.Frame(parent,padding=8)
        panel.pack(fill='both',expand=True)
        bar=ttk.Frame(panel)
        bar.pack(fill='x')
        for label,command in [('Quét Outlook',self.scan),('Nhập file .msg…',self.load_msg),
                             ('Đối chiếu ORDER' if kind=='out' else 'Kiểm IB và BOM 3093',self.verify),
                             ('Cài đặt',self.settings)]:
            if label=='Cài đặt' and kind=='out':continue
            ttk.Button(bar,text=label,command=command).pack(side='left',padx=(0,4))
        self.plan_filter=tk.StringVar(value='Tất cả')
        if kind=='out':
            extra=ttk.Menubutton(bar,text='Công cụ ▾')
            tools=tk.Menu(extra,tearoff=False)
            tools.add_command(label='Kiểm lượt quét',command=self.review_scan)
            tools.add_command(label='Mở ORDER ca trước…',command=self.unlock_prior)
            tools.add_command(label='Xử lý mail điều chỉnh…',command=self.revise)
            extra.configure(menu=tools);extra.pack(side='right')
            ttk.Button(bar,text='Ghi dòng thiếu vào ORDER…',command=self.import_selected).pack(side='left',padx=3)
            ttk.Label(bar,text='KHSX').pack(side='left',padx=(8,3))
            self.plan_box=ttk.Combobox(bar,textvariable=self.plan_filter,width=12,state='readonly',values=('Tất cả',))
            self.plan_box.pack(side='left')
            self.plan_box.bind('<<ComboboxSelected>>',lambda e:self.paint(notify=False))

        if kind=='out':
            dates=ttk.Frame(panel);dates.pack(fill='x')
            self.from_day=tk.StringVar(value=(datetime.now()-timedelta(days=int(self.cfg.get('lookback',3))-1)).strftime('%d/%m/%Y'))
            self.to_day=tk.StringVar(value=datetime.now().strftime('%d/%m/%Y'))
            for label,var in [('Nhận từ',self.from_day),('đến',self.to_day)]:
                ttk.Label(dates,text=label).pack(side='left')
                ttk.Entry(dates,textvariable=var,width=12).pack(side='left',padx=3)
            ttk.Button(dates,text='Xác nhận ODBS…',command=self.confirm_odbs).pack(side='left',padx=(0,4))
            ttk.Button(dates,text='Xác nhận đã copy…',command=self.confirm_copied).pack(side='left')
            ttk.Button(dates,text='Xác nhận OD mới và ghi…',command=lambda:self.import_selected(True)).pack(side='left')
            self.folder_label=ttk.Label(dates,text=self.cfg.get('folder_name') or 'Inbox và NVL');self.folder_label.pack(side='left',padx=6)
        self.status=tk.StringVar(value='Kho P · bỏ qua H' if kind=='out' else 'Kế hoạch hàng về · kiểm tra tại Plant 3093')
        ttk.Label(panel,textvariable=self.status,wraplength=960).pack(fill='x',pady=5)
        from zone_result_grid import KeyGrid, make_filter_bar
        status_opts=('Tất cả','Cần đối chiếu / xem','Chưa copy','Đã copy đủ','ODBS','Đã đóng (OD_DA_DONG)','Có vấn đề') if kind=='out' else ('Tất cả','Cần kiểm tra','Khớp kế hoạch','Thiếu BOM / linh kiện','Đã hoàn tất GR')
        self.filter_bar=make_filter_bar(panel,status_opts,on_change=lambda:self.paint(notify=False),search_label='Tìm nhanh')
        self.filter_bar['frame'].pack(fill='x',pady=(0,4))
        body=ttk.Frame(panel)
        body.pack(fill='both',expand=True)
        columns=(('material','Mã hàng',145),('qty','SL mail',75))
        if kind=='in':
            columns+=(('po','PO/SA',95),('po_item','Item PO',65),('ib','IB',95),('sap_qty','SL IB',80))
        else:
            columns+=(('station','Trạm / TL',175),('plan','KHSX',95))
        columns+=(('status','Kết quả',320),)
        if kind=='out':
            columns=[columns[i] for i in (4,3,0,1,2)]
        self.cols=columns
        self.tree=KeyGrid(body,[('Mail / giờ nhận',255)]+[(label,w) for key,label,w in columns])
        self.tree.bind('<Control-f>',lambda _:self.filter_bar['entry'].focus_set() or 'break')
        self.tree.on_copy=lambda msg:self.status.set(msg)
        ttk.Button(self.filter_bar['frame'],text='Thu gọn',command=lambda:self.expand_all(False)).pack(side='right',padx=(2,0))
        ttk.Button(self.filter_bar['frame'],text='Bung hết',command=lambda:self.expand_all(True)).pack(side='right',padx=(2,0))
        ttk.Button(self.filter_bar['frame'],text='Copy bảng',command=lambda:self.tree.copy_rows()).pack(side='right',padx=(0,4))
        def mail_menu(menu_widget,_row,_col):
            if self.kind=='out':
                menu_widget.add_command(label='Xác nhận ODBS…',command=self.confirm_odbs)
                menu_widget.add_command(label='Xác nhận đã copy…',command=self.confirm_copied)
                menu_widget.add_command(label='Ghi dòng thiếu vào ORDER…',command=self.import_selected)
                menu_widget.add_command(label='Xác nhận OD mới và ghi…',command=lambda:self.import_selected(True))
                menu_widget.add_separator()
            menu_widget.add_command(label='Bung tất cả thư',command=lambda:self.expand_all(True))
            menu_widget.add_command(label='Thu gọn tất cả thư',command=lambda:self.expand_all(False))
        self.tree.extra_menu=mail_menu
        self.mail_sort=(None,False)
        def sort_mail(event):
            col=self.tree.column_at(self.tree.header.canvasx(event.x))
            if col is not None:
                self.mail_sort=(col,self.mail_sort==(col,False))
                self.show_groups()
        self.tree.header.bind('<Button-1>',sort_mail)
        self.tree.tag_configure('warn',foreground='#973a16')
        self.tree.tag_configure('done',foreground='#176347')
        self.expanded=set()
        self.groups={}
        self.tree.bind('<Button-1>',self.click_mail,add='+')
        self.tree.bind('<Double-1>',self.detail)
        self.tree.bind('<Alt-Right>',lambda _:self.toggle_selected(True))
        self.tree.bind('<Alt-Left>',lambda _:self.toggle_selected(False))
        self.tree.bind('<Return>',lambda _:self.toggle_selected())
        self.tree.bind('<Map>',lambda _:self.paint(False) if self.needs_paint else None,add='+')
        if kind=='out':
            self.left_app=False
            self.return_job=None
            def focus_left(event):
                def check():
                    try:self.left_app=self.app.root.focus_displayof() is None
                    except KeyError:self.left_app=False
                self.app.root.after_idle(check)
            def focus_back(event):
                if self.left_app:
                    self.left_app=False
                    if self.return_job:self.app.root.after_cancel(self.return_job)
                    self.return_job=self.app.root.after(350,self.check_returned_order)
            self.app.root.bind('<FocusOut>',focus_left,add='+')
            self.app.root.bind('<FocusIn>',focus_back,add='+')
        self.schedule(start=True)

    def settings(self,parent=None):
        if parent is None:
            if self.busy:return
            win=tk.Toplevel(self.app.root)
            win.title('Cài đặt quét mail')
            win.transient(self.app.root)
            win.grab_set()
        else:
            win=parent
        frame=ttk.Frame(win,padding=12)
        frame.pack(fill='both',expand=True)
        values={}
        folder_ids=self.cfg.get('folder_ids')
        def entry(key,label,default):
            ttk.Label(frame,text=label).pack(anchor='w',pady=(5,0))
            var=values[key]=tk.StringVar(value=self.cfg.get(key,default))
            ttk.Entry(frame,textvariable=var,width=60).pack(fill='x')
            return var
        folder=tk.StringVar(value=self.cfg.get('folder_name','Inbox và NVL cùng hộp thư' if self.kind=='out' else 'Inbox mặc định'))
        def choose():
            nonlocal folder_ids
            try:
                import win32com.client
                f=win32com.client.Dispatch('Outlook.Application').Session.PickFolder()
                if f:
                    folder_ids=[str(f.EntryID),str(f.StoreID)]
                    folder.set(str(f.FolderPath))
            except Exception as exc:
                messagebox.showerror('Outlook',str(exc),parent=win)
        ttk.Button(frame,text='Chọn thư mục Outlook',command=choose).pack(anchor='w')
        ttk.Label(frame,textvariable=folder).pack(anchor='w')
        interval=entry('hours','Tự quét khi app mở · 0 tắt, 1 hoặc 2 giờ',0)
        if self.kind=='out':
            def password():
                from zone_excel_live import shared_password
                value=simpledialog.askstring('Mật khẩu ORDER','Mật khẩu chung các file ca (lưu cho tài khoản Windows này)',show='*',parent=win)
                if value:
                    shared_password(value)
                    self.password=value
                    self.app.shift_page.password=value
                    self.app.shift_page.passwords.clear()
            ttk.Button(frame,text='Đặt mật khẩu chung cho các file ca…',command=password).pack(anchor='w')
            entry('lookback','Quét lại Outlook trong số ngày gần nhất',3)
            entry('day_start','Giờ bắt đầu S6','06:00')
            entry('night_start','Giờ bắt đầu S7','18:00')
            ttk.Label(frame,textvariable=self.app.shift_page.title,wraplength=620).pack(anchor='w')
        else:
            entry('low','Cảnh báo nếu tồn còn lại ≤ % nhu cầu đã kiểm',10)
            entry('days','Số ngày kiểm trước hiệu lực BOM 3093 · 0 tắt',7)
            entry('unit','ĐVT mặc định cho thư mục NCC riêng (để trống nếu dùng chung)','')
            entry('pool','Phạm vi cột tồn SAP · NCC hoặc SLOC','NCC')
        dedicated=tk.BooleanVar(value=self.cfg.get('dedicated',False))
        if self.kind=='in':
            ttk.Checkbutton(frame,text='Phiên SAP đã cấu hình dành riêng cho app khi tự quét',variable=dedicated).pack(anchor='w',pady=4)
        def build_cfg():
            if self.busy:
                raise ValueError('Chờ thao tác mail hoàn tất để lưu cấu hình.')
            cfg={**self.cfg,**{k:v.get().strip() for k,v in values.items()},'folder_ids':folder_ids,'folder_name':folder.get(),'dedicated':dedicated.get()}
            if self.kind=='out':
                mail.receiving_shift(datetime.now(),cfg)
                if not 1<=int(cfg['lookback'])<=90:raise ValueError('Chọn phạm vi từ 1 đến 90 ngày.')
                if cfg.get('folder_ids')!=self.cfg.get('folder_ids'):
                    cfg.pop('last_scan',None)
                    cfg.pop('retry_since',None)
            if int(interval.get()) not in (0,1,2):
                raise ValueError('Chu kỳ phải là 0, 1 hoặc 2.')
            if self.kind=='in' and (not 0<=int(cfg['low'])<=100 or not 0<=int(cfg['days'])<=365):
                raise ValueError('Ngưỡng tồn 0–100%, số ngày 0–365.')
            if self.kind=='in' and cfg.get('pool','NCC').upper() not in ('NCC','SLOC'):
                raise ValueError('Chọn phạm vi tồn NCC hoặc SLOC.')
            if cfg.get('unit') and not folder_ids:
                raise ValueError('Chọn thư mục riêng của NCC trước khi đặt ĐVT mặc định.')
            if cfg.get('unit') and not messagebox.askyesno('ĐVT','Dùng cùng ĐVT mặc định cho mọi NCC trong thư mục khi mail thiếu ĐVT?',parent=win):
                return None
            return cfg
        def apply_cfg(cfg):
            changed=cfg.get('folder_ids')!=self.cfg.get('folder_ids')
            if self.kind=='out' and cfg.get('workbook')!=self.cfg.get('workbook'):
                self.password=None
            self.cfg=cfg
            if self.kind=='out':self.folder_label.configure(text=cfg.get('folder_name',''))
            if changed:
                self.messages=[]
                self.paint()
            self.schedule(start=True)
        def save():
            try:
                cfg=build_cfg()
                if cfg is None:return
                full={**self.app.config,self.settings_key:cfg}
                if not core.ConfigManager.save_config(full):
                    raise OSError('Không lưu được cấu hình')
                self.app.config=full
                apply_cfg(cfg)
                if parent is None:win.destroy()
                else:messagebox.showinfo('Mail OD','Đã lưu cấu hình Mail OD.',parent=win)
            except Exception as exc:
                messagebox.showerror('Cài đặt',str(exc),parent=win)
        save.build_cfg=build_cfg
        save.apply_cfg=apply_cfg
        if parent is None:ttk.Button(frame,text='Lưu cấu hình mail',command=save).pack(anchor='e',pady=8)
        return save

    def check_returned_order(self):
        self.return_job=None
        page=self.app.shift_page
        if not self.messages or not self.tree.winfo_ismapped() or not page.path:return
        if self.app.is_running or self.busy:
            self.return_job=self.app.root.after(750,self.check_returned_order)
            return
        if page.qty_editor and page.qty_editor.dirty():return
        self.verify()

    def schedule(self,start=False):
        if self.timer:
            self.app.root.after_cancel(self.timer)
            self.timer=None
        hours=int(self.cfg.get('hours',0))
        if hours:
            self.timer=self.app.root.after(12000 if start else hours*3600000,self.auto)

    def auto(self):
        self.timer=None
        if self.busy or (self.kind=='in' and self.app.is_running):
            self.timer=self.app.root.after(60000,self.auto)
            return
        self.scan(auto=True)
        self.schedule()

    def run(self,task,title,after=None,background=False,valid=lambda:True):
        if self.busy or (self.app.is_running and not background):
            self.status.set('Đang xử lý tác vụ khác.')
            return
        self.busy=True
        if not background:
            self.app.mail_out_working=self.kind=='out'
            self.app.is_running=True
        self.status.set(title+'…')
        def end(records,error):
            self.busy=False
            if not background:
                self.app.is_running=False
                self.app.mail_out_working=False
            if self.audit_pending:self.app.root.after_idle(self.refresh_cached_mail)
            if not valid():
                self.status.set("Ca đã đổi · quét Outlook cho ca hiện tại.")
                return
            if error:
                self.status.set(title+' · '+error)
                if not background:messagebox.showwarning(title,error,parent=self.app.root)
            else:
                self.messages=records
                if after:after()
                if self.audit_pending and self.kind=="out":
                    self.status.set("ORDER đã đổi · đang đối chiếu lại thư đã đọc.")
                else:self.paint(notify=not background)
        def worker():
            try:
                core.SapConnector.init_thread_com()
                try:
                    records=task()
                finally:
                    core.SapConnector.uninit_thread_com()
                self.app.post_ui(lambda:end(records,None))
            except Exception as exc:
                self.app.post_ui(lambda msg=str(exc):end(None,msg))
        threading.Thread(target=worker,daemon=True).start()

    def load_msg(self):
        paths=filedialog.askopenfilenames(parent=self.app.root,filetypes=[('Mail Outlook','*.msg')])
        if paths:
            self.scan_gaps={'rows':[],'range':None}
            self.scan(paths=paths)

    def unlock_prior(self):
        if self.busy or self.app.is_running:
            return
        path=self.cfg.get('workbook')
        if not path:
            self.app.shift_page.choose()
            return
        from zone_shift import parsed_name
        picked=filedialog.askopenfilename(parent=self.app.root,initialdir=Path(path).parent,
                    title='Đọc ORDER ca trước để đối chiếu mail',filetypes=[('ORDER Excel','*.xlsb *.xlsm *.xlsx')])
        if not picked:
            return
        previous=Path(picked)
        current=Path(path)
        old,now=parsed_name(previous),parsed_name(current)
        if not old or not now or old==now or old[0]>now[0] or (old[0]==now[0] and old[1]=='S7' and now[1]=='S6'):
            messagebox.showinfo('Ca trước','Chọn đúng file bàn giao có ngày/ca trước file đang dùng.',parent=self.app.root)
            return
        from zone_order_result import file_key
        key=file_key(previous)
        def loaded(result):
            if 'chưa lưu' in self.app.shift_page.sources.get(key,''):
                self.status.set('Hãy lưu ORDER ca trước rồi đọc lại để xác minh Done.')
                return
            self.history_cache[key]=(result[1],mail.order_index(result[0]))
            self.prior_selected.setdefault(file_key(current),{})[old]=previous
            if self.messages:
                self.verify()
            else:
                self.status.set('Đã đọc '+previous.name+' · Quét Outlook để đối chiếu.')
        self.app.shift_page.read_order(previous,loaded)

    def scan(self,paths=(),auto=False):
        if self.busy or (auto and self.kind=='in' and self.app.is_running):
            return
        cfg=dict(self.cfg)
        existing=tuple(self.messages)
        gaps=deepcopy(self.scan_gaps)
        page=self.app.shift_page
        revision=page.revision
        target=cfg.get('workbook')
        generation=getattr(self,'scan_generation',0)
        def valid():return self.kind!='out' or (self.cfg.get('workbook')==target and generation==getattr(self,'scan_generation',0))
        context={}
        if self.kind=='out' and target:
            from zone_order_result import file_key
            context=dict(password=self.password,passwords=dict(page.passwords),selected=tuple(self.prior_selected.get(file_key(target),{}).values()),cache=self.history_cache)
        main=deepcopy(self.app.config)
        started=datetime.now()
        since=started-timedelta(days=int(cfg.get('lookback',3)))
        until=started
        if self.kind=='out' and not paths and not auto:
            try:
                since=datetime.strptime(self.from_day.get(),'%d/%m/%Y')
                until=min(started,datetime.strptime(self.to_day.get(),'%d/%m/%Y')+timedelta(days=1)-timedelta(microseconds=1))
                if until<since:raise ValueError
            except ValueError:
                self.status.set('Kiểm tra khoảng ngày nhận (dd/mm/yyyy).');return
        def work():
            import time as _time
            if self.kind=='out' and not paths:
                gaps.clear()
                gaps.update(rows=[],range=(since,until),until=until)
            t0=_time.perf_counter()
            incoming=mail.outlook_scan(self.kind,since,paths,cfg.get('folder_ids'),gaps if self.kind=='out' and not paths else None)
            self.timings['outlook_s']=_time.perf_counter()-t0
            merged={r['id']:deepcopy(r) for r in existing if paths or self.kind!='out' and datetime.fromisoformat(r['received'])>=since}
            for r in incoming:
                merged[r['id']]=r
            records=sorted(merged.values(),key=lambda r:r['received'],reverse=True)
            summaries=[(r['id'],r['received'],r['subject']) for r in records]
            def headers():
                if valid() and self.tree.winfo_ismapped():
                    if not self.tree.keys and self.plan_filter.get()=='Tất cả':
                        blank=['']*len(self.cols)
                        self.tree.sync_rows([((mid,),[self.mail_title(received,subject),*blank],None)
                                             for mid,received,subject in summaries])
                    self.status.set(f'Đã đọc {len(summaries)} mail · đang đối chiếu')
            self.app.post_ui(headers)
            if (records and auto) or self.kind=='out' and (records or cfg.get('workbook')):
                try:
                    t1=_time.perf_counter()
                    self.audit(records,main,cfg,auto=auto,gaps=gaps,context=context)
                    self.timings['audit_s']=_time.perf_counter()-t1
                except Exception as exc:
                    if not records:raise
                    for m in records:
                        m['issues']=[v for v in m['issues'] if not v.startswith('Chưa hoàn tất đối chiếu · ')]
                        m['issues'].append('Chưa hoàn tất đối chiếu · '+('Mở ORDER trong Excel hoặc bấm Đối chiếu ORDER.' if 'ORDER_PASSWORD' in str(exc) else str(exc)))
                        for r in m['rows']:
                            r.update(match_state='waiting',status='Chờ đối chiếu lại')
            return records
        def scanned():
            self.scan_gaps=gaps
            if self.kind=='out':
                if 'odbs_links' in context and revision==page.revision and page.path:
                    page.set_odbs(context['odbs_links'])
                self.audit_path=target if context.get('table') is not None else None
                if revision!=page.revision:self.schedule_audit()
                self.audit_revision=revision if context.get("table") is not None else None
                audited=context.get('table')
                self.audit_table=page.table if page.table is not None and page.table==audited else audited
            if self.kind=='out' and not paths:
                pending=[m['received'] for m in self.messages if any(r.get('match_state') in
                         ('missing','waiting','unverified','review') for r in m['rows'])]
                self.cfg['retry_since']=min(pending) if pending else ''
                self.cfg['last_scan']=started.isoformat(timespec='seconds')
                self.app.config[self.settings_key]=self.cfg
                core.ConfigManager.save_config(self.app.config)
        self.run(work,'Quét Outlook và đối chiếu' if auto or self.kind=='out' else 'Quét Outlook',scanned,background=not (auto and self.kind=='in'),valid=valid)

    def audit(self,records,main,cfg,auto=False,current=None,gaps=None,context=None):
        if self.kind=='out':
            for m in records:
                m['issues']=[v for v in m['issues'] if not v.startswith('Chưa hoàn tất đối chiếu · ')]
                m.pop('history_unread',None)
            if not cfg.get('workbook'):
                for m in records:
                    for r in m['rows']:
                        r.update(match_state='waiting',status='Chờ chọn ORDER của ca')
                return
            from zone_order_result import file_key
            scan_context=context is not None
            if context is None:
                context=dict(password=self.password,passwords=dict(self.app.shift_page.passwords),
                             selected=tuple(self.prior_selected.get(file_key(cfg['workbook']),{}).values()),cache=self.history_cache)
            if gaps is None:gaps=self.scan_gaps
            gaps['rows']=[]
            if current is None:current=mail.order_sheet(cfg['workbook'],context['password'])
            mail.audit_workbooks(records,cfg['workbook'],context['password'],context['passwords'],context['cache'],current,context['selected'],
                                 {**cfg,'_scan_since':gaps['range'][0].date().isoformat() if gaps['range'] else ''},gaps if gaps['range'] else None)
            if scan_context:
                context['table']=current
            else:
                self.audit_path=str(cfg['workbook'])
                self.audit_table=current
            folder=Path(cfg['workbook']).parent
            known=mail.receipts(folder)
            wb_key=file_key(cfg['workbook'])
            unsaved='chưa lưu' in self.app.shift_page.sources.get(wb_key,'')
            try:
                import zone_excel_live as live
                with live.order_access(cfg['workbook']):
                    live_book=live.find(cfg['workbook'])
                    if live_book is not None:
                        unsaved=not live_book.Saved
            except Exception:
                pass
            observed={'observed:'+mail.mail_token(m,i) for m in records for i,r in enumerate(m['rows'])
                      if r.get('match_state')=='current' and r.get('match_line')}
            raw_observed={tok.split(':',1)[1] for tok in observed}
            sess=self.session_observed.setdefault(wb_key,set())
            if unsaved:
                sess.update(raw_observed)
            else:
                sess.difference_update(raw_observed)
                if observed-known:known=mail.receipts(folder,observed-known)
            sess.difference_update({mail.mail_token(m,i) for m in records for i,r in enumerate(m['rows']) if r.get('closed_od')})
            mail.flag_receipts(records,known,session_observed=sess)
            links=mail.link_odbs(cfg['workbook'],current,records,known)
            if scan_context:context['odbs_links']=links
        else:
            rows=[r for m in records for r in m['rows']]
            if rows:
                for r in rows:
                    for k in ('status','sap_qty','sap_ib'):
                        r.pop(k,None)
                with z.lease():
                    session=z.get_session(int(main['sap_session_idx']),main['sap_system'],main['sap_client'])
                    if auto and str(session.Info.Transaction).upper() not in ('SESSION_MANAGER','SMEN','S000') and not cfg.get('dedicated',False):
                        raise ValueError('Phiên SAP đang ở giao dịch khác. Bấm Kiểm IB và BOM khi có thể dùng phiên.')
                    zone_arrival.check_plans(session,rows,{**main['inbound'],'stock_per_vendor':cfg.get('pool','NCC').upper()=='NCC'},main,int(cfg.get('low',10)),int(cfg.get('days',7)),cfg.get('unit','').upper())

    def review_scan(self):
        if self.busy or self.app.is_running:return
        if not self.scan_gaps['range']:
            self.status.set('Quét Outlook để kiểm tra ngược các dòng Excel trong khoảng quét.');return
        first,last=self.scan_gaps['range']
        win=tk.Toplevel(self.app.root);win.title('Dòng ORDER chưa thấy mail khớp trong lượt quét')
        ttk.Label(win,text=f'{first:%d/%m %H:%M} – {last:%d/%m %H:%M} · {len(self.scan_gaps["rows"])} dòng chưa khớp trong {len(self.scan_gaps.get("files",[]))} file đã đọc.').pack()
        for folder in self.scan_gaps.get('folders',[]):ttk.Label(win,text='Outlook '+folder).pack(anchor='w')
        for error in self.scan_gaps.get('errors',[]):ttk.Label(win,text=error,wraplength=900).pack(anchor='w')
        from zone_shift_ui import grid
        tree=grid(win,[('File ca',250),('Dòng',65),('Mã NVL',135),('SL OD',75),('KHSX',100),('Giờ OD',160)])
        if self.scan_gaps.get('unread'):
            ttk.Label(win,text='File cần kiểm tra: '+', '.join(self.scan_gaps['unread']),wraplength=800).pack()
        for item in self.scan_gaps['rows']:tree.append_row(item)

    def schedule_audit(self):
        if self.kind!='out':return
        self.audit_revision=None
        self.audit_pending=True
        if not self.busy:self.app.root.after_idle(self.refresh_cached_mail)

    def refresh_cached_mail(self):
        if self.busy or not self.audit_pending:return
        self.audit_pending=False
        page=self.app.shift_page
        if not page.path or not self.messages:return
        path,revision,table=page.path,page.revision,page.table
        cfg=dict(self.cfg)
        from zone_order_result import file_key
        key=file_key(path)
        context=dict(password=page.password,passwords=dict(page.passwords),
                     selected=tuple(self.prior_selected.get(key,{}).values()),cache=self.history_cache)
        previous=self.messages
        gaps=deepcopy(self.scan_gaps)
        def work():
            records=deepcopy(previous)
            self.audit(records,{},cfg,current=table,gaps=gaps,context=context)
            return records
        def done():
            self.audit_path=str(path)
            self.audit_table=table
            self.audit_revision=revision
            page.set_odbs(context.get("odbs_links",set()))
            self.scan_gaps=gaps
        self.run(work,'Đối chiếu lại thư đã đọc',done,background=True,
                 valid=lambda:page.path==path and page.revision==revision)

    def audit_current(self):
        if self.needs_paint:
            self.status.set('Đang cập nhật danh sách mail.')
            return False
        page=self.app.shift_page
        if not page.path:return False
        import zone_shift as shift
        try:
            if shift.signature(page.path)!=page.stamp:
                self.status.set('ORDER đã sửa bên ngoài · tải lại trước khi xác nhận.')
                page.reload()
                return False
        except OSError as exc:
            self.status.set(str(exc))
            return False
        if self.audit_revision!=page.revision:
            self.status.set('ORDER đã thay đổi · đang đối chiếu lại.')
            self.schedule_audit()
            return False
        return True

    def confirm_odbs(self):
        page=self.app.shift_page
        if self.needs_paint or self.busy or self.app.is_running or not page.path:return
        if not self.audit_current() or str(page.path)!=getattr(self,'audit_path',None):return
        view=self.plan_filter.get()
        wanted=set()
        for node in self.tree.selection():
            if node not in self.display or len(node)>1 and node[1]=='issue':continue
            message,row=self.display[node]
            for i,r in enumerate(message['rows']):
                if (row is None or r is row) and r.get('warehouse','').upper()=='P' and (
                        view=='Tất cả' or str(mail.day(r.get('plan')))==view):
                    wanted.add(mail.mail_token(message,i))
        if not wanted:
            self.status.set('Chọn một thư hoặc các dòng kho P cần xác nhận ODBS.')
            return
        if not messagebox.askyesno('Xác nhận ODBS',f'Gắn nhãn OD bổ sung cho {len(wanted)} dòng P đã chọn trong app?',parent=self.app.root):return
        path,revision,table=page.path,page.revision,self.audit_table
        original=self.messages
        updated={}
        def commit():
            records=deepcopy(original)
            known=mail.receipts(path.parent,['odbs:'+token for token in wanted])
            updated['links']=mail.link_odbs(path,table,records,known)
            return records
        self.run(commit,'Lưu nhãn ODBS',lambda:page.set_odbs(updated['links']),
                 background=True,valid=lambda:page.path==path and page.revision==revision)

    def confirm_copied(self):
        page=self.app.shift_page
        if self.needs_paint or self.busy or not page.path or str(page.path)!=getattr(self,'audit_path',''):return
        if self.app.is_running:return
        chosen={}
        dates=self.plan_filter.get()
        for node in self.tree.selection():
            if node not in self.display or (len(node)>1 and node[1]=='issue'):continue
            message,row=self.display[node]
            tokens=chosen.setdefault(message['id'],set())
            if row is None:
                tokens.update(mail.mail_token(message,i) for i,r in enumerate(message['rows'])
                              if dates=='Tất cả' or str(mail.day(r.get('plan')))==dates)
            else:tokens.add(node[-1])
        wanted=set().union(*chosen.values()) if chosen else set()
        if not wanted:
            self.status.set('Chọn thư hoặc dòng OD cần xác nhận.')
            return
        if not messagebox.askokcancel('Xác nhận đã copy',
                f'Đánh dấu đã copy {len(wanted)} dòng trong {len(chosen)} thư đã chọn?',parent=self.app.root):return
        original=self.messages
        path=page.path
        def commit():
            records=deepcopy(original)
            known=mail.receipts(path.parent,['manual:'+token for token in wanted])
            mail.flag_receipts(records,known)
            return records
        self.run(commit,'Lưu xác nhận đã copy',background=True,valid=lambda:page.path==path)

    def revise(self):
        page=self.app.shift_page
        selection=self.tree.selection()
        if self.busy or self.app.is_running or self.app.mock_mode_var.get() or not page.table:return
        if not self.audit_current():return
        if len(selection)!=1 or selection[0] not in self.display:
            self.status.set('Chọn một dòng mã của mail điều chỉnh.');return
        m,row=self.display[selection[0]]
        if row is None or not any('điều chỉnh' in issue for issue in m.get('issues',())):
            self.status.set('Chọn dòng mã thuộc mail điều chỉnh / gửi lại.');return
        if row.get('warehouse','').upper()!='P':return
        from zone_cleanup import untouched,change_lines
        import zone_shift as sh
        candidates={n:r for n,r in sh.rows(page.table) if sh.norm(r[3])==sh.norm(row['material'])
                    and untouched(r) and sh.state(r)=='pending' and not sh.round_open(r)}
        win=tk.Toplevel(self.app.root);win.title('Đối chiếu mail điều chỉnh');win.transient(self.app.root);win.grab_set()
        ttk.Label(win,text=m['subject']+'\n'+row['material']+' · SL mail '+str(row['qty'])+' · KHSX '+str(row.get('plan',''))).pack()
        from zone_shift_ui import grid
        bar=ttk.Frame(win);bar.pack(side='bottom')
        table=grid(win,[('Dòng',50),('Mã NVL',130),('KHSX',100),('Trạm',145),('SL OD',85)])
        for n,r in candidates.items():table.append_row((n,r[3],sh.day(r[26]),r[5],r[4]),key=str(n))
        def apply(cancel):
            selected=table.selection()
            if len(selected)!=1:return
            n=int(selected[0]);r=candidates[n]
            qty,dt=mail.quantity(row.get('qty')),mail.day(row.get('plan'))
            if not cancel and (not qty or qty<=0 or not dt):return
            label=f"Hủy dòng {n}" if cancel else f"Dòng {n} · SL {r[4]} → {qty} · KHSX {sh.day(r[26])} → {dt}"
            if not messagebox.askyesno('Xác nhận thay đổi OD',label+'\n'+str(r[3])+' · '+str(r[5]),parent=win):return
            updates={} if cancel else {n:{5:float(qty),27:(dt-mail.day(0)).days}}
            win.destroy()
            page.task('Ghi điều chỉnh vào ORDER…',lambda:change_lines(page,{n:r},updates,m['subject']),
                      lambda data:(page.activate(page.path,page.password,data),self.verify()))
        def add():
            if candidates:
                if not messagebox.askyesno('Thêm mã','Đã có dòng cùng mã. Đây là nhu cầu bổ sung riêng?',parent=win):return
            if not messagebox.askyesno('Xác nhận OD mới','Thêm riêng '+row['material']+' từ mail điều chỉnh?',parent=win):return
            win.destroy()
            self.import_selected(True,(m,row))
        for label,action in [('Cập nhật SL / KHSX',lambda:apply(False)),('Hủy dòng chọn',lambda:apply(True)),('Thêm dòng mail',add)]:
            ttk.Button(bar,text=label,command=action).pack(side='left')

    def import_selected(self,force=False,revision=None):
        if self.app.mock_mode_var.get():
            self.status.set("Bỏ tích Mô phỏng để ghi vào Excel.");return
        page=self.app.shift_page
        if self.busy or not page.path or self.app.is_running:return
        if not self.audit_current():return
        if getattr(self,'audit_path',None)!=str(page.path):
            self.status.set('Chọn đúng ORDER và đối chiếu lại.');return
        expected=getattr(self,'audit_table',None)
        if not expected:
            self.status.set('Đối chiếu ORDER trước khi ghi.');return
        wanted=set()
        for node in self.tree.selection():
            if node not in self.display:continue
            m,row=self.display[node]
            for i,r in enumerate(m['rows']):
                can_state=r.get('match_state')=='missing' or force and r.get('match_state') in ('review','unverified')
                can_obs=force or not r.get('copy_observed')
                if not r.get('copy_saved') and not r.get('copy_confirmed') and not r.get('closed_od') and can_obs and (row is None or r is row) and can_state and not mail.blocking(m) and r.get('warehouse','').upper()=='P' and (
                        self.plan_filter.get()=='Tất cả' or str(mail.day(r.get('plan')))==self.plan_filter.get()):
                    wanted.add(mail.mail_token(m,i))
        if revision:
            m,row=revision
            checked=dict(m,issues=[x for x in m.get('issues',[]) if 'điều chỉnh' not in x])
            if mail.blocking(checked):return
            wanted={mail.mail_token(m,next(i for i,r in enumerate(m['rows']) if r is row))}
        if not wanted:
            self.status.set('Chọn mail hoặc dòng P đã xác minh thiếu. Kiểm tra file ca nhận nếu chưa đủ lịch sử.')
            return
        if not messagebox.askyesno('Ghi ORDER',f'Kiểm tra lại và thêm tối đa {len(wanted)} dòng còn thiếu vào {page.path.name}?',parent=self.app.root):return
        from zone_order_result import file_key
        records=deepcopy(self.messages)
        if revision:
            for msg in records:
                if msg['id']==revision[0]['id']:msg['issues']=checked['issues']
        from zone_shift import rows
        from collections import defaultdict
        stations=defaultdict(set)
        for _,line in rows(expected):
            if mail.clean(line[5]):stations[mail.norm(line[3]),mail.norm(line[9])].add(mail.clean(line[5]))
        for msg in records:
            fg_rows=[r for i,r in enumerate(msg['rows']) if r.get('fg') and mail.mail_token(msg,i) in wanted]
            if fg_rows:
                combine=messagebox.askyesnocancel('Ghép FG và trạm',msg['subject']+'\nGhép mã FG vào tên trạm cho các dòng đã chọn?',parent=self.app.root)
                if combine is None:return
                if not combine:
                    for r in fg_rows:
                        r['station']=r['station_without_fg']
            shifts=defaultdict(set)
            choices={}
            person=''
            for r in msg['rows']:
                shift=mail.shift_label(r.get('production_shift'))
                if shift:shifts[mail.norm(r.get('model')),mail.day(r.get('plan'))].add(shift)
            for i,r in enumerate(msg['rows']):
                token=mail.mail_token(msg,i)
                if token not in wanted:continue
                if r.get('model_scope') and not r.get('model'):
                    value=simpledialog.askstring('Model của lượt OD',r['material']+' · nhập VF8 hoặc VF9 cho dòng này',parent=self.app.root)
                    if value is None:return
                    if mail.norm(value) not in r['model_scope']:
                        self.status.set('Cần chọn đúng VF8 hoặc VF9 trước khi ghi ORDER.')
                        return
                    r['model']=value.strip().upper()
                if not all((r.get('material'),mail.quantity(r.get('qty')),r.get('model'),mail.day(r.get('plan')))):
                    wanted.discard(token);continue
                if not r.get('station'):
                    opts=sorted(stations[mail.norm(r['material']),mail.norm(r['model'])])
                    if len(opts)==1:r['resolved_station']=opts[0]
                    else:
                        value=simpledialog.askstring('Trạm nhận',r['material']+' · '+', '.join(opts)+' · để trống để giữ lại dòng',parent=self.app.root)
                        if value is None:return
                        if not value.strip():wanted.discard(token);continue
                        r['resolved_station']=value.strip()
                group=mail.norm(r['model']),mail.day(r['plan'])
                shift=mail.shift_label(r.get('production_shift'))
                if not shift and not r.get('production_shift'):
                    if len(shifts[group])==1:shift=next(iter(shifts[group]))
                    elif not shifts[group]:
                        import re
                        hint=re.search(r'(?i)\bca\s+(S[12367](?:\s*/\s*S[12367])*)\b',msg['subject'])
                        if hint:shift=mail.shift_label(hint[1])
                if not shift and r.get('bbbg_only'):shift='/'
                if not shift:
                    if group not in choices:
                        value=simpledialog.askstring('Ca chạy',f"{group[0]} · {group[1]} · nhập S6, S7 hoặc S6/S7 cho nhóm thiếu ca",parent=self.app.root)
                        if value is None:return
                        choices[group]=mail.shift_label(value)
                    shift=choices[group]
                if not shift:wanted.discard(token);continue
                r['production_shift']=shift
                if not mail.clean(r.get('person')):
                    if not person:person=mail.clean(simpledialog.askstring('Người OD',msg['subject'],parent=self.app.root))
                    if not person:return
                    r['person']=person
        if not wanted:
            self.status.set('Chưa có dòng đủ thông tin để ghi.');return
        import time
        timing=[time.monotonic(),'Chuẩn bị ghi ORDER',True]
        def progress(label):
            def update():
                timing[0]=time.monotonic();timing[1]=label
                self.status.set(label)
            self.app.post_ui(update)
        def tick():
            if timing[2] and self.busy:
                self.status.set(f'{timing[1]} · {int(time.monotonic()-timing[0])} giây')
                self.app.root.after(1000,tick)
        def done():
            timing[2]=False
            self.audit_table=result_state['table']
            self.session_observed.get(file_key(page.path),set()).difference_update(wanted)
            self.app.root.after_idle(lambda:self.status.set(f"100% · Đã lưu và xác minh {result_state['count']} dòng P"))
            page.activate(page.path,page.password,(result_state['table'],result_state['stamp']))
            self.schedule_audit()
        self.app.root.after(1000,tick)
        picks=list(self.prior_selected.get(file_key(page.path),{}).values())
        result_state={}
        allow_obs=bool(force or revision)
        def write():
            messages,table,count=mail.append_missing(records,wanted,page.path,page.password,page.passwords,self.history_cache,picks,self.cfg,self.app.config,expected,progress,allow_observed=allow_obs)
            import zone_shift as shift
            result_state.update(table=table,count=count,stamp=shift.signature(page.path))
            return messages
        self.run(write,'Ghi dòng P và đọc lại ORDER',done)

    def verify(self):
        if self.busy or self.app.is_running:
            return
        if not self.messages:
            self.status.set('Quét Outlook hoặc mở mail .msg trước.')
            return
        if self.kind=='out':
            if not self.cfg.get('workbook'):
                self.app.shift_page.choose()
                return
            path=Path(self.cfg['workbook'])
            page=self.app.shift_page
            def ready(result):
                table,stamp=result
                if page.path!=path:return
                if stamp!=page.stamp or table!=page.table:
                    page.activate(path,page.password,result)
                else:
                    self.schedule_audit()
            page.read_order(path,ready)
            return
        records=deepcopy(self.messages)
        main=deepcopy(self.app.config)
        cfg=dict(self.cfg)
        def work():
            self.audit(records,main,cfg)
            for m in records:
                m['issues']=[msg for msg in m['issues'] if not msg.startswith('Chưa hoàn tất đối chiếu · ')]
            return records
        self.run(work,'Đối chiếu ORDER' if self.kind=='out' else 'Kiểm IB và BOM Plant 3093')

    def paint(self,notify=True):
        self.view_version=getattr(self,'view_version',0)+1
        self.needs_paint=True
        if not self.tree.winfo_ismapped():return
        self.view_notify=notify
        if getattr(self,'building_view',False):return
        self.building_view=True
        version=self.view_version
        messages=self.messages
        selected=self.plan_filter.get()
        page=getattr(self.app,'shift_page',None)
        table=page.table if page and self.kind=='out' else None
        gaps=self.scan_gaps
        q_text=self.filter_bar['query'].get() if hasattr(self,'filter_bar') else ''
        st_filter=self.filter_bar['status'].get() if hasattr(self,'filter_bar') else 'Tất cả'
        def ready(result,error):
            self.building_view=False
            if not self.tree.winfo_ismapped():return
            if version!=self.view_version:
                self.paint(self.view_notify)
                return
            if error:
                self.needs_paint=False
                self.status.set('Lỗi hiển thị mail · '+error)
                return
            dates,choice,self.groups,summary,alerts=result
            self.needs_paint=False
            if self.kind=='out':
                self.plan_box.configure(values=['Tất cả',*dates])
                self.plan_filter.set(choice)
            self.expanded.intersection_update(self.groups)
            import time as _time
            t0=_time.perf_counter()
            self.show_groups()
            self.timings['render_ms']=(_time.perf_counter()-t0)*1000
            if self.timings:
                parts=[]
                if 'outlook_s' in self.timings:parts.append(f"Quét {self.timings['outlook_s']:.2f}s")
                if 'audit_s' in self.timings:parts.append(f"Đối chiếu {self.timings['audit_s']:.2f}s")
                if 'render_ms' in self.timings:parts.append(f"Vẽ {self.timings['render_ms']:.1f}ms")
                if parts:summary+=' · '+' / '.join(parts)
            if not self.busy:self.status.set(summary)
            if self.kind=='in' and notify and alerts and alerts!=self.alert_signature:
                messagebox.showwarning('Hàng về · BOM 3093','\n'.join(dict.fromkeys(problem for _,problem in alerts))[:650],parent=self.app.root)
            self.alert_signature=alerts
        def worker():
            try:
                result=self.build_view(messages,selected,table,gaps,q_text,st_filter)
                self.app.post_ui(lambda:ready(result,None))
            except Exception as exc:
                self.app.post_ui(lambda detail=str(exc):ready(None,detail))
        threading.Thread(target=worker,daemon=True).start()

    def build_view(self,messages,selected,table,gaps,q_text='',st_filter='Tất cả'):
        groups={}
        alerts=[]
        count=skip=completed=attention=shown=0
        actual_dates={d.isoformat() for m in messages for r in m['rows'] if (d:=mail.day(r.get('plan')))}
        actual_dates.update(d for m in messages for d in m.get('plan_counts',{}) if d)
        if self.kind=='out':
            if table:
                actual_dates.update(d.isoformat() for r in table[1:] if r[3] and (d:=mail.day(r[26])))
            if selected not in actual_dates:
                selected='Tất cả'
        history_notes=set()
        q_norm=mail.norm(q_text)
        for m in messages:
            records,omitted,visible=mail.visible_out(m,selected) if self.kind=='out' else (m['rows'],m['skipped'],True)
            if not visible:continue
            title=self.mail_title(m['received'],m['subject'])
            if q_norm:
                msg_hay=mail.norm(' '.join((title,m.get('sender',''),m.get('receive_shift',''),*m.get('issues',()))))
                if q_norm not in msg_hay:
                    records=[r for r in records if q_norm in mail.norm(' '.join(str(r.get(k,'')) for k in ('material','qty','station','leader','plan','status','po','ib','sap_ib','delivery')))]
                    if not records:continue
            if st_filter!='Tất cả':
                if self.kind=='out':
                    def match_out_st(r):
                        st=r.get('status','')
                        ms=r.get('match_state','')
                        if st_filter=='Cần đối chiếu / xem':return ms in ('review','missing','unverified','waiting') or bool(r.get('copy_observed') and ms!='current')
                        if st_filter=='Chưa copy':return ms in ('missing','unverified') and not r.get('copy_confirmed') and not r.get('copy_saved')
                        if st_filter=='Đã copy đủ':return ms in ('current','history','archived') or bool(r.get('copy_confirmed') or r.get('copy_saved'))
                        if st_filter=='ODBS':return bool(r.get('odbs'))
                        if st_filter=='Đã đóng (OD_DA_DONG)':return bool(r.get('closed_od'))
                        if st_filter=='Có vấn đề':return bool(m['issues']) or ms=='review' or 'Cần đối chiếu' in st
                        return True
                    records=[r for r in records if match_out_st(r)]
                    if not records and not (st_filter=='Có vấn đề' and m['issues']):continue
                else:
                    def match_in_st(r):
                        st=r.get('status','Chờ đối chiếu')
                        if st_filter=='Cần kiểm tra':return not self.row_done(st)
                        if st_filter=='Khớp kế hoạch':return st.startswith('Khớp kế hoạch')
                        if st_filter=='Thiếu BOM / linh kiện':return 'BOM' in st or 'Thiếu linh kiện' in st or 'hết hiệu lực' in st
                        if st_filter=='Đã hoàn tất GR':return 'Đã hoàn tất GR' in st
                        return True
                    records=[r for r in records if match_in_st(r)]
                    if not records:continue
            shown+=1
            count+=len(records)
            skip+=omitted
            headline={}
            tag=None
            if self.kind=='out':
                from collections import Counter
                stats=Counter(r.get('match_state','waiting') for r in records)
                linked=stats['current']+stats['history']+stats['archived']
                copied=sum(bool(r.get('copy_confirmed') or r.get('copy_saved') or r.get('match_state') in ('current','history','archived')) for r in records)
                problems=list(m['issues'])
                if stats['unverified']:
                    history_notes.update(m.get('history_unread',[]))
                if records:
                    unit='dòng' if any(not r.get('warehouse') for r in records) else 'dòng P'
                    text=(f'Đã copy {copied}/{len(records)} {unit}' if stats['waiting']!=len(records) else 'Chờ đối chiếu ORDER')
                    if copied==len(records):text=f'Done · đã copy {copied}/{len(records)} {unit}'
                    if copied!=linked:text+=f' · đối chiếu ORDER {linked}/{len(records)}'
                    supply=Counter(r['supply_state'] for r in records if r.get('supply_state'))
                    if supply:text+=' · '+', '.join(f'{v} {k}' for k,v in supply.items())
                    if stats['history']:
                        text+=f" · {stats['history']} Done ca trước"
                    for key,label in [('missing','dòng P chưa copy'),('review','cần kiểm tra'),('unverified','thiếu lịch sử'),('waiting','chưa kiểm')]:
                        if stats[key]:
                            text+=f' · {stats[key]} {label}'
                else:
                    text='Chỉ có kho H' if omitted and not problems else 'Chưa có dòng P đọc được cho KHSX này'
                marked=sum(bool(r.get('odbs')) for r in records)
                if marked:text+=f' · {marked} ODBS'
                if omitted:text+=f' · {omitted} dòng H'
                if records and m.get("receive_shift"):
                    original=sum(bool(r.get('origin_line')) for r in records)
                    text+=' · '+m['receive_shift']+' ('+(f'{original}/{len(records)} ở ca nhận' if records and records[0].get('origin_checked') else 'thiếu file ca nhận')+')'
                if copied<len(records) and m.get("history_unread"):
                    problems+=m["history_unread"]
                if problems:
                    text+=' · '+' · '.join(problems)
                warn=bool(problems or copied<len(records))
                attention+=int(warn)
                completed+=int(bool(records) and copied==len(records))
                plans=sorted({d.strftime('%d/%m/%Y') for r in records if (d:=mail.day(r.get('plan')))})
                plans=plans or ([selected] if selected!='Tất cả' else sorted(d for d in m.get('plan_counts',{}) if d))
                headline={'plan':', '.join(plans),'status':text}
                tag='warn' if warn else 'done'
            groups[m['id']]=(m,records,title,tuple(headline.get(k,'') for k,_,_ in self.cols),tag)
            alerts.extend((m['id'],problem) for problem in m['issues'])
            for r in records:
                state=r.get('status','Chờ đối chiếu')
                if state!='Chờ đối chiếu' and not self.row_done(state):
                    alerts.append((m['id'],r['material']+' · '+state))
        scope=' · '+', '.join(sorted(history_notes)[:3]) if history_notes else ''
        summary=(f'{shown} mail · {count} dòng'+(f' OD · {completed} mail đã copy đủ · {attention} mail cần xem'+(f' · bỏ {skip} dòng H' if selected=='Tất cả' else '') if self.kind=='out' else f' · {len(alerts)} mục cần kiểm tra')+scope+f' · {datetime.now():%H:%M}')
        if self.kind=='out' and not shown and selected!='Tất cả':
            summary=f'KHSX {selected} · chưa thấy thư OD xác định được ngày này trong nguồn đã quét.'
        if self.kind=='out' and gaps.get('folders'):
            summary+=(' · Outlook '+', '.join(gaps['folders'])+(f" · {len(gaps['errors'])} thư đọc lỗi (Kiểm lượt quét)" if gaps.get('errors') else ''))
        return sorted(actual_dates),selected,groups,summary,tuple(sorted(alerts))

    @staticmethod
    def row_done(state):
        return state.startswith(('Khớp kế hoạch','Đã copy','IB đã hoàn tất GR','Đã đóng ở OD_DA_DONG')) and ' | ' not in state and 'Cần đối chiếu' not in state

    def expand_all(self,opened=True):
        if opened:
            self.expanded.update(k for k,(m,recs,_,_,_) in self.groups.items() if recs or m['issues'])
        else:
            self.expanded.clear()
        self.show_groups()

    @staticmethod
    def mail_title(received,subject):
        return datetime.fromisoformat(received).strftime('%d/%m %H:%M')+' · '+subject

    def show_groups(self):
        entries=[]
        display={}
        from zone_result_grid import sort_value
        groups=list(self.groups.items())
        col,reverse=getattr(self,'mail_sort',(None,False))
        if col is not None:
            groups.sort(key=lambda pair:sort_value(pair[1][0]['received'] if col==0 else pair[1][3][col-1]),reverse=reverse)
        for mid,(message,records,title,headline,tag) in groups:
            expanded=mid in self.expanded
            prefix=('▼  ' if expanded else '▶  ') if records or message['issues'] else ''
            entries.append(((mid,),(prefix+title,*headline),tag))
            display[(mid,)]=(message,None)
            if not expanded:continue
            for i,problem in enumerate(message['issues']):
                entries.append(((mid,'issue',i),('    Cần kiểm tra',*(problem if k=='status' else '' for k,_,_ in self.cols)),'warn'))
            # Filtered rows retain their identity in the complete message.
            originals={id(r):i for i,r in enumerate(message['rows'])}
            if col:
                field=self.cols[col-1][0]
                records=sorted(records,key=lambda r:sort_value(r.get(field,'')),reverse=reverse)
            for row in records:
                key=(mid,'row',mail.mail_token(message,originals[id(row)]))
                fields={**row,'ib':row.get('sap_ib') or row.get('ib',''),
                        'station':' / '.join(filter(None,(row.get('station'),row.get('leader'))))}
                state=fields.setdefault('status','Chờ đối chiếu')
                if row.get('copy_confirmed') or row.get('copy_saved'):
                    state=fields['status']=('Đã copy · người dùng xác nhận' if row.get('copy_confirmed') else 'Đã copy · Excel đã lưu')+' · '+state
                if row.get('odbs'):fields['status']='ODBS · '+state
                entries.append((key,('    '+message['sender'],*(fields.get(k,'') for k,_,_ in self.cols)),
                                'done' if self.row_done(state) else 'warn'))
                display[key]=(message,row)
        self.display=display
        self.tree.sync_rows(entries)

    def toggle_selected(self,opened=None):
        if self.tree.active:
            key=self.tree.keys[self.tree.active[0]-1]
            if len(key)==1:self.toggle(key,opened)
        return 'break'

    def toggle(self,key,opened=None):
        group=self.groups.get(key[0])
        if not group or not (group[1] or group[0]['issues']):return
        if opened is None:opened=key[0] not in self.expanded
        if opened:self.expanded.add(key[0])
        else:self.expanded.discard(key[0])
        self.show_groups()

    def click_mail(self,event):
        key=self.tree.identify_row(event.y)
        if key and len(key)==1 and self.tree.canvasx(event.x)<28:self.toggle(key)

    def detail(self,event):
        node=self.tree.identify_row(event.y)
        if node in self.display:
            m,r=self.display[node]
            if r is None and node[0] in self.groups and (self.groups[node[0]][1] or m['issues']):
                if self.tree.canvasx(event.x)>=28:self.toggle(node)
                return
            messagebox.showinfo(m['subject'],m['sender']+' · '+m['received']+'\n\n'+
                                ('\n'.join(f'{k}  {v}' for k,v in r.items() if v) if r else '\n'.join(m['issues'])),parent=self.app.root)
