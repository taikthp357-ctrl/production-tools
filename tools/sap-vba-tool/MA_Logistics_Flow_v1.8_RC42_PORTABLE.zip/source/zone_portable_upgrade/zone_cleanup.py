"""Close obsolete demand after checking the live ORDER sheet."""
import tkinter as tk
from tkinter import ttk,messagebox
import zone_shift as sh
from zone_order_result import writable_order


def untouched(row):
    return all(sh.norm(row[i]) in ('','hetton','hettonkhoma') for i in (13,16,19)) and all(
        not sh.clean(row[i]) for i in (14,17,20)) and all(row[i] in (None,'',0,'0') for i in (15,18,21,22))


def eligible(row):
    return bool(sh.day(row[26]) and sh.state(row) in ('pending',sh.PART))


def open_ob(row):
    for slot in (13,16,19):
        ob=sh.clean(row[slot])
        if sh.norm(ob) in ('','hetton','hettonkhoma'):
            continue
        if row[slot+2] in (None,'',0,'0') or '/' in ob and not sh.confirmed_shared(row):
            return ob
    return 'lượt thùng đang mở' if sh.round_open(row) else ''


def change_lines(page,selected,changes,reason):
    # Pending history stays available for reconciliation. Source rows are archived
    # in this workbook before its active OD fields change in the same Excel save.
    path,pwd=page.path,page.password
    with writable_order(path,pwd) as (book,sheet,shared):
        current=sh.values(sheet)
        if any(n>len(current) or current[n-1]!=old for n,old in selected.items()):
            raise ValueError('Dòng OD đã thay đổi. Tải lại và đối chiếu trước khi ghi.')
        import zone18
        proposed=[line for line in sh.plan(current,None,None,None,page.app.config,review=True) if line['row'] in selected]
        with zone18.journal() as conn:
            if sh.reservations(conn,proposed):
                raise ValueError('Có dòng đã gửi SAP. Đối soát lượt ra đơn trước khi chỉnh OD.')
        try:archive=book.Worksheets('OD_DA_DONG')
        except Exception:
            archive=book.Worksheets.Add(After=book.Worksheets(book.Worksheets.Count))
            archive.Name='OD_DA_DONG'
        if not archive.Cells(1,1).Value2:
            headers=('Lý do','Dòng ORDER',*current[0])
            archive.Range(archive.Cells(1,1),archive.Cells(1,len(headers))).Value2=(headers,)
        first=max(2,int(archive.Cells(archive.Rows.Count,1).End(-4162).Row)+1)
        undo=[]
        try:
            for i,(n,r) in enumerate(selected.items(),first):
                snapshot=(reason,n,*r)
                cells=archive.Range(archive.Cells(i,1),archive.Cells(i,len(snapshot)))
                cells.NumberFormat='@';cells.Value2=(snapshot,)
                if sh.clean(archive.Cells(i,6).Value2)!=sh.clean(r[3]):raise ValueError('Chưa xác minh được mã trong lịch sử đóng OD.')
                updates=changes.get(n)
                if updates is None:
                    updates={col:None for col in range(1,len(r)+1) if r[col-1] not in (None,'') and not sheet.Cells(n,col).HasFormula}
                    if 4 not in updates:raise ValueError('Mã NVL dùng công thức, cần kiểm tra dòng.')
                for col,value in updates.items():
                    cell=sheet.Cells(n,col)
                    if cell.HasFormula:raise ValueError('Ô cần chỉnh đang có công thức.')
                    undo.append((cell,cell.Value2))
                    if value is None:cell.ClearContents()
                    else:cell.Value2=value
                    if sh.clean(cell.Value2)!=sh.clean(value):raise ValueError('Excel đọc lại khác giá trị cần ghi.')
            sheet.Calculate()
            book.Save()
            if not book.Saved:raise ValueError('Excel chưa xác nhận lưu các OD đã đóng.')
            try:
                import zone_mail
                closed_rows=zone_mail._read_closed_sheet(book)
            except Exception:
                closed_rows=None
        except Exception:
            if shared:
                for cell,old in reversed(undo):cell.Value2=old
                archive.Rows(f'{first}:{first+len(selected)-1}').ClearContents()
            raise
    result=sh.load(path,pwd)
    sh.history_snapshot(path,result[0])
    if closed_rows is not None:
        try:
            import zone_mail
            zone_mail.closed_snapshot(path,list(closed_rows),expected=result[1])
        except Exception:
            pass
    return result


def cleanup_dialog(page):
    if not page.table or page.app.is_running:return
    if page.app.mock_mode_var.get():
        messagebox.showinfo('Dọn OD','Tắt Mô phỏng để dọn ORDER của ca.',parent=page.app.root);return
    source=page.table
    candidates={n:r for n,r in sh.rows(source) if eligible(r)}
    if not candidates:
        messagebox.showinfo('Dọn OD','File ca không có OD Pending hoặc cấp một phần có ngày KHSX.',parent=page.app.root);return
    if page.cleanup:return
    page.cleanup=CleanupView(page,candidates)
    page.cleanup.paint()


class CleanupView:
    def __init__(self,page,candidates):
        self.sort_field=0
        self.desc=False
        self.page=page
        self.source=page.table
        self.path=page.path
        self.candidates=candidates
        tree=page.tree
        self.selected={page.lines[k]['line_id'] for k in tree.selection()}
        self.active=(page.lines[tree.active[0]]['line_id'],tree.active[1]) if tree.active else None
        self.scroll=tree.xview()[0],tree.yview()[0]
        page.toolbar.pack_forget()
        page.footer.pack_forget()
        self.bar=ttk.Frame(page.requests.master)
        self.bar.pack(fill='x',before=page.requests)
        ttk.Label(self.bar,text='Dọn OD · Chọn ngày KHSX').pack(side='left')
        dates=sorted({str(sh.day(r[26])) for r in candidates.values()})
        self.day=tk.StringVar(value='')
        box=ttk.Combobox(self.bar,textvariable=self.day,values=dates,state='readonly',width=12)
        box.pack(side='left',padx=5)
        box.bind('<<ComboboxSelected>>',lambda _:self.paint())
        self.quick=tk.StringVar()
        ttk.Label(self.bar,text='Tìm nhanh').pack(side='left',padx=(6,2))
        q_entry=ttk.Entry(self.bar,textvariable=self.quick,width=16)
        q_entry.pack(side='left',padx=(0,6))
        self._job=None
        self.quick.trace_add('write',lambda *_:self._job and self.bar.after_cancel(self._job) or setattr(self,'_job',self.bar.after(90,self.paint)))
        tree.bind('<Control-f>',lambda _:q_entry.focus_set() or 'break')
        ttk.Button(self.bar,text='Đóng các dòng chọn',command=self.close).pack(side='left')
        ttk.Button(self.bar,text='Quay lại ORDER',command=self.leave).pack(side='right')
        ttk.Button(self.bar,text='Copy bảng',command=lambda:tree.copy_rows()).pack(side='right',padx=4)

    def sort_header(self,event):
        tree=self.page.tree
        x=tree.header.canvasx(event.x)
        for field,w in zip((0,3,5,4,22,6,10,24),tree.widths):
            if x<w:
                self.desc=not self.desc if self.sort_field==field else False
                self.sort_field=field
                selected={self.visible[k] for k in tree.selection()}
                self.paint()
                tree.selection_set({k for k,n in self.visible.items() if n in selected})
                return
            x-=w

    def paint(self):
        page=self.page
        if page.table is not self.source:
            self.leave()
            return
        tree=page.tree
        tree.show_columns(['Dòng','Mã hàng','Trạm','SL ORDER','Đã cấp','Còn thiếu','OB','Tình trạng'])
        self.visible={}
        page.lines={}
        entries=[]
        q_norm=sh.norm(self.quick.get()) if hasattr(self,'quick') else ''
        for n,r in self.candidates.items():
            if str(sh.day(r[26]))!=self.day.get():continue
            try:remaining=max(0,float(r[4])-float(r[22] or 0))
            except (ValueError,TypeError):remaining=''
            obs=' / '.join(sh.clean(r[i]) for i in (13,16,19) if sh.norm(r[i]) not in ('','hetton','hettonkhoma'))
            label='Cấp một phần' if sh.state(r)==sh.PART else 'Pending'
            waiting=open_ob(r)
            if waiting:label+=' · Cần đối soát '+waiting
            if q_norm and q_norm not in sh.norm(' '.join((str(n),sh.clean(r[3]),sh.clean(r[5]),obs,label))):continue
            fields={0:n,3:r[3],5:r[5],4:r[4],22:r[22],6:remaining,10:obs,24:label}
            entries.append((fields,n,[n,r[3],'',r[5],r[4],r[22],sh.clean(remaining),'','','',obs,label]))
        def key(entry):
            value=entry[0][self.sort_field]
            if self.sort_field in (0,4,22,6):
                try:return float(value or 0)
                except (ValueError,TypeError):return 0
            return sh.clean(value).casefold()
        for _,n,values in sorted(entries,key=key,reverse=self.desc):
            self.visible[tree.add(values)]=n

    def leave(self):
        page=self.page
        page.cleanup=None
        self.bar.destroy()
        main=page.requests.master
        page.toolbar.pack(fill='x',before=main.pack_slaves()[0])
        page.footer.pack(side='bottom',fill='x',before=page.requests)
        page.paint()
        self.restore()

    def restore(self):
        page=self.page
        if page.path!=self.path:return
        tree=page.tree
        tree.selection_set({k for k,r in page.lines.items() if r['line_id'] in self.selected})
        if self.active:
            node=next((k for k,r in page.lines.items() if r['line_id']==self.active[0]),None)
            if node and self.active[1]<len(tree.widths):tree.active=(node,self.active[1])
        if tree.render_job is not None:
            tree.after_cancel(tree.render_job)
        tree.render_view()
        tree.xview_moveto(self.scroll[0])
        tree.yview_moveto(self.scroll[1])

    def close(self):
        page=self.page
        if page.app.is_running or page.table is not self.source or page.path!=self.path or page.app.mock_mode_var.get():return
        selected={self.visible[k]:self.candidates[self.visible[k]] for k in page.tree.selection()}
        if not selected:return
        waiting=[f'Dòng {n} · {open_ob(r)}' for n,r in selected.items() if open_ob(r)]
        if waiting:
            messagebox.showinfo('Đối soát OB','Cần đối soát trước khi đóng OD:\n'+'\n'.join(waiting[:12]),parent=page.app.root)
            return
        if not messagebox.askyesno('Đóng OD',f'Đóng {len(selected)} dòng KHSX {self.day.get()} và bỏ khỏi báo cáo? Cấp tiếp cần OD mới.',parent=page.app.root):return
        reason='Đóng OD theo KHSX '+self.day.get()
        self.leave()
        def saved(data):
            page.activate(self.path,page.password,data)
            self.restore()
        page.task('Lưu các OD đã đóng…',lambda:change_lines(page,selected,{},reason),saved)
