"""Read local Outlook tables and reconcile them with ORDER and SAP."""
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser
from pathlib import Path
import re
import unicodedata


def norm(value):
    value = str(value or '').casefold().replace('đ', 'd')
    return ''.join(c for c in unicodedata.normalize('NFKD', value) if c.isalnum())


def clean(value):
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return ' '.join(str(value if value is not None else '').split())


def day(value):
    if isinstance(value, (int, float)):
        try:
            return (datetime(1899, 12, 30) + timedelta(days=value)).date()
        except (OverflowError, ValueError):
            return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    english = re.fullmatch(r'(\d{1,2})-([A-Za-z]{3})-(\d{2}|\d{4})', clean(value))
    if english:
        months = 'jan feb mar apr may jun jul aug sep oct nov dec'.split()
        try:
            year = int(english[3]) + (2000 if len(english[3]) == 2 else 0)
            return date(year, months.index(english[2].lower()) + 1, int(english[1]))
        except ValueError:
            return None
    for fmt in ('%d.%m.%Y','%d/%m/%Y','%d-%b-%y','%Y-%m-%d','%m/%d/%Y','%d-%m-%Y'):
        try:
            return datetime.strptime(clean(value), fmt).date()
        except ValueError:
            pass


def quantity(value):
    try:
        if isinstance(value,str) and re.fullmatch(r"[1-9]\d{0,2}\.\d{3}",value.strip()):
            return None
        number = Decimal(clean(value))
        return number if number.is_finite() and number > 0 else None
    except InvalidOperation:
        return None


class Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack = []
        self.tables = []
        self.quoted = False

    def handle_starttag(self, tag, attrs):
        if tag == 'blockquote' or any('divrplyfwdmsg' in str(v).lower() for k,v in attrs if k=='id'):
            self.quoted = True
        if tag == 'table':
            self.stack.append([[], None, None, self.quoted])
        elif self.stack:
            frame = self.stack[-1]
            if tag == 'tr':
                frame[1] = []
            elif tag in ('td','th') and frame[1] is not None:
                frame[2] = []
            elif tag == 'br' and frame[2] is not None:
                frame[2].append(' ')

    def handle_endtag(self, tag):
        if not self.stack:
            return
        frame = self.stack[-1]
        if tag in ('td','th') and frame[2] is not None:
            frame[1].append(clean(''.join(frame[2])))
            frame[2] = None
        elif tag == 'tr' and frame[1] is not None:
            frame[0].append(frame[1])
            frame[1] = None
        elif tag == 'table':
            self.tables.append((frame[3], frame[0]))
            self.stack.pop()

    def handle_data(self, data):
        if re.match(r'^\s*(From|Từ)\s*:', data, re.I):
            self.quoted = True
        if self.stack and self.stack[-1][2] is not None:
            self.stack[-1][2].append(data)


ALIASES = {
    'warehouse': ('Kho','Warehouse'), 'material': ('Mã vật tư ORDER','Mã SG','Mã NVL','PN','P/N','Part number','Material','Material number','Mã hàng','Mã','Item code'),
    'fg': ('Mã FG','FG','FG Code'), 'component': ('Component',), 'qty': ('SL OD','Số lượng','Delivery Qty','Delivery Quantity','Quantity','QTY','SL','Planned quantity'),
    'station': ('Vị trí cấp hàng','KHU VỰC TL NHẬN','Trạm giao','Trạm'), 'leader': ('TL','Tổ trưởng'),
    'production_shift': ('Ca','Ca chạy','Ca/SX','Ca SX'), 'model': ('Model',), 'plan': ('KHSX','Ngày KHSX'), 'person': ('Người OD',),
    'po': ('PO/SA','PO','SA','PO Number','Purchase order','Purchasing Document','Số PO','Scheduling agreement'),
    'po_item': ('Item of PO/SA','PO Item','Item','SA Item','RefIt'), 'unit': ('ĐVT','UOM','Unit','Đơn vị'),
    'ib': ('IB','Inbound delivery','Inbound delivery number','Delivery number','Số IB'),
    'candidate': ('Suppiler Batch','Supplier Batch','External ID'), 'delivery': ('Delivery date','Ngày giao','Ngày giao hàng'),
    'plant': ('Plant','Nhà máy'), 'note': ('NOTE','Ghi chú')
}


def parse_tables(tables, kind, plan_counts=None):
    result = []
    skipped = 0
    found = False
    issues = []
    for quoted, table in tables:
        if kind == 'out' and quoted:
            continue
        mapping = {}
        for pos,cells in enumerate(table):
            names = [norm(x) for x in cells]
            cols = {k:next((names.index(norm(a)) for a in aliases if norm(a) in names),None)
                    for k,aliases in ALIASES.items()}
            if kind=='out':
                if cols['material'] is None and 'sg' in names:
                    j=names.index('sg')
                    samples=[clean(line[j]) for line in table[pos+1:pos+7] if len(line)>j and clean(line[j])]
                    if any(re.fullmatch(r'[A-Za-z]+[A-Za-z0-9-]*[0-9][A-Za-z0-9-]*',v) for v in samples):
                        cols['material']=j
                if cols['model'] is None and 'limo' in names:cols['model']=names.index('limo')
            if cols['material'] is None and cols['fg'] is not None:
                cols['material']=cols['component']
            if cols['qty'] is None:
                cols['qty'] = next((i for i,n in enumerate(names) if n.startswith(('soluongod','slodkhsx'))),None)
            if cols['material'] is not None and cols['qty'] is not None:
                ok = True if kind=='out' else (cols['po'] is not None or cols['ib'] is not None)
                mapping = {k:i for k,i in cols.items() if i is not None} if ok else {}
                found |= bool(mapping)
                continue
            if not mapping or not any(names):
                continue
            r = {k:clean(cells[i]) if i<len(cells) else '' for k,i in mapping.items()}
            if kind=='out':
                if not r.get('material') and not r.get('qty') and all(n in ('','us','sg') for n in names):continue
                r.setdefault('warehouse','')
            if kind=='out' and (r.get('fg') or norm(r.get('model')) in ('wild','vfwild') and 'component' in mapping):
                fg=r.get('fg') or r['material']
                r['fg']=fg
                r['station_without_fg']='-'.join(filter(None,(r.get('station'),r.get('leader'))))
                r['material']=r.get('component') or r['material']
                r['station']='-'.join(filter(None,(fg,r.get('station'),r.get('leader'))))
                r['leader']=''
            if any(n in ('total','tong','tongcong','grandtotal') for n in names[:3]):
                continue
            if kind=='out' and plan_counts is not None:
                dt=day(r.get('plan'))
                if dt or r['warehouse'].upper()=='H':
                    counts=plan_counts.setdefault(dt.isoformat() if dt else '',{'H':0})
                    if r['warehouse'].upper()=='H':counts['H']+=1
            if kind=='out' and r['warehouse'].upper()=='H':
                skipped += 1
                continue
            if kind=='out' and r['warehouse'].upper()!='P' and 'warehouse' in mapping:
                issues.append('Kho chưa xác định: '+r.get('material',''))
                continue
            r['material'] = r['material'].upper()
            if not r['material'] or quantity(r['qty']) is None:
                issues.append('Thiếu mã hoặc SL chưa rõ: '+' / '.join(filter(None,(r['material'],r['qty']))))
                continue
            if kind=='in':
                if not r.get('ib') and re.fullmatch(r'185\d{5,7}',r.get('candidate','')):
                    r['ib'] = r['candidate']
                if not r.get('plant') and r.get('note')=='3093':
                    r['plant']='3093'
            result.append(r)
    return result, skipped, issues, found


def spreadsheet_tables(attachment,kind,plan_counts=None):
    from tempfile import TemporaryDirectory
    from openpyxl import load_workbook
    with TemporaryDirectory() as folder:
        path=Path(folder)/'plan.xlsx'
        attachment.SaveAsFile(str(path))
        book=load_workbook(path,read_only=True,data_only=True)
        try:
            tables=[]
            for sheet in book.worksheets:
                if sheet.sheet_state!='visible':
                    continue
                if sheet.max_row and sheet.max_row>20000 or sheet.max_column and sheet.max_column>120:
                    raise ValueError('Bảng kế hoạch vượt phạm vi đọc 20.000 dòng / 120 cột')
                tables.append((False,[list(map(clean,r)) for r in sheet.values if any(x is not None for x in r)]))
            return parse_tables(tables,kind,plan_counts)
        finally:
            book.close()


def extract(mail, kind, explicit=False):
    parser = Tables()
    parser.feed(str(mail.HTMLBody or ''))
    body=str(mail.Body or '')
    if not parser.tables or kind=='out' and not any(not q for q,_ in parser.tables):
        plain=re.split(r'(?im)^\s*(?:from|từ)\s*:',body,maxsplit=1)[0] if kind=='out' else body
        table=[line.split('\t') for line in plain.splitlines() if '\t' in line]
        if table:
            parser.tables.append((False,table))
    current=[t for t in parser.tables if not t[0]]
    plan_counts={}
    rows, skipped, issues, found = parse_tables(current,kind,plan_counts)
    if kind=='out' and not found:
        # Outlook's plain body can place one Excel cell in each paragraph.
        latest=re.split(r'(?im)^\s*(?:from|từ)\s*:',body,maxsplit=1)[0]
        cells=[clean(v) for v in re.split(r'\n[ \t\r]*\n',latest.replace('\r\n','\n')) if clean(v)]
        for start,value in enumerate(cells[:-2]):
            if norm(value) not in ('stt','no') or norm(cells[start+1])!='model':continue
            first=next((j for j in range(start+2,min(len(cells),start+40)) if cells[j].isdigit()),None)
            if first is None:continue
            headers=cells[start:first]
            if 'kho' not in [norm(x) for x in headers]:continue
            table=[headers]
            pos=first
            while pos<len(cells) and cells[pos].isdigit():
                row=cells[pos:pos+len(headers)]
                if len(row)!=len(headers):break
                table.append(row)
                pos+=len(headers)
            rows,skipped,issues,found=parse_tables([(False,table)],kind,plan_counts)
            if found:
                if pos<len(cells) and cells[pos].isdigit():issues.append('Dòng cuối bảng thiếu ô')
                break
    if kind=='in' and not found:
        lead=norm(re.split(r'(?im)^\s*(?:from|từ)\s*:',str(mail.Body or ''),maxsplit=1)[0])
        if not any(k in lead for k in ('cancel','huykehoach','huydon','huylich')):
            rows, skipped, issues, found=parse_tables([t for t in parser.tables if t[0]],kind)
    subject = clean(mail.Subject)
    subject_key = norm(subject)
    relevant = explicit or found or (('od' in subject_key and ('khsx' in subject_key or 'nvl' in subject_key))
                                    if kind=='out' else any(k in subject_key for k in ('giaohang','hangve','delivery','shipment','asn')))
    attachments=getattr(mail,'Attachments',None)
    if attachments is not None and (kind=='in' or relevant):
        for i in range(1,attachments.Count+1):
            att=attachments.Item(i)
            name=str(att.FileName)
            ext=Path(name).suffix.lower()
            if ext in ('.xlsx','.xlsm'):
                try:
                    more,omitted,problems,recognized=spreadsheet_tables(att,kind,plan_counts)
                    if recognized:
                        relevant=found=True
                        if rows and more and (kind!='out' or {norm(r['material']) for r in rows} & {norm(r['material']) for r in more}):
                            issues.append('Có nhiều bảng kế hoạch · kiểm tra dòng trùng giữa nội dung và file '+name)
                        skipped+=omitted
                        rows.extend(more)
                        issues.extend(problems)
                    elif relevant and not found:
                        issues.append('Chưa nhận diện cột trong '+name)
                except Exception as exc:
                    relevant=True
                    issues.append(name+' · '+str(exc))
            elif relevant and not found and ext in ('.pdf','.xls','.xlsb','.csv','.zip'):
                issues.append('Cần kiểm tra file đính kèm '+name)
    if not relevant:
        return None
    if not found:
        issues.append('Cần kiểm tra mẫu hoặc file đính kèm · chưa đọc được bảng')
    lead = str(mail.Body or '').split('From:')[0].split('Từ:')[0].splitlines()[:10]
    revision = any(s in norm(' '.join(lead)) for s in ('cancel','huyod','huydon','huykehoach','huylich','guilai','thaythe','dieuchinh'))
    if revision:
        issues.append('Mail điều chỉnh / gửi lại · kiểm tra bản thay thế trước khi xử lý')
    if kind=='in':
        dates=re.findall(r'(?<!\d)(\d{1,2}[./-]\d{1,2}[./-]20\d{2})(?!\d)',subject)
        for r in rows:
            if not clean(r.get('arrival_plan')) and clean(r.get('delivery')):
                r['arrival_plan']=r['delivery']
            elif len(set(dates))==1 and day(dates[0]) and not clean(r.get('arrival_plan')):
                r['arrival_plan']=dates[0]
    if kind=='out':
        # A line may legitimately have a different date from another line in the mail.
        intro=' '.join(lead).split('STT')[0]
        plans=subject_plans(intro) or subject_plans(subject)
        shift_hint=re.search(r'(?i)\b(S[12367](?:\s*/\s*S[12367])*)\b',intro)
        if not shift_hint:
            shift_hint=re.search(r'(?i)\b(S[12367](?:\s*/\s*S[12367])*)\b',subject)
        if re.search(r'(?i)\bOD\s+KEO\b',subject):
            for r in rows:
                r['bbbg_only']=True
                r['model']=r.get('model') or 'KEO'
        if re.search(r'(?i)\bVF89\b',subject):
            for r in rows:
                if not r.get('model'):r['model_scope']=('vf8','vf9')
        if shift_hint:
            for r in rows:
                if not r.get('production_shift'):r['production_shift']=shift_label(shift_hint[1])

        if len(plans)==1:
            subject_day=next(iter(plans)).isoformat()
            unknown=plan_counts.pop('',{'H':0})
            plan_counts.setdefault(subject_day,{'H':0})['H']+=unknown['H']
            for r in rows:
                if not clean(r.get('plan')):
                    r['plan']=next(iter(plans)).isoformat()
                    r['plan_source']='Tiêu đề KHSX'
    received=mail.ReceivedTime
    try:
        mid=clean(mail.PropertyAccessor.GetProperty('http://schemas.microsoft.com/mapi/proptag/0x1035001F'))
    except Exception:
        mid=''
    result=dict(id=mid or str(mail.EntryID), subject=subject, sender=clean(mail.SenderName),
                received=received.strftime('%Y-%m-%d %H:%M:%S'), plan_counts=plan_counts, rows=rows, skipped=skipped, issues=issues)
    if kind=='out':
        import hashlib,json
        from collections import Counter
        repeats=Counter()
        for r in rows:
            identity=[result['id'],*[norm(r.get(k)) for k in ('material','model','station','leader','person','production_shift')],
                      str(quantity(r.get('qty'))),str(day(r.get('plan')))]
            key=json.dumps(identity,ensure_ascii=False)
            repeats[key]+=1
            r['mail_token_v2']=hashlib.sha256((key+'|'+str(repeats[key])).encode()).hexdigest()
    return result


def subject_plans(subject):
    # Model or shift text may occur between KHSX and the date (VF8NP NGÀY 23-Nov-26).
    if 'khsx' not in norm(subject):return set()
    dates=re.findall(r'(?i)(?<![0-9])(?:20[0-9]{2}-[0-9]{2}-[0-9]{2}|[0-9]{1,2}(?:[./-][0-9]{1,2}[./-]20[0-9]{2}|-[a-z]{3}-(?:20)?[0-9]{2}))(?![0-9])',subject)
    return {d for value in dates if (d:=day(value))}


def visible_out(message,selected):
    rows=message['rows']
    if selected=='Tất cả':return rows,message['skipped'],True
    rows=[r for r in rows if str(day(r.get('plan')))==selected]
    counts=message.get('plan_counts',{})
    return rows,counts.get(selected,{}).get('H',0),bool(rows or selected in counts)


def scan_folders(session,kind,folder_ids):
    if folder_ids:return [session.GetFolderFromID(*folder_ids)]
    inbox=session.GetDefaultFolder(6)
    folders=[inbox]
    if kind=='out':
        for parent in (inbox.Parent,inbox):
            collection=parent.Folders
            for i in range(1,collection.Count+1):
                child=collection.Item(i)
                if str(child.Name).strip().casefold()=='nvl' and child.EntryID!=inbox.EntryID:
                    folders.append(child)
    return folders


def outlook_scan(kind, since, paths=(), folder_ids=None, diagnostics=None):
    import win32com.client
    session=win32com.client.Dispatch('Outlook.Application').Session
    result=[]
    if paths:
        for path in paths:
            record=extract(session.OpenSharedItem(str(Path(path).resolve())),kind,True)
            if record:
                if not record['id'] or record['id']=='None':
                    record['id']=str(Path(path).resolve())
                result.append(record)
        return result
    for folder in scan_folders(session,kind,folder_ids):
        label=str(folder.FolderPath)
        if diagnostics is not None:diagnostics.setdefault('folders',[]).append(label)
        items=folder.Items
        items.Sort('[ReceivedTime]',True)
        item=items.GetFirst()
        while item is not None:
            if getattr(item,'Class',0)==43:
                received=item.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S')
                if datetime.fromisoformat(received)<since:break
                if diagnostics and diagnostics.get("until") and datetime.fromisoformat(received)>diagnostics["until"]:
                    item=items.GetNext();continue
                try:
                    record=extract(item,kind,explicit=bool(folder_ids) and kind=="in")
                except Exception as exc:
                    if diagnostics is None:raise
                    subject=clean(getattr(item,'Subject',''))
                    diagnostics.setdefault('errors',[]).append(label+' · '+received+' · '+subject+' · '+str(exc))
                    record=None
                    if kind=='out' and 'od' in norm(subject):
                        record=dict(id=str(item.EntryID),subject=subject,sender='',received=received,rows=[],skipped=0,
                                    plan_counts={d.isoformat():{'H':0} for d in subject_plans(subject)},
                                    issues=['Chưa đọc được nội dung thư · '+str(exc)])
                if record:result.append(record)
            item=items.GetNext()
    return result


def order_sheet(path,password):
    from zone_shift import load
    return load(path,password)[0]


def order_stamp(day_value, time_value):
    workday=day(day_value)
    if not workday:
        return None
    try:
        if isinstance(time_value,(float,int)) and 0<=time_value<1:
            return datetime.combine(workday,time.min)+timedelta(seconds=round(time_value*86400))
        clock=time_value.time() if isinstance(time_value,datetime) else time.fromisoformat(str(time_value))
        return datetime.combine(workday,clock)
    except (TypeError,ValueError,OverflowError):
        return None


def order_index(values):
    fields={3:('manvl','mahang'),4:('sloder','slorder','soluong'),5:('tram',),9:('model',),
            24:('tinhtrangcapdon',),26:('khsx',),28:('ngayorder',),29:('gioorder',),30:('nguoiorder',)}
    if not values or len(values[0])<31 or any(norm(values[0][i]) not in options for i,options in fields.items()):
        raise ValueError('Sheet ORDER khác mẫu. Kiểm tra tiêu đề D/E/F/J/Y/AA/AC/AD/AE.')
    result=defaultdict(list)
    for i,r in enumerate(values[1:],2):
        stamp=order_stamp(r[28],r[29])
        key=(norm(r[3]),quantity(r[4]),norm(r[9]),day(r[26]),norm(r[30]))
        if stamp and all(key) and norm(r[5]):
            result[(key,stamp,norm(r[5]))].append((i,norm(r[24])))
    return result


def prior_files(current,earliest,selected=()):
    from zone_shift import parsed_name,SUFFIXES
    current=Path(current)
    active=parsed_name(current)
    if not active:
        return [],['Tên file ca hiện tại chưa xác định']
    groups=defaultdict(list)
    for p in current.parent.iterdir():
        identity=parsed_name(p)
        if not identity or p.suffix.lower() not in SUFFIXES or not p.is_file():
            continue
        dt,team=identity
        earlier=dt<active[0] or dt==active[0] and team<active[1] and (team in ('S1','S2','S3'))==(active[1] in ('S1','S2','S3'))
        if earlier and dt>=earliest-timedelta(days=1):
            groups[identity].append(p)
    for manual in selected:
        manual=Path(manual)
        identity=parsed_name(manual)
        if (identity and identity!=active and identity[0]<=active[0] and manual!=current
                and identity[0]>=earliest-timedelta(days=1)):
            groups[identity]=[manual]
    paths=[]
    problems=[]
    for (dt,team),files in sorted(groups.items(),reverse=True):
        paths.extend(sorted(files,key=lambda p:(p.stat().st_mtime_ns,p.name),reverse=True))
    return paths,problems


def reconcile_order(messages,values,history=(),unread=(),index_override=None,origin_shift=None,schedule=None):
    current=order_index(values) if index_override is None else index_override
    # Merge snapshots by business identity. A carried line seen in several shifts is one order.
    evidence={identity:[('current',n,'') for n,_ in rows] for identity,rows in current.items()}
    for label,index in history:
        for identity,rows in index.items():
            done=[n for n,state in rows if state=='done']
            if not done:
                continue
            entries=evidence.setdefault(identity,[])
            # Only admit historical Done for occurrences missing in the current/newer snapshot.
            known_done=sum(state=='done' for _,state in current.get(identity,()))
            historical=sum(item[0]=='history' for item in entries)
            extra=min(len(done)-known_done-historical,len(rows)-len(entries))
            if extra>0:
                entries.extend(('history',n,label) for n in done[:extra])
    lookup=defaultdict(list)
    for (key,stamp,station),entries in evidence.items():
        lookup[key].append((stamp,station,entries))
    relaxed=defaultdict(list)
    if origin_shift:
        for key,possibilities in lookup.items():
            for stamp,station,entries in possibilities:
                relaxed[(key[0],key[1],key[3],key[4],station)].append((key[2],stamp,entries))
    by_material=defaultdict(list)
    for (key,stamp,station),entries in evidence.items():
        by_material[key[0]].append((key,stamp,station,entries))
    candidates=[]
    owners=defaultdict(set)
    for m in messages:
        received=datetime.fromisoformat(m['received'])
        m['history_unread']=list(unread)
        for r in m['rows']:
            key=(norm(r['material']),quantity(r['qty']),norm(r.get('model')),day(r.get('plan')),norm(r.get('person')))
            station,leader=norm(r.get('station')),norm(r.get('leader'))
            stations={s for s in (station,leader,station+leader) if s}
            nearby=[(stamp,entries) for stamp,s,entries in lookup[key] if s in stations and stamp.date()==received.date()]
            close=[entries for stamp,entries in nearby if abs((stamp-received).total_seconds())<=300]
            fallback=False
            if not close and origin_shift and receiving_shift(received,schedule or {})==origin_shift:
                choices=[entries for stamp,s,entries in lookup[key] if s in stations]
                if all(key) and len(choices)==1 and len(choices[0])==1:
                    close=choices
                    fallback=True
            ambiguous=False
            if not close and origin_shift and receiving_shift(received,schedule or {})==origin_shift and all(key):
                matches=[(model,stamp,entries) for station_key in stations
                         for model,stamp,entries in relaxed[(key[0],key[1],key[3],key[4],station_key)]]
                if len(matches)==1 and len(matches[0][2])==1:
                    model,stamp,entries=matches[0]
                    if model==key[2] or model=='limo' and key[2] in ('limorhd','limolhd','dungchung'):
                        close=[entries]
                        fallback=True
                    else:ambiguous=True
                elif matches:ambiguous=True
            r['date_mismatch']=fallback
            hits=[item for entries in close for item in entries]
            hits.sort(key=lambda e:e[0]!='current')
            for item in hits:
                owners[item].add(m['id'])
            elsewhere=sorted({stamp for stamp,s,entries in lookup[key] if s in stations})
            times=', '.join(d.strftime('%d/%m %H:%M') for d in elsewhere[:3])
            review='Kiểm tra ngày giờ · Excel '+times+' · nhận '+received.strftime('%d/%m %H:%M') if not hits and times else ''
            if ambiguous:review='Có dòng cùng mã, SL, trạm, KHSX và người OD · cần kiểm tra model/dòng trùng'
            if len(close)>1:
                review='Nhiều giờ OD hoặc trạm cùng khớp · kiểm tra trước khi xác nhận'
                hits=[]
            if not all(key) or not stations:
                review='Thiếu mã, SL, model, KHSX, người OD hoặc trạm để xác minh'
            if not hits and (r.get('model_scope') or not r.get('warehouse') or not key[4]):
                scope=r.get('model_scope',())
                possible=[items for k,t,s,items in by_material[key[0]]
                          if k[1]==key[1] and k[3]==key[3] and s in stations
                          and (k[2] in scope if scope else not key[2] or k[2]==key[2])
                          and (not key[4] or key[4]==k[4]) and abs((t-received).total_seconds())<=300]
                if len(possible)==1 and len(possible[0])==1:hits=possible[0]
                elif possible:review='Có nhiều lượt ORDER phù hợp · kiểm tra model và dòng'
                elif by_material[key[0]] and (not review or review.startswith('Thiếu ')):
                    review='Có lịch sử mã · chưa khớp lượt OD'
            if review.startswith('Thiếu mã, SL'):
                fields=zip(('mã','SL','model','KHSX','người OD','trạm'),(*key,stations))
                review='Thiếu '+', '.join(label for label,value in fields if not value)+' để xác minh'
            candidates.append((r,hits,review))
    used=set()
    for r,hits,review in candidates:
        r.pop('_review',None)
        r.pop('match_line',None)
        r.pop('short_occurrence',None)
        if any(len(owners[item])>1 for item in hits):
            code,text='review','Nhiều mail trùng dòng ORDER · kiểm tra bản gửi lại'
        else:
            match=next((item for item in hits if item not in used),None)
            if match:
                used.add(match)
                code,n,label=match
                r['match_line']=n
                text=(f'Đã copy · ORDER dòng {n}' if code=='current' else f'Đã copy · Done ca trước · {label} · dòng {n}')
            elif review or hits:
                if hits and not review:r['short_occurrence']=True
                code,text='review',review or 'Dòng ORDER đã khớp với một dòng khác trong mail'
            elif unread:
                code,text='unverified','Chưa khớp ca này · chưa xác minh đủ file ca trước'
            else:
                code,text='missing','Chưa thấy trong ORDER hiện tại và các ca đã đọc'
        r.update(match_state=code,status=text)


def receiving_shift(stamp,schedule):
    if schedule.get('_team_system') in ('S1','S2','S3'):
        hour=stamp.hour
        team='S1' if 6<=hour<14 else 'S2' if 14<=hour<22 else 'S3'
        return stamp.date()-timedelta(days=int(hour<6)),team
    begin,end=(time.fromisoformat(schedule.get(k,v)) for k,v in [('day_start','06:00'),('night_start','18:00')])
    if begin>=end:
        raise ValueError('Giờ bắt đầu ca ngày phải trước giờ bắt đầu ca đêm.')
    clock=stamp.time()
    if begin<=clock<end:
        return stamp.date(),'S6'
    return stamp.date()-timedelta(days=int(clock<begin)),'S7'


def workbook_evidence(messages,path,password,passwords,cache,current,selected,schedule):
    from zone_shift import historical_order,parsed_name
    from zone_order_result import file_key
    active=parsed_name(path)
    table=current if current is not None else order_sheet(path,password)
    earliest=min((datetime.fromisoformat(m['received']).date() for m in messages),default=active[0])
    if schedule.get('_scan_since'):earliest=min(earliest,date.fromisoformat(schedule['_scan_since']))
    need_history=any(receiving_shift(datetime.fromisoformat(m['received']),schedule)!=active or any('điều chỉnh' in x for x in m['issues']) for m in messages)
    paths,unread=prior_files(path,earliest,selected) if need_history else ([],[])
    sources={active:(Path(path).name,order_index(table))}
    for p in paths:
        if parsed_name(p) in sources:continue
        key=file_key(p)
        try:
            index=historical_order(p,passwords.get(key) or password,cache,order_index)
            sources[parsed_name(p)]=(p.name,index)
        except Exception as exc:
            unread.append(p.name+' · '+str(exc))
    return table,active,sources,unread


def closed_snapshot(path, closed_rows=None, expected=None):
    """Cache and reuse OD_DA_DONG rows per workbook signature without re-opening Excel."""
    import json, os, zlib
    import zone18
    import zone_shift as sh
    file_id=os.path.normcase(str(Path(path).resolve()))
    current=sh.signature(path)
    if expected is not None and current!=expected:return None
    stamp=json.dumps(current)
    with zone18.journal() as conn:
        if closed_rows is not None:
            data=zlib.compress(json.dumps(closed_rows,ensure_ascii=False,default=str).encode(),1)
            conn.execute('INSERT OR REPLACE INTO order_closed VALUES(?,?,?)',(file_id,stamp,data))
            return closed_rows
        hit=conn.execute('SELECT data FROM order_closed WHERE path=? AND stamp=?',(file_id,stamp)).fetchone()
        if hit:return tuple(tuple(row) for row in json.loads(zlib.decompress(hit[0])))
    return None


def _read_closed_sheet(book):
    try:
        sheet=book.Worksheets('OD_DA_DONG')
    except Exception:
        return ()
    end=max(1,int(sheet.Cells(sheet.Rows.Count,1).End(-4162).Row))
    if end<2:
        return ()
    vals=sheet.Range(f'A2:AK{end}').Value2
    if not vals:
        return ()
    if not isinstance(vals,tuple):vals=((vals,),)
    elif vals and not isinstance(vals[0],tuple):vals=(vals,)
    return tuple(tuple(r) for r in vals if r and any(clean(c) for c in r[:7]))


def closed_entries(path, password, passwords, cache, extra_paths=()):
    """Collect OD_DA_DONG records across the active workbook and opened/cached history files."""
    import json
    import zone_shift as sh
    import zone_excel_live as live
    from zone_order_result import file_key
    entries=[]
    seen=set()
    targets=[Path(path), *(Path(p) for p in extra_paths)]
    for target in targets:
        try:
            key=file_key(target)
        except OSError:
            continue
        if key in seen:continue
        seen.add(key)
        rows_data=None
        with live.order_access(target):
            book=live.find(target)
            if book is not None:
                rows_data=_read_closed_sheet(book)
            else:
                cache_key=(key,'closed')
                try:
                    stamp=sh.signature(target)
                except OSError:
                    continue
                if cache_key in cache and cache[cache_key][0]==stamp:
                    rows_data=cache[cache_key][1]
                else:
                    cached=closed_snapshot(target)
                    if cached is not None:
                        rows_data=cached
                    else:
                        pw=passwords.get(key) or password
                        try:
                            with sh.excel_book(target,pw,False) as opened:
                                rows_data=_read_closed_sheet(opened)
                            closed_snapshot(target,list(rows_data),expected=stamp)
                        except Exception:
                            rows_data=()
                    cache[cache_key]=(stamp,rows_data)
        fname=target.name
        for raw in rows_data or ():
            if len(raw)<12:continue
            reason=clean(raw[0]) or 'Đã đóng'
            orig=raw[2:]
            mat=norm(orig[3]) if len(orig)>3 else ''
            if not mat:continue
            qty_val=quantity(orig[4]) if len(orig)>4 else None
            station_val=norm(orig[5]) if len(orig)>5 else ''
            model_val=norm(orig[9]) if len(orig)>9 else ''
            plan_val=day(orig[26]) if len(orig)>26 else None
            person_val=norm(orig[30]) if len(orig)>30 else ''
            mail_tok=''
            if len(orig)>34 and orig[34]:
                try:mail_tok=str(json.loads(orig[34]).get('mail_row') or '')
                except (TypeError,ValueError,AttributeError):pass
            entries.append((fname,reason,mail_tok,mat,qty_val,model_val,plan_val,station_val,person_val))
    return entries


def apply_closed_od(messages, closed):
    if not closed:return
    by_token={}
    by_sig=defaultdict(list)
    for fname,reason,tok,mat,qty_val,model_val,plan_val,station_val,person_val in closed:
        if tok:by_token[tok]=(fname,reason)
        by_sig[(mat,qty_val,plan_val)].append((fname,reason,model_val,station_val,person_val))
    for m in messages:
        for i,r in enumerate(m['rows']):
            r.pop('closed_od',None)
            if r.get('match_state') not in ('missing','unverified','review'):continue
            tok=mail_token(m,i)
            leg=legacy_token(m,i)
            hit=by_token.get(tok) or by_token.get(leg)
            if not hit:
                mat=norm(r.get('material'))
                qty_val=quantity(r.get('qty'))
                plan_val=day(r.get('plan'))
                model_val=norm(r.get('model'))
                person_val=norm(r.get('person'))
                station,leader=norm(r.get('station')),norm(r.get('leader'))
                stations={s for s in (station,leader,station+leader) if s}
                for fname,reason,c_model,c_sta,c_person in by_sig.get((mat,qty_val,plan_val),()):
                    if (not model_val or not c_model or model_val==c_model) and (not stations or c_sta in stations) and (not person_val or not c_person or person_val==c_person):
                        hit=(fname,reason)
                        break
            if hit:
                fname,reason=hit
                r['closed_od']=f'{reason} ({fname})'
                r.update(match_state='archived',status=f'Đã đóng trong OD_DA_DONG · {reason} ({fname})')


def audit_workbooks(messages,path,password,passwords,cache,current=None,selected=(),schedule=None,scan_gaps=None):
    from zone_shift import parsed_name
    schedule=dict(schedule or {}, _team_system=(parsed_name(path) or (None,''))[1])
    table,active,sources,unread=workbook_evidence(messages,path,password,passwords,cache,current,selected,schedule)
    if scan_gaps is not None:
        scan_gaps['files']=[name for name,_ in sources.values()]
        scan_gaps['unread']=list(unread)
    archives=[v for k,v in sources.items() if k!=active]
    reconcile_order(messages,table,archives,unread)
    # Validate each mail against its original shift, even when copied into the current file.
    for identity,(name,index) in sources.items():
        matches=[{'id':m['id'],'received':m['received'],'issues':m.get('issues',()),'rows':[dict(r) for r in m['rows']]} for m in messages]
        reconcile_order(matches,None,index_override=index,origin_shift=identity,schedule=schedule)
        if scan_gaps is not None and scan_gaps.get('range'):
            matched={r['match_line'] for m in matches for r in m['rows'] if r.get('match_line')}
            first,last=scan_gaps['range']
            for (key,stamp,station),entries in index.items():
                if first<=stamp<=last and receiving_shift(stamp,schedule)==identity and key[-1]!='bosungkhop':
                    for n,_ in entries:
                        if n not in matched:
                            scan_gaps['rows'].append((name,n,key[0].upper(),key[1],key[3],stamp))
        for msg,result in zip(messages,matches):
            origin=receiving_shift(datetime.fromisoformat(msg['received']),schedule)
            msg['receive_shift']=f'{origin[1]} {origin[0]:%d/%m/%Y}'
            for r,found in zip(msg['rows'],result['rows']):
                if origin==identity:
                    r['origin_line']=found.get('match_line') if found['match_state']=='current' else None
                    if found['match_state']=='current' and found.get('date_mismatch') and not msg.get('issues'):
                        if identity==active:
                            r.update(match_state='current',match_line=found['match_line'])
                        elif r['match_state'] not in ('current','history'):
                            r.update(match_state='archived')
                        r['status']=f'Đã có trong ORDER · {name} dòng {found["match_line"]} · khác giờ OD hoặc cách ghi model'
                if found['match_state']=='current' and identity!=active and r['match_state'] in ('missing','unverified'):
                    r.update(match_state='archived',status=f'Đã copy · {name} dòng {found["match_line"]} · kiểm tra bàn giao')
                if found['match_state']=='review' and r['match_state'] in ('missing','unverified'):
                    r.update(match_state='review',status=found['status'])
    # Near-identical rows with a changed qty/model/person/date are unsafe to append.
    related=defaultdict(set)
    for _,index in sources.values():
        for (key,stamp,station),entries in index.items():
            related[(key[0],stamp.date())].add((stamp,station))
    tracked={}
    for ident,(fname,idx) in sorted(sources.items()):
        line_keys={}
        for entry,positions in idx.items():
            for n,state in positions:line_keys[n]=entry
        tracked[ident]=(idx,line_keys,fname)
    active_material_days={(norm(row[3]),day(row[26])) for row in table[1:]}
    active_lines=defaultdict(list)
    for n,line in enumerate(table[1:],2):
        if clean(line[3]):active_lines[norm(line[3])].append(str(n))
    for msg in messages:
        stamp=datetime.fromisoformat(msg['received'])
        origin=receiving_shift(stamp,schedule)
        for r in msg['rows']:
            r.pop('supply_state',None)
            r['origin_checked']=origin in sources
            if origin not in sources:
                r['origin_line']=None
            if (origin==active and r['match_state']=='review' and r['status'].startswith('Thiếu ') and not clean(r.get('person'))
                    and all((quantity(r.get('qty')),clean(r.get('model')),clean(r.get('station')),day(r.get('plan'))))
                    and (norm(r['material']),day(r['plan'])) not in active_material_days):
                r.update(match_state='missing',status='Chưa copy vào ORDER ca nhận · cần nhập người OD trước khi ghi')
            if not r.get('warehouse') and r['match_state'] not in ('current','archived','history'):
                occurrence=active_lines.get(norm(r['material']),())
                r.update(match_state='review',status='Mail thiếu cột Kho · '+('lịch sử mã trong ORDER dòng '+', '.join(occurrence) if occurrence else 'chưa thấy lịch sử mã trong file ca'))
            if origin==active and not active_lines.get(norm(r['material'])) and not msg.get('issues') and r['match_state'] in ('review','unverified','missing'):
                r.update(match_state='missing',status='Chưa copy · file ca nhận chưa có mã này')
                if not r.get('warehouse'):r['status']+=' · mail thiếu cột Kho, chỉ tra cứu'
            if r.get('warehouse') and r.get('short_occurrence') and origin in sources and not unread and not r.get('origin_line'):
                r.update(match_state='missing',status='Số dòng P trùng trong mail nhiều hơn số dòng ORDER đã copy')
            if r['match_state']=='unverified' and origin==active and not r.get('short_occurrence'):
                r.update(match_state='missing',status='Chưa thấy dòng trong file ca nhận hiện tại')
            if r['match_state']=='missing' and not r.get('short_occurrence'):
                stations={norm(r.get('station')),norm(r.get('station'))+norm(r.get('leader'))}
                if any(s in stations and abs((t-stamp).total_seconds())<=300 for t,s in related[norm(r['material']),stamp.date()]):
                    r.update(match_state='review',status='Trùng mã, trạm và giờ OD · kiểm tra SL hoặc các dòng lặp')
            if origin not in sources:
                if r['match_state']=='missing':
                    r.update(match_state='unverified',status='Chưa có file ca nhận mail để kiểm tra')
                msg['history_unread']=list(dict.fromkeys([*msg.get('history_unread',[]),'Thiếu file '+msg['receive_shift']]))
            elif r.get('origin_line'):
                if r['match_state'] not in ('current','history','archived') and not msg.get('issues'):
                    r.update(match_state='archived',status='Đã copy · file ca nhận')
                key=tracked[origin][1].get(r['origin_line'])
                latest='Đã copy · chưa có số cấp sau bàn giao'
                for ident,(idx,_,fname) in tracked.items():
                    if ident<origin or not key:continue
                    positions=idx.get(key,())
                    if len(positions)==1:
                        n,st=positions[0]
                        if ident==active or st=='done':
                            latest={'done':'Done','partialfinished':'Cấp một phần','pending':'Pending'}.get(st,'Cần kiểm tra')
                            if ident==active and norm(table[n-1][27])=='hettonkhoma':latest+=' · hết tồn'
                        else:
                            last={'partialfinished':'Cấp một phần','pending':'Pending'}.get(st,st)
                            latest=f'Lần ghi gần nhất {ident[0]:%d/%m} {ident[1]} · {last}'
                r['supply_state']=latest
                r['status']+=' · '+latest
                r['status']+=f' · ca nhận dòng {r["origin_line"]}'
            elif origin!=active and r['match_state']=='current':
                r['status']+=' · đã copy ở ca sau'
            if r.get('match_state')=='current':
                import json
                line=table[r['match_line']-1]
                try:
                    origin_token=json.loads(line[34]).get('mail_row') if len(line)>34 and line[34] else ''
                except (TypeError,ValueError,AttributeError):
                    origin_token=''
                r['status']+=' · app đã ghi' if origin_token else ' · có trong Excel'
    try:
        extra_files=[Path(path).parent/name for ident,(name,_) in sources.items() if ident!=active]
        closed=closed_entries(path,password,passwords,cache,(*selected,*extra_files))
        apply_closed_od(messages,closed)
    except Exception:
        pass
    return table


def mail_token(message,row_index):
    import hashlib
    return message['rows'][row_index].get('mail_token_v2') or legacy_token(message,row_index)


def legacy_token(message,row_index):
    import hashlib
    return hashlib.sha256(f"{message['id']}|{row_index}".encode()).hexdigest()


def receipts(folder,tokens=(),remove=()):
    import os
    import zone18 as z
    where=os.path.normcase(str(Path(folder).resolve()))
    with z.journal() as conn:
        if remove:
            conn.executemany('DELETE FROM mail_write WHERE folder=? AND token=?',[(where,t) for t in remove])
        if tokens:
            conn.executemany('INSERT OR IGNORE INTO mail_write VALUES(?,?)',[(where,t) for t in tokens])
        return {v for v, in conn.execute('SELECT token FROM mail_write WHERE folder=?',(where,))}


def explicit_odbs(text):
    words=unicodedata.normalize('NFD',clean(text).casefold().replace('đ','d'))
    words=''.join(c for c in words if not unicodedata.combining(c))
    return bool(re.search(r'\bod\s*bs\b|\b(?:od|order|don(?: hang)?|hang)\s+bo\s+sung\b',words)
                or words.strip()=='bo sung')


def order_bindings(table):
    """Excel's mail token survives row movement. Fall back to a unique ORDER identity."""
    from collections import Counter
    import json
    import zone_shift as sh
    cached=getattr(table,'mail_binding_index',None)
    if cached is not None:return cached
    identities=[(n,row,key,sh.row_identity(row)) for n,row,key in sh.indexed(table)]
    counts=Counter(identity for n,row,key,identity in identities)
    bindings={}
    for n,row,key,identity in identities:
        token=None
        if len(row)>34 and row[34]:
            try:token=json.loads(row[34]).get('mail_row')
            except (ValueError,TypeError,AttributeError):pass
        if token:bindings[n]=(key,'mail:'+str(token))
        elif counts[identity]==1:bindings[n]=(key,'order:'+key)
    uses=Counter(binding for _,binding in bindings.values())
    bindings={n:item for n,item in bindings.items() if uses[item[1]]==1}
    if hasattr(table,'line_index'):table.mail_binding_index=bindings
    return bindings


def odbs_links(path,updates=()):
    from zone_order_result import file_key
    import zone18
    order=file_key(path)
    with zone18.journal() as conn:
        if updates:
            conn.executemany('INSERT OR REPLACE INTO mail_odbs VALUES(?,?,?)',
                             [(order,token,binding) for token,binding in updates])
        return {key for key, in conn.execute('SELECT binding FROM mail_odbs WHERE order_file=?',(order,))}


def inherit_odbs(old_path, old_table, new_path, new_table):
    """Carry ODBS labels across shift handover (e.g., S7 -> S6) without altering Excel NOTE."""
    from zone_order_result import file_key
    import zone18
    if not old_path or not new_path or not old_table or not new_table:
        return set()
    old_file=file_key(old_path)
    new_file=file_key(new_path)
    if old_file==new_file:
        return odbs_links(new_path)
    with zone18.journal() as conn:
        saved=conn.execute('SELECT token, binding FROM mail_odbs WHERE order_file=?',(old_file,)).fetchall()
        existing={key for key, in conn.execute('SELECT binding FROM mail_odbs WHERE order_file=?',(new_file,))}
    if not saved:
        return existing
    saved_bindings={b:t for t,b in saved}
    old_bindings=order_bindings(old_table)
    new_bindings=order_bindings(new_table)
    old_keys={key:b for _,(key,b) in old_bindings.items() if b in saved_bindings}
    updates=[]
    for _,(new_key,new_binding) in new_bindings.items():
        if new_binding in existing:
            continue
        if new_binding in saved_bindings:
            updates.append((saved_bindings[new_binding],new_binding))
        elif new_key in old_keys:
            updates.append((saved_bindings[old_keys[new_key]],new_binding))
    return odbs_links(new_path,updates)


def link_odbs(path,table,messages,known):
    selected=[]
    for message in messages:
        marked=explicit_odbs(message.get('subject'))
        for i,row in enumerate(message['rows']):
            token=mail_token(message,i)
            row['odbs']=(row.get('warehouse','').upper()!='H' and
                         (marked or explicit_odbs(row.get('note')) or 'odbs:'+token in known))
            if row['odbs'] and row.get('match_state')=='current' and row.get('match_line'):
                selected.append((token,legacy_token(message,i),row['match_line'],norm(row.get('material'))))
    updates=[]
    if selected:
        bindings=order_bindings(table)
        for token,legacy,n,material in selected:
            if n not in bindings or not material or norm(table[n-1][3])!=material:continue
            key=bindings[n][1]
            if key.startswith('order:') or key in ('mail:'+token,'mail:'+legacy):
                updates.append((token,key))
    return odbs_links(path,updates)


def flag_receipts(messages,known,session_observed=()):
    session_set=set(session_observed)
    for m in messages:
        for i,r in enumerate(m['rows']):
            token=mail_token(m,i)
            r['copy_confirmed']='manual:'+token in known
            r['copy_observed']='observed:'+token in known or token in session_set
            r['copy_saved']=token in known or legacy_token(m,i) in known
            if r['copy_confirmed'] or r.get('closed_od'):continue
            if r.get('match_state') in ('missing','unverified') and (mail_token(m,i) in known or legacy_token(m,i) in known):
                r.update(match_state='review',status='App từng ghi và đọc lại thành công · kiểm tra dòng đổi hoặc đã xóa')
            elif r.get('match_state') in ('missing','unverified') and r['copy_observed']:
                r.update(match_state='review',status='Cần đối chiếu · từng thấy trong ORDER nhưng hiện chưa có trong file đã lưu')


def shift_label(value):
    parts=re.split(r'\s*(?:/|,|;|&|\+|\bvà\b)\s*',clean(value).upper(),flags=re.I)
    if not all(re.fullmatch('S[12367]',p) for p in parts):return ''
    return '/'.join(sorted(set(parts)))


def blocking(message):
    return any(not issue.startswith(('Kho chưa xác định','Thiếu mã hoặc SL chưa rõ')) for issue in message.get('issues',()))


def append_missing(messages,wanted,path,password,passwords,cache,selected,cfg,config,expected,progress,allow_observed=False):
    from zone_order_result import writable_order,append_mail_block
    import zone_shift as sh
    import json
    with writable_order(path,password) as (book,sheet,shared):
        current=sh.values(sheet)
        # Recheck only selected demand against the writable, live workbook.
        if current!=expected:
            from copy import deepcopy
            old_rows=set(map(tuple,expected[1:]))
            changed={(norm(row[3]),day(row[26])) for row in current[1:] if tuple(row) not in old_rows}
            fresh=deepcopy(messages)
            reconcile_order(fresh,current)
            for msg in fresh:
                for i,line in enumerate(msg['rows']):
                    token=mail_token(msg,i)
                    if token not in wanted:continue
                    if line.get('match_state')=='current':
                        wanted.discard(token)
                        original=next(m for m in messages if m['id']==msg['id'])
                        original['rows'][i].update(line)
                    elif (norm(line['material']),day(line.get('plan'))) in changed:
                        raise ValueError(line['material']+' · dòng OD liên quan vừa thay đổi, kiểm tra dòng đang chọn.')
        known=receipts(Path(path).parent)
        for row in current[1:]:
            if len(row)>34 and row[34]:
                try:known.add(json.loads(row[34])['mail_row'])
                except (TypeError,ValueError,KeyError):pass
        flag_receipts(messages,known)
        records=[]
        tokens=[]
        for m in messages:
            received=datetime.fromisoformat(m['received'])
            for i,r in enumerate(m['rows']):
                token=mail_token(m,i)
                if (token not in wanted or token in known or (not allow_observed and "observed:"+token in known)
                        or "manual:"+token in known or legacy_token(m,i) in known or r.get('closed_od') or blocking(m)):
                    continue
                if r.get('warehouse','').upper()!='P':
                    continue
                station=r.get('resolved_station') or ' '.join(filter(None,(r.get('station'),r.get('leader'))))
                production_shift=r.get('production_shift') or r.get('confirmed_shift') or ('/' if r.get('bbbg_only') else '')
                if not production_shift:
                    options={clean(line[11]) for _,line in sh.rows(current) if
                             norm(line[9])==norm(r['model']) and day(line[26])==day(r['plan']) and clean(line[11])}
                    if len(options)!=1:raise ValueError(f"{r['material']} thiếu Ca chạy. Chọn ca chạy trước khi ghi.")
                    production_shift=options.pop()
                fields={4:r['material'],5:float(quantity(r['qty'])),6:station,7:config['plant'],
                        8:config['sloc_from'],9:config['sloc_to'],10:r['model'],11:sh.parsed_name(path)[1],
                        12:production_shift,27:(day(r['plan'])-day(0)).days,28:'Chỉ lập BBBG' if r.get('bbbg_only') else 'Chưa ra đơn',
                        29:(received.date()-day(0)).days,30:(received.hour*3600+received.minute*60+received.second)/86400,
                        31:r['person'],35:json.dumps({'mail_row':token, 'bbbg_only':bool(r.get('bbbg_only'))})}
                for col in (7,8,9):
                    value=clean(fields[col])
                    if value.isascii() and value.isdecimal() and value==str(int(value)):
                        fields[col]=int(value)
                if tuple(current[0][32:34])==(sh.BASE_QTY,sh.BASE_NOTE):
                    fields[33]=0
                records.append(fields)
                tokens.append(token)
        def validate(data,first):
            written_at.update((token,first+i) for i,token in enumerate(tokens))
            for offset,fields in enumerate(records):
                row=data[first+offset-1]
                if any(clean(row[c-1])!=clean(v) for c,v in fields.items() if c!=30) or abs(row[29]-fields[30])>1/86400:
                    raise ValueError('Dòng OD đọc lại chưa khớp mail.')
                if sh.state(row)!='pending' or float(row[22] or 0)!=0:
                    raise ValueError('Dòng OD mới chưa ở trạng thái chờ cấp.')
        written_at={}
        if records:
            updated=append_mail_block(book,sheet,current,records,validate,progress)
    if records:
        check=updated
        for m in messages:
            for i,r in enumerate(m['rows']):
                if mail_token(m,i) in tokens:
                    r.update(match_state='current',status='Đã copy · đã lưu trong ORDER',supply_state='Pending',
                             copy_saved=True,match_line=written_at[mail_token(m,i)])
        try:receipts(Path(path).parent,tokens,remove=['observed:'+t for t in tokens])
        except Exception as exc:raise ValueError('Excel đã lưu. Cần đối chiếu lại nhật ký: '+str(exc))
        progress(f'100% · Đã lưu {len(records)} dòng P')
    return messages,(check if records else current),len(records)
