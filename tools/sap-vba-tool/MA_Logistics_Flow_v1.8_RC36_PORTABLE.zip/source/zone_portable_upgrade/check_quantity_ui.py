"""Exercise the embedded Tk UI with 1,257 synthetic tickets and an XLSX-backed Office adapter."""
from pathlib import Path
from types import SimpleNamespace as S
from unittest.mock import patch
import sys,tkinter as tk,tempfile,os
import check_portable as cp
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[2]/'MA_Logistics_Flow.exe'
_,entries,_=cp.archive(p.read_bytes())
mods=cp.pyz_entries(cp.payload(next(e for e in entries.values() if e[3]==b'z')))
sys.meta_path.insert(0,cp.EmbeddedSource(mods))
import zone_workspace as ws,sap_zone_core as core,sap_zone_gui as gui
import threading, time, traceback
from contextlib import contextmanager, ExitStack
from datetime import datetime
from openpyxl import Workbook,load_workbook
from openpyxl.utils.cell import range_boundaries
import zone_qty as q,zone_shift as sh,zone_mail as mail
from tkinter import ttk
now=time.perf_counter

class FakeBook:
    def __init__(self,path):
        wb=self.wb=Workbook()
        self.sheet=wb.active
        self.sheet.title='ORDER'
        head=[None]*35
        for c,v in sh.FIELD_NAMES.items(): head[c]=v
        head[-1]=sh.TRACK
        self.sheet.append(head)
        for i in range(419):
            row=[None]*35
            row[3:10]=[f'MAT-{i:04}',100,'Trạm '+str(i%8),'3093','P','L','VF7']
            row[11]='S6'
            row[24:28]=['Pending',None,'2026-11-22','Đã ra đơn, chờ cấp']
            for j,slot in enumerate(q.SLOTS):
                row[slot:slot+2]=[str(1000000000+i*3+j),f'{i+1:04}-{j+1}']
            if i in (216,217):row[q.SLOTS[i-215]]='1013345776'
            self.sheet.append(row)
        self.path=path
        self.wb.save(path)
        self.Saved=True
        self.saves=0
        self.writes=[]
        self.last_save=0
        self.Rows=S(Count=1048576)
    def Save(self):
        self.wb.save(self.path)
        self.saves+=1
        self.Saved=True
        self.last_save=now()
    def Calculate(self):
        pass
    def Range(self,addr):
        c1,r1,c2,r2=range_boundaries(addr)
        return ExcelRange(self,c1,r1,c2,r2)
    def Cells(self,r,c):
        return ExcelRange(self,c,r,c,r)

class ExcelRange:
    def __init__(self,b,c1,r1,c2,r2):
        self.b,self.c1,self.r1,self.c2,self.r2=b,c1,r1,c2,r2
    def End(self,mode):
        return S(Row=420)
    @property
    def HasFormula(self):
        return self.b.sheet.cell(self.r1,self.c1).data_type=='f'
    @property
    def Value2(self):
        s=self.b.sheet
        if (self.r1,self.c1)==(self.r2,self.c2):
            return s.cell(self.r1,self.c1).value
        return tuple(tuple(s.cell(r,c).value for c in range(self.c1,self.c2+1)) for r in range(self.r1,self.r2+1))
    @Value2.setter
    def Value2(self,data):
        if self.r1==self.r2 and self.c1==self.c2:data=((data,),)
        self.b.writes.append((self.c1,self.r1,self.r2))
        self.b.Saved=False
        for i,row in enumerate(data):
            for j,val in enumerate(row):self.b.sheet.cell(self.r1+i,self.c1+j).value=val

def wait(root,predicate):
    until=now()+8
    while not predicate():
        root.update()
        if now()>until:raise RuntimeError('Timed out')
        time.sleep(.001)
    root.update()

def widgets(w):
    yield w
    for child in w.winfo_children():yield from widgets(child)

def button(w,text):
    return next(child for child in widgets(w) if isinstance(child,(ttk.Button,tk.Button)) and child['text']==text)

with tempfile.TemporaryDirectory() as d, ExitStack() as ctx:
    path=Path(d)/'261122_THEO DOI ORDER NVL_P_S6.xlsx'
    book=FakeBook(path)
    @contextmanager
    def writable(path,password):
        # An isolated Office adapter for testing. Uses a real XLSX on disk.
        yield book,book,True
    ctx.enter_context(patch.object(ws,'start_workspace'))
    ctx.enter_context(patch.object(core,'get_base_dir',return_value=d))
    ctx.enter_context(patch.object(core.SapConnector,'init_thread_com'))
    ctx.enter_context(patch.object(core.SapConnector,'uninit_thread_com'))
    ctx.enter_context(patch.object(q,'writable_order',writable))
    os.environ['LOCALAPPDATA']=d
    r=tk.Tk()
    errors=[]
    r.report_callback_exception=lambda ex,val,tb:errors.append(''.join(traceback.format_exception(ex,val,tb)))
    warnings=ctx.enter_context(patch.object(q.messagebox,'showwarning'))
    app=gui.SapZoneApp(r)
    r.geometry('1000x670')
    app.show_order_page()
    r.update()
    app.mock_mode_var.set(False)
    pg=app.shift_page
    rows=sh.values(book)
    pg.activate(path,None,(rows,sh.signature(path)))
    r.update()
    assert pg.reporting.dirty and not pg.reporting.sheets
    def do_open():
        start=now()
        button(r,'Nhập SL…').invoke()
        r.update()
        return (now()-start)*1000
    first=do_open()
    ed=pg.qty_editor
    assert len(ed.shown)==1257
    r.focus_force()
    ed.search.focus_set()
    r.update()
    ed.close()
    r.update()
    reopened=[]
    for _ in range(5):
        reopened.append(do_open())
        assert r.focus_get()==ed.search,(r.focus_get(),ed.search)
        ed.close()
        r.update()
    do_open()
    # Go to mail via the same navigation controls an operator uses.
    button(r,'Check mail OD').invoke()
    r.update()
    start_scan=threading.Event()
    release_scan=threading.Event()
    def outlook(*_):
        start_scan.set()
        release_scan.wait(8)
        return [dict(id='od1',received='2026-11-22T08:30:00',subject='Test OD',sender='Test',issues=[],rows=[],skipped=0)]
    ctx.enter_context(patch.object(mail,'outlook_scan',outlook))
    ctx.enter_context(patch.object(mail,'order_sheet',return_value=rows))
    ctx.enter_context(patch.object(mail,'audit_workbooks'))
    app.out_mail.scan()
    wait(r,start_scan.is_set)
    assert app.out_mail.busy and not app.is_running
    app.show_order_page()
    r.update()
    assert ed.active and r.focus_get()==ed.search
    ed.query.set('4577')
    start=now()
    ed.search.insert('end','6')
    ed.search.event_generate('<Return>')
    r.update()
    search_time=(now()-start)*1000
    assert len(ed.shown)==2 and ed.editor[1]==ed.shown[0], ed.shown
    for val,mat in [('28+15','MAT-0216'),('8+7','MAT-0217')]:
        entry,iid,_=ed.editor
        assert ed.table.tickets[iid][3]==mat
        entry.insert(0,val)
        if val=='28+15':
            button(r,'Check mail OD').invoke()
            r.update()
            app.show_order_page()
            r.update()
            assert r.focus_get()==entry and entry.get()=='28+15'
            release_scan.set()
            wait(r,lambda:not app.out_mail.busy)
            assert entry.get()=='28+15' and r.focus_get()==entry
        entry.event_generate('<Return>')
        r.update()
    assert [int(ed.drafts[i]) for i in ed.shown]==[43,15]
    assert ed.tree.rows[0][-1]=='43'
    # Keep a scan in flight across Ctrl+S itself.
    start_scan.clear()
    release_scan.clear()
    app.out_mail.scan(auto=True)
    wait(r,start_scan.is_set)
    ed.search.event_generate('<Control-s>')
    wait(r,lambda:not ed.busy)
    assert book.saves==1 and not ed.drafts and r.focus_get()==ed.search and app.out_mail.busy
    after=(now()-book.last_save)*1000
    release_scan.set()
    wait(r,lambda:not app.out_mail.busy)
    persisted=load_workbook(path)['ORDER']
    assert [(persisted.cell(n,4).value,persisted.cell(n,c).value) for n,c in [(218,19),(219,22)]]==[('MAT-0216',43),('MAT-0217',15)]
    assert [persisted.cell(218,c).value for c in (16,22)]==[None,None]
    assert [persisted.cell(219,c).value for c in (16,19)]==[None,None]
    assert pg.reporting.dirty
    # A manual edit must block the entire batch and retain all drafts.
    ed.first()
    r.update()
    e=ed.editor[0];e.delete(0,'end');e.insert(0,'44');e.event_generate('<Return>');r.update()
    e=ed.editor[0];e.delete(0,'end');e.insert(0,'16');e.event_generate('<Return>');r.update()
    book.sheet.cell(219,22).value=18
    ed.search.event_generate('<Control-s>')
    wait(r,lambda:not ed.busy)
    assert warnings.call_count==1 and book.saves==1 and len(ed.drafts)==2 and book.sheet.cell(218,19).value==43
    assert '219' in str(warnings.call_args)
    book.sheet.cell(219,22).value=15
    with patch.object(q,'writable_order',side_effect=OSError('Excel đang bận')):
        ed.search.event_generate('<Control-s>')
        wait(r,lambda:not ed.busy)
    assert book.saves==1 and len(ed.drafts)==2 and '218' in str(warnings.call_args)
    ed.search.event_generate('<Control-s>')
    wait(r,lambda:not ed.busy)
    assert not ed.drafts and book.saves==2
    # All slots, two adjacent writes to SL1 via one Excel range and no gap overwrite.
    sheet=ed.table
    keys=[sheet.line_index[i][2] for i in range(3)]
    q.save_batch(path,None,sheet,{(keys[0],13):q.amount(3),(keys[1],13):q.amount(4),(keys[2],16):q.amount(5)},[])
    assert (16,2,3) in book.writes
    persisted=load_workbook(path)['ORDER']
    assert [persisted['P2'].value,persisted['P3'].value,persisted['S4'].value,persisted['S3'].value]==[3,4,5,None]
    # A physical move/insertion invalidates the previous fast-path index.
    shifted=list(rows)
    shifted[1],shifted[2]=shifted[2],shifted[1]
    shifted=ed.table.refreshed(shifted)
    assert shifted.numbers[ed.table.line_index[0][2]]==3
    # Separate operations using the same ORDER path must wait for each other.
    import zone_excel_live as live
    started=threading.Event()
    entered=threading.Event()
    def waiter():
        started.set()
        with live.order_access(path):entered.set()
    with live.order_access(path):
        thread=threading.Thread(target=waiter)
        thread.start()
        assert started.wait(2) and not entered.wait(.05)
    thread.join(2)
    assert entered.is_set()
    # Independently check column pixel origins at several scroll offsets.
    r.geometry('740x660');r.minsize(500,450);r.update()
    for offset in (0,.25,1):
        ed.tree.xview_moveto(offset);r.update()
        assert abs(ed.tree.canvasx(0)-ed.tree.header.canvasx(0))<=1
    # Both the wide and tall plan preview keep all pixels inside the frame.
    for w,h,vw,vh in [(1500,320,710,500),(420,1600,800,320),(1500,950,790,500),(120,90,900,600)]:
        img=tk.PhotoImage(master=r,width=w,height=h)
        thumb=ws.fit_plan_image(ed.tree,img,vw,vh)
        assert thumb.width()<=vw and thumb.height()<=vh and abs(thumb.width()-thumb.height()*w/h)<max(2,w/h)
    button(r,'Check mail OD').invoke()
    r.update()
    out=app.out_mail
    out.messages=[dict(id='detail-test',received='2026-11-22T09:00:00',subject='Test',sender='AA',issues=[],skipped=0,
                       rows=[dict(material='ABC',qty=10,plan='2026-11-22') for _ in range(80)])]
    out.paint(False)
    top,=out.tree.get_children()
    assert len(out.tree.get_children(top))==1
    out.tree.focus(top)
    out.tree.event_generate('<<TreeviewOpen>>')
    r.update()
    assert len(out.tree.get_children(top))==80
    # Test overlapping report requests and discard results superseded by new filters.
    report=pg.reporting
    report_frame=next(tab for tab in app.notebook.tabs() if 'báo cáo' in app.notebook.tab(tab,'text').lower())
    app.notebook.select(report_frame)
    wait(r,lambda:bool(report.sheets))
    report.mode.set('Báo cáo cuối ca')
    report.paint()
    report.mode.set('Tổng quan')
    report.paint()
    wait(r,lambda:report.chart_data is not None and not report.computing)
    assert report.chart_data and not report.sheets
    report.mode.set('Báo cáo cuối ca')
    report.paint()
    wait(r,lambda:len(report.sheets)==2)
    assert report.groups and report.items
    # Refusing to abandon an unsaved quantity when switching shifts keeps it in place.
    app.show_order_page()
    r.update()
    ed.first()
    r.update()
    ed.editor[0].delete(0,'end')
    ed.editor[0].insert(0,'58')
    path2=path.with_name('261122_THEO DOI ORDER NVL_P_S7.xlsx')
    with patch.object(q.messagebox,'askyesno',return_value=False):
        pg.activate(path2,None,(rows,sh.signature(path)))
    assert pg.path==path and pg.qty_editor==ed and ed.editor[0].get()=='58'
    with patch.object(q.messagebox,'askyesno',return_value=True):
        pg.activate(path2,None,(rows,sh.signature(path)))
    assert pg.path==path2 and pg.qty_editor is None and not ed.win.winfo_exists()
    assert not errors,errors
    print('RESULT',dict(cold=round(first,1),reopen=[round(t,1) for t in reopened],enter=round(search_time,1),saved_focus=round(after,1)))
    r.destroy()
