"""Production schedule, operator preferences and workspace paths."""
import json
import os
import re
import shutil
import sqlite3
import struct
import tempfile
import uuid
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, simpledialog, ttk


def personal():
    path=Path(os.environ.get('LOCALAPPDATA') or Path.home())/'MA_Logistics_Flow'
    path.mkdir(parents=True,exist_ok=True)
    return path


def prefs():
    path=personal()/'preferences.json'
    return json.loads(path.read_text(encoding='utf8')) if path.exists() else {}


def remember(**fields):
    path=personal()/'preferences.json'
    tmp=path.with_name(uuid.uuid4().hex+'.tmp')
    tmp.write_text(json.dumps({**prefs(),**fields},ensure_ascii=False),encoding='utf8')
    os.replace(tmp,path)


DEFAULT={'text':'#183449','selection':'#bfdaed','size':10}


def appearance_tab(app,book):
    panel=ttk.Frame(book,padding=12)
    book.add(panel,text='Giao diện / Dữ liệu')
    colors=dict(DEFAULT,**prefs().get('appearance',{}))
    example=tk.Label(panel,text='Mã hàng     BIW73010105AA     Đã ra đơn, chờ cấp',padx=10,pady=5)
    size=tk.StringVar(value=str(colors['size']))
    def apply():
        style=ttk.Style(panel)
        style.configure('.',foreground=colors['text'],font=('Segoe UI',colors['size']))
        for name in ('Treeview','Result.Treeview'):
            style.configure(name,foreground=colors['text'],font=('Segoe UI',colors['size']),rowheight=max(24,colors['size']*2+5))
            style.map(name,background=[('selected',colors['selection'])],foreground=[('selected',colors['text'])])
        app.root._ma_colors=dict(colors)
        example.configure(bg=colors['selection'],fg=colors['text'],font=('Segoe UI',colors['size']))
        def update(widget):
            if hasattr(widget,'render_view'):
                widget.visible_range=None
                widget.cell_font.configure(size=colors['size'])
                widget.fit_text.cache_clear()
                widget.queue_view()
            for child in widget.winfo_children():update(child)
        update(app.root)
    def select(key):
        _,value=colorchooser.askcolor(colors[key],parent=panel)
        if value:colors[key]=value;apply()
    for key,label in [('text','Màu chữ'),('selection','Màu dòng chọn')]:
        ttk.Button(panel,text=label,command=lambda k=key:select(k)).pack(anchor='w')
    ttk.Combobox(panel,textvariable=size,values=(9,10,11,12,13,14),state='readonly',width=8).pack(anchor='w')
    size.trace_add('write',lambda *_:(colors.update(size=int(size.get())),apply()))
    example.pack(anchor='w',pady=8)
    ttk.Button(panel,text='Lưu giao diện',command=lambda:remember(appearance=dict(colors))).pack(anchor='w')
    def reset():
        colors.update(DEFAULT);size.set(str(colors['size']));remember(appearance=dict(colors))
    ttk.Button(panel,text='Khôi phục mặc định',command=reset).pack(anchor='w')
    apply()
    label=tk.StringVar(value=prefs().get('journal','Nhật ký hiện tại của máy'))
    ttk.Label(panel,textvariable=label,wraplength=750).pack(anchor='w',pady=8)
    def select_db(create):
        import zone18 as z
        if app.is_running:return
        if create:
            folder=filedialog.askdirectory(parent=panel,title='Chọn thư mục ứng dụng dùng chung')
            if not folder:return
            folder=Path(folder)/'Data';folder.mkdir(exist_ok=True)
            path=folder/(datetime.now().strftime('%y%m%d')+'_SQL_V19.sqlite')
            if path.exists():
                messagebox.showinfo('Data','Bộ dữ liệu đã tồn tại. Dùng Chọn bộ SQL.',parent=panel);return
            temp=folder/(uuid.uuid4().hex+'.tmp')
            try:
                with z.journal() as src:
                    dest=sqlite3.connect(temp)
                    try:src.backup(dest)
                    finally:dest.close()
                # On Windows rename fails if a concurrent operator published first.
                temp.rename(path)
            finally:temp.unlink(missing_ok=True)
        else:
            name=filedialog.askopenfilename(parent=panel,filetypes=[('SQL','*_SQL_V19.sqlite')])
            if not name:return
            path=Path(name)
        if not re.fullmatch(r'\d{6}_SQL_V19\.sqlite',path.name,re.I):raise ValueError('Tên cần có mẫu YYMMDD_SQL_V19.sqlite.')
        conn=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
        try:
            conn.execute('select run_id from run_result limit 1').fetchone()
            if conn.execute('pragma quick_check').fetchone()!=('ok',):raise ValueError('SQL không đạt kiểm tra.')
        finally:conn.close()
        remember(journal=str(path))
        label.set(str(path)+' · áp dụng sau khi mở lại app')
    def db_action(create):
        try:select_db(create)
        except Exception as exc:messagebox.showwarning('Data',str(exc),parent=panel)
    ttk.Button(panel,text='Tạo bộ SQL từ nhật ký hiện tại…',command=lambda:db_action(True)).pack(anchor='w')
    ttk.Button(panel,text='Chọn bộ SQL hiện có…',command=lambda:db_action(False)).pack(anchor='w')


def png_bytes(source):
    source=Path(source)
    if source.suffix.lower()=='.png':
        return source.read_bytes()
    import win32com.client
    image=win32com.client.Dispatch('WIA.ImageFile');image.LoadFile(str(source.resolve()))
    proc=win32com.client.Dispatch('WIA.ImageProcess')
    proc.Filters.Add(proc.FilterInfos('Convert').FilterID)
    proc.Filters(1).Properties('FormatID').Value='{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}'
    with tempfile.TemporaryDirectory() as tmp:
        target=Path(tmp)/'image.png'
        proc.Apply(image).SaveFile(str(target))
        return target.read_bytes()


def clipboard_png():
    import win32clipboard as clip
    clip.OpenClipboard()
    try:
        fmt=clip.RegisterClipboardFormat('PNG')
        if clip.IsClipboardFormatAvailable(fmt):return bytes(clip.GetClipboardData(fmt))
        if not clip.IsClipboardFormatAvailable(8):raise ValueError('Clipboard chưa có ảnh.')
        dib=bytes(clip.GetClipboardData(8))
    finally:clip.CloseClipboard()
    header=struct.unpack_from('<I',dib)[0]
    bits=struct.unpack_from('<H',dib,14)[0]
    used=struct.unpack_from('<I',dib,32)[0]
    compression=struct.unpack_from('<I',dib,16)[0]
    offset=14+header+4*(used or (1<<bits if bits<=8 else 0))+(12 if header==40 and compression==3 else 0)
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)/'clip.bmp'
        path.write_bytes(struct.pack('<2sIHHI',b'BM',14+len(dib),0,0,offset)+dib)
        return png_bytes(path)


def fit_plan_image(canvas, image, width, height):
    sw,sh=image.width(),image.height()
    ratio=min(1,width/sw,height/sh)
    w,h=max(1,round(sw*ratio)),max(1,round(sh*ratio))
    if (w,h)==(sw,sh):return image
    # Native Tk copies strips in C and needs no extra Windows image libraries.
    step=min(sw//w,sh//h)
    if step>1:
        image=image.subsample(step)
        sw,sh=image.width(),image.height()
    if (sw,sh)==(w,h):return image
    strip=tk.PhotoImage(master=canvas,width=w,height=sh)
    for x in range(w):
        sx=min(sw-1,int((x+0.5)*sw/w))
        canvas.tk.call(str(strip),'copy',str(image),'-from',sx,0,sx+1,sh,'-to',x,0)
    result=tk.PhotoImage(master=canvas,width=w,height=h)
    for y in range(h):
        sy=min(sh-1,int((y+0.5)*sh/h))
        canvas.tk.call(str(result),'copy',str(strip),'-from',0,sy,w,sy+1,'-to',0,y)
    return result


def schedule_tab(app):
    page=ttk.Frame(app.notebook,padding=6)
    app.notebook.insert(app.tab_config,page,text='KHSX')
    toolbar=ttk.Frame(page);toolbar.pack(fill='x')
    current=tk.StringVar()
    selector=ttk.Combobox(toolbar,textvariable=current,state='readonly',width=26)
    selector.pack(side='left')
    caption=tk.StringVar()
    ttk.Label(page,textvariable=caption,wraplength=1000).pack(anchor='w')
    canvas=tk.Canvas(page,background='white',highlightthickness=0)
    canvas.pack(fill='both',expand=True)
    base=[Path(prefs().get('plans') or personal()/'KHSX')]
    canvas.original=canvas.preview=None
    job=None
    last_size=None
    def fit():
        nonlocal job,last_size
        job=None
        if not canvas.original or not canvas.winfo_ismapped():return
        w,h=canvas.winfo_width(),canvas.winfo_height()
        if min(w,h)<2 or last_size==(w,h):return
        canvas.preview=fit_plan_image(canvas,canvas.original,w,h)
        canvas.delete('all')
        canvas.create_image(w/2,h/2,anchor='center',image=canvas.preview)
        last_size=w,h
    def queue_fit(*_):
        nonlocal job
        if job is not None:canvas.after_cancel(job)
        job=canvas.after(90,fit)
    canvas.bind('<Configure>',queue_fit)
    canvas.bind('<Map>',queue_fit)
    def show(*args):
        nonlocal last_size
        canvas.delete('all')
        canvas.original=canvas.preview=None
        last_size=None
        if not current.get():return
        try:
            path=base[0]/(current.get()+'.png')
            canvas.original=tk.PhotoImage(master=canvas,file=str(path))
            queue_fit()
            note=path.with_suffix('.txt')
            caption.set(note.read_text(encoding='utf8') if note.exists() else '')
        except Exception as exc:caption.set(str(exc))
    def refresh():
        try:names=sorted((p.stem for p in base[0].glob('*_KHSX_*.png')),reverse=True)
        except OSError as exc:caption.set(str(exc));return
        selector.configure(values=names)
        current.set(names[0] if names else '');canvas.delete('all');caption.set('');show()
    def add(paste):
        try:
            if paste:data=clipboard_png()
            else:
                file=filedialog.askopenfilename(parent=page,filetypes=[('Ảnh','*.png *.jpg *.jpeg *.bmp')])
                if not file:return
                data=png_bytes(file)
            if not data.startswith(b'\x89PNG\r\n\x1a\n'):raise ValueError('Ảnh PNG không hợp lệ.')
            note=simpledialog.askstring('Lưu KHSX','Tuần / ngày áp dụng và ghi chú điều chỉnh',parent=page)
            if note is None:return
            base[0].mkdir(parents=True,exist_ok=True)
            name=datetime.now().strftime('%y%m%d_KHSX_%H%M%S_%f')
            target=base[0]/(name+'.png')
            temp=target.with_suffix('.tmp')
            temp.write_bytes(data);target.with_suffix('.txt').write_text(note,encoding='utf8')
            os.replace(temp,target);refresh()
        except Exception as exc:messagebox.showwarning('KHSX',str(exc),parent=page)
    def folder():
        value=filedialog.askdirectory(parent=page,title='Thư mục lịch KHSX dùng chung')
        if value:base[0]=Path(value);remember(plans=value);refresh()
    for label,cmd in [('Dán ảnh',lambda:add(True)),('Chọn ảnh…',lambda:add(False)),('Thư mục lịch…',folder),('Làm mới',refresh),('Ảnh gốc',lambda:current.get() and os.startfile(str(base[0]/(current.get()+'.png'))))]:
        ttk.Button(toolbar,text=label,command=cmd).pack(side='left',padx=2)
    selector.bind('<<ComboboxSelected>>',show)
    loaded=[]
    def mapped(_):
        if not loaded:loaded.append(True);page.after_idle(refresh)
    page.bind('<Map>',mapped)
    app.root.bind('<Control-v>',lambda _:add(True) if app.notebook.select()==str(page) else None,add='+')


def start_workspace(core):
    import msvcrt
    from shutil import copyfile
    config=personal()/'config.json'
    legacy=Path(core.ConfigManager.get_path())
    if not config.exists() and legacy.is_file():
        copyfile(legacy,config)
    core.ConfigManager.get_path=classmethod(lambda cls:str(config))
    value=prefs().get('journal')
    from ctypes import windll
    app_dir=Path(core.get_base_dir()).resolve()
    remote=str(app_dir).startswith(chr(92)*2) or windll.kernel32.GetDriveTypeW(str(app_dir.anchor))==4
    if not value and remote:
        data=app_dir/'Data'
        choices=list(data.glob('*_SQL_V19.sqlite'))
        if len(choices)==1:
            value=str(choices[0])
        elif len(choices)>1:
            value=filedialog.askopenfilename(initialdir=str(data),title='Chọn bộ SQL đang dùng cho kho',filetypes=[('SQL','*_SQL_V19.sqlite')])
            if not value:raise ValueError('Cần chọn bộ dữ liệu của kho.')
        else:
            data.mkdir(exist_ok=True)
            value=str(data/(datetime.now().strftime('%y%m%d')+'_SQL_V19.sqlite'))
    if not value:return
    path=Path(value)
    if not path.is_file() and (prefs().get('journal') or not remote):
        raise ValueError('Không tìm thấy bộ SQL đã chọn: '+value)
    lock=path.with_suffix('.lock').open('a+b')
    try:
        lock.seek(0)
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:
        lock.close()
        raise ValueError('Bộ SQL đang có người dùng hoặc ổ chung chưa cho phép khóa. Đóng phiên trước rồi mở lại.')
    core._shared_lock=lock
    if not path.exists():
        import zone18
        temp=path.with_suffix('.building')
        temp.unlink(missing_ok=True)
        dest=sqlite3.connect(temp)
        try:
            legacy_db=app_dir/'data'/'sap_zone_v18.sqlite'
            if legacy_db.exists():
                with zone18.journal() as src:src.backup(dest)
            else:
                # Initialize the schema in the staged file itself.
                core._shared_journal=None
                original=core.get_base_dir
                try:
                    with tempfile.TemporaryDirectory() as staging:
                        core.get_base_dir=lambda:staging
                        with zone18.journal() as src:src.backup(dest)
                finally:core.get_base_dir=original
        finally:dest.close()
        temp.rename(path)
    remember(journal=value)
    core._shared_journal=value
