"""OUT NVL lookup across handovers and FIFO replenishment by order row."""
from collections import defaultdict
from datetime import date,datetime,timedelta
from decimal import Decimal
from pathlib import Path
import re
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog

import zone_mail as mail
import zone_shift as sh
from zone_order_result import file_key

DATE_TOKEN=r'(?<!\d)(?:\d{4}-\d\d-\d\d|\d{1,2}[./-]\d{1,2}[./-]20\d\d)(?!\d)'


def requested(text,catalog):
    tokens=re.findall(r'(?<![A-Z0-9])[A-Z0-9]*\d[A-Z0-9]*(?![A-Z0-9])',re.sub(DATE_TOKEN,' ',text.upper()))
    hits=set()
    review=[]
    for token in dict.fromkeys(tokens):
        if token in catalog:
            hits.add(token)
        elif len(token)>=4:
            matches=sorted(code for code in catalog if token in code)
            if len(matches)==1:hits.add(matches[0])
            elif matches:review.append(token+' → '+', '.join(matches[:12]))
            elif re.search('[A-Z]',token) or text.strip()==token or any(line.strip()==token for line in text.splitlines()):review.append(token+' · chưa thấy mã')
    return hits,review


def material_index(table):
    cached=getattr(table,'material_lookup',None)
    if cached is not None:return cached
    records=defaultdict(list)
    cartons=set()
    for n,row,key in sh.indexed(table):
        material=sh.clean(row[3]).upper()
        records[material].append((sh.day(row[26]),n,row,key))
        if sh.packing(row[2])[0]:cartons.add(material)
    if hasattr(table,'line_index'):table.material_lookup=records,cartons
    return records,cartons


def lookup(text,anchor,books,messages,indexed=False):
    first=anchor-timedelta(days=2)
    indexes=[(path,table if indexed else material_index(table)) for path,table in books]
    catalog=set()
    cartons=set()
    for path,(records,boxed) in indexes:
        catalog.update(records)
        cartons.update(boxed)
    relevant_mail=defaultdict(list)
    for m in messages:
        for r in m['rows']:
            material=r['material'].upper()
            catalog.add(material)
            dt=mail.day(r.get('plan'))
            if dt and first<=dt:
                relevant_mail[material,dt].append((m,r))
    codes,review=requested(text,catalog)
    groups=defaultdict(list)
    seen=set()
    for path,(records,_) in indexes:
        for material in codes:
            for dt,n,row,key in records.get(material,()):
                if key not in seen and dt and first<=dt and (dt<=anchor or path==books[0][0]):
                    groups[material,dt].append((material,dt,n,row,path,key))
                    seen.add(key)
    for k in relevant_mail:
        if k[0] in codes:groups.setdefault(k,[])
    for code in sorted(codes-{key[0] for key in groups}):
        review.append(code+(' · hàng thùng cấp theo giờ/gọi · chưa thấy ORDER trong kỳ tra' if code in cartons else ' · chưa thấy trong ORDER và mail đã đọc của kỳ tra'))
    return groups,relevant_mail,review


def fifo_quantities(candidates):
    import math
    lines=sorted((dict(r) for r in candidates),key=lambda r:(r['kh'],r['row']))
    boxes=defaultdict(list)
    for r in lines:
        r['qty']=max(0,float(r['ordered'])-float(r['issued'] or 0))
        if r['pack']:
            boxes[r['material'],sh.norm(r['station']),r['pack']].append(r)
            r['boxes']=0
    for (_,_,pack),group in boxes.items():
        total=sum(r['qty'] for r in group)
        count=math.ceil(total/pack)
        group[-1]['qty']+=count*pack-total
        group[-1]['boxes']=count
    return lines


def mb51(materials,first,last,cfg):
    import zone_inbound as inbound
    import zone18 as z
    with z.lease():
        s=z.get_session(int(cfg['sap_session_idx']),cfg['sap_system'],cfg['sap_client'])
        z.start(s,'MB51')
        for field in ('CHARG','LIFNR','KUNNR','BWART','SOBKZ','AUFNR','EBELN','KOSTL','MBLNR','XBLNR','MATNR','WERKS','LGORT','USNAM'):
            for bound in ('LOW','HIGH'):inbound.field(s,field+'-'+bound,'',True)
        inbound.field(s,'LGORT-LOW','1005')
        inbound.field(s,'WERKS-LOW','3093')
        inbound.field(s,'BWART-LOW','311')
        inbound.field(s,'BWART-HIGH','312')
        inbound.field(s,'BUDAT-LOW',first.strftime('%d.%m.%Y'))
        inbound.field(s,'BUDAT-HIGH',last.strftime('%d.%m.%Y'))
        if len(materials)==1:inbound.field(s,'MATNR-LOW',materials[0])
        else:z.inline_select(s,'wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH',materials)
        z.require(s,'wnd[0]/tbar[1]/btn[8]').press()
        try:
            _,message=z.status(s,allow_warnings=True)
        except z.StopRun as exc:
            if not re.search('no (?:data|documents|entries|records)|không có dữ liệu',str(exc),re.I):raise
            return []
        if re.search('no (?:data|documents|entries|records)|không có dữ liệu',message,re.I):return []
        keys=('MATNR','MBLNR','BWART','MENGE','MEINS','LGORT')
        docs=inbound.paged_alv(s,inbound.result_grid(s),keys,('UMLGO','BUDAT','SHKZG','WERKS','XBLNR','CHARG','BKTXT','CPUTM'))
        return [d for d in docs if d['MATNR'] in materials and d['BWART'] in ('311','312') and
                d['LGORT']=='1005']


def row_info(r):
    numbers=' / '.join(sh.clean(r[i]) for i in (14,17,20) if sh.clean(r[i]))
    obs=' / '.join(sh.clean(r[i]) for i in (13,16,19) if sh.clean(r[i]))
    recorded=any(sh.clean(r[i]) for i in (15,18,21)) or bool(r[22])
    issued=float(r[22] or 0)
    gap=max(0,float(r[4])-issued)
    waiting=sh.pending_order(r)
    note=sh.clean(r[27])
    if sh.norm(note)=='chocap':note='Đã ra đơn, chờ cấp'
    if recorded and gap:
        if sh.packing(r[2])[0]:
            status='Cấp một phần · còn '+sh.clean(gap)+' EA'+(' · '+waiting if waiting else '')
        else:
            status='Cấp thiếu '+sh.clean(gap)+' · '+(waiting or 'cần ra đơn cấp bù')
    else:
        if recorded and not gap:status='Done'
        elif waiting:status=waiting
        elif sh.packing(r[2])[0] and sh.norm(note) in ('','chuaradon','captheogio','hangthungcaptheogiogoi'):status='Pending'
        else:status=note or 'Chưa ra đơn'
    return (sh.clean(issued) if recorded else '',sh.clean(gap) if recorded else '',numbers,obs,status)


def order_detail(root,rows,order_action=None):
    from zone_result_grid import ResultGrid
    win=tk.Toplevel(root);win.title('Chi tiết mã · ORDER');win.geometry('1150x450')
    heads={(sh.clean(r[3]),sh.clean(r[9]),str(sh.day(r[26]))) for _,r,_ in rows}
    single=len(heads)==1
    if single:ttk.Label(win,text=' · '.join(next(iter(heads)))).pack(anchor='w',padx=8)
    context=[('Mã NVL',120)] if single else [('Mã NVL',120),('Model',45),('KHSX',80)]
    t=ResultGrid(win,context+[('Trạm',150),('SL OD',60),('Đã cấp',60),('Còn thiếu',70),('Tình trạng',215),('Số đơn',105),('OB',120)])
    source=tk.StringVar()
    ttk.Label(win,textvariable=source).pack(anchor='w')
    rows=list(rows)
    direction={}
    def populate():
        t.reset()
        for n,r,path in rows:
            add(n,r,path)
    def add(n,r,path):
        issued,gap,num,ob,status=row_info(r)
        prefix=[r[3]] if single else [r[3],r[9],sh.day(r[26])]
        t.add((*prefix,r[5],sh.clean(r[4]),issued,gap,status,num,ob))
    populate()
    def sort(event):
        x=t.header.canvasx(event.x)
        for j,width in enumerate(t.widths):
            if x<width:break
            x-=width
        active=(id(rows[t.active[0]-1]),t.active[1]) if t.active else None
        selected={id(rows[i-1]) for i in t.selection()}
        reverse=not direction.get(j,True)
        direction.clear();direction[j]=reverse
        def key(pair):
            text=str(pair[1][j])
            return tuple((1,int(s)) if s.isdigit() else (0,s.casefold()) for s in re.split(r'(\d+)',text))
        rows[:]=[r for r,_ in sorted(zip(rows,t.rows),key=key,reverse=reverse)]
        populate()
        t.selection_set([i for i,r in enumerate(rows,1) if id(r) in selected])
        if active:t.active=(next(i for i,r in enumerate(rows,1) if id(r)==active[0]),active[1])
    t.header.bind('<Button-1>',sort)
    if order_action:
        ttk.Button(win,text='Ra đơn OD các dòng chọn…',command=lambda:order_action(win,[rows[i-1] for i in t.selection()])).pack(side='bottom')
    def display_source(event):
        selected=t.selection()
        if selected:
            n,r,path=rows[int(selected[0])-1]
            source.set(f'Dòng {n} · {path} · {sh.display_note(r)}')
    t.bind('<ButtonRelease-1>',display_source,add='+')
    def stale():
        rows.clear()
        t.reset()
        source.set('ORDER đã cập nhật · mở lại chi tiết để dùng số mới.')
    win.order_stale=stale
    return win


class SearchPage:
    def __init__(self,parent,page,to_order):
        self.page,self.to_order=page,to_order
        self.cache={}
        self.items={}
        self.anchor=tk.StringVar()
        self.hint=tk.StringVar(value='Dán mã, danh sách hoặc nội dung tin nhắn. Bấm đúp kết quả để xem nguồn.')
        self.future=tk.BooleanVar(value=False)
        self.last_result=None
        self.input=tk.Text(parent,height=3,wrap='word')
        self.input.pack(fill='x',padx=8,pady=5)
        bar=ttk.Frame(parent);bar.pack(fill='x',padx=8)
        ttk.Label(bar,text='KHSX').pack(side='left')
        ttk.Entry(bar,textvariable=self.anchor,width=13).pack(side='left',padx=4)
        for name,fn in [('Tra mã',self.search),('Ra đơn cấp bù',self.submit),('Tra MB51',self.sap),('Chốt OB ghép…',self.close_shared)]:
            ttk.Button(bar,text=name,command=fn).pack(side='left',padx=3)
        ttk.Checkbutton(bar,text='Hiện KHSX sau ngày tra',variable=self.future,command=self.refilter).pack(side='left')
        self.old_done=tk.BooleanVar(value=False)
        ttk.Checkbutton(bar,text='Hiện đã cấp đủ ngày trước',variable=self.old_done,command=self.refilter).pack(side='left')
        self.issues=[]
        ttk.Button(bar,text='Nguồn tra',command=lambda:messagebox.showinfo('Nguồn tra', '\n'.join(self.issues) or 'Không có cảnh báo nguồn.',parent=parent)).pack(side='right')
        ttk.Label(parent,textvariable=self.hint).pack(fill='x',padx=8)
        from zone_result_grid import ResultGrid
        self.tree=ResultGrid(parent,[('KHSX',100),('Mã NVL',155),('SL OD',75),('Đã cấp',80),('Còn thiếu',85),('Số đơn',130),('Tình trạng',370)])
        self.tree.enable_sort(lambda:self.items)
        self.tree.message_for_row=self.message
        self.tree.bind('<Double-1>',lambda e:self.detail())

    def message(self,index):
        if index not in self.items:return str(self.tree.rows[index-1][-1])
        (code,dt),lines,_=self.items[index]
        parts=[f'{code} · KHSX {dt:%d/%m}']
        for _,_,_,r,_,_ in lines:
            issued,gap,num,_,status=row_info(r)
            fields=[sh.clean(r[5]),'SL OD '+sh.clean(r[4])]
            if issued:fields.append('đã cấp '+issued)
            if gap and gap!='0':fields.append('còn thiếu '+gap)
            if num:fields.append('phiếu '+num)
            fields.append(status)
            parts.append(' · '.join(filter(None,fields)))
        if not lines:parts.append('Có mail · chưa xác minh ORDER')
        return '\n'.join(parts)

    def refilter(self):
        if self.last_result:self.last_result()

    def search(self):
        p=self.page
        if not p.path or p.app.is_running:return
        text=self.input.get('1.0','end').strip()
        if not text:return
        days={mail.day(v) for v in re.findall(DATE_TOKEN,text)}
        if len(days)>1:
            self.hint.set('Tin chứa nhiều ngày. Tách yêu cầu theo từng KHSX rồi tra lại.')
            return
        pivot=next(iter(days)) if days else mail.day(self.anchor.get() or sh.parsed_name(p.path)[0])
        if not pivot:
            self.hint.set('Kiểm tra ngày KHSX.');return
        self.anchor.set(pivot.isoformat())
        revision=p.revision
        current_path=p.path
        selected=list(p.app.out_mail.prior_selected.get(file_key(p.path),{}).values())
        def work():
            current,stamp,source,options=sh.read_order(current_path,p.password,False)
            previous,issues=mail.prior_files(current_path,min(pivot,sh.parsed_name(current_path)[0])-timedelta(days=2),selected)
            current=p.table if current==p.table else current
            active_index=material_index(current)
            books=[(current_path,active_index)]
            import zone_excel_live as live
            opened=list(live.books()) if previous else []
            loaded=set()
            for path in previous:
                if sh.parsed_name(path) in loaded:continue
                try:
                    old=sh.historical_order(path,p.passwords.get(file_key(path)) or p.password,self.cache,material_index,opened)
                    books.append((path,old))
                    loaded.add(sh.parsed_name(path))
                except Exception as exc:issues.append(path.name+' · '+str(exc))
            for past,table in sh.missing_history(current_path.parent,pivot-timedelta(days=2),sh.parsed_name(current_path),loaded):
                books.append((past,material_index(table)))
            if len(books)==1:issues.append('Chưa có file bàn giao')
            return current,stamp,source,options,lookup(text,pivot,books,p.app.out_mail.messages,True),issues,active_index
        def ready(result):
            if revision!=p.revision:
                self.hint.set("ORDER đã thay đổi · bấm Tra lại.")
                return
            data,stamp,src,opts,(groups,mails,review),issues,books=result
            same=data==p.table and stamp==p.stamp and src==p.sources.get(file_key(p.path))
            if not same:
                p.sources[file_key(p.path)]=src
                if opts is not None:p.pivots[file_key(p.path)]=opts
                p.activate(current_path,p.password,(data,stamp))
            p.table.material_lookup=books
            self.snapshot=(current_path,data)
            self.last_result=lambda:render(groups,mails,review,issues)
            self.last_result()
        def render(groups,mails,review,issues):
            self.items={}
            self.tree.reset()
            groups={k:v for k,v in groups.items() if self.future.get() or k[1]<=pivot}
            for key,lines in sorted(groups.items(),key=lambda kv:(kv[0][1].toordinal(),kv[0][0])):
                info=[row_info(r) for _,_,_,r,_,_ in lines]
                active=[v for v in info if v[1]!='0' or v[0]=='']
                if key[1]<pivot and info and not active and not self.old_done.get():continue
                states=list(dict.fromkeys(v[-1] for v in active))
                status=(states[0] if len(states)==1 else f'{len(active)} dòng OD còn mở · xem chi tiết') if active else ('Đã cấp đủ' if info else 'Có mail · chưa xác minh ORDER')
                measured=any(v[0] for v in info)
                ordered=sum(float(row[3][4]) for row in lines)
                issued=sum(float(row[3][22] or 0) for row in lines)
                missing=sum(max(0,float(row[3][4])-float(row[3][22] or 0)) for row in lines)
                node=self.tree.add((key[1],key[0],sh.clean(ordered) if lines else '',sh.clean(issued) if measured else '',
                                    sh.clean(missing) if measured else '',
                                    ' / '.join(dict.fromkeys(v[2] for v in info if v[2])),status))
                self.items[node]=(key,lines,mails.get(key,[]))
            for msg in review:
                self.tree.add(('',msg.split()[0],'','','','',msg))
            last=max([pivot,*[k[1] for k in groups]])
            self.hint.set(f'KHSX {pivot-timedelta(days=2):%d/%m} – {last:%d/%m} · {len(self.items)} nhóm mã/ngày'+
                          (f' · {len(issues)} lưu ý nguồn (xem chi tiết)' if issues else ''))
            self.issues=issues
        p.task('Đang tra ORDER và mail…',work,ready)

    def selected(self):
        return [self.items[n] for n in self.tree.selection() if n in self.items]

    def detail(self):
        selected=self.selected()
        if not selected:return
        win=order_detail(self.page.app.root,[(n,r,path.name) for _,records,_ in selected for _,_,n,r,path,_ in records])
        for _,_,mails in selected:
            for m,r in mails:ttk.Label(win,text=f"{m['received']} · {m['subject']} · {r.get('status','')}").pack(anchor='w')

    def submit(self):
        p=self.page
        if p.app.is_running or not self.selected():return
        if getattr(self,'snapshot',None)!=(p.path,p.table):
            self.hint.set('ORDER đã thay đổi. Tra lại trước khi cấp bù.');return
        origins={key for _,records,_ in self.selected() for _,_,_,r,path,key in records if path==p.path}
        candidates=[r for r in sh.plan(p.table,None,None,sh.FIFO,p.app.config) if r['origin'] in origins]
        if not candidates:
            self.hint.set('Chưa có dòng thiếu trong ORDER ca này. Kiểm tra bàn giao hoặc nhập dòng mail thiếu trước.');return
        if any(r['problem'] for r in candidates):
            self.hint.set(' · '.join(r['material']+' '+r['problem'] for r in candidates if r['problem']));return
        candidates=fifo_quantities(candidates)
        if len({r['material'] for r in candidates})==1 and all(not r['pack'] for r in candidates):
            total=sum(r['qty'] for r in candidates)
            limit=simpledialog.askfloat('Cấp bù FIFO','SL thực ra (EA), ưu tiên KHSX cũ:',initialvalue=total,minvalue=0,maxvalue=total,parent=p.app.root)
            if not limit:return
            for r in candidates:
                r['qty']=min(limit,r['qty']);limit-=r['qty']
            candidates=[r for r in candidates if r['qty']]
        details=[]
        for r in candidates:
            zone,tl,mapped=p.app.zone_mgr.resolve_zone_tl(r['material'],r['station'])
            details.append(f'{r["kh"]} · {r["material"]} · {r["station"]} · {zone} · {r["qty"]:g} EA')
        if not messagebox.askyesno('Phân bổ cấp bù theo ngày và trạm','\n'.join(details)+'\nRa đơn các dòng này?',parent=p.app.root):return
        self.to_order()
        p.on_run(candidates,p.path,p.stamp)

    def close_shared(self):
        p=self.page
        if p.app.mock_mode_var.get():
            self.hint.set("Bỏ tích Mô phỏng để lưu xác nhận vào Excel.");return
        if p.app.is_running or getattr(self,'snapshot',None)!=(p.path,p.table):return
        keys={key for _,lines,_ in self.selected() for _,_,_,r,path,key in lines
              if path==p.path and sh.round_open(r) and not sh.round_open(r,True)}
        if not keys:
            self.hint.set('Chọn dòng có đủ SL thực cấp trong ô ghép nhiều OB.');return
        if messagebox.askyesno('Chốt OB ghép',f'Đã đối chiếu và xác nhận cấp đủ {len(keys)} dòng?',parent=p.app.root):
            from zone_order_result import confirm_shared_slots
            p.task('Đang chốt OB ghép…',lambda:confirm_shared_slots(p.path,p.password,p.table,keys),lambda _:self.search())

    def sap(self):
        p=self.page
        if p.app.is_running:return
        keys=[key for key,_,_ in self.selected()]
        if not keys and len(self.items)==1:keys=[next(iter(self.items.values()))[0]]
        if not keys:
            raw=self.input.get('1.0','end').strip().upper()
            dt=sh.day(self.anchor.get()) or date.today()
            if re.fullmatch(r'[A-Z]{2,6}[0-9][A-Z0-9]{4,20}',raw):keys=[(raw,dt)]
            else:
                self.hint.set('Chọn dòng kết quả hoặc nhập một mã đầy đủ để tra MB51.');return
        codes=list(dict.fromkeys(k[0] for k in keys))
        end=max(date.today(),max(k[1] for k in keys))
        def show(docs):
            win=tk.Toplevel(p.app.root);win.title('MB51 · đối chiếu phát sinh 311 / đảo 312')
            from zone_shift_ui import grid
            cols=('MATNR','MENGE','CHARG','XBLNR','MBLNR','BKTXT','CPUTM','BUDAT','MEINS','BWART')
            from zone_result_grid import ResultGrid
            labels=('Mã SG','Số lượng','Batch','OB','Chứng từ vật tư','Nội dung chứng từ','Giờ nhập','Ngày trả','Đơn vị','MVT')
            tree=ResultGrid(win,[(label,115) for label in labels])
            tree.enable_sort()
            for doc in sorted(docs,key=lambda d:(mail.day(d.get('BUDAT')) or date.min,d.get('CPUTM','')),reverse=True):tree.add([doc.get(c,'') for c in cols],warning=doc['BWART']=='312')
            self.hint.set(f'MB51 · {len(docs)} dòng tại kho '+str(p.app.config['sloc_from']))
            ttk.Label(win,text=f'{len(docs)} dòng chứng từ · đối chiếu chứng từ trước khi xác nhận cấp.').pack()
        self.hint.set('Đang tra MB51 · '+', '.join(codes))
        p.task('Đang tra lịch sử MB51…',lambda:mb51(codes,min(k[1] for k in keys)-timedelta(days=2),end,p.app.config),show)
