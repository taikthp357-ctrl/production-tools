"""Close obsolete demand after checking the live ORDER sheet."""
from datetime import timedelta
import tkinter as tk
from tkinter import ttk,messagebox
import zone_shift as sh
from zone_order_result import writable_order


def untouched(row):
    return all(sh.norm(row[i]) in ('','hetton','hettonkhoma') for i in (13,16,19)) and all(
        not sh.clean(row[i]) for i in (14,17,20)) and all(row[i] in (None,'',0,'0') for i in (15,18,21,22))


def overdue(row,workday):
    dt=sh.day(row[26])
    return bool(dt and dt+timedelta(days=2)<workday and sh.norm(row[27])=='hettonkhoma'
                and sh.state(row) in ('pending',sh.PART) and not sh.round_open(row) and (untouched(row) or not sh.pending_order(row)))


def change_lines(page,selected,changes,reason):
    # Pending history stays available for reconciliation. Source rows are archived
    # in this workbook before its active OD fields change in the same Excel save.
    path,pwd=page.path,page.password
    with writable_order(path,pwd) as (book,sheet,shared):
        current=sh.values(sheet)
        if any(n>len(current) or current[n-1]!=old for n,old in selected.items()):
            raise ValueError('Dòng OD đã thay đổi. Tải lại và đối chiếu trước khi ghi.')
        import zone18
        proposed=[line for line in sh.plan(current,None,None,None,page.app.config,review=True) if line['row'] in selected]
        with zone18.journal() as conn:
            if sh.reservations(conn,proposed):
                raise ValueError('Có dòng đã gửi SAP. Đối soát lượt ra đơn trước khi chỉnh OD.')
        try:archive=book.Worksheets('OD_DA_DONG')
        except Exception:
            archive=book.Worksheets.Add(After=book.Worksheets(book.Worksheets.Count))
            archive.Name='OD_DA_DONG'
        if not archive.Cells(1,1).Value2:
            headers=('Lý do','Dòng ORDER',*current[0])
            archive.Range(archive.Cells(1,1),archive.Cells(1,len(headers))).Value2=(headers,)
        first=max(2,int(archive.Cells(archive.Rows.Count,1).End(-4162).Row)+1)
        undo=[]
        try:
            for i,(n,r) in enumerate(selected.items(),first):
                snapshot=(reason,n,*r)
                cells=archive.Range(archive.Cells(i,1),archive.Cells(i,len(snapshot)))
                cells.NumberFormat='@';cells.Value2=(snapshot,)
                if sh.clean(archive.Cells(i,6).Value2)!=sh.clean(r[3]):raise ValueError('Chưa xác minh được mã trong lịch sử đóng OD.')
                updates=changes.get(n)
                if updates is None:
                    updates={col:None for col in range(1,len(r)+1) if r[col-1] not in (None,'') and not sheet.Cells(n,col).HasFormula}
                    if 4 not in updates:raise ValueError('Mã NVL dùng công thức, cần kiểm tra dòng.')
                for col,value in updates.items():
                    cell=sheet.Cells(n,col)
                    if cell.HasFormula:raise ValueError('Ô cần chỉnh đang có công thức.')
                    undo.append((cell,cell.Value2))
                    if value is None:cell.ClearContents()
                    else:cell.Value2=value
                    if sh.clean(cell.Value2)!=sh.clean(value):raise ValueError('Excel đọc lại khác giá trị cần ghi.')
            sheet.Calculate()
            book.Save()
        except Exception:
            if shared:
                for cell,old in reversed(undo):cell.Value2=old
                archive.Rows(f'{first}:{first+len(selected)-1}').ClearContents()
            raise
    result=sh.load(path,pwd)
    sh.history_snapshot(path,result[0])
    return result


def cleanup_dialog(page):
    if not page.table or page.app.is_running:return
    if page.app.mock_mode_var.get():
        messagebox.showinfo('Dọn OD','Tắt Mô phỏng để dọn ORDER của ca.',parent=page.app.root);return
    date,team=sh.parsed_name(page.path)
    source=page.table
    candidates={n:r for n,r in sh.rows(source) if overdue(r,date)}
    if not candidates:
        messagebox.showinfo('Dọn OD','Ca này chưa có dòng hết tồn quá D+2.',parent=page.app.root);return
    if page.cleanup:return
    page.cleanup=CleanupView(page,candidates)
    page.cleanup.paint()


class CleanupView:
    def __init__(self,page,candidates):
        self.sort_field=0
        self.desc=False
        self.page=page
        self.source=page.table
        self.path=page.path
        self.candidates=candidates
        tree=page.tree
        self.selected={page.lines[k]['line_id'] for k in tree.selection()}
        self.active=(page.lines[tree.active[0]]['line_id'],tree.active[1]) if tree.active else None
        self.scroll=tree.xview()[0],tree.yview()[0]
        page.toolbar.pack_forget()
        page.footer.pack_forget()
        self.bar=ttk.Frame(page.requests.master)
        self.bar.pack(fill='x',before=page.requests)
        ttk.Label(self.bar,text='Dọn OD hết tồn quá D+2 · KHSX').pack(side='left')
        dates=sorted({str(sh.day(r[26])) for r in candidates.values()})
        self.day=tk.StringVar(value=dates[0])
        box=ttk.Combobox(self.bar,textvariable=self.day,values=dates,state='readonly',width=12)
        box.pack(side='left',padx=5)
        box.bind('<<ComboboxSelected>>',lambda _:self.paint())
        ttk.Button(self.bar,text='Đóng các dòng chọn',command=self.close).pack(side='left')
        ttk.Button(self.bar,text='Quay lại ORDER',command=self.leave).pack(side='right')

    def sort_header(self,event):
        tree=self.page.tree
        x=tree.header.canvasx(event.x)
        for field,w in zip((0,3,5,4,22),tree.widths):
            if x<w:
                self.desc=not self.desc if self.sort_field==field else False
                self.sort_field=field
                selected={self.visible[k] for k in tree.selection()}
                self.paint()
                tree.selection_set({k for k,n in self.visible.items() if n in selected})
                return
            x-=w

    def paint(self):
        page=self.page
        if page.table is not self.source:
            self.leave()
            return
        tree=page.tree
        tree.show_columns(['Dòng','Mã hàng','Trạm','SL ORDER','Đã cấp'])
        self.visible={}
        page.lines={}
        def order(item):
            n,r=item
            if self.sort_field==0:return n
            if self.sort_field in (4,22):
                try:return float(r[self.sort_field] or 0)
                except (ValueError,TypeError):return 0
            return sh.clean(r[self.sort_field]).casefold()
        for n,r in sorted(self.candidates.items(),key=order,reverse=self.desc):
            if str(sh.day(r[26]))!=self.day.get():continue
            node=tree.add([n,r[3],'',r[5],r[4],r[22],'','','','','',''])
            self.visible[node]=n

    def leave(self):
        page=self.page
        page.cleanup=None
        self.bar.destroy()
        main=page.requests.master
        page.toolbar.pack(fill='x',before=main.pack_slaves()[0])
        page.footer.pack(side='bottom',fill='x',before=page.requests)
        page.paint()
        self.restore()

    def restore(self):
        page=self.page
        if page.path!=self.path:return
        tree=page.tree
        tree.selection_set({k for k,r in page.lines.items() if r['line_id'] in self.selected})
        if self.active:
            node=next((k for k,r in page.lines.items() if r['line_id']==self.active[0]),None)
            if node and self.active[1]<len(tree.widths):tree.active=(node,self.active[1])
        if tree.render_job is not None:
            tree.after_cancel(tree.render_job)
        tree.render_view()
        tree.xview_moveto(self.scroll[0])
        tree.yview_moveto(self.scroll[1])

    def close(self):
        page=self.page
        if page.app.is_running or page.table is not self.source or page.path!=self.path or page.app.mock_mode_var.get():return
        selected={self.visible[k]:self.candidates[self.visible[k]] for k in page.tree.selection()}
        if not selected:return
        if not messagebox.askyesno('Đóng OD',f'Đóng {len(selected)} dòng KHSX {self.day.get()} và bỏ khỏi báo cáo? Cấp tiếp cần OD mới.',parent=page.app.root):return
        self.leave()
        def saved(data):
            page.activate(self.path,page.password,data)
            self.restore()
        page.task('Lưu các OD đã đóng…',lambda:change_lines(page,selected,{},'Hết tồn quá D+2'),saved)
