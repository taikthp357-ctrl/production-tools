"""Tkinter additions to the Portable UI."""
from datetime import datetime
from collections import Counter, deque
from pathlib import Path
import re
import faulthandler
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

import sap_zone_core as core
import zone18 as z
import zone_inbound as inbound
from zone_pdf_job import run_job


def styles(root):
    style=ttk.Style(root)
    style.theme_use("clam")
    root.configure(bg="#eaf0f7")
    style.configure(".",font=("Segoe UI",10),background="#eaf0f7",foreground="#10203a")
    style.configure("TNotebook",background="#eaf0f7",borderwidth=0)
    style.configure("TNotebook.Tab",padding=(18,9),background="#e3ebf5",borderwidth=0)
    style.map("TNotebook.Tab",background=[("selected","#1559ba")],
              foreground=[("selected","#ffffff")],padding=[("selected",(18,9)),("!selected",(18,9))],
              expand=[("selected",(0,0,0,0)),("!selected",(0,0,0,0))])
    style.configure("TButton",padding=(8,5),background="#f5f8fc",bordercolor="#c7d3e3",borderwidth=1)
    style.map("TButton",background=[("active","#e1ecfb")])
    style.configure("Surface.TFrame",background="#ffffff",bordercolor="#cbd7e6")
    style.configure("Surface.TLabel",background="#ffffff")
    style.configure("Surface.TCheckbutton",background="#ffffff")
    style.configure("Mode.TRadiobutton",padding=(8,5),background="#f5f8fc")
    style.map("Mode.TRadiobutton",background=[("selected","#dbeaff")],foreground=[("selected","#164ca0")])
    style.configure("Hint.TLabel",background="#ffffff",foreground="#465b78")
    style.configure("Heading.TLabel",background="#ffffff",font=("Segoe UI",13,"bold"))
    style.configure("Result.Treeview",background="#ffffff",fieldbackground="#ffffff",rowheight=25,
                    bordercolor="#cbd7e6",borderwidth=1)
    style.configure("Result.Treeview.Heading",background="#e9f0f9",font=("Segoe UI",10,"bold"),padding=(5,5))
    style.map("Result.Treeview",background=[("selected","#cbe0ff")],foreground=[("selected","#12274d")])


def card(parent):
    return ttk.Frame(parent,style="Surface.TFrame",padding=11,borderwidth=1,relief="solid")


def accent(parent,text,command):
    return tk.Button(parent,text=text,command=command,font=("Segoe UI",10,"bold"),padx=12,pady=5,
                     fg="#ffffff",bg="#1559ba",activebackground="#124991",activeforeground="#ffffff",
                     disabledforeground="#cbdbf2",relief="flat",cursor="hand2")


class InboundPage:
    KEYS = ("ib","item","material","batch","qty","unit","sloc","bom","ib_state")
    LABELS = ("IB","Item IB","Mã hàng","Batch","Số lượng","ĐVT","SLoc","BOM / linh kiện","Trạng thái")

    def __init__(self, app, page):
        self.app=app
        self.page=page
        self.rows={}
        self.busy=False
        self.context=tk.StringVar()
        self.status=tk.StringVar(value="Dán dữ liệu để bắt đầu.")
        self.by_ib=tk.BooleanVar(value=True)
        self.demo=tk.BooleanVar(value=True)
        self.source=tk.StringVar(value="VL06I")
        self.instructions=tk.StringVar()
        top=card(page)
        top.pack(fill="x",padx=12,pady=(8,0))
        ttk.Label(top,text="Tra cứu chứng từ nhập",style="Heading.TLabel").pack(anchor="w")
        ttk.Label(top,textvariable=self.context,style="Hint.TLabel").pack(anchor="w",pady=(2,4))
        controls=ttk.Frame(top,style="Surface.TFrame")
        controls.pack(fill="x",pady=(5,3))
        ttk.Radiobutton(controls,text="Có số IB",variable=self.by_ib,value=True,command=self.mode,
                        style="Mode.TRadiobutton").pack(side="left")
        ttk.Radiobutton(controls,text="Tìm theo mã / PO",variable=self.by_ib,value=False,command=self.mode,
                        style="Mode.TRadiobutton").pack(side="left",padx=6)
        self.demo_button=ttk.Checkbutton(controls,text="Mô phỏng",variable=self.demo,command=self.clear_table,
                                        style="Surface.TCheckbutton")
        self.demo_button.pack(side="right")
        self.source_box=ttk.Combobox(controls,textvariable=self.source,values=("VL06I","ZMME240"),width=12,state="readonly")
        self.source_box.pack(side="right",padx=6)
        self.source_box.bind("<<ComboboxSelected>>",self.mode)
        ttk.Label(top,textvariable=self.instructions,style="Hint.TLabel").pack(anchor="w")
        search=ttk.Frame(top,style="Surface.TFrame")
        search.pack(fill="x",pady=(5,0))
        self.entry=tk.Text(search,height=3,wrap="none",font=("Consolas",10),bg="#f8fafc",relief="solid",bd=1,padx=7,pady=5)
        self.entry.pack(side="left",fill="x",expand=True)
        accent(search,"Tìm IB",lambda:self.action("IB")).pack(side="right",padx=(8,0))

        results=card(page)
        results.pack(fill="both",expand=True,padx=12,pady=8)
        heading=ttk.Frame(results,style="Surface.TFrame")
        heading.pack(fill="x",pady=(0,5))
        ttk.Label(heading,text="Kết quả tra cứu",style="Heading.TLabel").pack(side="left")
        ttk.Button(heading,text="Sao chép kết quả",command=self.copy_table).pack(side="right")
        actions=ttk.Frame(results,style="Surface.TFrame")
        actions.pack(fill="x",pady=(0,7))
        for label,key in (("Kiểm tra BOM trên IB","BOM IB"),("Tra BOM master","BOM master"),
                          ("Kiểm tra PO/SA","PO/SA"),("Tra Queue","Queue"),("Tra GR Doc","GR Doc")):
            ttk.Button(actions,text=label,command=lambda k=key:self.action(k)).pack(side="left",padx=(0,5))
        area=ttk.Frame(results,style="Surface.TFrame")
        area.pack(fill="both",expand=True)
        from zone_result_grid import KeyGrid
        self.tree=KeyGrid(area,list(zip(self.LABELS,(98,55,135,88,72,45,54,155,218))))
        self.tree.configure(height=5*self.tree.height_px)
        self.tree.bind("<<TreeviewSelect>>",lambda _e:self.detail())
        footer=ttk.Frame(page,padding=(12,0,12,7))
        footer.pack(fill="x")
        ttk.Label(footer,textvariable=self.status,wraplength=750).pack(side="left")
        ttk.Button(footer,text="Chi tiết dòng",command=self.toggle_detail).pack(side="right")
        self.detail_text=tk.Text(results,height=4,wrap="word",font=("Segoe UI",9),state="disabled",padx=7,pady=4)
        self.tree.tag_configure("odd",background="#f3f7fc")
        self.tree.tag_configure("warning",background="#fff4dc",foreground="#825100")
        self.tree.tag_configure("ok",background="#edf8f1",foreground="#1d5937")
        self.mode()
        self.refresh_config()

    def refresh_config(self):
        cfg=self.app.config["inbound"]
        self.context.set(f"Kho EWM {cfg['warehouse']}  ·  Plant {cfg['plant'] or 'theo IB'}  ·  SLoc {cfg['sloc'] or 'theo IB'}")

    def mode(self,_event=None):
        if self.by_ib.get():
            self.source.set("VL06I")
        self.source_box.configure(state="disabled" if self.by_ib.get() else "readonly")
        self.instructions.set("Dán IB, hoặc IB | Mã hàng | SL | ĐVT (tùy chọn). Có thể dán A:I từ workbook GR." if self.by_ib.get() else
                              "Dán Mã hàng | SL | PO/SA | Bill | item PO | ĐVT, hoặc A:I từ workbook GR. ZMME240 cần Bill.")

    def clear_table(self):
        if not self.busy:
            self.rows={}
            self.paint()
            self.status.set("Đã đổi chế độ. Tìm IB để nạp dữ liệu.")

    def copy_table(self):
        data=[self.rows[row] for row in (self.tree.selection() or self.tree.get_children())]
        if data:
            self.app.copy_text("\n".join("\t".join(str(r.get(k,"")) for k in self.KEYS) for r in data))
            self.status.set(f"Đã sao chép {len(data)} dòng.")

    def paint(self, selected=()):
        self.tree.clear_rows()
        for index,(key,row) in enumerate(self.rows.items()):
            state=row.get("ib_state","")
            caution=state.startswith(("Chưa","Ứng viên","Trạng thái SAP")) or " · " in state or row.get("bom","").startswith("Thiếu")
            tag="warning" if caution else ("ok" if state.startswith(("Đang mở","Đã hoàn tất")) else "odd" if index%2 else "")
            self.tree.append_row([row.get(field,"") for field in self.KEYS],key,tag)
        alive=[k for k in selected if k in self.rows]
        if alive:
            self.tree.selection_set(alive)
        self.detail()

    def toggle_detail(self):
        if self.detail_text.winfo_manager():
            self.detail_text.pack_forget()
        else:
            self.detail_text.pack(fill="x",pady=(5,0))

    def detail(self):
        picks=self.tree.selection()
        row=self.rows.get(picks[0],{}) if picks else {}
        summary=[]
        labels={"po":"PO/SA","po_item":"Item PO/SA","bill":"Bill","plant":"Plant","batch":"Batch","expiry":"HSD",
                "expected_qty":"SL yêu cầu","expected_sloc":"SLoc yêu cầu",
                "sap_status":"Trạng thái SAP","source":"Nguồn","ib_note":"Ghi chú"}
        summary.extend(f"{label} {row[k]}" for k,label in labels.items() if row.get(k))
        text="  •  ".join(summary)
        for key in ("BOM IB","BOM master","PO/SA","Queue","GR Doc"):
            if key in row:
                text+=f"\n{key}  {row[key]}"
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0","end")
        self.detail_text.insert("1.0",text)
        self.detail_text.configure(state="disabled")

    def selected(self):
        if self.tree.selection():
            keys=list(self.tree.selection())
            return keys,[dict(self.rows[k]) for k in keys]
        return list(self.rows),[dict(r) for r in self.rows.values()]

    def action(self, name):
        if self.busy or self.app.is_running:
            self.status.set("Đang xử lý tác vụ khác.")
            return
        source=self.source.get()
        cfg=dict(self.app.config["inbound"])
        main=dict(self.app.config)
        demo=self.demo.get()
        try:
            if name=="IB":
                keys=[]
                data=inbound.request_rows(self.entry.get("1.0","end"),self.by_ib.get(),source)
            elif name=="PO/SA" and not self.rows and not self.by_ib.get():
                requests=inbound.request_rows(self.entry.get("1.0","end"),False,"VL06I")
                self.rows={str(i):dict(r,ib_state="Chưa tra IB") for i,r in enumerate(requests)}
                self.paint()
                keys,data=self.selected()
            else:
                keys,data=self.selected()
            if not data:
                raise z.StopRun("Cần dữ liệu trong bảng trước khi tra.")
            if name=="BOM master" and not demo and not cfg.get("plant") and any(not r.get("plant") for r in data):
                raise z.StopRun("Chọn Plant trong cấu hình IN NVL để tra BOM master.")
        except (ValueError,z.StopRun) as exc:
            self.status.set(str(exc))
            return
        self.busy=True
        self.app.is_running=True
        self.demo_button.state(["disabled"])
        if name=="IB":
            self.rows={}
            self.paint()
        self.status.set(("Mô phỏng • " if demo else "")+"Đang tra "+name+"…")
        def work():
            try:
                if demo:
                    output=self.fetch(name,None,data,cfg,main,source)
                else:
                    with z.lease():
                        core.SapConnector.init_thread_com()
                        try:
                            session=z.get_session(int(main["sap_session_idx"]),main["sap_system"],main["sap_client"])
                            output=self.fetch(name,session,data,cfg,main,source)
                        finally:
                            core.SapConnector.uninit_thread_com()
                self.app.post_ui(lambda:self.complete(name,keys,output,demo))
            except Exception as exc:
                self.app.post_ui(lambda message=str(exc):self.failed(name,keys,message))
        threading.Thread(target=work,daemon=True).start()

    @staticmethod
    def fetch(name,session,data,cfg,main,source):
        if session is None:
            if name=="IB":
                return [dict(ib=q.get("ib",f"18590000{i}"),item="000010",material=q.get("material","DEMO-NVL"),
                             qty=q.get("qty","200"),unit="EA",sloc=cfg.get("sloc") or "DEMO",po=q.get("po","5300000000"),
                             po_item="00010",ib_state="Mô phỏng",source="Mô phỏng") for i,q in enumerate(data,1)]
            return [("Mô phỏng", "Dữ liệu minh họa. Tra SAP để có kết quả thật.") for _ in data]
        if name=="IB":
            if "ib" not in data[0] and source=="ZMME240":
                return inbound.verify_zmme(session,inbound.zmme(session,data,cfg,main),cfg,main)
            return inbound.vl06i(session,data,cfg,main)
        if name in ("BOM IB","BOM master"):
            values=[]
            cache={}
            for row in data:
                try:
                    if name=="BOM IB":
                        label,lines=inbound.bom_ib(session,row,{**cfg,"sap_number_format":main.get("sap_number_format","EU")})
                    else:
                        key=(row["material"],row.get("plant") or cfg["plant"],cfg.get("bom_usage","1"))
                        if key not in cache:
                            cache[key]=inbound.bom_master(session,*key)
                        lines=cache[key]
                        label="Có BOM master" if lines else "Chưa thấy BOM master"
                    detail=" • ".join(f"{r['IDNRK']} cần {r['MENGE']} {r['MEINS']}"+
                                      (f", tồn {r['available']}" if "available" in r else "") for r in lines)
                    values.append((label,label+(" → "+detail if detail else "")))
                except Exception as exc:
                    values.append(("Chưa kiểm tra được",str(exc)))
            return values
        if name=="PO/SA":
            eligible=[(i,row) for i,row in enumerate(data) if row.get("po") and row.get("material")]
            output=[inbound.purchase_result(row,[],main) for row in data]
            if eligible:
                matches = inbound.purchase(session,[row for _,row in eligible],cfg)
                for (index,row),items in zip(eligible,matches,strict=True):
                    output[index]=inbound.purchase_result(row,items,main)
            return output
        eligible=[(i,row) for i,row in enumerate(data)
                  if inbound.IB.fullmatch(row.get("ib","")) and "sap_status" in row and row.get("source")=="VL06I" and row.get("material")
                  and (name=="Queue" or row.get("material"))]
        output=[("Chưa xác minh item VL06I","Cần kết quả IB/item xác minh để tra "+name+".") for _ in data]
        if not eligible:
            return output
        rows_to_check=[row for _,row in eligible]
        if name=="Queue":
            for (index,_),rows in zip(eligible,inbound.receive_queue(session,rows_to_check,cfg),strict=True):
                output[index]=("Có Queue" if rows else "Chưa thấy Queue",
                               " • ".join(f"{r.get('QSTATE','')} {r.get('QNAME','')} {r['ERRMESS']}".strip() or "Có Queue" for r in rows))
        else:
            for (index,_),rows in zip(eligible,inbound.material_docs(session,rows_to_check,cfg),strict=True):
                output[index]=("Tìm thấy chứng từ" if rows else "Chưa thấy chứng từ",
                               " • ".join(f"{r['MBLNR']}/{r['MJAHR']} • MvT {r['BWART']} • dòng {r.get('ZEILE','?')}" for r in rows))
        return output

    def complete(self,name,keys,output,demo):
        self.busy=False
        self.app.is_running=False
        self.demo_button.state(["!disabled"])
        if name=="IB":
            self.rows={str(i):r for i,r in enumerate(output)}
            self.paint()
            found=sum(bool(row.get("material") and (row.get("source")=="Mô phỏng" or "sap_status" in row)) for row in output)
            self.status.set(("Mô phỏng • " if demo else "")+f"{found} dòng vật tư đã đọc · {len(output)-found} dòng chưa xác minh.")
        else:
            for key,(label,detail) in zip(keys,output):
                self.rows[key][name]=" · ".join(part for part in (label,detail) if part)
                if name=="BOM IB":
                    self.rows[key]["bom"]=label
            self.paint(keys)
            if not self.detail_text.winfo_manager():
                self.toggle_detail()
            groups=Counter(label for label,_ in output if label)
            summary=" · ".join(f"{count} {label}" for label,count in groups.items())
            self.status.set(f"{'Mô phỏng • ' if demo else ''}{name} · {summary or f'{len(output)} dòng'}")

    def failed(self,name,keys,message):
        self.busy=False
        self.app.is_running=False
        self.demo_button.state(["!disabled"])
        if name!="IB":
            for key in keys:
                self.rows[key][name]="Chưa kiểm tra được. "+message
                if name=="BOM IB":
                    self.rows[key]["bom"]="Chưa kiểm tra được"
            self.paint(keys)
        self.status.set("Chưa kiểm tra được • "+message)


def install(namespace):
    App=namespace["SapZoneApp"]
    old_init=App.__init__

    def init(self,root):
        from zone_workspace import start_workspace
        try:
            start_workspace(core)
        except (ValueError,OSError) as exc:
            messagebox.showerror("Dữ liệu dùng chung",str(exc),parent=root)
            root.destroy()
            raise SystemExit(1)
        self.results_are_demo=False
        self.results_context=None
        self.saved_scope=None
        self.pdf_batch=None
        self.last_pdf=None
        self.preview_running=False
        self.pdf_ui_log=None
        self.ui_updates=deque()
        old_init(self,root)
        root.title(f"{z.APP_NAME} · Portable {z.VERSION}")
        root.minsize(960,620)
        root.protocol("WM_DELETE_WINDOW",lambda:close(self))
        root.after(30,lambda:drain_ui(self))
        try:
            saved=z.latest_result()
            if saved:
                self.current_results=saved["records"]
                self.saved_scope=(self.current_results,saved.get("context"))
                render(self)
                self.status_text_var.set("Đã nạp kết quả gần nhất.")
            for run in z.output_history(self.config):
                files=run.get("pdf_files",[])
                if files and Path(files[-1]).is_file():
                    set_last_pdf(self,files[-1])
                    break
        except Exception as exc:
            self.status_text_var.set("Chưa nạp nhật ký: "+str(exc))

    def check_connection(self):
        token=object()
        self.connection_check=token
        cfg=dict(self.config)
        def work():
            try:
                core.SapConnector.init_thread_com()
                try:
                    res=core.SapConnector.test_connection(session_idx=int(cfg.get('sap_session_idx',-1)),
                        preferred_sys=cfg.get('sap_system','PSV'),preferred_client=cfg.get('sap_client','908'))
                finally:
                    core.SapConnector.uninit_thread_com()
            except Exception:
                res={}
            def ready():
                if self.connection_check is not token:return
                if res.get('ok'):
                    self._update_sap_badge(f"🟢 SAP Sẵn Sàng ({res.get('system')}/{res.get('client')} - User: {res.get('user')})",'#15803d')
                else:self._update_sap_badge('🔴 Chưa Kết Nối SAP','#b91c1c')
            post_ui(self,ready)
        threading.Thread(target=work,daemon=True).start()

    def drain_ui(self):
        self.root.after(30,lambda:drain_ui(self))
        for _ in range(16):
            try:
                callback=self.ui_updates.popleft()
            except IndexError:
                return
            callback()

    def post_ui(self,callback):
        self.ui_updates.append(callback)

    def progress_from_worker(self,value):
        post_ui(self,lambda:self.progress_bar.configure(value=value))

    def status_from_worker(self,message):
        post_ui(self,lambda:self.status_text_var.set(message))

    def close(self):
        if self.is_running or self.preview_running or any(getattr(m,'busy',False) for m in (self.out_mail,self.in_mail)):
            messagebox.showinfo(z.APP_NAME,"Tác vụ đang chạy. Đợi hoàn tất trước khi đóng.")
        else:
            editor=getattr(self.shift_page,'qty_editor',None)
            if editor and not editor.discard_ok():return
            if self.pdf_ui_log is not None:
                faulthandler.disable()
                self.pdf_ui_log.close()
            self.root.destroy()

    def build(self):
        styles(self.root)
        header=tk.Frame(self.root,bg="#0b2450")
        header.pack(fill="x")
        tk.Label(header,text=z.APP_NAME,font=("Segoe UI",17,"bold"),fg="white",bg="#0b2450").pack(side="left",padx=(17,12),pady=10)
        tk.Label(header,text="Portable "+z.VERSION,font=("Segoe UI",10),fg="#cbdcf7",bg="#0b2450").pack(side="left")
        self.sap_badge_var=tk.StringVar(value="Đang kiểm tra SAP…")
        self.lbl_sap_badge=tk.Label(header,textvariable=self.sap_badge_var,font=("Segoe UI",10,"bold"),
                                    fg="white",bg="#334155",padx=9,pady=4)
        self.lbl_sap_badge.pack(side="right",padx=14)
        self.notebook=ttk.Notebook(self.root)
        self.notebook.pack(fill="both",expand=True)
        from zone_mail_ui import MailPage
        out=ttk.Frame(self.notebook)
        page=ttk.Frame(self.notebook)
        self.tab_config=ttk.Frame(self.notebook)
        self.notebook.add(out,text="OUT NVL")
        self.notebook.add(page,text="IN NVL")
        self.notebook.add(self.tab_config,text="Cấu hình")
        report_page=ttk.Frame(self.notebook)
        self.notebook.insert(self.tab_config,report_page,text="Báo cáo")
        order=ttk.Frame(out)
        nav=ttk.Frame(out)
        nav.pack(fill="x",padx=12,pady=4)
        self.tab_main=ttk.Frame(out)
        search_frame=ttk.Frame(out)
        mail_frame=ttk.Frame(out)
        self._build_tab_main()
        buttons={}
        manual=tk.Menubutton(nav,text='Ra đơn / Tra OB ▾',relief='flat',pady=5)
        choices=tk.Menu(manual,tearoff=False)
        manual.configure(menu=choices)
        manual.pack(side='left',padx=(0,3))
        for key,title in [('lookup','Tra OB / In phiếu'),('manual','Ra đơn dán tay')]:
            choices.add_command(label=title,command=lambda k=key:select(k))
        def select(mode):
            if self.is_running:
                return
            self.tab_main.pack_forget()
            search_frame.pack_forget()
            mail_frame.pack_forget()
            order.pack_forget()
            if mode=="search":
                search_frame.pack(fill="both",expand=True)
            elif mode=="new":
                order.pack(fill="both",expand=True)
            elif mode=="mail":
                mail_frame.pack(fill="both",expand=True)
            else:
                self.out_mode.set(mode)
                change_mode(self)
                self.tab_main.pack(fill="both",expand=True)
            manual.configure(text={'lookup':'Tra OB / In phiếu ▾','manual':'Ra đơn dán tay ▾'}.get(mode,'Ra đơn / Tra OB ▾'))
            for key,b in buttons.items():
                b.configure(bg="#1559ba" if key==mode else "#e3ebf5",fg="white" if key==mode else "#10203a")
        for mode,title in (("new","Tra cứu KHSX / Model"),("mail","Check mail OD"),("search","Tra mã / Cấp bù")):
            buttons[mode]=tk.Button(nav,text=title,width=16,relief="flat",pady=5,command=lambda m=mode:select(m))
            buttons[mode].pack(side="left",padx=(0,3))
        self.out_mail=MailPage(self,mail_frame,"out")
        self.out_mail.cfg.pop("workbook",None)
        from zone_shift_ui import ShiftPage
        self.shift_page=ShiftPage(self,order,report_page,lambda rows,path,stamp:start_order(self,rows,path,stamp))
        from zone_search import SearchPage
        self.search_page=SearchPage(search_frame,self.shift_page,lambda:select("new"))
        self.show_order_page=lambda:(self.notebook.select(out),select('new'))
        from zone_workspace import schedule_tab
        schedule_tab(self)
        def lookup_result(obs,mock):
            self.mock_mode_var.set(mock)
            select("lookup")
            self.txt_input.delete("1.0","end")
            self.txt_input.insert("1.0","\n".join(obs))
            lookup_obs(self,obs)
        self.shift_page.lookup_result=lookup_result
        ttk.Button(header,text="Thông báo",command=lambda:show_log(self)).pack(side="right",padx=3)
        ttk.Button(header,text="Bắt đầu / đổi ca…",command=self.shift_page.choose).pack(side="right",padx=6)
        ttk.Label(nav,textvariable=self.shift_page.title).pack(side="right",padx=8)
        select("lookup")
        inner=ttk.Notebook(page)
        inner.pack(fill="both",expand=True)
        ib=ttk.Frame(inner)
        arrivals=ttk.Frame(inner)
        inner.add(ib,text="Tra IB")
        inner.add(arrivals,text="Hàng về và BOM")
        self.inbound_page=InboundPage(self,ib)
        self.in_mail=MailPage(self,arrivals,"in")
        self._build_tab_config()

    def stamp_editor(self,parent,sample="20-03"):
        from zone_stamp_ui import edit_style
        def persist(style):
            config={**self.config,"pdf_stamp":style}
            if not core.ConfigManager.save_config(config):
                raise ValueError("Chưa lưu được kiểu số.")
            self.config=config
        def preview(request,target):
            run_job(core.get_base_dir(),request,target=target)
            run_job(core.get_base_dir(),dict(operation="preview",path=str(target)))
        edit_style(parent,self.config.get("pdf_stamp",{}),sample,persist,preview,self.post_ui)

    def config_ui(self):
        book=ttk.Notebook(self.tab_config)
        book.pack(fill="both",expand=True,padx=12,pady=10)
        panels={}
        for name in ("Chung","OUT NVL","IN NVL"):
            frame=ttk.Frame(book,padding=12)
            book.add(frame,text=name)
            panels[name]=frame
        common,out,inp=panels.values()
        from zone_workspace import appearance_tab
        appearance_tab(self,book)
        def entry(parent,index,label,value,wide=19):
            row,col=divmod(index,2)
            col*=2
            ttk.Label(parent,text=label).grid(row=row,column=col,sticky="w",padx=(0,8),pady=6)
            widget=ttk.Entry(parent,width=wide)
            widget.insert(0,str(value))
            widget.grid(row=row,column=col+1,sticky="ew",padx=(0,14),pady=6)
            return widget
        def add(panel,fields):
            for index,(attr,key,label) in enumerate(fields):
                setattr(self,attr,entry(panel,index,label,self.config.get(key,"")))
        add(common,[("cfg_sap_sys","sap_system","System SAP"),("cfg_sap_client","sap_client","Client"),
                    ("cfg_sap_idx","sap_session_idx","Chỉ số phiên (-1: tự chọn)"),("cfg_sap_num","sap_number_format","Định dạng số SAP (EU / US / AUTO)")])
        if not self.cfg_sap_num.get():
            self.cfg_sap_num.insert(0,"EU")
        ttk.Button(common,text="Thử kết nối",command=self._test_sap_connection).grid(row=3,column=0,sticky="w")
        ttk.Button(common,text="Đối soát Post",command=lambda:reconcile(self)).grid(row=3,column=1,sticky="w")
        ttk.Label(common,text="-1 dùng phiên SAP khớp đầu tiên đang rảnh. Chỉ số 0 trở lên dùng phiên chỉ định.").grid(row=4,column=0,columnspan=4,sticky="w",pady=12)
        add(out,[("cfg_whse","ewm_warehouse","Kho EWM"),("cfg_storage","ewm_storage_type","Storage Type"),
                 ("cfg_owner","ewm_owner","Owner"),("cfg_plant","plant","Plant MIGO"),
                 ("cfg_sloc_from","sloc_from","SLoc xuất"),("cfg_sloc_to","sloc_to","SLoc nhận"),
                 ("cfg_max_mats","max_materials_per_group","Số mã / OB"),("cfg_max_lines","max_lines_per_group","Số dòng / OB"),
                 ("cfg_strategy","allocation_strategy","FIFO / FEFO"),("cfg_copies","sap_print_copies","Số liên tại SAP"),
                 ("cfg_pdf_dir","pdf_output_folder","Thư mục PDF"),("cfg_av_node","available_node","Node Available Stock"),
                 ("cfg_av_col","available_column","Cột Available Qty"),("cfg_av_unit","available_unit_column","Cột ĐVT khả dụng")])
        self.cfg_auto_print=tk.BooleanVar(value=bool(self.config.get("auto_print_pdf",False)))
        ttk.Checkbutton(out,text="Tự gửi WHO sang SAP sau khi ra đơn mới",variable=self.cfg_auto_print).grid(row=7,column=0,columnspan=2,sticky="w")
        ttk.Button(out,text="Chọn thư mục PDF",command=self._browse_pdf_dir).grid(row=7,column=2,columnspan=2,sticky="w")
        self.cfg_skip_blank=tk.BooleanVar(value=self.config.get("pdf_skip_blank",True))
        ttk.Checkbutton(out,text="Mặc định bỏ trang trắng trong PDF",variable=self.cfg_skip_blank).grid(
            row=10,column=0,columnspan=2,sticky="w",pady=5)
        ttk.Button(out,text="Chỉnh số phiếu PDF",command=lambda:stamp_editor(self,self.root)).grid(row=10,column=2,columnspan=2,sticky="w")
        self.lbl_zone_status=ttk.Label(out,text=f"Ánh xạ Zone • {len(self.zone_mgr.mappings)} quy tắc")
        self.lbl_zone_status.grid(row=8,column=0,columnspan=2,sticky="w",pady=9)
        mapbar=ttk.Frame(out)
        mapbar.grid(row=8,column=2,columnspan=2,sticky="w")
        ttk.Button(mapbar,text="Mở ánh xạ",command=self._open_zone_file).pack(side="left")
        ttk.Button(mapbar,text="Nạp lại",command=self._reload_zone_map).pack(side="left",padx=4)
        ttk.Label(out,text="Bỏ trống Node và cột để nhận theo tên. Chỉ đặt mã kỹ thuật khi đã đối chiếu layout SAP.").grid(row=9,column=0,columnspan=4,sticky="w")
        self.inbound_entries={}
        names={"warehouse":"Kho EWM nhập","plant":"Plant nhập / tra BOM","sloc":"SLoc tham chiếu",
               "date_from":"Từ ngày (DD.MM.YYYY)","date_to":"Đến ngày (DD.MM.YYYY)",
               "me2n_scope":"Phạm vi ME2N",
               "bom_usage":"BOM Usage (CS03)","component_stock_column":"Tên cột tồn linh kiện đã xác minh"}
        for index,(key,label) in enumerate(names.items()):
            value=self.config["inbound"].get(key,"1" if key=="bom_usage" else "")
            self.inbound_entries[key]=entry(inp,index,label,value)
        ttk.Label(inp,text="Ngày trống dùng bộ lọc theo workbook GR. Plant và SLoc đọc từ IB nếu để trống.").grid(row=6,column=0,columnspan=4,sticky="w",pady=12)
        ttk.Button(self.tab_config,text="Lưu cấu hình",command=self._save_config).pack(anchor="e",padx=18,pady=(0,12))

    def save(self):
        if self.is_running:
            messagebox.showinfo("Cấu hình","Đợi tác vụ hoàn tất trước khi đổi cấu hình.")
            return
        config=dict(self.config)
        fields={"sap_system":self.cfg_sap_sys,"sap_client":self.cfg_sap_client,"sap_session_idx":self.cfg_sap_idx,
                "sap_number_format":self.cfg_sap_num,"ewm_warehouse":self.cfg_whse,"ewm_storage_type":self.cfg_storage,
                "ewm_owner":self.cfg_owner,"plant":self.cfg_plant,"sloc_from":self.cfg_sloc_from,"sloc_to":self.cfg_sloc_to,
                "max_materials_per_group":self.cfg_max_mats,"max_lines_per_group":self.cfg_max_lines,
                "allocation_strategy":self.cfg_strategy,"sap_print_copies":self.cfg_copies,"pdf_output_folder":self.cfg_pdf_dir,
                "available_node":self.cfg_av_node,"available_column":self.cfg_av_col,"available_unit_column":self.cfg_av_unit}
        config.update({k:v.get().strip() for k,v in fields.items()})
        config["auto_print_pdf"]=self.cfg_auto_print.get()
        config["pdf_skip_blank"]=self.cfg_skip_blank.get()
        config["inbound"]={k:v.get().strip() for k,v in self.inbound_entries.items()}
        try:
            for k in ("sap_session_idx","max_materials_per_group","max_lines_per_group","sap_print_copies"):
                config[k]=int(config[k])
            if (config["sap_session_idx"] < -1 or not 1<=config["max_materials_per_group"]<=5 or
                    not 1<=config["max_lines_per_group"]<=20 or not 1<=config["sap_print_copies"]<=20):
                raise ValueError("Chỉ số phiên hoặc giới hạn nhóm/bản in không hợp lệ.")
            if config["allocation_strategy"] not in ("FIFO","FEFO") or config["sap_number_format"] not in ("EU","US","AUTO"):
                raise ValueError("Chọn FIFO/FEFO và định dạng EU/US/AUTO.")
            if not all(config[k] for k in ("sap_system","sap_client","ewm_warehouse","ewm_storage_type","ewm_owner","plant","sloc_from","sloc_to")):
                raise ValueError("Cần System, Client và cấu hình kho xuất.")
            if not config["inbound"]["warehouse"] or not config["inbound"]["bom_usage"]:
                raise ValueError("Cần kho nhập và BOM Usage.")
            inbound.dates(config["inbound"])
            if not core.ConfigManager.save_config(config):
                raise ValueError("Không ghi được cấu hình.")
        except (OSError,ValueError,z.StopRun) as exc:
            messagebox.showerror("Cấu hình",str(exc))
            return
        self.config=config
        self.inbound_page.refresh_config()
        if self.shift_page.table:
            import zone_shift
            self.shift_page.candidates=zone_shift.candidates(self.shift_page.table,config)
            self.shift_page.refresh_receipts()
            self.shift_page.filter_changed()
        update_print(self)
        self._check_sap_status_async()
        messagebox.showinfo("Cấu hình","Đã lưu cấu hình Chung, OUT NVL và IN NVL.")

    def build_main(self):
        top=card(self.tab_main)
        top.pack(fill="x",padx=12,pady=(8,0))
        bar=ttk.Frame(top,style="Surface.TFrame")
        bar.pack(fill="x")
        self.out_mode=tk.StringVar(value="lookup")
        self.mock_mode_var=tk.BooleanVar(value=True)
        ttk.Checkbutton(bar,text="Mô phỏng",variable=self.mock_mode_var,
                        style="Surface.TCheckbutton",command=lambda:update_print(self)).pack(side="right")
        ttk.Button(bar,text="Dán",command=self._paste_clipboard).pack(side="right",padx=5)
        ttk.Button(bar,text="Xóa",command=self._clear_input).pack(side="right")
        self.out_hint=tk.StringVar()
        self.input_size=ttk.Button(bar,text="Mở rộng",command=lambda:expand_input(self))
        self.input_size.pack(side="right",padx=(0,5))
        ttk.Label(top,textvariable=self.out_hint,style="Hint.TLabel").pack(anchor="w",pady=(4,2))
        self.txt_input=tk.Text(top,height=2,wrap="none",font=("Consolas",10),bg="#f8fafc",
                               fg="#10203a",relief="solid",bd=1,padx=8,pady=4,undo=True)
        self.txt_input.pack(fill="x")
        self.out_drafts={}
        self.out_input_mode="lookup"
        self.out_actions=ttk.Frame(top,style="Surface.TFrame")
        self.out_actions.pack(fill="x",pady=(4,0))
        self.number_inputs=ttk.Frame(self.out_actions,style="Surface.TFrame")
        self.sodon_prefix_var=tk.StringVar(value=datetime.now().strftime("%d-"))
        self.sodon_start_var=tk.StringVar(value="1")
        for label,variable,width in (("Tiền tố INWH",self.sodon_prefix_var,9),("Số bắt đầu",self.sodon_start_var,6)):
            ttk.Label(self.number_inputs,text=label,style="Surface.TLabel").pack(side="left",padx=(0,5))
            ttk.Entry(self.number_inputs,textvariable=variable,width=width).pack(side="left",padx=(0,10))
        self.btn_run=accent(self.out_actions,"Ra đơn mới",lambda:start_new(self))
        self.btn_continue_ob=accent(self.out_actions,"Tra OB",lambda:continue_ob(self))
        self.progress_bar=ttk.Progressbar(top,mode="determinate")

        results=card(self.tab_main)
        results.pack(fill="both",expand=True,padx=12,pady=8)
        heading=ttk.Frame(results,style="Surface.TFrame")
        heading.pack(fill="x",pady=(0,6))
        ttk.Label(heading,text="Kết quả theo dõi",style="Heading.TLabel").pack(side="left")
        self.lbl_row_count=ttk.Label(heading,style="Hint.TLabel")
        self.lbl_row_count.pack(side="left",padx=9)
        self.btn_show_pdf=accent(heading,"Mở PDF đã đóng số",lambda:open_pdf(self))
        self.btn_show_pdf.configure(text="Mở PDF…")
        self.btn_show_pdf.pack(side="right")
        accent(heading,"Chọn PDF gốc",lambda:choose_source(self)).pack(side="right",padx=6)
        tools=ttk.Frame(results,style="Surface.TFrame")
        tools.pack(fill="x",pady=(0,5))
        for label,command in (
            ("Chọn cả OB",lambda:select_ob(self)),("Tra lại MON",lambda:retry_ob(self)),
            ("Gán số đơn",lambda:assign_numbers(self)),("Copy 3 cột",self._copy_3_columns_to_clipboard),
        ):
            ttk.Button(tools,text=label,command=command).pack(side="left",padx=(0,5))
        button=ttk.Menubutton(tools,text="Thao tác")
        menu=tk.Menu(button,tearoff=False)
        menu.add_command(label="Lấy PDF từ SAP cho dòng đã chọn",command=self._on_btn_create_pdf_clicked)
        self.out_action_menu=menu
        for label,command in (("Gán số đơn cho dòng đã chọn",lambda:assign_numbers(self,selected_records(self))),
                              ("Chi tiết dòng đã chọn",lambda:show_selected_details(self)),
                              ("Xuất Excel",self._export_excel),("Mở thư mục PDF",self._open_pdf_folder),
                              ("Lịch sử",lambda:show_history(self)),
                              ("Ô đang chọn",self._on_tree_copy_shortcut),("Dòng đã chọn (4 cột)",lambda:copy_rows(self)),
                              ("Cột OB",self._copy_ob_column_to_clipboard),("Cột INWH",self._copy_sodon_column_to_clipboard),
                              ("Danh sách WHO in được",self._copy_who_column_to_clipboard),
                              ("Toàn bộ bảng (4 cột)",self._copy_4_columns_to_clipboard)):
            menu.add_command(label=label,command=command)
        button.configure(menu=menu)
        button.pack(side="right")
        self.btn_create_pdf=accent(tools,"Lấy PDF từ SAP",lambda:print_selected(self,all_results=True))
        self.btn_create_pdf.pack(side="right",padx=(5,7))
        table=ttk.Frame(results,style="Surface.TFrame")
        table.pack(fill="both",expand=True)
        columns=("ob","material","sodon","who","state")
        from zone_result_grid import KeyGrid
        self.tree=KeyGrid(table,list(zip(("Số OB","Mã hàng","Số đơn INWH","Mã WHO SAP","Trạng thái"),(120,150,135,200,160))))
        self.tree.configure(height=6*self.tree.height_px)
        for name,background,foreground in (("oddrow","#f3f7fc","#10203a"),("evenrow","#ffffff","#10203a"),
                                            ("ready","#edf8f1","#1d5937"),("pending","#fff8e8","#825100"),
                                            ("error","#fff0f0","#8b2830")):
            self.tree.tag_configure(name,background=background,foreground=foreground)
        self.tree.bind("<Double-1>",self._on_tree_double_click)
        self.tree.bind("<Button-3>",self._on_tree_right_click)
        self.tree.bind("<<TreeviewSelect>>",lambda _event:update_print(self))
        footer=ttk.Frame(self.tab_main,padding=(12,0,12,8))
        footer.pack(side="bottom",fill="x",before=results)
        self.status_text_var=tk.StringVar(value="Dán số OB để tra MON.")
        ttk.Label(footer,textvariable=self.status_text_var,wraplength=680).pack(side="left")
        self.out_log=[]
        self.status_text_var.trace_add("write",lambda *_:log_status(self))
        ttk.Button(footer,text="Nhật ký thao tác",command=lambda:show_log(self)).pack(side="right")
        change_mode(self)
        render(self)

    def expand_input(self):
        expanded=int(self.txt_input.cget("height"))==2
        self.txt_input.configure(height=6 if expanded else 2)
        self.input_size.configure(text="Thu gọn" if expanded else "Mở rộng")

    def change_mode(self):
        mode=self.out_mode.get()
        if self.is_running:
            self.out_mode.set(self.out_input_mode)
            return
        if mode!=self.out_input_mode:
            self.out_drafts[self.out_input_mode]=self.txt_input.get("1.0","end-1c")
            self.txt_input.delete("1.0","end")
            self.txt_input.insert("1.0",self.out_drafts.get(mode,""))
            self.out_input_mode=mode
        self.btn_run.pack_forget()
        self.btn_continue_ob.pack_forget()
        self.number_inputs.pack_forget()
        if mode=="lookup":
            self.out_hint.set("Mỗi dòng một số OB. App tra cả danh sách trong một lượt MON.")
            self.btn_continue_ob.pack(side="right")
        else:
            self.out_hint.set("Dán từ Excel theo thứ tự Mã hàng · Số lượng · Trạm · Zone (tùy chọn).")
            self.btn_run.pack(side="right")
            self.number_inputs.pack(side="left")

    def log_status(self):
        self.out_log.append(f"{datetime.now():%H:%M:%S}  {self.status_text_var.get()}")
        del self.out_log[:-100]

    def show_log(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("Nhật ký thao tác OUT NVL")
        dialog.geometry("730x330")
        view=tk.Text(dialog,padx=10,pady=8,wrap="word")
        view.insert("1.0","\n".join(self.out_log))
        view.see("end")
        view.configure(state="disabled")
        view.pack(fill="both",expand=True)

    def show_history(self):
        if self.is_running:
            return
        try:
            runs=z.output_history(self.config)
        except Exception as exc:
            messagebox.showerror("Lịch sử",str(exc))
            return
        if not runs:
            messagebox.showinfo("Lịch sử","Chưa có lượt tra SAP đã lưu.")
            return
        dialog=tk.Toplevel(self.root)
        dialog.title("Lịch sử OUT NVL")
        dialog.geometry("710x350")
        listing=tk.Listbox(dialog,font=("Segoe UI",10))
        listing.pack(fill="both",expand=True,padx=12,pady=10)
        for run in runs:
            obs=list(dict.fromkeys(row["ob"] for row in run["records"]))
            listing.insert("end",f"{run['run_id']}  •  {len(obs)} OB  •  {', '.join(obs[:4])}")
        def load():
            selected=listing.curselection()
            if not selected or self.is_running:
                return
            self.current_results=runs[selected[0]]["records"]
            self.saved_scope=(self.current_results,runs[selected[0]].get("context"))
            self.results_are_demo=False
            self.results_context=None
            render(self)
            self.status_text_var.set("Đã mở lịch sử. Bấm Tra lại MON để xác minh cả danh sách trước khi in.")
            dialog.destroy()
        ttk.Button(dialog,text="Mở kết quả",command=load).pack(anchor="e",padx=12,pady=(0,10))
        listing.bind("<Double-1>",lambda _e:load())

    def copy_text(self,value):
        self.root.clipboard_clear()
        self.root.clipboard_append(value)

    def copy(self,_event=None):
        return self.tree.copy_cell(_event)

    def copy_rows(self):
        copy_tracking(self,4,selected_records(self))

    def copy_tracking(self,count,records=None):
        records=self.current_results if records is None else records
        data=[z.tracking_values(row)[:count] for row in records]
        if data:
            self.copy_text("\r\n".join("\t".join(map(str,row)) for row in data))
            self.status_text_var.set(f"Đã sao chép {len(data)} dòng.")

    def copy_whos(self):
        whos=z.printable_whos(self.current_results)
        if whos:
            self.copy_text("\r\n".join(whos))
            self.status_text_var.set(f"Đã sao chép {len(whos)} WHO in được.")

    def copy_numbers(self):
        if self.current_results:
            self.copy_text("\r\n".join(z.tracking_values(row)[2] for row in self.current_results))
            self.status_text_var.set(f"Đã sao chép số đơn của {len(self.current_results)} dòng.")

    def export_excel(self):
        if not self.current_results:
            return
        path=filedialog.asksaveasfilename(parent=self.root,defaultextension=".xlsx",
                                         filetypes=[("Excel","*.xlsx")],
                                         initialfile=f"KET_QUA_RA_DON_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
        if path:
            try:
                z.export_tracking(self.current_results,path)
            except Exception as exc:
                messagebox.showerror("Xuất Excel",str(exc),parent=self.root)
                return
            self.status_text_var.set("Đã lưu Excel • "+path)

    def show_selected_details(self):
        records=selected_records(self)
        if records:
            lines=[f"{row['ob']} · {row['material']}\n{row.get('detail') or row.get('state','')}" for row in records[:12]]
            if len(records)>12:
                lines.append(f"Còn {len(records)-12} dòng. Có thể xem toàn bộ trong file Excel.")
            messagebox.showinfo("Chi tiết dòng đã chọn","\n\n".join(lines),parent=self.root)

    def render(self):
        self.tree.clear_rows()
        for index,row in enumerate(self.current_results):
            state=row.get("state") or ("Đã lưu WHO" if z.printable_whos([row]) else "Chờ WHO")
            values=[row.get(k,"") for k in ("ob","material","sodon","who")]+[state]
            if self.results_are_demo:
                values[-1]="Mô phỏng"
            elif self.results_context!=z.output_context(self.config) and z.printable_whos([row]):
                values[-1]="Đã lưu WHO · tra lại"
            tag={"Sẵn sàng in":"ready","Đã lưu PDF":"ready","Chờ WHO":"pending",
                 "In được một phần":"pending","Đã in một phần":"pending",
                 "Không in · toàn A":"pending","Chưa kiểm tra hết WT":"pending",
                 "Chưa thấy OB trong MON":"pending","Chưa xác minh Document":"pending",
                 "Không tìm thấy OB":"pending","Lỗi tra MON":"error"}.get(values[-1],"evenrow" if index%2==0 else "oddrow")
            self.tree.append_row(values,str(index),tag)
        count=len({row["ob"] for row in self.current_results})
        self.lbl_row_count.configure(text=f"{count} OB · {len(self.current_results)} dòng")
        update_print(self)

    def finished(self,summary):
        self.is_running=False
        self.btn_run.configure(state="normal",text="Ra đơn mới")
        self.btn_continue_ob.configure(state="normal",text="Tra OB")
        pending=getattr(self,'lookup_pending',())
        self.lookup_pending=()
        if pending and not summary.get('records'):
            self.current_results=[]
            summary=dict(summary,message='Chưa có kết quả cho '+', '.join(pending)+' · '+summary.get('message',''))
        if summary.get("records"):
            self.current_results=summary["records"]
            self.results_are_demo=bool(summary.get("is_mock",True))
            self.results_context=summary.get("context")
        render(self)
        if hasattr(self,"shift_page"):
            if getattr(self.shift_page,"posting",False):
                self.shift_page.order_progress.set(summary.get("message") or "Đã kết thúc.")
            self.shift_page.posting=False
            self.shift_page.run_btn.configure(text="Ra đơn các dòng đã chọn")
            self.shift_page.refresh_receipts(summary)
            if summary.get('order_file') and not summary.get('is_mock'):
                page=self.shift_page
                valid=[e for e in page.cached_receipts if e['run']==summary.get('run_id') and e['valid'] and not e['mock']]
                if valid and page.path:
                    from zone_order_result import write
                    path,pwd=page.path,page.password
                    page.task('Ghi OB và số đơn vào ORDER…',
                        lambda:write(path,pwd,valid),lambda result:page.activate(path,pwd,result[1]))
        lookup_done=summary.get("lookup") and summary.get("records")
        self.progress_bar.configure(value=100 if summary["success"] or lookup_done else 0)
        self.progress_bar.pack_forget()
        self.status_text_var.set(summary.get("message") or "Đã kết thúc.")
        if summary.get("pdf_files"):
            set_last_pdf(self,summary["pdf_files"][-1])
        for failure in summary.get("failures",[]):
            self.out_log.append(f"{datetime.now():%H:%M:%S}  {failure}")
        del self.out_log[:-100]
        if not summary["success"] and not lookup_done:
            messagebox.showwarning("Cần kiểm tra",summary.get("message") or "Tác vụ chưa hoàn tất.")

    def edit_number(self,item,_values):
        if item.isdecimal() and int(item)<len(self.current_results):
            assign_numbers(self,[self.current_results[int(item)]])

    def trace_pdf_ui(self,step):
        try:
            if self.pdf_ui_log is None:
                logs=Path(core.get_base_dir())/"data"/"pdf_logs"
                logs.mkdir(parents=True,exist_ok=True)
                self.pdf_ui_log=(logs/f"UI_{datetime.now():%Y%m%d_%H%M%S_%f}.log").open(
                    "a",encoding="utf-8",buffering=1)
                faulthandler.enable(file=self.pdf_ui_log)
            self.pdf_ui_log.write(f"{datetime.now():%H:%M:%S}  {step}\n")
        except (OSError,RuntimeError):
            # Print jobs still report their own errors if the UI log is unavailable.
            pass

    def can_import(self):
        context=z.output_context(self.config)
        return self.results_context==context or (self.saved_scope is not None and
                self.saved_scope[0] is self.current_results and self.saved_scope[1]==context)

    def choose_source(self):
        if self.is_running:
            return
        sources=filedialog.askopenfilenames(parent=self.root,title="Chọn PDF gốc từ SAP",filetypes=[("PDF","*.pdf")])
        if not sources:
            return
        self.is_running=True
        def offline(found,error):
            self.is_running=False
            if error or not found:
                messagebox.showwarning("PDF",error or "Chưa nhận diện được WHO trong PDF.")
                return
            if self.current_results and can_import(self) and not self.results_are_demo:
                ready=set(z.printable_whos(self.current_results))
                blocked={w for row in self.current_results for w in row.get("who","").split("/") if z.WHO.fullmatch(w)}-ready
                if set(found)&blocked:
                    messagebox.showwarning("PDF","Có WHO đang bị chặn trong bảng kết quả: "+", ".join(sorted(set(found)&blocked)))
                    return
                if set(found)<=ready:
                    print_selected(self,True,True,sources,found)
                    return
            win=tk.Toplevel(self.root)
            win.title("Đóng số trực tiếp trên PDF gốc")
            win.transient(self.root)
            win.grab_set()
            ttk.Label(win,text="Mỗi dòng một WHO và số phiếu. Có thể chỉnh số trước khi đóng.").pack(padx=12,pady=6)
            entries=tk.Text(win,width=40,height=min(16,len(found)+1))
            entries.pack(padx=12)
            for i,who in enumerate(found,1):
                entries.insert("end",f"{who}  {datetime.now():%d}-{i:02}\n")
            blank=tk.BooleanVar(value=self.config.get("pdf_skip_blank",True))
            ttk.Checkbutton(win,text="Bỏ trang trắng",variable=blank).pack(anchor="w",padx=12)
            def submit():
                try:
                    pairs=[line.split() for line in entries.get("1.0","end").splitlines() if line.strip()]
                    orders=dict(pairs)
                    if len(pairs)!=len(found) or set(orders)!=set(found) or len(set(orders.values()))!=len(found):
                        raise ValueError("Mỗi WHO cần một số phiếu riêng.")
                except ValueError as exc:
                    messagebox.showwarning("PDF",str(exc),parent=win)
                    return
                skip=blank.get()
                win.destroy()
                send_pdf(self,orders,skip,int(self.config.get("sap_print_copies",2)),sources,offline=True)
            ttk.Button(win,text="Kiểu số phiếu",command=lambda:stamp_editor(self,win)).pack(side="left",padx=12,pady=6)
            ttk.Button(win,text="Đóng số và mở PDF",command=submit).pack(side="right",padx=12,pady=6)
        def worker():
            try:
                result=run_job(core.get_base_dir(),dict(operation="inspect",sources=list(sources)))
                post_ui(self,lambda:offline(result["whos"],""))
            except Exception as exc:
                post_ui(self,lambda msg=str(exc):offline([],msg))
        threading.Thread(target=worker,daemon=True).start()

    def print_selected(self,all_results=False,importing=False,chosen_sources=(),source_whos=()):
        if self.is_running:
            return
        if (self.mock_mode_var.get() and not importing) or self.results_are_demo:
            messagebox.showinfo("In PDF","Cần kết quả WHO đã tra trên SAP và tắt mô phỏng để in.")
            return
        scope_ok=can_import(self) if importing else self.results_context==z.output_context(self.config)
        if not self.current_results or not scope_ok:
            messagebox.showinfo("In PDF","Mở kết quả từ Lịch sử hoặc tra OB để có danh sách WHO và số INWH." if importing else "Tra lại MON để xác minh WHO trước khi in.")
            return
        trace_pdf_ui(self,"Đọc danh sách WHO đủ điều kiện in")
        records=self.current_results if all_results else selected_records(self)
        whos=[w for w in z.printable_whos(records) if not source_whos or w in source_whos]
        if not whos:
            messagebox.showwarning("In PDF","Phạm vi này chưa có WHO đủ điều kiện in.")
            return
        batch=self.pdf_batch if importing and self.pdf_batch and self.pdf_batch[0] is self.current_results else None
        numbers=z.known_orders(self.current_results)
        if batch:
            numbers.update(batch[1])
        missing=sum(who not in numbers for who in whos)
        if missing:
            try:
                history=[row for run in z.output_history(self.config) for row in run["records"]]
                prior=[{"who_numbers":numbers},*self.current_results,*history]
                numbers=z.known_orders(prior)
                numbering=z.Pipeline({"sodon_prefix":self.sodon_prefix_var.get(),
                                      "sodon_start":self.sodon_start_var.get()},None)
                generated=z.available_order_numbers(*numbering.numbering(),prior)
                for who in whos:
                    if who not in numbers:
                        numbers[who]=next(generated)
            except Exception as exc:
                messagebox.showerror("In PDF",f"Chưa chuẩn bị được số INWH. {exc}")
                return
        dialog=tk.Toplevel(self.root)
        dialog.title("Đối chiếu PDF gốc với WHO" if importing else "Lấy PDF từ SAP")
        dialog.geometry("660x370")
        dialog.transient(self.root)
        dialog.grab_set()
        panel=ttk.Frame(dialog,padding=12)
        panel.pack(fill="both",expand=True)
        copies=int(self.config.get("sap_print_copies",2))
        if batch:
            copies=batch[2]
        label=tk.StringVar()
        ttk.Label(panel,textvariable=label).pack(anchor="w")
        table=ttk.Frame(panel)
        table.pack(fill="both",expand=True,pady=8)
        listing=tk.Listbox(table,selectmode="multiple",exportselection=False,font=("Consolas",10))
        scroll=ttk.Scrollbar(table,command=listing.yview)
        scroll.pack(side="right",fill="y")
        listing.configure(yscrollcommand=scroll.set)
        listing.pack(side="left",fill="both",expand=True)
        by_who={who:set() for who in whos}
        for row in records:
            for who in z.printable_whos([row]):
                if who in by_who:
                    by_who[who].add(row["ob"])
        inwh_width=max(16,max(len(numbers.get(who,""))+3 for who in whos))
        ttk.Label(panel,text=f"{'WHO':<14}{'INWH':<{inwh_width}}OB",font=("Consolas",10)).pack(before=table,anchor="w",padx=3)
        for who in whos:
            listing.insert("end",f"{who:<14}{numbers.get(who,'Chưa gán'):<{inwh_width}}{' / '.join(sorted(by_who[who]))}")
        for i, who in enumerate(whos):
            if not batch or who in batch[1]:
                listing.selection_set(i)
        pending_count=sum(not z.printable_whos([row]) for row in records)
        if pending_count:
            ttk.Label(panel,text=f"{pending_count} dòng trong phạm vi không có WHO đủ điều kiện in.").pack(anchor="w")
        excluded={who for row in records for who in row.get("who","").split("/") if z.WHO.fullmatch(who)}-set(whos)
        if excluded:
            ttk.Label(panel,text=f"{len(excluded)} WHO ngoài phạm vi in. Xem chi tiết trong bảng kết quả.").pack(anchor="w")
        if missing:
            ttk.Label(panel,text="Số INWH mới trong danh sách được lưu sau khi tạo PDF thành công.").pack(anchor="w")
        skip_blank=tk.BooleanVar(master=dialog,value=batch[3] if batch else self.config.get("pdf_skip_blank",True))
        ttk.Checkbutton(panel,text="Bỏ trang trắng",variable=skip_blank).pack(anchor="w")
        def redraw(_event=None):
            selected=[whos[i] for i in listing.curselection()]
            count=len({ob for who in selected for ob in by_who[who]})
            label.set(f"{count} OB · {len(selected)} WHO · {copies} bản/WHO")
            confirm.configure(state="normal" if selected else "disabled")
        def confirm_print():
            selected=[whos[i] for i in listing.curselection()]
            if selected:
                options=skip_blank.get()
                sources=chosen_sources
                if importing and not sources:
                    sources=filedialog.askopenfilenames(parent=dialog,title="Chọn một hoặc nhiều PDF gốc từ SAP",
                                                       filetypes=[("PDF","*.pdf")])
                    if not sources:
                        return
                dialog.destroy()
                send_pdf(self,{who:numbers[who] for who in selected},options,copies,sources)
        footer=ttk.Frame(panel)
        footer.pack(fill="x",pady=(5,0))
        def select_all(selected):
            if selected:
                listing.selection_set(0,"end")
            else:
                listing.selection_clear(0,"end")
            redraw()
        ttk.Button(footer,text="Chọn tất cả",command=lambda:select_all(True)).pack(side="left")
        ttk.Button(footer,text="Bỏ chọn tất cả",command=lambda:select_all(False)).pack(side="left",padx=5)
        if importing:
            def edit_number_style():
                selected=listing.curselection()
                example=numbers[whos[selected[0] if selected else 0]]
                stamp_editor(self,dialog,example)
            ttk.Button(footer,text="Chỉnh số phiếu",command=edit_number_style).pack(side="left")
        confirm=accent(footer,"Chọn file và đóng số" if importing else "Gửi sang SAP",confirm_print)
        confirm.pack(side="right")
        listing.bind("<<ListboxSelect>>",redraw)
        redraw()
        trace_pdf_ui(self,f"Đã mở xác nhận in · {len(whos)} WHO")

    def set_last_pdf(self,path):
        self.last_pdf=Path(path)
        self.btn_show_pdf.configure(state="normal")

    def open_pdf(self):
        if self.preview_running:
            return
        path=self.last_pdf
        if path is None or not path.is_file():
            path=filedialog.askopenfilename(parent=self.root,title="Mở PDF",filetypes=[("PDF","*.pdf")])
            if not path:
                return
        self.preview_running=True
        self.btn_show_pdf.configure(state="disabled")
        def completed(error):
            self.preview_running=False
            self.btn_show_pdf.configure(state="normal")
            if error:
                record_pdf_error(self,error)
                messagebox.showwarning("Mở xem PDF",f"PDF đã lưu tại {path}.\n{error}",parent=self.root)
        def work():
            error=""
            try:
                run_job(core.get_base_dir(),dict(operation="preview",path=str(path)))
            except Exception as exc:
                error=str(exc) or type(exc).__name__
            post_ui(self,lambda:completed(error))
        threading.Thread(target=work,daemon=True).start()

    def record_pdf_error(self,error):
        self.out_log.append(f"{datetime.now():%H:%M:%S}  PDF: {error}")
        del self.out_log[:-100]

    def send_pdf(self,orders,skip_blank,copies,sources,offline=False):
        if self.is_running or (not offline and not can_import(self)):
            return
        trace_pdf_ui(self,f"Khởi chạy tác vụ PDF · {len(orders)} WHO")
        folder=Path(self.config.get("pdf_output_folder") or "OUTPUT_PDF").resolve()
        path=folder/datetime.now().strftime("PHIEU_INWH_%Y%m%d_%H%M%S_%f.pdf")
        self.is_running=True
        update_print(self)
        self.status_text_var.set(f"Đang xử lý {len(orders)} WHO · {copies} liên/WHO…")
        cfg=dict(self.config)
        def work():
            error=""
            result=None
            def progress(event):
                note=event["stage"]
                if event.get("who"):
                    note+=f" · WHO {event['who']} ({event['index']}/{event['total']})"
                post_ui(self,lambda:self.status_text_var.set(note))
            try:
                if sources:
                    request=dict(operation="import",sources=list(sources),orders=orders,
                                 copies=copies,skip_blank=skip_blank,style=cfg.get("pdf_stamp"))
                    result=run_job(core.get_base_dir(),request,target=path,progress=progress)
                else:
                    result=z.make_pdf_job(cfg,orders,progress=progress)
            except Exception as exc:
                error=str(exc) or type(exc).__name__
            def completed():
                if offline and not error:
                    self.is_running=False
                    set_last_pdf(self,path)
                    self.status_text_var.set(f"Đã đóng số {len(orders)} WHO · {path}")
                    update_print(self)
                    open_pdf(self)
                else:
                    pdf_done(self,path,error,orders,result,copies,skip_blank)
            post_ui(self,completed)
        threading.Thread(target=work,daemon=True).start()

    def pdf_done(self,path,error,orders,result,copies,skip_blank):
        self.is_running=False
        if error:
            self.status_text_var.set("Chưa tạo PDF · "+error.splitlines()[0])
            record_pdf_error(self,error)
            update_print(self)
            messagebox.showwarning("In PDF",error,parent=self.root)
        elif result.get("submitted"):
            self.pdf_batch=(self.current_results,orders,copies,skip_blank)
            self.status_text_var.set(f"Đã gửi {len(orders)} WHO · {copies} liên/WHO. Lưu PDF ở Windows rồi bấm Chọn PDF gốc.")
        else:
            self.pdf_batch=None
            numbers={**z.known_orders(self.current_results),**orders}
            for row in self.current_results:
                if any(who in orders for who in z.printable_whos([row])):
                    z.apply_order_numbers(row,numbers)
            z.mark_printed(self.current_results,list(orders))
            note=f"Đã lưu PDF · {result['pages']} trang · bỏ {result['blank_removed']} trang trắng · {path}"
            try:
                z.save_result(dict(run_id=datetime.now().strftime("PRINT_%Y%m%d_%H%M%S_%f"),
                                   context=z.output_context(self.config),records=self.current_results,
                                   message=note,pdf_files=[str(path)],pdf_whos=list(orders)))
            except Exception as exc:
                note+=f" · Lỗi ghi nhật ký: {exc}"
            render(self)
            self.status_text_var.set(note)
            set_last_pdf(self,path)
            open_pdf(self)
        update_print(self)

    def reconcile(self):
        if self.is_running:
            return
        try:
            rows=z.pending()
        except Exception as exc:
            messagebox.showerror("Đối soát Post",str(exc))
            return
        if not rows:
            messagebox.showinfo("Đối soát Post","Không có nhóm đang chờ đối soát.")
            return
        pop=tk.Toplevel(self.root)
        pop.title("Đối soát Post")
        pop.geometry("850x360")
        listing=tk.Listbox(pop)
        listing.pack(fill="both",expand=True,padx=12,pady=8)
        for token,run,state,doc,ob,message in rows:
            listing.insert("end",f"{run} • {state} • MIGO {doc or '?'} • {message}")
        def apply():
            selection=listing.curselection()
            if not selection:
                return
            ob=simpledialog.askstring("Đối soát SAP","Nhập OB đã xác minh. Để trống khi đã xác nhận SAP chưa Post.",parent=pop)
            if ob is None:
                return
            note=simpledialog.askstring("Đối soát SAP","Ghi lại bằng chứng đối soát trên SAP",parent=pop)
            if note is None:
                return
            try:
                z.resolve_pending(rows[selection[0]][0],ob.strip(),note)
            except Exception as exc:
                messagebox.showerror("Đối soát Post",str(exc),parent=pop)
                return
            if ob.strip():
                latest=z.latest_result()
                incoming=latest["records"] if latest else []
                keep=[r for r in self.current_results if all(r["ob"]!=q["ob"] or r["material"]!=q["material"] for q in incoming)]
                self.current_results=keep+incoming
                self.results_are_demo=False
                self.results_context=None
                render(self)
                self.status_text_var.set("Đã lưu OB đối soát. Chọn Tra lại MON.")
            pop.destroy()
        ttk.Button(pop,text="Ghi kết quả đối soát",command=apply).pack(pady=8)

    def selected_records(self):
        return [self.current_results[int(iid)] for iid in self.tree.selection()
                if iid.isdecimal() and int(iid)<len(self.current_results)]

    def select_ob(self):
        picks={row["ob"] for row in selected_records(self)}
        if not picks:
            self.status_text_var.set("Chọn một dòng để mở rộng phạm vi đến cả OB.")
            return
        self.tree.selection_set(*(str(i) for i,row in enumerate(self.current_results) if row["ob"] in picks))

    def update_print(self):
        ready=(not self.is_running and not self.mock_mode_var.get() and not self.results_are_demo
               and self.results_context==z.output_context(self.config))
        total=len(z.printable_whos(self.current_results)) if ready else 0
        selected=len(z.printable_whos(selected_records(self))) if total else 0
        self.btn_create_pdf.configure(state="normal" if total else "disabled",
                                      text=f"Lấy PDF từ SAP ({total} WHO)" if total else "Lấy PDF từ SAP")
        self.out_action_menu.entryconfigure(0,state="normal" if selected else "disabled",
                                            label=f"Lấy PDF từ SAP cho dòng đã chọn ({selected} WHO)" if selected else "Lấy PDF từ SAP cho dòng đã chọn")

    def assign_numbers(self, only=None):
        if self.is_running:
            return
        picks=self.current_results if only is None else only
        whos=z.printable_whos(picks)
        if not whos:
            self.status_text_var.set("Không có WHO đủ điều kiện để gán số đơn trong phạm vi này.")
            return
        if not self.results_are_demo and self.results_context!=z.output_context(self.config):
            self.status_text_var.set("Tra lại MON trước khi gán số đơn cho kết quả lịch sử.")
            return
        try:
            prior=[] if self.results_are_demo else [row for run in z.output_history(self.config) for row in run["records"]]
        except Exception as exc:
            messagebox.showerror("Gán số đơn",str(exc))
            return
        numbers=z.known_orders([*self.current_results,*prior])
        dialog=tk.Toplevel(self.root)
        dialog.title("Gán số đơn INWH")
        dialog.geometry("670x405")
        dialog.transient(self.root)
        dialog.grab_set()
        panel=ttk.Frame(dialog,padding=12)
        panel.pack(fill="both",expand=True)
        scope="Toàn bộ kết quả" if only is None else "Dòng đã chọn"
        ttk.Label(panel,text=f"{scope} · {len(whos)} WHO in được · Mỗi WHO một số.",wraplength=630).pack(anchor="w")
        input_area=ttk.Frame(panel)
        input_area.pack(fill="both",expand=True,pady=7)
        inputs=tk.Text(input_area,height=9,font=("Consolas",10),padx=7,pady=5)
        inputs.insert("1.0","\n".join(f"{who}\t{numbers.get(who,'')}" for who in whos))
        scroll=ttk.Scrollbar(input_area,command=inputs.yview)
        scroll.pack(side="right",fill="y")
        inputs.configure(yscrollcommand=scroll.set)
        inputs.pack(side="left",fill="both",expand=True)
        feedback=tk.StringVar()
        ttk.Label(panel,textvariable=feedback,wraplength=630).pack(anchor="w")
        bar=ttk.Frame(panel)
        bar.pack(fill="x",pady=(5,0))
        prefix=tk.StringVar(value=self.sodon_prefix_var.get())
        first=tk.StringVar(value=self.sodon_start_var.get())
        ttk.Label(bar,text="Tiền tố").pack(side="left")
        ttk.Entry(bar,textvariable=prefix,width=9).pack(side="left",padx=4)
        ttk.Label(bar,text="Bắt đầu").pack(side="left")
        ttk.Entry(bar,textvariable=first,width=7).pack(side="left",padx=4)
        def fill():
            try:
                p,n=z.Pipeline({"sodon_prefix":prefix.get(),"sodon_start":first.get()},None).numbering()
                available=z.available_order_numbers(p,n,[*self.current_results,*prior])
                rows=[f"{who}\t{numbers[who] if who in numbers else next(available)}" for who in whos]
            except (ValueError,z.StopRun) as exc:
                feedback.set(str(exc))
                return
            inputs.delete("1.0","end")
            inputs.insert("1.0","\n".join(rows))
        def apply():
            new={}
            try:
                for line in inputs.get("1.0","end").splitlines():
                    if not line.strip():
                        continue
                    who,value=line.split()
                    if who not in whos or who in new or not z.valid_order_number(value):
                        raise ValueError
                    new[who]=value
                if set(new)!=set(whos) or len(set(new.values()))!=len(new):
                    raise ValueError
            except ValueError:
                feedback.set("Mỗi dòng cần đúng WHO đã chọn và một số đơn duy nhất, ví dụ WH-01.")
                return
            occupied={value for who,value in numbers.items() if who not in new}
            if occupied.intersection(new.values()):
                feedback.set("Có số đơn đã dùng cho WHO khác. Chọn số khác hoặc bấm Gợi ý số.")
                return
            updated=[dict(row) for row in self.current_results]
            for row in updated:
                if set(z.printable_whos([row])).intersection(new):
                    z.apply_order_numbers(row,{**numbers,**new})
            if not self.results_are_demo:
                try:
                    z.save_result(dict(run_id=datetime.now().strftime("NUMBER_%Y%m%d_%H%M%S_%f"),
                                       context=self.results_context,records=updated,message="Đã cập nhật INWH."))
                except Exception as exc:
                    feedback.set(str(exc))
                    return
            selection=self.tree.selection()
            self.current_results=updated
            self.shift_page.refresh_receipts()
            render(self)
            if selection:
                self.tree.selection_set(*selection)
                self.tree.see(selection[0])
            if not self.results_are_demo and self.shift_page.path:
                page=self.shift_page
                touched={(r['ob'],r['material']) for r in updated if set(z.printable_whos([r])).intersection(new)}
                matching=[e for e in page.cached_receipts if e['valid'] and not e['mock']
                          and any((ob,e['source']['material']) in touched for ob,num in e['pairs'])]
                if matching:
                    from zone_order_result import write
                    path,pwd=page.path,page.password
                    page.task('Ghi số đơn vừa gán vào ORDER…',lambda:write(path,pwd,matching),
                              lambda result:page.activate(path,pwd,result[1]))
            self.status_text_var.set(f"Đã lưu số đơn cho {len(new)} WHO.")
            dialog.destroy()
        ttk.Button(bar,text="Gợi ý số",command=fill).pack(side="left",padx=5)
        accent(bar,"Lưu số đơn",apply).pack(side="right")
        inputs.focus_set()

    def start_out(self,pipeline,button,label):
        self.pipeline=pipeline
        self.is_running=True
        self.results_context=None
        self.progress_bar.configure(value=0)
        self.progress_bar.pack(fill="x",pady=(4,0))
        button.configure(text="Dừng")
        self.status_text_var.set(label)
        update_print(self)

    def start_new(self):
        if self.is_running:
            request_stop(self)
            return
        raw=self.txt_input.get("1.0","end-1c")
        try:
            requests=[]
            for n,line in enumerate(raw.splitlines(),1):
                if not line.strip():
                    continue
                from zone_mail import norm
                if n==1 and norm(line.split("\t")[0]) in ("mahang","manvl","material"):
                    continue
                fields=line.split('	')
                if len(fields)>1 and re.fullmatch(r'\d+[.,]\d{3}',fields[1].strip()):
                    value=simpledialog.askstring('Xác nhận SL',f'Dòng {n} · {fields[0]} · SL dán: {fields[1]}. Nhập số EA, ví dụ 1500 hoặc 1.5.',parent=self.root)
                    if value is None:return
                    if not re.fullmatch(r'\d+(?:[.,]\d+)?',value.strip()) or re.fullmatch(r'\d+[.,]\d{3}',value.strip()):
                        raise ValueError(f'Dòng {n}: số lượng chưa hợp lệ.')
                    fields[1]=value.strip()
                    line='	'.join(fields)
                parsed=core.parse_paste_data(line)
                if len(parsed)!=1:
                    raise ValueError(f"Kiểm tra dòng {n}: cần mã hàng và số lượng hợp lệ.")
                requests.extend(parsed)
            if not requests:
                raise ValueError("Dán ít nhất một dòng Mã hàng, SL, Trạm và Zone tùy chọn.")
            start_order(self,requests,None,None)
        except Exception as exc:
            messagebox.showwarning("Ra đơn dán tay",str(exc),parent=self.root)

    def start_order(self,requests,path,stamp):
        from zone_shift import reservations,signature
        from zone_order_result import file_key
        cfg={**self.config,"sodon_prefix":self.sodon_prefix_var.get(),"sodon_start":self.sodon_start_var.get()}
        pipeline=z.Pipeline(cfg,self.zone_mgr)
        prefix,first=pipeline.numbering()
        mock=self.mock_mode_var.get()
        if mock and path:
            runs=self.shift_page.demo_runs.get(file_key(path),{})
            previous=[num for run in runs.values() for r in run.get('records',[]) for num in r.get('who_numbers',{}).values()]
            used=[int(n[len(prefix):]) for n in previous if n.startswith(prefix) and n[len(prefix):].isdigit()]
            cfg.update(sodon_start=max([first,*[i+1 for i in used]]),
                       mock_ob_offset=sum(len(run.get('order_obs',())) for run in runs.values()))
            pipeline=z.Pipeline(cfg,self.zone_mgr)
        requests=[dict(row) for row in requests]
        total=sum(row["qty"] for row in requests)
        label=path.name if path else "Dữ liệu dán tay"
        extra=''
        if path and requests[0].get('mode') in ('Thùng cấp thêm','Cả model · 1 lượt','Thùng còn thiếu','Cấp bù FIFO'):
            boxes=sum(r['boxes'] for r in requests)
            done=sum(r['source_state']=='done' for r in requests)
            outstanding=sum(bool(r['open_obs']) for r in requests)
            extra=f"{requests[0].get('mode')} · {boxes} thùng · {done} dòng đã Done · {outstanding} dòng có OB chưa ghi SL cấp.\n"
        if not mock and not messagebox.askyesno("Ra đơn",f"{extra}{label}\n{len(requests)} dòng · {total:g} EA.\nGửi yêu cầu MIGO 311 trên SAP?",parent=self.root):
            return
        selected_table=self.shift_page.table if path else None
        selected_password=self.shift_page.password if path else None
        def claim():
            if signature(path)!=stamp:
                raise ValueError("File ORDER đã thay đổi. Tải lại trước khi ra đơn.")
            from zone_shift import verify_view
            verify_view(path,selected_password,selected_table,extra=bool(extra))
            with z.journal() as conn:
                reservations(conn,requests,pipeline.run_id)
        if path:
            pipeline.order_file=file_key(path)
            if not mock:pipeline.claim_order=claim
            self.shift_page.posting=True
        button=self.shift_page.run_btn if path else self.btn_run
        start_out(self,pipeline,button,"Đang ra đơn từ "+label+"…")
        self.worker_thread=threading.Thread(target=self._run_pipeline_worker,args=(requests,mock),daemon=True)
        self.worker_thread.start()

    def lookup_obs(self,obs):
        self.lookup_pending=tuple(obs)
        mock=self.mock_mode_var.get()
        existing=[row for row in self.current_results if row["ob"] in obs] if self.results_are_demo==mock else []
        if not mock and self.results_context not in (None,z.output_context(self.config)):
            existing=[]
        pipeline=z.Pipeline(self.config,self.zone_mgr)
        start_out(self,pipeline,self.btn_continue_ob,f"Đang tra MON cho {len(obs)} OB…")
        def work():
            try:
                result=pipeline.run_who_lookup_for_obs(obs,existing,self._update_progress_from_worker,
                                                        self._update_status_from_worker,mock)
                post_ui(self,lambda:finished(self,result))
            except Exception as exc:
                post_ui(self,lambda message=str(exc):out_error(self,message))
        self.worker_thread=threading.Thread(target=work,daemon=True)
        self.worker_thread.start()

    def retry_ob(self):
        if self.is_running:
            return
        obs=list(dict.fromkeys(row["ob"] for row in self.current_results if z.OB.fullmatch(row["ob"])))
        if obs:
            lookup_obs(self,obs)
        else:
            self.status_text_var.set("Chưa có OB trong bảng để tra lại MON.")

    def out_error(self,message):
        finished(self,dict(success=False,message=message))

    def continue_ob(self):
        if self.is_running:
            request_stop(self)
            return
        try:
            obs=z.parse_obs(self.txt_input.get("1.0","end"))
        except z.StopRun as exc:
            self.status_text_var.set(str(exc))
            return
        if not obs:
            self.status_text_var.set("Dán ít nhất một số OB để tra MON.")
            return
        lookup_obs(self,obs)

    def run_worker(self,requests,mock_mode):
        def approve(ob):
            event=threading.Event()
            approved=False
            def show():
                nonlocal approved
                try:
                    approved=messagebox.askyesno("Yêu cầu xuất lặp",
                        f"Nhóm giống OB {ob} đã Post trước đó. Bạn đã đối chiếu và muốn Post một yêu cầu mới?",
                        parent=self.root)
                finally:
                    event.set()
            post_ui(self,show)
            return event.wait(120) and approved and not self.pipeline.stop_requested
        self.pipeline.approve_repeat=approve
        try:
            result=self.pipeline.run(requests,self._update_progress_from_worker,
                                     self._update_status_from_worker,mock_mode)
            post_ui(self,lambda:finished(self,result))
        except Exception as exc:
            post_ui(self,lambda message=str(exc):out_error(self,message))

    def request_stop(self):
        if getattr(self,"pipeline",None):
            self.pipeline.request_stop()
            self.status_text_var.set("Đang dừng ở bước kế tiếp…")

    App._check_sap_status_async=check_connection
    App.__init__=init
    App._build_ui=build
    App._build_tab_main=build_main
    App._build_tab_config=config_ui
    App._save_config=save
    App._on_tree_copy_shortcut=copy
    App._copy_3_columns_to_clipboard=lambda self:copy_tracking(self,3)
    App._copy_4_columns_to_clipboard=lambda self:copy_tracking(self,4)
    App._copy_who_column_to_clipboard=copy_whos
    App._copy_sodon_column_to_clipboard=copy_numbers
    App._export_excel=export_excel
    App._on_pipeline_finished=finished
    App._on_btn_create_pdf_clicked=print_selected
    App._request_stop=request_stop
    App._run_pipeline_worker=run_worker
    App._on_btn_continue_ob_clicked=continue_ob
    App.copy_text=copy_text
    App._renumber_sodon_dialog=assign_numbers
    App._edit_sodon_dialog=edit_number
    App._on_pipeline_error=out_error
    App._retry_mon_for_current_table=retry_ob
    App._on_btn_run_clicked=start_new
    App._update_progress_from_worker=progress_from_worker
    App._update_status_from_worker=status_from_worker
    App.post_ui=post_ui
