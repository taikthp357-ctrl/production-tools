# Kiểm thử RC34

Đã chạy mã nạp từ EXE trên Linux/Tk, với Excel COM và Outlook giả lập, ghi và mở lại XLSX thử nghiệm.

| Thao tác (ms, trung vị / chậm nhất) | RC33 | RC34 |
|---|---:|---:|
| Mở bảng lần đầu | 24.4 / 24.9 | 19.0 / 19.3 |
| Mở lại bảng | 1.8 / 2.3 | 1.8 / 2.6 |
| Enter chọn kết quả | 2.2 / 2.3 | 2.1 / 2.2 |
| Excel xác nhận đến nhập tiếp | 28.5 / 31.9 | 27.8 / 28.8 |
| Bung thư với 12 dòng mã | 4.0 / 4.0 | 4.2 / 4.4 |

Mỗi phiên bản chạy 3 ca thử nhập SL, mỗi ca mở lại bảng 5 lần. Phép thử Outlook dùng 24 thư, 288 dòng kho P. Các số trên chỉ phản ánh máy thử.

- 1.257 lượt cấp. Đuôi OB chung, hai lượt nhập 43 và 15 vào đúng SL2 và SL3. Giữ bản nháp khi Excel bận hoặc sửa tay. Sau lần cập nhật tiếp, kiểm tra số đã cấp trong chi tiết từ báo cáo có tính tổng SL của file mẫu.
- Thử Outlook trả về sau khi đổi dữ liệu cùng ca. App đối chiếu lại đúng bảng mới từ thư đã đọc, chỉ gọi quét một lần. Đổi sang file khác khi đang quét thì bỏ kết quả của file cũ.
- Kiểm tra ô đang chọn, bàn phím, clipboard, OB ghép, copy nhiều dòng, nút Nhập SL ở 960/1280/1366 px, xử lý file trùng, SL mơ hồ và kết quả tra lỗi. Lặp bộ thử thay đổi ca và thao tác chính 5 lần sau khi đưa cập nhật trạng thái kết nối về luồng giao diện.
- RAM tiến trình sau 1 / 7 / 13 lần kích hoạt file ca. RC33 đo 79,2 / 79,6 / 79,9 MiB. RC34 đo 78,8 / 79,2 / 79,4 MiB. Đây là phép thử ngắn trên cloud.
- Chưa nghiệm thu trực tiếp trên Windows tại kho với Office và ổ mạng thực tế.
