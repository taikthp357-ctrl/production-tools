# Kế hoạch nâng cấp từ RC30

| Hạng mục | Điều kiện nghiệm thu |
|---|---|
| Tốc độ | Thu nhỏ và khôi phục không tải ORDER. Chuyển Báo cáo không đọc lại ca trước. Chi phí vẽ phụ thuộc số dòng nhìn thấy. Đo trên Windows khi mở file ca từ UNC. |
| KHSX | Dán ảnh, chọn ảnh, thêm ghi chú, mở lịch cũ và dùng cùng thư mục lịch ở máy nhận ca. |
| Cá nhân hóa | Mỗi tài khoản có màu chữ, màu chọn, cỡ chữ riêng và nút mặc định. |
| Báo cáo và tra cứu | Lọc tất cả model có cột Model. Từ chi tiết báo cáo chọn dòng và chọn hàng thường hoặc hàng thùng để ra đơn. Sắp xếp giữ đúng dòng. |
| SAP và Excel | Ghi lại đúng kết quả SAP thật đã có đủ OB và số đơn. Lỗi ghi hoặc thiếu số giữ lịch sử đối soát. Không gửi lại lệnh SAP khi thử ghi lại. |
| Mail OD | Gọn thanh công cụ. Hỏi ghép FG theo mail. Hàng keo có lối lập BBBG riêng. Mail điều chỉnh cần đối chiếu dòng gốc và xác nhận thay đổi. |
| Dọn OD | Xem trước các dòng hết tồn cũ hơn D+2 theo ngày ca. Giữ thực cấp và dấu vết, loại khỏi cấp bù và báo cáo. Thử lại sau gián đoạn giữa SQL và Excel. |
| Dữ liệu dùng chung | Thư mục Data. Một tên YYMMDD_SQL_V19.sqlite cố định theo bộ dữ liệu. Di chuyển dữ liệu cũ có kiểm tra. Trước khi cho phép ghi nhiều máy cần thử mất mạng, mất máy ở bước SAP đã nhận lệnh và bàn giao cho máy khác. |
| Hồi quy | Kiểm tra nhập nhiều phiếu, SL1–3, phép cộng, bảng có đường kẻ, không ghi đè giao dịch đang chờ. |

## Bàn giao RC31

- Tab **KHSX** lưu ảnh PNG và ghi chú theo phiên bản trong thư mục lịch đã chọn. Có thể chọn cùng một thư mục từ hai máy. Ảnh xem ở tab của app. Sheet Báo cáo hiện có trong Excel vẫn sử dụng ảnh đã được chèn trong workbook.
- **Cấu hình → Giao diện / Dữ liệu** lưu màu chữ, màu chọn và cỡ chữ theo tài khoản Windows. Khi triển khai cùng bộ SQL, RC31 chỉ cho một phiên mở bộ đó tại một thời điểm. Trước lần chuyển đầu tiên, đóng RC30 và sao lưu bộ SQL hiện hành. Nếu nhật ký nằm trên máy đang vận hành, dùng nút tạo bộ SQL từ máy đó trước khi sử dụng EXE ở ổ chung. Chọn cùng bộ trên các máy còn lại. Các nhật ký đã tách trên nhiều máy cần đối soát trước khi hợp nhất.
- **Tra cứu KHSX / Model → Nhập SL** mở bảng nhập ngay tại tab. Có thể gõ 45776 để lọc 1013345776, chọn ô, nhập 28+15, Enter xuống dòng, Ctrl+F đổi phiếu, Ctrl+S ghi. Dòng sửa giữ theo lượt OB khi lọc hoặc sort. App kiểm tra lại giá trị trong Excel trước khi lưu.
- **Check mail OD → Công cụ → Xử lý mail điều chỉnh** cho xem dòng gốc đủ điều kiện, xác nhận cập nhật SL/KHSX, hủy hoặc thêm dòng. Mail keo ghi NOTE Chỉ lập BBBG. Với bảng có FG và trạm, app hỏi khi ghi. Các mail lịch chạy nhiều ca giữ nhãn ca như S6/S7.
- **ORDER → Dọn OD hết tồn quá D+2** lấy ngày ca làm mốc, chọn ngày KHSX và dòng cụ thể. Ví dụ ca 22/11 được dọn đến 19/11. Dòng đã có phiếu chờ cấp hoặc đang cần đối soát tiếp tục được giữ. App lưu dòng đã chọn vào sheet OD_DA_DONG, bỏ dữ liệu nghiệp vụ khỏi dòng ORDER và cập nhật bản chụp SQL của file ca hiện tại. Lịch sử SAP, xác nhận mail và các ca cũ được giữ để tra cứu.
- **Báo cáo cấp NVL** bấm ô số dưới model, chọn dòng, bấm Ra đơn OD và chọn hàng thùng hoặc thường. Kiểm tra số dòng đủ điều kiện rồi mới ra đơn. Sau khi có đủ OB và số đơn, app thử ghi vào Excel và đọc lại. Nếu Excel từ chối ghi, xem Kết quả và dùng lại chức năng ghi cho đúng lượt đã có.
- **Bàn giao ca** dùng file tạm cạnh file nguồn và công bố tên ca chính thức sau khi Excel lưu thành công. Dòng mail mới lấy định dạng Packing và Gap từ dòng mẫu liền trên.

## Kiểm tra trước khi đưa vào ca thật

1. Thử trên bản sao S6/S7 và một bản sao của nhật ký đang sử dụng. Kiểm tra mẫu BBBG từ UNC, ghi phiếu và số đơn rồi đóng mở Excel để đối chiếu.
2. Với bảng 1.257 dòng, thử thu nhỏ và khôi phục 10 lần, chuyển các tab và giữ bộ lọc OB. Tiêu chí đề xuất là hết mảng đen và thấy bảng trong 300 ms ở ít nhất 9/10 lượt sau khi dữ liệu đã nạp. Phép thử bộ vẽ 520 px đã xác nhận 24 dòng được vẽ và 0 dòng vẽ lại khi phạm vi giữ nguyên. Chưa đo được thời gian khôi phục thật trên máy Windows của kho.
3. Mở cùng bộ SQL trên hai máy. Máy thứ hai phải báo bộ dữ liệu đang sử dụng. Đóng phiên đầu rồi mở lại từ máy thứ hai, kiểm tra OB, số đơn và phiếu vừa lưu. Chưa kiểm thử UNC và mất mạng thực tế.
4. Thử riêng mail đổi lịch, tách biệt dòng chưa ra đơn với dòng đã có OB. Dọn một dòng hết tồn ở D+3 rồi kiểm tra báo cáo, bản chụp SQL, lịch sử Excel và mail cũ. Dòng D+2 phải được giữ.
