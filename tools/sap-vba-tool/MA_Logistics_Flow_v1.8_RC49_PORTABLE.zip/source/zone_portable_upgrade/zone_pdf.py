"""Assemble SAP warehouse-order PDFs with their assigned INWH numbers."""
from pathlib import Path
import os
import re
from tempfile import TemporaryDirectory

from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject, TextStringObject

WHO_HEADER = re.compile(r"Warehouse\s+Order\s*/\s*Lệnh\s+kho\s+0*(60[0-9]{8})(?!\d)", re.I)
FOOTERS = re.compile(r"(?:Trang|Page)\s+\d+\s*/\s*\d+|\b\d{2}\.\d{2}\.\d{4}\b|"
                     r"\b\d{2}:\d{2}:\d{2}\b|Date\s*/\s*Ngày\s*:", re.I)
GRAPHICS = {b"Do", b"INLINE IMAGE", b"sh", b"S", b"s", b"f", b"F", b"f*", b"B", b"B*", b"b", b"b*"}
TEXT = {b"Tj", b"TJ", b"'", b'"'}



class PDFError(RuntimeError):
    pass


def is_blank(page, text):
    if FOOTERS.sub("",text).strip() or page.get("/Annots"):
        return False
    contents=page.get_contents()
    if contents is None:
        return True
    operators={operator for _,operator in contents.operations}
    return not (GRAPHICS & operators or (not text.strip() and TEXT & operators))


MM = 72/25.4
DEFAULT_STYLE = dict(anchor="bottom-right", x=10, y=10, margin=10, size=18, family="Helvetica",
                     style="bold", color="#000000", frame="none", border=1, pad=2, white=False)
ANCHORS = ("top-left","top-center","top-right","bottom-left","bottom-center","bottom-right","custom")
STYLE_FONTS = {
    "Helvetica": ("Helvetica","Helvetica-Bold","Helvetica-Oblique","Helvetica-BoldOblique"),
    "Times": ("Times-Roman","Times-Bold","Times-Italic","Times-BoldItalic"),
    "Courier": ("Courier","Courier-Bold","Courier-Oblique","Courier-BoldOblique"),
}
STYLES = ("regular","bold","italic","bolditalic")


def checked_style(values=None):
    settings={**DEFAULT_STYLE, **(values or {})}
    for k,low,high in (("x",0,10000),("y",0,10000),("margin",0,50),("size",8,72),
                       ("border",0.3,4),("pad",0.5,8)):
        try:
            settings[k]=float(str(settings[k]).replace(",","."))
        except ValueError:
            raise PDFError("Nhập số hợp lệ cho vị trí, cỡ chữ, lề và khung.") from None
        if not low<=settings[k]<=high:
            raise PDFError(f"Giá trị {k} cần trong khoảng {low:g} đến {high:g}.")
    if (settings["anchor"] not in ANCHORS or settings["family"] not in STYLE_FONTS or
        settings["style"] not in STYLES or settings["frame"] not in ("none","rectangle","ellipse") or
        not re.fullmatch("#[0-9a-fA-F]{6}",settings["color"])):
        raise PDFError("Kiểu số phiếu hoặc mã màu chưa hợp lệ.")
    return settings


def placement(width,height,label,s):
    from pypdf._codecs.core_font_metrics import CORE_FONT_METRICS
    font=STYLE_FONTS[s["family"]][STYLES.index(s["style"])]
    size=s["size"]
    widths=CORE_FONT_METRICS[font].character_widths
    tw=sum(widths.get(c,widths["default"]) for c in label)*size/1000
    gap=s["pad"]*MM + (size*.22 if "italic" in s["style"] else 1)
    stroke=s["border"] if s["frame"]!="none" else 0
    scale=2**.5 if s["frame"]=="ellipse" else 1
    w=(tw+2*gap)*scale+stroke
    h=(1.45*size+2*(s["pad"]*MM+1))*scale+stroke
    margin=s["margin"]*MM
    if min(width-w-2*margin,height-h-2*margin)<0:
        raise PDFError("Số phiếu vượt vùng in. Giảm cỡ chữ, khoảng đệm hoặc lề.")
    anchor=s["anchor"]
    if anchor=="custom":
        x=max(margin,min(s["x"]*MM,width-margin-w))
        top=max(margin,min(s["y"]*MM,height-margin-h))
    else:
        side,align=anchor.split("-")
        x={"left":margin,"center":(width-w)/2,"right":width-margin-w}[align]
        top=margin if side=="top" else height-margin-h
    return x,top,w,h,tw,font


def ellipse_path(x,y,w,h):
    rx,ry=w/2,h/2
    dx,dy=rx*.55228475,ry*.55228475
    cx,cy=x+rx,y+ry
    return (f"{cx+rx:f} {cy:f} m {cx+rx:f} {cy+dy:f} {cx+dx:f} {cy+ry:f} {cx:f} {cy+ry:f} c "
            f"{cx-dx:f} {cy+ry:f} {cx-rx:f} {cy+dy:f} {cx-rx:f} {cy:f} c "
            f"{cx-rx:f} {cy-dy:f} {cx-dx:f} {cy-ry:f} {cx:f} {cy-ry:f} c "
            f"{cx+dx:f} {cy-ry:f} {cx+rx:f} {cy-dy:f} {cx+rx:f} {cy:f} c h")


def stamp_page(page, number, style=None):
    if not re.fullmatch(r"[0-9A-Za-z_-]{1,26}",number):
        raise PDFError("Số phiếu không hợp lệ.")
    s=checked_style(style)
    if page.rotation:
        page.transfer_rotation_to_content()
    boxes=(page.cropbox,page.mediabox,page.trimbox)
    left,bottom=max(float(b.left) for b in boxes),max(float(b.bottom) for b in boxes)
    right,top=min(float(b.right) for b in boxes),min(float(b.top) for b in boxes)
    unit=float(page.user_unit)
    if unit<=0 or right<=left or top<=bottom:
        raise PDFError("Khổ trang PDF không hợp lệ.")
    x,offset,w,h,tw,font=placement((right-left)*unit,(top-bottom)*unit,number,s)
    y=(top-bottom)*unit-offset-h
    overlay=PdfWriter().add_blank_page(width=right-left,height=top-bottom)
    overlay.mediabox.lower_left=(left,bottom)
    overlay.mediabox.upper_right=(right,top)
    key=NameObject
    overlay[key("/Resources")]=DictionaryObject({key("/Font"):DictionaryObject({
        key("/MAFlowFont"):DictionaryObject({key("/Type"):key("/Font"),key("/Subtype"):key("/Type1"),
                                            key("/BaseFont"):key("/"+font)})})})
    color=" ".join(f"{int(s['color'][i:i+2],16)/255:.5f}" for i in (1,3,5))
    ops=[f"q {1/unit:f} 0 0 {1/unit:f} {left:f} {bottom:f} cm", f"{color} RG 1 g"]
    frame=s["frame"]
    if frame!="none" or s["white"]:
        border=s["border"] if frame!="none" else 0
        bx,by,bw,bh=x+border/2,y+border/2,w-border,h-border
        path=ellipse_path(bx,by,bw,bh) if frame=="ellipse" else f"{bx:f} {by:f} {bw:f} {bh:f} re"
        op="f" if frame=="none" else ("B" if s["white"] else "S")
        ops.append(f"{border:f} w {path} {op}")
    ops.append(f"{color} rg BT /MAFlowFont {s['size']:f} Tf {x+(w-tw)/2:f} {y+(h-.75*s['size'])/2:f} Td ({number}) Tj ET Q")
    stream=DecodedStreamObject()
    stream.set_data(" ".join(ops).encode("ascii"))
    overlay[key("/Contents")]=stream
    page.merge_page(overlay)
    page[key("/MAFlowSlip")]=TextStringObject(number)


PAGINATION = re.compile(r"\b(?:Trang|Page)\s+(\d+)\s*/\s*(\d+)\b", re.I)


def numbered_pdf(target, orders, copies, skip_blank, sources, stage=None, style=None):
    """Index original SAP pages, validate the whole batch, then publish one PDF."""
    target = Path(target).resolve()
    if not orders or not sources or not 1 <= copies <= 20 or any(
        not re.fullmatch(r"60[0-9]{8}", who) or not re.fullmatch(r"[0-9A-Za-z_-]{1,26}", number)
        for who, number in orders.items()
    ):
        raise PDFError("Cần PDF gốc, danh sách WHO và số INWH hợp lệ.")
    if len(set(orders.values())) != len(orders):
        raise PDFError("Có WHO trùng số INWH. Kiểm tra lại số đã gán.")
    if target.exists():
        raise PDFError("Đường dẫn PDF đã tồn tại.")
    report = stage or (lambda name: None)
    pages = {who: {} for who in orders}
    totals = {}
    if len({Path(src).resolve() for src in sources}) != len(sources):
        raise PDFError("Một file PDF gốc được chọn nhiều lần.")
    for source in sources:
        path = Path(source)
        report("Đọc " + path.name)
        reader = PdfReader(path, strict=True)
        if reader.is_encrypted or not len(reader.pages):
            raise PDFError(f"File {path.name} trống hoặc có mật khẩu.")
        who = None
        previous_number = 0
        leading = []
        trailing = None
        for index, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            where = f"{path.name}, trang {index}"
            if "/MAFlowSlip" in page or re.search(r"\bINWH\s+[0-9A-Za-z_-]+", text):
                raise PDFError(f"{where} đã có số INWH. Chọn PDF gốc từ SAP.")
            headers = WHO_HEADER.findall(text)
            pagination = PAGINATION.findall(text)
            blank = is_blank(page, text)
            if not pagination and blank:
                (leading if trailing is None else trailing).append(page)
                continue
            if len(pagination) != 1:
                raise PDFError(f"{where} thiếu hoặc trùng chỉ số Trang x/y.")
            n, total = map(int, pagination[0])
            if not 1 <= n <= total or total > 10000:
                raise PDFError(f"{where} có chỉ số trang không hợp lệ.")
            if n == 1 and len(headers) != 1:
                raise PDFError(f"{where} thiếu tiêu đề WHO duy nhất.")
            previous_who = who
            if headers:
                if len(headers) != 1 or headers[0] not in orders:
                    raise PDFError(f"{where} có WHO ngoài danh sách hoặc không rõ: {', '.join(headers)}.")
                who = headers[0]
            if not who or (n > 1 and (previous_who != who or previous_number not in (n, n-1))):
                raise PDFError(f"{where} chưa xác minh được WHO cho trang {n}/{total}.")
            if totals.setdefault(who, total) != total:
                raise PDFError(f"WHO {who} có số trang khác nhau giữa các liên.")
            trailing = []
            pages[who].setdefault(n, []).append((leading, page, blank, trailing))
            leading = []
            previous_number = n
            if index % 15 == 0:
                report(f"Đã đọc {index}/{len(reader.pages)} trang của {path.name}")
        if trailing is None:
            raise PDFError(f"File {path.name} chỉ có trang trắng.")
    errors = []
    for who, by_page in pages.items():
        if not by_page:
            errors.append(f"Thiếu WHO {who}")
            continue
        for n in range(1, totals[who]+1):
            count = len(by_page.get(n, []))
            if count != copies:
                errors.append(f"WHO {who} · trang {n}/{totals[who]} có {count}/{copies} liên")
    if errors:
        raise PDFError("\n".join(errors[:15]) + (f"\nCòn {len(errors)-15} lỗi." if len(errors)>15 else ""))
    writer = PdfWriter()
    stamps = []
    removed = 0
    for who, by_page in pages.items():
        report(f"Đóng số {orders[who]} cho WHO {who}")
        for copy in range(copies):
            for n in range(1, totals[who]+1):
                before, original, blank, after = by_page[n][copy]
                group = [(p, True) for p in before] + [(original, blank)] + [(p, True) for p in after]
                for page, is_spacer in group:
                    if is_spacer and skip_blank:
                        removed += 1
                        continue
                    dest = writer.add_page(page)
                    if not is_spacer:
                        stamp_page(dest, orders[who], style)
                    stamps.append(None if is_spacer else orders[who])
    target.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="maflow_", dir=target.parent, ignore_cleanup_errors=True) as folder:
        staged = Path(folder) / "result.pdf"
        writer.write(staged)
        check = PdfReader(staged, strict=True)
        if len(check.pages) != len(stamps):
            raise PDFError("PDF kết quả sai số trang.")
        for index, (page, stamp) in enumerate(zip(check.pages, stamps), 1):
            if stamp and (page.get("/MAFlowSlip") != stamp or stamp not in (page.extract_text() or "")):
                raise PDFError(f"Trang {index} thiếu số INWH sau khi lưu.")
            if index % 15 == 0:
                report(f"Đối chiếu trang {index}/{len(stamps)}")
        if target.exists():
            raise PDFError("Đường dẫn PDF đã tồn tại.")
        os.rename(staged, target)
    return dict(pages=len(stamps), blank_removed=removed, whos=len(orders), copies=copies)
