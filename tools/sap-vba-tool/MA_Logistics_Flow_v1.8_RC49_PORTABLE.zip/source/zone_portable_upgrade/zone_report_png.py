"""Render report sheets directly with the Windows system font, independent of the viewport."""
from datetime import datetime
from pathlib import Path
import os
import shutil
import struct
import tempfile
import zlib

from zone_report_tables import BORDER


def chunk(tag,data):
    return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data))


def write_rgb(path,width,height,rows):
    encoder=zlib.compressobj(6)
    with open(path,'wb') as output:
        output.write(b'\x89PNG\r\n\x1a\n')
        output.write(chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0)))
        for row in rows:
            data=encoder.compress(b'\0'+row)
            if data:
                output.write(chunk(b'IDAT',data))
        output.write(chunk(b'IDAT',encoder.flush()))
        output.write(chunk(b'IEND',b''))


def windows_png(sheet,path,scale=2):
    import ctypes as ct
    from ctypes import wintypes as wt
    gdi=ct.WinDLL('gdi32',use_last_error=True)
    user=ct.WinDLL('user32',use_last_error=True)
    ptr=ct.c_void_p
    integer=ct.c_int
    def api(dll,name,result,*args):
        fn=getattr(dll,name)
        fn.restype=result
        fn.argtypes=list(args)
        return fn
    newdc=api(gdi,'CreateCompatibleDC',ptr,ptr)
    bitmap=api(gdi,'CreateDIBSection',ptr,ptr,ptr,wt.UINT,ct.POINTER(ptr),ptr,wt.DWORD)
    select=api(gdi,'SelectObject',ptr,ptr,ptr)
    delete=api(gdi,'DeleteObject',wt.BOOL,ptr)
    close=api(gdi,'DeleteDC',wt.BOOL,ptr)
    newbrush=api(gdi,'CreateSolidBrush',ptr,wt.DWORD)
    font=api(gdi,'CreateFontW',ptr,*([integer]*5+[wt.DWORD]*8+[wt.LPCWSTR]))
    mode=api(gdi,'SetBkMode',integer,ptr,integer)
    color=api(gdi,'SetTextColor',wt.DWORD,ptr,wt.DWORD)
    rectptr=ct.POINTER(wt.RECT)
    fill=api(user,'FillRect',integer,ptr,rectptr,ptr)
    draw=api(user,'DrawTextW',integer,ptr,wt.LPCWSTR,integer,rectptr,wt.UINT)
    flush=api(gdi,'GdiFlush',wt.BOOL)
    width,height=sheet.width*scale+1,sheet.height*scale+1
    if width*height>85000000:
        raise ValueError('Ảnh vượt khổ. Thu hẹp khoảng KHSX trước khi xuất.')
    info=ct.create_string_buffer(struct.pack('<IiiHHIIiiII',40,width,-height,1,32,0,0,0,0,0,0))
    address=ptr()
    dc=newdc(None)
    handle=bitmap(dc,info,0,ct.byref(address),None,0) if dc else None
    if not dc or not handle:
        if dc:close(dc)
        raise OSError('Windows không cấp được vùng nhớ để kết xuất ảnh.')
    oldbmp=select(dc,handle)
    originals=[]
    brushes={}
    fonts={}
    def rgb(hexcode):
        r,g,b=bytes.fromhex(hexcode[1:])
        return r|(g<<8)|(b<<16)
    def brush(value):
        if value not in brushes:
            brushes[value]=newbrush(rgb(value))
            if not brushes[value]:raise OSError('Không tạo được màu ảnh.')
        return brushes[value]
    try:
        mode(dc,1)
        fill(dc,ct.byref(wt.RECT(0,0,width,height)),brush(BORDER))
        for cell in sheet.cells:
            x,y,r,b=[v*scale for v in cell.bounds]
            # The shared outer border and each left/top pixel are supplied by the background.
            fill(dc,ct.byref(wt.RECT(x+1,y+1,r,b)),brush(cell.fill))
            if not cell.text:continue
            key=(cell.size,cell.bold)
            if key not in fonts:
                fonts[key]=font(-cell.size*scale,0,0,0,700 if cell.bold else 400,0,0,0,1,0,0,4,0,'Segoe UI')
                if not fonts[key]:raise OSError('Không tạo được phông chữ báo cáo.')
            old=select(dc,fonts[key])
            if not originals:originals.append(old)
            color(dc,rgb(cell.color))
            lines=cell.text.split('\n')
            line_height=(cell.size+4)*scale
            top=(y+b-line_height*len(lines))//2
            for part in lines:
                box=wt.RECT(x+5*scale,top,r-5*scale,top+line_height)
                draw(dc,part,len(part.encode('utf-16-le'))//2,ct.byref(box),
                     0x800|0x20|0x4|(0 if cell.align=='left' else 1))
                top+=line_height
        flush()
        def rows():
            for line in range(height):
                bgra=ct.string_at(address.value+line*width*4,width*4)
                raw=bytearray(width*3)
                raw[::3],raw[1::3],raw[2::3]=bgra[2::4],bgra[1::4],bgra[::4]
                yield raw
        if path is None:
            import win32clipboard
            data=bytes(info)[:40]+ct.string_at(address.value,width*height*4)
            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardData(8,data)
            finally:
                win32clipboard.CloseClipboard()
        else:
            write_rgb(path,width,height,rows())
    finally:
        if originals:select(dc,originals[0])
        select(dc,oldbmp)
        for obj in [handle,*fonts.values(),*brushes.values()]:
            if obj:delete(obj)
        close(dc)


def export_set(directory,identifier,sheets,renderer=windows_png):
    root=Path(directory)
    folder=root/(identifier+'_'+datetime.now().strftime('%H%M%S_%f'))
    stage=Path(tempfile.mkdtemp(prefix='.ma_anh_',dir=root))
    try:
        for sheet,name in zip(sheets,('01_Bao_cao_cap_NVL','02_Tinh_trang_cap_NVL','03_Ket_qua_cap_NVL'),strict=True):
            renderer(sheet,stage/(name+'.png'))
        os.rename(stage,folder)
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        raise
    return folder
