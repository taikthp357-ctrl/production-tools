"""Internal station handover slips using the approved bilingual Excel form."""
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from datetime import datetime
import os
from pathlib import Path
import re
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import zone_shift as sh
from zone_order_result import writable_order


SHARED_FORMS = Path(r'\\10.128.10.72\fvn$\03.Khối sản xuất\01.Nhà máy VinFast Hải Phòng\04.Xưởng lắp ráp kim loại - cơ khí NMHP\01. Lắp ráp kim loại\5.LOGISTIC\III. Internal\III. Kho P part\3. Theo doi hang nhap P\240101_FT-P')


def resolve_template(configured):
    if configured and Path(configured).is_file():
        return Path(configured)
    candidates = sorted((p for p in SHARED_FORMS.iterdir()
                         if re.fullmatch(r'(?:\d{6}_BBGN|BBBG_MAU|FVN_SX_KHO03\.0[68].*)\.xls[bmx]',p.name,re.I)),
                        key=lambda p:p.name)
    current = SHARED_FORMS / '261122_BBGN.xlsb'
    if current in candidates:
        return current
    if len(candidates)==1:
        return candidates[0]
    raise ValueError('Chọn mẫu trong mục Đổi mẫu. '+('Có nhiều mẫu phù hợp.' if candidates else 'Thư mục chung chưa có mẫu BBBG.'))


def qty_text(value):
    number = format(value,'f')
    return number.rstrip('0').rstrip('.') if '.' in number else number


def quantity(value):
    try:
        result=Decimal(str(value))
        if not result.is_finite() or result<=0:raise ValueError
    except (InvalidOperation,ValueError):
        raise ValueError('SL bàn giao phải lớn hơn 0.')
    return result


def pasted(text):
    items=[]
    for line in text.splitlines():
        cells=line.strip(' |\t').split()
        if not cells:continue
        cells=[v for v in cells if v!='|']
        if len(cells)<2 or not re.fullmatch(r'[A-Z]+[0-9][A-Z0-9]+',cells[0].upper()):
            raise ValueError('Dán mỗi dòng một mã NVL và số lượng ở cuối dòng.')
        items.append((cells[0].upper(),quantity(cells[-1])))
    return items


PARTY_KEYS = ('name', 'emp_id', 'dept', 'title', 'phone')
DEFAULT_RECEIVER_DEPT = 'Sản xuất'


def _clean_party(raw, default_dept=''):
    src = raw if isinstance(raw, dict) else {}
    out = {k: sh.clean(src.get(k, '')) for k in PARTY_KEYS}
    if default_dept and not out['dept']:
        out['dept'] = default_dept
    return out


def normalize_bbbg_config(config):
    cfg = config if isinstance(config, dict) else {}
    raw_users = cfg.get('bbbg_users') if isinstance(cfg.get('bbbg_users'), dict) else {}
    users = {}
    for uid, profile in raw_users.items():
        key = sh.clean(uid).upper()
        if key:
            users[key] = _clean_party(profile)
    default_user = sh.clean(cfg.get('bbbg_default_sap_user', '')).upper()
    if default_user and default_user not in users and len(users) == 1:
        default_user = next(iter(users))
    receiver = _clean_party(cfg.get('bbbg_receiver'), DEFAULT_RECEIVER_DEPT)
    return users, default_user, receiver


def detect_sap_user(config, cached_user=''):
    cached = sh.clean(cached_user).upper()
    if cached:
        return cached
    try:
        import sap_zone_core as core
        res = core.SapConnector.test_connection(
            session_idx=int((config or {}).get('sap_session_idx', -1)),
            preferred_sys=(config or {}).get('sap_system', 'PSV'),
            preferred_client=(config or {}).get('sap_client', '908'),
        )
        if isinstance(res, dict) and res.get('ok') and res.get('user'):
            return sh.clean(res['user']).upper()
    except Exception:
        pass
    return ''


def resolve_parties(config, sap_user='', receiver_override=None):
    users, default_user, receiver = normalize_bbbg_config(config)
    chosen_user = sh.clean(sap_user).upper() or default_user or (next(iter(users)) if len(users) == 1 else '')
    sender = dict(users.get(chosen_user, _clean_party({})))
    recv = dict(receiver)
    if isinstance(receiver_override, dict):
        for k in PARTY_KEYS:
            if k in receiver_override:
                recv[k] = sh.clean(receiver_override[k])
    if not recv['dept']:
        raise ValueError('Cần nhập Bộ phận bên nhận bàn giao (mặc định bắt buộc).')
    return chosen_user, sender, recv


def is_production_dept(dept):
    key = sh.norm(dept)
    if not key:
        return True
    if any(x in key for x in ('ngoaixuong', 'nhacungcap', 'ncc', 'khongoai', 'xuattrakho', 'vanchuyen', 'giaohang', 'external', 'vendor', 'supplier', 'outsource')):
        return False
    return any(x in key for x in ('sanxuat', 'sx', 'line', 'laprap', 'body', 'trim', 'paint', 'welding', 'assembly', 'xuong'))


def resolve_footer(config, recv_dept, sender_name='', internal_prod=None, approver_override=None):
    is_prod = is_production_dept(recv_dept) if internal_prod is None else bool(internal_prod)
    approver_name = sh.clean(approver_override if approver_override is not None else (config or {}).get('bbbg_approver', ''))
    if not is_prod:
        if not sh.clean(sender_name):
            raise ValueError('Xuất ra khỏi xưởng (không phải sản xuất): cần cấu hình Họ và Tên Người bàn giao theo User SAP.')
        if not approver_name:
            raise ValueError('Xuất ra khỏi xưởng (không phải sản xuất): cần cấu hình Tên Người phê duyệt.')
    return is_prod, approver_name


def _write_cell(sheet, row_idx, col_idx, value):
    cell = sheet.Cells(row_idx, col_idx)
    try:
        target = cell.MergeArea.Cells(1, 1)
    except Exception:
        target = cell
    target.Value2 = value
    return target


def _party_grid_positions(sheet):
    sender_col, recv_col = 3, 7
    for c in range(1, 12):
        key = sh.norm(sheet.Cells(4, c).Value2)
        if 'benbangiao' in key or 'handoverparty' in key:
            sender_col = c
        elif 'bennhan' in key or 'takeoverparty' in key:
            recv_col = c
    defaults = {'name': 5, 'emp_id': 6, 'dept': 7, 'title': 8, 'phone': 9}
    row_map = dict(defaults)
    for r in range(4, 11):
        key = sh.norm(sheet.Cells(r, 1).Value2)
        if 'hovaten' in key or 'fullname' in key:
            row_map['name'] = r
        elif 'manv' in key or 'employeecode' in key:
            row_map['emp_id'] = r
        elif 'bophan' in key or 'department' in key:
            row_map['dept'] = r
        elif 'chucvu' in key or 'title' in key:
            row_map['title'] = r
        elif 'sodienthoai' in key or 'phone' in key:
            row_map['phone'] = r
    return sender_col, recv_col, row_map


def _place_top_right_number(sheet, number):
    try:
        if getattr(sheet.Rows(1), 'Hidden', False):
            sheet.Rows(1).Hidden = False
        if float(getattr(sheet.Rows(1), 'RowHeight', 0) or 0) < 28:
            sheet.Rows(1).RowHeight = 28
    except Exception:
        pass
    for c in range(8, 12):
        try:
            existing = sh.clean(sheet.Cells(1, c).Value2)
            if existing.casefold().startswith('số phiếu'):
                _write_cell(sheet, 1, c, None)
        except Exception:
            pass
    note_col = 11
    try:
        top_limit = float(sheet.Rows(3).Top)
        shape_lefts = []
        for s in sheet.Shapes:
            try:
                if float(s.Top) < top_limit and int(s.TopLeftCell.Column) >= 8:
                    shape_lefts.append((int(s.TopLeftCell.Column), float(s.Left)))
            except Exception:
                pass
        if shape_lefts:
            min_col, min_left = min(shape_lefts, key=lambda x: x[1])
            note_col = max(8, min_col - 1)
            for c in range(11, 7, -1):
                try:
                    right_edge = float(sheet.Columns(c).Left) + float(sheet.Columns(c).Width)
                    if right_edge <= min_left + 2:
                        note_col = c
                        break
                except Exception:
                    pass
    except Exception:
        note_col = 10
    cell = _write_cell(sheet, 1, note_col, f'Số phiếu: {number}')
    try:
        cell.HorizontalAlignment = -4152  # xlRight
        cell.VerticalAlignment = -4108    # xlCenter
        cell.WrapText = False
        cell.Font.Bold = True
        cell.Font.Size = 18
    except Exception:
        pass


def _pdf_printer_name():
    if os.name != 'nt':
        return ''
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows NT\CurrentVersion\Devices') as key:
            val, _ = winreg.QueryValueEx(key, 'Microsoft Print to PDF')
            if ',' in str(val):
                port = str(val).split(',', 1)[1].strip()
                if port:
                    return f'Microsoft Print to PDF on {port}'
    except Exception:
        pass
    return ''


def _switch_pdf_printer(book):
    app = getattr(book, 'Application', None)
    if app is None:
        return None
    target = _pdf_printer_name()
    if not target:
        return None
    try:
        previous = str(app.ActivePrinter or '')
        if previous.casefold() != target.casefold():
            app.ActivePrinter = target
            return app, previous
    except Exception:
        pass
    return None


def _configure_a4_page(sheet):
    last_row = 36
    for r in range(42, 32, -1):
        try:
            if any(sh.clean(sheet.Cells(r, c).Value2) for c in range(1, 12)):
                last_row = max(36, r)
                break
        except Exception:
            pass
    ps = sheet.PageSetup
    settings = (
        ('RightHeader', ''),
        ('PaperSize', 9),         # xlPaperA4
        ('Orientation', 2),       # xlLandscape
        ('LeftMargin', 14),
        ('RightMargin', 14),
        ('TopMargin', 14),
        ('BottomMargin', 14),
        ('HeaderMargin', 7),
        ('FooterMargin', 7),
        ('CenterHorizontally', True),
        ('CenterVertically', False),
        ('PrintArea', f'$A$1:$K${last_row}'),
        ('Zoom', False),
        ('FitToPagesWide', 1),
        ('FitToPagesTall', 1),
    )
    for attr, value in settings:
        try:
            setattr(ps, attr, value)
        except Exception:
            pass


def _sig_box(sheet, hdr_r, hdr_c):
    try:
        hdr = sheet.Cells(hdr_r, hdr_c).MergeArea
        next_r = int(hdr.Row) + int(hdr.Rows.Count)
        return sheet.Cells(next_r, hdr_c).MergeArea
    except Exception:
        return sheet.Cells(hdr_r + 1, hdr_c).MergeArea


def _footer_positions(sheet):
    handover_box = approval_box = security_box = None
    for r in range(32, 38):
        for c in range(1, 12):
            key = sh.norm(sheet.Cells(r, c).Value2)
            if not key:
                continue
            if handover_box is None and ('nguoibangiao' in key or 'handoverer' in key):
                handover_box = _sig_box(sheet, r, c)
            elif approval_box is None and ('pheduyet' in key or 'approval' in key):
                approval_box = _sig_box(sheet, r, c)
            elif security_box is None and ('anninh' in key or 'securitysignature' in key):
                security_box = _sig_box(sheet, r, c)
    return (
        handover_box or sheet.Cells(35, 1).MergeArea,
        approval_box or sheet.Cells(35, 3).MergeArea,
        security_box or sheet.Cells(35, 6).MergeArea,
    )


def _strike_diagonal(area, enabled):
    try:
        diag = area.Borders(5)  # xlDiagonalDown
        if enabled:
            diag.LineStyle = 1   # xlContinuous
            diag.Weight = -4138  # xlMedium
        else:
            diag.LineStyle = -4142  # xlNone
    except Exception:
        pass


def _set_sig_name(area, full_name=''):
    try:
        top_left = area.Cells(1, 1)
    except Exception:
        top_left = area
    raw = str(top_left.Value2 or '')
    m = re.search(r'\(Full name\)', raw, re.I)
    prefix = raw[:m.end()] if m else (raw.strip() or 'Họ và Tên:\n(Full name)')
    top_left.Value2 = f'{prefix}  {full_name}' if full_name else prefix


def render(template,rows,destination,number,day,sender_info=None,receiver_info=None,internal_prod=None,approver_name=''):
    with sh.excel_book(template,None) as book:
        sheet=next((s for s in book.Worksheets if 'partno' in sh.norm(s.Cells(12,2).Value2)),None)
        if sheet is None or 'batch' not in sh.norm(sheet.Cells(12,3).Value2) or 'ghichu' not in sh.norm(sheet.Cells(11,11).Value2):
            raise ValueError(f'{Path(template).name}: kiểm tra tiêu đề Mã hàng (B12), Batch (C12), Ghi chú (K11) trên sheet biểu mẫu.')
        sheet.Cells(4,1).Value2='Ngày (Date): '+datetime.now().strftime('%d/%m/%Y %H:%M')
        _place_top_right_number(sheet,number)
        sender_col,recv_col,row_map=_party_grid_positions(sheet)
        sender=_clean_party(sender_info)
        receiver=_clean_party(receiver_info)
        for key in PARTY_KEYS:
            r_idx=row_map[key]
            _write_cell(sheet,r_idx,sender_col,sender[key])
            _write_cell(sheet,r_idx,recv_col,receiver[key])
        try:
            sheet.Rows('13:30').Hidden=False
        except Exception:
            pass
        sheet.Range('A13:K30').ClearContents()
        for i,(row,qty) in enumerate(rows,13):
            sheet.Cells(i,7).NumberFormat='General'
            for col,value in ((1,i-12),(2,sh.clean(row[3])),(3,sh.clean(row[0])),(4,'/'),(5,'/'),
                              (6,'EA'),(7,float(qty)),(11,sh.clean(row[5]))):
                sheet.Cells(i,col).Value2=value
        keep_rows=max(5,min(len(rows),18))
        if keep_rows<18:
            try:
                sheet.Rows(f'{13+keep_rows}:30').Hidden=True
            except Exception:
                pass
        handover_sig,approval_sig,security_sig=_footer_positions(sheet)
        is_prod=is_production_dept(receiver['dept']) if internal_prod is None else bool(internal_prod)
        _set_sig_name(handover_sig,'' if is_prod else sender['name'])
        _set_sig_name(approval_sig,'' if is_prod else sh.clean(approver_name))
        _strike_diagonal(approval_sig,is_prod)
        _strike_diagonal(security_sig,is_prod)
        restored=_switch_pdf_printer(book)
        try:
            _configure_a4_page(sheet)
            sheet.ExportAsFixedFormat(0,str(destination.resolve()))
        finally:
            if restored is not None:
                try:restored[0].ActivePrinter=restored[1]
                except Exception:pass


def issue(page,template,chosen,day,demo,sender_info=None,receiver_info=None,internal_prod=None,approver_name=None):
    from contextlib import nullcontext
    cfg=getattr(page.app,'config',{})
    if sender_info is None or receiver_info is None:
        _,d_sender,d_receiver=resolve_parties(cfg,getattr(page.app,'current_sap_user',''))
        if sender_info is None:sender_info=d_sender
        if receiver_info is None:receiver_info=d_receiver
    if not sh.clean((receiver_info or {}).get('dept','')):
        raise ValueError('Cần nhập Bộ phận bên nhận bàn giao (mặc định bắt buộc).')
    is_prod,approver=resolve_footer(cfg,receiver_info.get('dept',''),(sender_info or {}).get('name',''),internal_prod,approver_name)
    folder=page.path.parent/('BBBG_MO_PHONG' if demo else 'BBBG')/day
    folder.mkdir(parents=True,exist_ok=True)
    lock=folder/'.dang_lap'
    try:lock.mkdir()
    except FileExistsError:raise ValueError('Thư mục BBBG đang có lượt lập phiếu. Kiểm tra lượt đang chạy.')
    try:
        ctx=nullcontext((None,None,False)) if demo else writable_order(page.path,page.password)
        with ctx as (book,sheet,shared):
            current=page.table if demo else sh.values(sheet)
            indexed={key:(n,r) for n,r,key in sh.indexed(current)}
            groups=defaultdict(list)
            used={int(m[1]) for p in folder.glob('BBBG-*.pdf') if (m:=re.fullmatch(r'BBBG-(\d+)',p.stem))}
            for n,row in sh.rows(current):
                if str(sh.day(row[26]))==day:
                    used.update(int(m[1]) for col in (14,17,20) if (m:=re.fullmatch(r'BBBG-(\d+)',sh.clean(row[col]))))
            for key,qty in chosen.items():
                if key not in indexed:raise ValueError('Dòng ORDER đã thay đổi. Tải lại trước khi lập.')
                n,row=indexed[key]
                if row!=page._row_lookup[key] or str(sh.day(row[26]))!=day or sh.norm(row[27]) not in ('hettonkhoma','chilapbbbg'):
                    raise ValueError(f'Dòng {n} đã đổi hoặc chưa thuộc nhóm Hết tồn kho MA.')
                slot=next((j for j in (13,16,19) if not sh.clean(row[j]) and not sh.clean(row[j+1]) and row[j+2] in (None,'',0,'0')),None)
                if slot is None or not sh.clean(row[5]):raise ValueError(f'Dòng {n} thiếu trạm hoặc đã hết ô số phiếu.')
                if qty>quantity(row[4])-Decimal(str(row[22] or 0)):raise ValueError(f'Dòng {n}: SL vượt nhu cầu còn lại.')
                groups[sh.clean(row[5])].append((n,row,qty,slot))
            files=[];edits=[]
            try:
                for station,lines in groups.items():
                    for start in range(0,len(lines),18):
                        batch=lines[start:start+18]
                        seq=max(used,default=0)+1
                        used.add(seq)
                        number=f'BBBG-{seq:02d}'
                        path=folder/(number+'.pdf')
                        if path.exists():raise ValueError('Số BBBG vừa được sử dụng.')
                        files.append(path)
                        render(template,[(r,q) for _,r,q,_ in batch],path,number,day,sender_info,receiver_info,is_prod,approver)
                        if not path.is_file() or path.stat().st_size<1:raise ValueError('Xuất PDF chưa hoàn tất.')
                        if demo:continue
                        for n,row,qty,slot in batch:
                            note_val=sh.clean(row[27]) if sh.norm(row[27])=='chilapbbbg' else 'Đã ra đơn, chờ cấp'
                            for col,value in ((slot+2,number),(28,note_val)):
                                cell=sheet.Cells(n,col)
                                if cell.HasFormula:raise ValueError(f'Dòng {n} có công thức tại cột cần ghi.')
                                edits.append((cell,cell.Value2,value))
                for cell,old,value in edits:cell.Value2=value
                if edits:
                    sheet.Calculate()
                    if any(cell.Value2!=value for cell,_,value in edits):raise ValueError('Đọc lại số phiếu khác giá trị cần lưu.')
                    book.Save()
            except Exception:
                if shared:
                    for cell,old,_ in reversed(edits):cell.Value2=old
                for p in files:p.unlink(missing_ok=True)
                raise
            return files
    finally:lock.rmdir()


def config_tab(app, book):
    """Build BBGN per-SAP-user handover profile & receiver defaults inside Cấu hình."""
    tab=ttk.Frame(book,padding=12)
    book.add(tab,text='BBGN')
    users,default_user,receiver=normalize_bbbg_config(app.config)
    profiles={k:dict(v) for k,v in users.items()}

    tpl_var=tk.StringVar(value=app.config.get('bbbg_shared_template',''))
    top_row=ttk.Frame(tab)
    top_row.pack(fill='x',pady=(0,8))
    ttk.Label(top_row,text='Mẫu Excel BBGN').pack(side='left',padx=(0,6))
    ttk.Entry(top_row,textvariable=tpl_var,width=56).pack(side='left',fill='x',expand=True,padx=(0,6))
    def pick_tpl():
        name=filedialog.askopenfilename(parent=tab,filetypes=[('Mẫu Excel','*.xlsb *.xlsx *.xlsm')])
        if name:tpl_var.set(name)
    ttk.Button(top_row,text='Chọn mẫu…',command=pick_tpl).pack(side='left')

    sender_box=ttk.LabelFrame(tab,text='Bên bàn giao (theo User SAP)',padding=10)
    sender_box.pack(fill='x',pady=(0,8))
    uid_var=tk.StringVar(value=default_user or (next(iter(profiles)) if profiles else ''))
    ttk.Label(sender_box,text='User SAP').grid(row=0,column=0,sticky='w',padx=(0,8),pady=4)
    uid_box=ttk.Combobox(sender_box,textvariable=uid_var,width=18,values=sorted(profiles))
    uid_box.grid(row=0,column=1,sticky='w',pady=4)
    sender_vars={k:tk.StringVar() for k in PARTY_KEYS}
    last_uid=[sh.clean(uid_var.get()).upper()]

    def stash_current():
        prev=last_uid[0]
        vals={k:sender_vars[k].get().strip() for k in PARTY_KEYS}
        if prev and any(vals.values()):
            profiles[prev]=vals

    def load_uid(uid):
        key=sh.clean(uid).upper()
        last_uid[0]=key
        data=profiles.get(key,_clean_party({}))
        for k in PARTY_KEYS:
            sender_vars[k].set(data[k])

    def on_uid_change(_=None):
        stash_current()
        load_uid(uid_var.get())
        uid_box.configure(values=sorted(profiles))
    uid_box.bind('<<ComboboxSelected>>',on_uid_change)

    def fetch_sap_uid():
        stash_current()
        active=detect_sap_user(app.config,getattr(app,'current_sap_user',''))
        if not active:
            messagebox.showinfo('BBGN','Chưa kết nối phiên SAP GUI. Có thể gõ tay User SAP vào ô.',parent=tab)
            return
        app.current_sap_user=active
        uid_var.set(active)
        if active not in profiles:
            profiles[active]=_clean_party({})
        load_uid(active)
        uid_box.configure(values=sorted(profiles))

    def save_uid_btn():
        key=sh.clean(uid_var.get()).upper()
        if not key:
            messagebox.showwarning('BBGN','Nhập User SAP trước khi cập nhật.',parent=tab)
            return
        profiles[key]={k:sender_vars[k].get().strip() for k in PARTY_KEYS}
        last_uid[0]=key
        uid_var.set(key)
        uid_box.configure(values=sorted(profiles))

    def delete_uid_btn():
        key=sh.clean(uid_var.get()).upper()
        if key in profiles:
            profiles.pop(key)
        nxt=next(iter(sorted(profiles)),'')
        uid_var.set(nxt)
        load_uid(nxt)
        uid_box.configure(values=sorted(profiles))

    ubtns=ttk.Frame(sender_box)
    ubtns.grid(row=0,column=2,columnspan=2,sticky='w',padx=(8,0))
    ttk.Button(ubtns,text='Lấy từ SAP',command=fetch_sap_uid).pack(side='left',padx=(0,4))
    ttk.Button(ubtns,text='Cập nhật user',command=save_uid_btn).pack(side='left',padx=(0,4))
    ttk.Button(ubtns,text='Xóa user',command=delete_uid_btn).pack(side='left')

    labels=(('name','Họ và Tên'),('emp_id','Mã NV'),('dept','Bộ phận'),('title','Chức vụ'),('phone','Số điện thoại'))
    for idx,(k,lbl) in enumerate(labels,start=1):
        r,c=divmod(idx-1,2)
        ttk.Label(sender_box,text=lbl).grid(row=r+1,column=c*2,sticky='w',padx=(0,8),pady=4)
        ttk.Entry(sender_box,textvariable=sender_vars[k],width=26).grid(row=r+1,column=c*2+1,sticky='ew',padx=(0,14),pady=4)
    load_uid(uid_var.get())

    recv_box=ttk.LabelFrame(tab,text='Bên nhận bàn giao (Bộ phận mặc định bắt buộc · các mục khác có thể bỏ trống)',padding=10)
    recv_box.pack(fill='x',pady=(0,6))
    recv_vars={k:tk.StringVar(value=receiver[k]) for k in PARTY_KEYS}
    recv_order=(('dept','Bộ phận * (mặc định)'),('name','Họ và Tên (tùy chọn)'),('emp_id','Mã NV (tùy chọn)'),
                ('title','Chức vụ (tùy chọn)'),('phone','Số điện thoại (tùy chọn)'))
    for idx,(k,lbl) in enumerate(recv_order):
        r,c=divmod(idx,2)
        ttk.Label(recv_box,text=lbl).grid(row=r,column=c*2,sticky='w',padx=(0,8),pady=4)
        ttk.Entry(recv_box,textvariable=recv_vars[k],width=26).grid(row=r,column=c*2+1,sticky='ew',padx=(0,14),pady=4)

    footer_box=ttk.LabelFrame(tab,text='Chân trang & Phê duyệt (khi xuất ra khỏi xưởng, không phải sản xuất)',padding=10)
    footer_box.pack(fill='x',pady=(0,6))
    approver_var=tk.StringVar(value=sh.clean(app.config.get('bbbg_approver','')))
    ttk.Label(footer_box,text='Tên người phê duyệt (Approval)').grid(row=0,column=0,sticky='w',padx=(0,8),pady=4)
    ttk.Entry(footer_box,textvariable=approver_var,width=30).grid(row=0,column=1,sticky='w',pady=4)
    ttk.Label(footer_box,text='Nếu cấp sản xuất: tự gạch chéo phần Phê duyệt & An ninh.').grid(row=1,column=0,columnspan=2,sticky='w')

    class Controller:
        def build_cfg(self):
            key=sh.clean(uid_var.get()).upper()
            vals={k:sender_vars[k].get().strip() for k in PARTY_KEYS}
            if key and any(vals.values()):
                profiles[key]=vals
                last_uid[0]=key
            elif key and key in profiles:
                profiles[key]=vals
            recv={k:recv_vars[k].get().strip() for k in PARTY_KEYS}
            if not recv['dept']:
                raise ValueError('Cần nhập Bộ phận bên nhận bàn giao (mặc định bắt buộc).')
            return {
                'bbbg_users':{k:_clean_party(v) for k,v in profiles.items() if k},
                'bbbg_default_sap_user':key,
                'bbbg_receiver':recv,
                'bbbg_approver':approver_var.get().strip(),
                'bbbg_shared_template':tpl_var.get().strip(),
            }
        def apply_cfg(self,cfg):
            if cfg.get('bbbg_default_sap_user'):
                uid_box.configure(values=sorted(cfg.get('bbbg_users',{})))
    return Controller()


def open_form(page):
    if not page.path or page.app.is_running:return
    source=page.table
    day=page.kh.get()
    if day=="Cả file ca":
        messagebox.showinfo("Lập BBBG","Chọn một ngày KHSX để lập BBBG.",parent=page.app.root);return
    choices={k:r for k,r in page._row_lookup.items() if str(sh.day(r[26]))==day and sh.norm(r[27]) in ('hettonkhoma','chilapbbbg')}
    chosen={}
    win=tk.Toplevel(page.app.root)
    win.title('Lập BBBG theo trạm · '+day)
    bar=ttk.Frame(win);bar.pack(fill='x')
    default=SHARED_FORMS/'261122_BBGN.xlsb'
    template=tk.StringVar(value=page.app.config.get('bbbg_shared_template') or str(default))
    def browse():
        name=filedialog.askopenfilename(parent=win,filetypes=[('Mẫu Excel','*.xlsb *.xlsx *.xlsm')])
        if name:
            import sap_zone_core as core
            template.set(name);page.app.config['bbbg_shared_template']=name;core.ConfigManager.save_config(page.app.config)
    ttk.Button(bar,text='Đổi mẫu…',command=browse).pack(side='left')
    caption=tk.StringVar()
    def show_file(*_):
        caption.set('Mẫu: '+Path(template.get()).name+'    ·    ORDER: '+page.path.name)
    template.trace_add('write',show_file);show_file()
    ttk.Label(win,textvariable=caption,width=1).pack(fill='x')

    users,default_uid,receiver=normalize_bbbg_config(page.app.config)
    active_uid=sh.clean(getattr(page.app,'current_sap_user','') or '').upper() or default_uid or (next(iter(users)) if users else '')
    party_frame=ttk.Frame(win,padding=(4,4))
    party_frame.pack(fill='x')
    sap_uid_var=tk.StringVar(value=active_uid)
    recv_dept_var=tk.StringVar(value=receiver['dept'])
    sender_preview=tk.StringVar()
    ttk.Label(party_frame,text='User SAP').pack(side='left',padx=(0,4))
    uid_combo=ttk.Combobox(party_frame,textvariable=sap_uid_var,width=14,values=sorted({*users,*([active_uid] if active_uid else ())}))
    uid_combo.pack(side='left',padx=(0,8))
    ttk.Label(party_frame,textvariable=sender_preview).pack(side='left',padx=(0,10))
    ttk.Label(party_frame,text='Bộ phận nhận *').pack(side='left',padx=(4,4))
    ttk.Entry(party_frame,textvariable=recv_dept_var,width=18).pack(side='left')
    def update_preview(*_):
        u=sh.clean(sap_uid_var.get()).upper()
        p=users.get(u)
        if p and any(p.values()):
            parts=[p[k] for k in ('name','emp_id','dept','title','phone') if p.get(k)]
            sender_preview.set('Bàn giao: '+' · '.join(parts))
        else:
            sender_preview.set('Chưa cấu hình User SAP này (vào Cấu hình → BBGN)')
    sap_uid_var.trace_add('write',update_preview)
    update_preview()

    footer_opt=ttk.Frame(win,padding=(4,0,4,4))
    footer_opt.pack(fill='x')
    prod_var=tk.BooleanVar(value=is_production_dept(recv_dept_var.get()))
    approver_edit=tk.StringVar(value=sh.clean(page.app.config.get('bbbg_approver','')))
    manual_mode=[False]
    ttk.Checkbutton(footer_opt,text='Cấp sản xuất (gạch Phê duyệt & An ninh)',variable=prod_var,
                    command=lambda:manual_mode.__setitem__(0,True)).pack(side='left',padx=(0,12))
    ttk.Label(footer_opt,text='Phê duyệt (ngoài xưởng)').pack(side='left',padx=(0,4))
    ttk.Entry(footer_opt,textvariable=approver_edit,width=22).pack(side='left')
    def sync_prod(*_):
        if not manual_mode[0]:
            prod_var.set(is_production_dept(recv_dept_var.get()))
    recv_dept_var.trace_add('write',sync_prod)

    footer=ttk.Frame(win);footer.pack(side='bottom',fill='x')
    win.minsize(640,380)
    ttk.Label(win,text='Dán mã và SL ở cuối mỗi dòng. Bấm đúp dòng bên dưới để sửa SL.').pack(anchor='w')
    entry=tk.Text(win,height=4);entry.pack(fill='x')
    from zone_shift_ui import grid
    tree=grid(win,[('Mã NVL',135),('Trạm',180),('NCC',160),('SL bàn giao',105)])
    def refresh():
        tree.clear_rows()
        for k,q in chosen.items():
            r=choices[k];tree.append_row((r[3],r[5],r[0],qty_text(q)),key=k)
    selection=page.tree.selection()
    if selection:
        use_selection=messagebox.askyesnocancel('Nguồn lập BBBG',f'Lấy {len(selection)} dòng OD đang chọn?\nCó: dùng OD đang chọn. Không: dán mã và SL.',parent=win)
        if use_selection is None:
            win.destroy()
            return
        if not use_selection:selection=[]
    for n in selection:
        k=page.lines[n]['origin']
        if k in choices:
            r=choices[k];gap=Decimal(str(r[4]))-Decimal(str(r[22] or 0))
            if gap>0:chosen[k]=gap
    refresh()
    if selection and len(chosen)<len(selection):
        ttk.Label(win,text=f'{len(chosen)}/{len(selection)} dòng đủ điều kiện · chỉ lấy dòng hết tồn còn thiếu.').pack()
    def add():
        try:
            staged=dict(chosen)
            for code,q in pasted(entry.get('1.0','end')):
                keys=[k for k,r in choices.items() if sh.clean(r[3]).upper()==code]
                if not keys:raise ValueError(code+' chưa có dòng Hết tồn kho MA ở KHSX '+day)
                index=1
                if len(keys)>1:
                    prompt='\n'.join(f'{i}. {choices[k][9]} · {choices[k][5]} · SL OD {choices[k][4]}' for i,k in enumerate(keys,1))
                    index=simpledialog.askinteger(code,'Chọn dòng nhận SL '+str(q)+'\n'+prompt,minvalue=1,maxvalue=len(keys),parent=win)
                    if index is None:return
                staged[keys[index-1]]=q
            chosen.update(staged);refresh()
        except ValueError as exc:messagebox.showwarning('BBBG',str(exc),parent=win)
    def change(event):
        k=tree.identify_row(event.y)
        if not k:return
        v=simpledialog.askstring('BBBG','SL bàn giao',initialvalue=qty_text(chosen[k]),parent=win)
        if v is not None:
            try:chosen[k]=quantity(v);refresh()
            except ValueError as exc:messagebox.showwarning('BBBG',str(exc),parent=win)
    tree.bind('<Double-1>',change)
    ttk.Button(bar,text='Thêm mã dán',command=add).pack(side='left')
    def remove():
        for k in tree.selection():chosen.pop(k,None)
        refresh()
    ttk.Button(bar,text='Bỏ dòng chọn',command=remove).pack(side='left')
    def reopen():
        folder=page.path.parent/('BBBG_MO_PHONG' if page.app.mock_mode_var.get() else 'BBBG')/day
        if folder.is_dir():os.startfile(str(folder))
        else:messagebox.showinfo('BBBG','KHSX này chưa có thư mục phiếu.',parent=win)
    ttk.Button(bar,text='Phiếu đã lập',command=reopen).pack(side='left')
    def submit():
        if page.table is not source or not chosen or page.app.is_running:return
        try:
            _,sender_info,receiver_info=resolve_parties(
                page.app.config,sap_uid_var.get(),{'dept':recv_dept_var.get()})
            is_prod,approver=resolve_footer(
                page.app.config,receiver_info['dept'],sender_info.get('name',''),prod_var.get(),approver_edit.get())
        except ValueError as exc:
            messagebox.showwarning('BBBG',str(exc),parent=win);return
        demo=bool(page.app.mock_mode_var.get())
        mode='Xuất PDF mô phỏng' if demo else 'Xuất PDF và lưu số phiếu vào '+page.path.name
        if not messagebox.askyesno('Lập BBBG',mode+f' cho {len(chosen)} dòng?',parent=win):return
        configured=template.get()
        win.destroy()
        def ready(files):
            page.reload()
            os.startfile(str(files[0]))
            messagebox.showinfo('BBBG','Mở PDF để in. Các phiếu đã lưu ở\n'+str(files[0].parent)+'\n'+', '.join(p.name for p in files),parent=page.app.root)
        page.task('Đang lập BBBG…',lambda:issue(page,resolve_template(configured),chosen,day,demo,sender_info,receiver_info,is_prod,approver),ready)
    ttk.Button(footer,text='Lập BBBG theo trạm…',command=submit).pack(anchor='e')
