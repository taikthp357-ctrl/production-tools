"""Batch entry of actual quantities in the active ORDER workbook."""
from decimal import Decimal, InvalidOperation
from collections import defaultdict
import re
import tkinter as tk
from tkinter import ttk, messagebox

import zone_shift as sh
from zone_order_result import writable_order

SLOTS = (13, 16, 19)
AUTO_NOTES = {'', 'done', 'chuaradon', 'chocap', 'daradonchocap', 'radoncaplai', 'canradoncapbu'}


def amount(value):
    try:
        number = Decimal(str(value).strip().replace(',', '.'))
        if number.is_finite() and number >= 0 and number.adjusted() < 15 and len(number.normalize().as_tuple().digits) <= 15:
            return number
    except (InvalidOperation, ValueError):
        pass
    raise ValueError('SL cần là số từ 0 trở lên, tối đa 15 chữ số có nghĩa.')


def entry_amount(text):
    if '+' not in text:
        return amount(text)
    parts = [part.strip() for part in text.split('+')]
    if any(not re.fullmatch(r'[0-9]+(?:[.,][0-9]+)?', part) for part in parts):
        raise ValueError('Nhập SL hoặc phép cộng đầy đủ, ví dụ 28+15.')
    from decimal import localcontext
    values = [amount(part) for part in parts]
    with localcontext() as ctx:
        ctx.prec = max(30, max(len(part) for part in parts) + len(str(len(parts))) + 16)
        return amount(sum(values, Decimal(0)))


def actual(value):
    return None if value in ('', None) else amount(value)


def ticket(row, slot):
    return tuple(sh.clean(v) for v in row[slot:slot+2])


def usable(row, slot):
    ob, slip = ticket(row, slot)
    parts = [part.strip() for part in ob.split('/') if part.strip()] if ob else []
    return bool((parts and all(re.fullmatch(r'10\d{8}', part) for part in parts)) or (slip and not parts))
    

def derived(row):
    ordered = amount(row[4])
    issued = sum((actual(row[s+2]) or 0 for s in SLOTS), Decimal(0))
    note = sh.clean(row[27])
    if ordered == 0:
        raise ValueError('SL ORDER bằng 0, cần kiểm tra dòng.')
    state = 'Done' if issued >= ordered else 'Partial finished' if issued else 'Pending'
    managed = sh.norm(note) in AUTO_NOTES
    if state == 'Done' and (managed or sh.norm(note) in {'hettonkhoma','hangtapket'}):
        note = ''
    elif managed:
        waiting = any(usable(row,s) and actual(row[s+2]) is None for s in SLOTS)
        note = 'Đã ra đơn, chờ cấp' if waiting else 'Ra đơn cấp lại' if issued or any(usable(row,s) for s in SLOTS) else 'Chưa ra đơn'
    return state, note


class OrderTable(tuple):
    """Immutable Excel rows with one active-shift lookup shared by the pages."""
    def __new__(cls, table):
        if isinstance(table, cls):
            return table
        self = super().__new__(cls, table)
        self.line_index = tuple(sh.indexed(self))
        self.by_key = {key: row for n, row, key in self.line_index}
        self.numbers = {key: n for n, row, key in self.line_index}
        self.tickets = {}
        self.search_text = {}
        for n, row, key in self.line_index:
            for i, slot in enumerate(SLOTS, 1):
                if usable(row, slot):
                    ob, slip = ticket(row, slot)
                    fields = (n, sh.day(row[26]), row[9], row[3], row[5], slip, ob, i)
                    iid = (key, slot)
                    self.tickets[iid] = fields
                    self.search_text[iid] = '\0'.join(map(sh.norm, fields[3:7]))
        return self


    def refreshed(self,rows):
        if len(rows)!=len(self) or rows[0]!=self[0]:
            return OrderTable(rows)
        changed={i for i,(old,new) in enumerate(zip(self,rows)) if old!=new}
        if not changed:return self
        # Quantity, notes and calculated totals normally change. Preserve the slot
        # ordering and search strings unless a row identity or a ticket changed.
        ticket_fields=(3,5,9,13,14,16,17,19,20,26)
        for i in changed:
            old,new=self[i],rows[i]
            if (sh.row_identity(old)!=sh.row_identity(new)
                    or any(old[c]!=new[c] for c in ticket_fields)):
                return OrderTable(rows)
        fresh=tuple.__new__(OrderTable,(rows[i] if i in changed else row for i,row in enumerate(self)))
        fresh.line_index=tuple((n,fresh[n-1],key) for n,_,key in self.line_index)
        fresh.by_key={key:row for n,row,key in fresh.line_index}
        fresh.numbers=self.numbers
        fresh.tickets=self.tickets
        fresh.search_text=self.search_text
        return fresh


def read_lines(sheet, numbers, width):
    end = 'AI' if width >= 35 else 'AH'
    result = {}
    for low, high in sh.blocks(sorted(numbers)):
        rows = sheet.Range(f'A{low}:{end}{high}').Value2
        result.update(enumerate(rows, low))
    return result


def save_batch(path, password, table, drafts, sync):
    groups = defaultdict(dict)
    for (key, slot), value in drafts.items():
        groups[key][slot] = value
    targets = sorted((table.numbers[key], key) for key in groups.keys() | set(sync))
    with writable_order(path, password) as (book, sheet, shared):
        width = len(table[0])
        header = sheet.Range('A1:AH1').Value2
        sh.validate(header)
        live = read_lines(sheet, [n for n, _ in targets], width)
        edits = defaultdict(dict)
        for n, key in targets:
            old, row = table.by_key[key], live[n]
            if sh.row_identity(row) != sh.row_identity(old):
                raise ValueError(f'Dòng {n} · {old[3]} đã đổi vị trí hoặc thông tin ORDER. Đọc lại ORDER để đối chiếu.')
            for slot in SLOTS:
                before=(ticket(old,slot),sh.clean(old[slot+2]))
                after=(ticket(row,slot),sh.clean(row[slot+2]))
                if slot not in groups.get(key,{}) and before!=after:
                    raise ValueError(f'Dòng {n} · {old[3]} · lượt {SLOTS.index(slot)+1} vừa đổi trong Excel.')
            updated = list(row)
            for slot, value in groups.get(key, {}).items():
                label = f'Dòng {n} · {old[3]} · SL{SLOTS.index(slot)+1}'
                current = actual(row[slot+2])
                if ticket(row, slot) != ticket(old, slot) or current not in (actual(old[slot+2]), value):
                    raise ValueError(f'{label} đã đổi trong Excel (OB {row[slot]}, SL {sh.clean(row[slot+2])}).')
                updated[slot+2] = value
                if current != value:
                    if sheet.Cells(n, slot+3).HasFormula:
                        raise ValueError(label+' chứa công thức.')
                    edits[slot+3][n] = (row[slot+2], float(value))
            state, note = derived(updated)
            for col, value in ((25, state), (28, note)):
                if sh.clean(row[col-1]) != value and not sheet.Cells(n, col).HasFormula:
                    if sh.clean(row[col-1]) != sh.clean(old[col-1]):
                        raise ValueError(f'Dòng {n} · {old[3]} đã đổi trạng thái hoặc NOTE trong Excel.')
                    edits[col][n] = (row[col-1], value)
        applied = []
        save_attempted = False
        try:
            # Never assign a rectangle containing gaps, untargeted cells or formulas.
            for col, changes in edits.items():
                letter = {16:'P', 19:'S', 22:'V', 25:'Y', 28:'AB'}[col]
                for low, high in sh.blocks(sorted(changes)):
                    cells = sheet.Range(f'{letter}{low}:{letter}{high}')
                    old, new = zip(*(changes[n] for n in range(low, high+1)))
                    applied.append((cells, old))
                    cells.Value2 = new[0] if low == high else tuple((v,) for v in new)
            if edits:
                sheet.Calculate()
                check = read_lines(sheet, [n for n,_ in targets], width)
                for col, changes in edits.items():
                    for n, (_, value) in changes.items():
                        if sh.clean(check[n][col-1]) != sh.clean(value):
                            raise ValueError(f'Dòng {n}, cột {col} · Excel trả về giá trị khác dữ liệu nhập.')
            if edits or not book.Saved:
                save_attempted = True
                book.Save()
            if not book.Saved:
                raise ValueError('Excel chưa xác nhận lưu workbook.')
            # One bulk read on the same handle also captures recalculated formulas
            # and other operators' edits outside the submitted rows.
            stamp = sh.signature(path)
            current = sh.values(sheet)
            for n, key in targets:
                row = current[n-1]
                for slot, value in groups.get(key, {}).items():
                    if (sh.row_identity(row) != sh.row_identity(table.by_key[key])
                            or ticket(row, slot) != ticket(table.by_key[key], slot)
                            or actual(row[slot+2]) != value):
                        raise ValueError(f'Dòng {n} · {table.by_key[key][3]} · SL{SLOTS.index(slot)+1} chưa khớp sau lưu.')
            if stamp != sh.signature(path):
                raise ValueError('File đã thay đổi trong lúc xác minh.')
        except Exception as exc:
            if shared and not save_attempted:
                for cells, old in reversed(applied):
                    cells.Value2 = old[0] if len(old)==1 else tuple((v,) for v in old)
                if applied:
                    sheet.Calculate()
            if save_attempted:
                raise ValueError(f'Đã gọi lệnh lưu. Đọc lại ORDER để xác minh trước khi thử lại. {exc}') from exc
            raise
    return table.refreshed(current), stamp


def open_editor(page, host):
    if not page.path:
        return
    if page.app.mock_mode_var.get():
        messagebox.showinfo('Nhập SL','Tắt Mô phỏng để nhập SL thực cấp.',parent=page.app.root)
        return
    editor = getattr(page, 'qty_editor', None)
    if editor is None:
        page.qty_editor = editor = QuantityEditor(page,host)
    editor.show()


class QuantityEditor:
    def __init__(self, page, host):
        from zone_result_grid import ResultGrid
        self.page = page
        self.path = page.path
        self.win = ttk.Frame(host, padding=4)
        bar = ttk.Frame(self.win, padding=5)
        bar.pack(fill='x')
        ttk.Label(bar,text='Mã / trạm / số đơn / OB').pack(side='left')
        self.query = tk.StringVar(value=page.quick.get())
        self.search = ttk.Entry(bar,textvariable=self.query,width=24)
        self.search.pack(side='left',padx=5)
        self.hint = tk.StringVar()
        ttk.Label(self.win,textvariable=self.hint).pack(anchor='w')
        frame = ttk.Frame(self.win)
        frame.pack(fill='both',expand=True)
        columns = ('Dòng','KHSX','Model','Mã hàng','Trạm','Số đơn','OB','Lượt','SL thực cấp')
        self.tree = ResultGrid(frame,list(zip(columns,(52,94,66,130,175,118,118,48,96))),toolbar=False)
        self.table = page.table
        self.drafts = {}
        self.editor = None
        self.job = None
        self.busy = False
        self.order = (0,False)
        self.ordered = list(self.table.tickets)
        self.shown = []
        self.positions = {}
        self.active = False
        self.tree.header.bind('<Button-1>',self.sort)
        self.tree.bind('<Button-1>',self.click)
        self.tree.bind('<Return>',lambda _:self.start(self.shown[self.tree.active[0]-1]) if self.tree.active else self.first())
        for widget in self.tree.master.winfo_children():
            if isinstance(widget,ttk.Scrollbar):
                view=self.tree.yview if str(widget.cget('orient'))=='vertical' else self.tree.xview
                widget.configure(command=lambda *args,view=view:self.commit() and view(*args))
        self.tree.bind('<MouseWheel>',self.wheel)
        self.tree.bind('<Configure>',self.reposition,add='+')
        self.search.bind('<Return>',self.first)
        self.query.trace_add('write',self.queue_filter)
        ttk.Button(bar,text='Lưu SL',command=self.save).pack(side='left')
        ttk.Button(bar,text='Đọc lại ORDER',command=self.reload).pack(side='left')
        ttk.Button(bar,text='Đồng bộ NOTE lệch…',command=lambda:self.save(True)).pack(side='left')
        ttk.Button(bar,text='Kết thúc nhập',command=self.close).pack(side='right')
        self.bind_controls(self.win)
        self.filter()
        self.win.bind('<Map>',self.restore_focus)

    def bind_controls(self, widget):
        widget.bind('<Control-f>',self.find)
        widget.bind('<Control-s>',lambda e:self.save() or 'break')
        for child in widget.winfo_children():
            self.bind_controls(child)

    def restore_focus(self,event):
        if event.widget is self.win and self.active:
            self.win.after_idle(self.focus)

    def focus(self):
        if self.active and self.win.winfo_viewable():
            (self.editor[0] if self.editor else self.search).focus_set()

    def show(self):
        self.active = True
        self.win.place(x=0,y=0,relwidth=1,relheight=1)
        self.win.lift()
        if self.table is not self.page.table and not self.dirty():
            self.replace_table(self.page.table)
        self.focus()

    def dirty(self):
        return bool(self.drafts or self.editor and self.editor[0].get().strip()!=self.editor[2])

    def discard_ok(self):
        return not self.dirty() or messagebox.askyesno('Nhập SL','Bỏ các ô chưa lưu?',parent=self.page.app.root)

    def close(self):
        if self.busy or not self.commit() or not self.discard_ok():
            return
        if self.drafts:
            self.drafts.clear()
            self.filter()
        self.active = False
        self.win.place_forget()
        self.page.finish_qty_view()

    def dispose(self):
        if self.job is not None:
            self.win.after_cancel(self.job)
        self.win.destroy()

    def values(self, iid):
        key, slot = iid
        return (*self.table.tickets[iid], sh.clean(self.drafts.get(iid,self.table.by_key[key][slot+2])))

    def status(self, message=''):
        self.hint.set((message+' · ' if message else '')+f'{len(self.shown)} lượt · {len(self.drafts)} ô chưa lưu · Enter xuống dòng · Ctrl+F tìm tiếp · Ctrl+S lưu')

    def commit(self):
        if self.editor is None:
            return True
        entry, iid, original = self.editor
        key, slot = iid
        raw = entry.get().strip()
        try:
            if raw and raw != original:
                value = entry_amount(raw)
                if value != actual(self.table.by_key[key][slot+2]):
                    self.drafts[iid] = value
                else:
                    self.drafts.pop(iid,None)
        except ValueError as exc:
            messagebox.showwarning('SL thực cấp',str(exc),parent=self.win)
            entry.focus_set()
            return False
        self.editor = None
        entry.destroy()
        if iid in self.positions:
            self.tree.update_cell(self.positions[iid], len(self.tree.names)-1, self.values(iid)[-1])
        self.status()
        return True

    def queue_filter(self,*_):
        if self.job is not None:
            self.win.after_cancel(self.job)
        self.job = self.win.after(35,self.filter)

    def filter(self):
        if self.job is not None:
            self.win.after_cancel(self.job)
            self.job = None
        if not self.commit():
            return False
        query = sh.norm(self.query.get())
        old=self.shown
        selected={old[i-1] for i in self.tree.selection() if i<=len(old)}
        active=(old[self.tree.active[0]-1],self.tree.active[1]) if self.tree.active and self.tree.active[0]<=len(old) else None
        self.shown = [i for i in self.ordered if query in self.table.search_text[i]] if query else self.ordered[:]
        self.positions = {iid:n for n,iid in enumerate(self.shown)}
        self.tree.replace_rows([self.values(iid) for iid in self.shown])
        self.tree.selection_set({self.positions[k]+1 for k in selected if k in self.positions})
        if active and active[0] in self.positions:self.tree.active=(self.positions[active[0]]+1,active[1])
        self.status()
        return True

    def sort_keys(self):
        column, reverse = self.order
        def value(iid):
            field = self.values(iid)[column]
            if column in (0,7,8):
                try:return amount(field)
                except ValueError:return Decimal(-1)
            return tuple((1,int(s)) if s.isdigit() else (0,s) for s in re.split(r'(\d+)',str(field).casefold()))
        if self.order == (0,False):
            self.ordered = list(self.table.tickets)
        else:
            self.ordered = sorted(self.table.tickets,key=value,reverse=reverse)

    def sort(self,event):
        if not self.commit():return
        x=self.tree.header.canvasx(event.x)
        for i,w in enumerate(self.tree.widths):
            if x<w:
                self.order = (i,not self.order[1] if i==self.order[0] else False)
                self.sort_keys()
                self.filter()
                return
            x-=w

    def first(self,event=None):
        if self.job is not None and not self.filter():return 'break'
        if self.shown:self.start(self.shown[0])
        return 'break'

    def click(self,event):
        pos=int(self.tree.canvasy(event.y)//self.tree.height_px)
        if 0<=pos<len(self.shown):
            if self.tree.canvasx(event.x)>=sum(self.tree.widths[:-1]):self.start(self.shown[pos])
            elif self.commit():self.tree.choose(event)
        return 'break'

    def wheel(self,event):
        if self.commit():self.tree.yview_scroll(-int(event.delta/120),'units')
        return 'break'

    def reposition(self,event=None):
        if self.editor is None:return
        entry,iid,_ = self.editor
        index=self.positions[iid]
        tree=self.tree
        x=sum(tree.widths[:-1])-tree.canvasx(0)
        y=index*tree.height_px-tree.canvasy(0)
        entry.place(x=int(x)+1,y=int(y)+1,width=tree.widths[-1]-2,height=tree.height_px-2)

    def start(self,iid):
        if self.busy or not self.commit():return
        index = self.positions[iid]
        tree = self.tree
        tree.selection_set([index+1])
        tree.active=(index+1,len(tree.names)-1)
        y=index*tree.height_px
        if y<tree.canvasy(0) or y+tree.height_px>tree.canvasy(tree.winfo_height()):
            tree.yview_moveto(y/max(tree.winfo_height(),len(self.shown)*tree.height_px))
        tree.xview_moveto(1)
        entry=ttk.Entry(tree)
        original=self.values(iid)[-1]
        self.editor=entry,iid,original
        self.reposition()
        entry.insert(0,original)
        entry.select_range(0,'end')
        entry.focus_set()
        self.bind_controls(entry)
        def advance(direction):
            pos=index+direction
            if self.commit():
                if 0<=pos<len(self.shown):
                    self.start(self.shown[pos])
                else:self.find()
            return 'break'
        entry.bind('<Return>',lambda _:advance(1))
        entry.bind('<Shift-Return>',lambda _:advance(-1))

    def find(self,event=None):
        if self.commit():
            self.search.focus_set()
            self.search.select_range(0,'end')
        return 'break'

    def replace_table(self,table):
        self.table=table
        self.sort_keys()
        self.filter()

    def reload(self):
        if self.busy or self.page.app.is_running or not self.commit():return
        self.busy=True
        def ready(data):
            self.busy=False
            latest,_=data
            keep=dict(self.drafts)
            for (key,slot),value in self.drafts.items():
                old=self.table.by_key[key]
                now=latest.by_key.get(key)
                if now is None or ticket(now,slot)!=ticket(old,slot):
                    messagebox.showwarning('Dòng OD đã đổi',f'{old[3]} · {ticket(old,slot)} đã đổi. Bản nhập vẫn được giữ.',parent=self.win)
                    return
                current=actual(now[slot+2])
                if current==value:
                    keep.pop((key,slot))
                elif current!=actual(old[slot+2]):
                    prompt=f'Dòng {latest.numbers[key]} · {old[3]} · {ticket(now,slot)}\nExcel: {current} · Đang nhập: {value}\nGiữ số đang nhập cho lần lưu tiếp theo?'
                    decision=messagebox.askyesnocancel('Chọn SL cho lượt này',prompt,parent=self.win)
                    if decision is None:return
                    if not decision:keep.pop((key,slot))
            self.drafts=keep
            self.page.apply_qty_table(data)
            self.replace_table(latest)
        def work():
            rows,stamp=sh.load(self.path,self.page.password)
            return OrderTable(rows),stamp
        self.page.task('Đang đọc ORDER…',work,ready,self.failed)

    def failed(self,error):
        self.busy=False
        self.status('Giữ bản nhập')
        self.page.app.status_text_var.set('Giữ bản nhập · '+str(error))
        messagebox.showwarning('Nhập SL',str(error)+'\nBản nhập vẫn được giữ.',parent=self.page.app.root)
        return True

    def save(self,sync_notes=False):
        if self.busy:return
        if self.page.app.mock_mode_var.get():
            self.status('Tắt Mô phỏng trước khi lưu SL')
            return
        if self.page.app.is_running:
            self.status('ORDER đang bận · giữ bản nhập để lưu tiếp')
            return
        if not self.commit():return
        sync=[]
        if sync_notes:
            for key,row in self.table.by_key.items():
                if any(usable(row,s) for s in SLOTS):
                    try:_,note=derived(row)
                    except ValueError:continue
                    if note!=sh.clean(row[27]):sync.append(key)
            if not sync:
                self.status('NOTE các dòng có phiếu đã khớp')
                return
            if not messagebox.askyesno('Đồng bộ NOTE',f'Cập nhật NOTE cho {len(sync)} dòng trong {self.path.name}?',parent=self.win):return
        if not self.drafts and not sync:
            self.status('Không có ô cần lưu')
            return
        self.busy=True
        snapshot=dict(self.drafts)
        table=self.table
        password=self.page.password
        self.status('Đang lưu và xác minh ORDER')
        def work():
            try:return save_batch(self.path,password,table,snapshot,sync)
            except Exception as exc:
                lines=', '.join(f'{table.numbers[k]} (SL{SLOTS.index(s)+1})' for k,s in list(snapshot)[:8])
                raise ValueError(f'{self.path.name} · dòng {lines or ", ".join(str(table.numbers[k]) for k in sync[:8])}\n{exc}') from exc
        def done(data):
            self.busy=False
            self.drafts.clear()
            self.page.apply_qty_table(data)
            self.replace_table(data[0])
            message=f'Đã lưu và xác minh {len(snapshot)} ô SL' if snapshot else f'Đã đồng bộ {len(sync)} dòng NOTE'
            self.status(message)
            self.page.app.status_text_var.set(message)
            if self.win.winfo_viewable():self.find()
        self.page.task('Đang lưu SL và xác minh ORDER…',work,done,self.failed)
