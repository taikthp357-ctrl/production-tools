"""Copy report tables as Windows HTML Format and Unicode tab-separated text."""
from html import escape
import sys
import time


def cell_text(value):
    if value is None:
        return ''
    return str(value).replace('\x00', '').replace('\r\n', ' ').replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')


def table_formats(sections):
    html = []
    text = []
    border = 'border:1px solid #8599a8;padding:3px 6px;'
    for title, headers, rows in sections:
        headers = [cell_text(header) for header in headers]
        lines = []
        if title:
            title = cell_text(title)
            html.append('<p><strong>' + escape(title) + '</strong></p>')
            lines.append(title)
        lines.append('\t'.join(headers))
        html.append('<table border="1" cellspacing="0" cellpadding="3" '
                    'style="border-collapse:collapse;empty-cells:show;font-family:Segoe UI,Arial,sans-serif">')
        html.append('<thead><tr>')
        for header in headers:
            html.append(f'<th style="{border}background-color:#234663;color:#ffffff">{escape(header)}</th>')
        html.append('</tr></thead><tbody>')
        for row in rows:
            values = [cell_text(value) for value in row]
            if len(values) > len(headers):
                raise ValueError('Số ô vượt quá số cột trong bảng.')
            values.extend([''] * (len(headers) - len(values)))
            lines.append('\t'.join(values))
            html.append('<tr>')
            for header, value in zip(headers, values):
                # Excel otherwise interprets slips such as 26-05 as dates.
                style = border
                if header in ('Mã NVL', 'Mã hàng', 'Mã SG', 'Số đơn', 'OB', 'Batch'):
                    style += 'mso-number-format:"\\@";'
                html.append(f"<td style='{style}'>{escape(value)}</td>")
            html.append('</tr>')
        html.append('</tbody></table>')
        text.append('\r\n'.join(lines))
    return '\r\n\r\n'.join(text), ''.join(html)


def windows_html(fragment):
    header = ('Version:1.0\r\nStartHTML:{:010d}\r\nEndHTML:{:010d}\r\n'
              'StartFragment:{:010d}\r\nEndFragment:{:010d}\r\n')
    prefix = b'<html><head><meta charset="utf-8"></head><body><!--StartFragment-->'
    suffix = b'<!--EndFragment--></body></html>'
    content = fragment.encode('utf-8')
    start_html = len(header.format(0, 0, 0, 0))
    start_fragment = start_html + len(prefix)
    end_fragment = start_fragment + len(content)
    offsets = header.format(start_html, end_fragment + len(suffix), start_fragment, end_fragment)
    return offsets.encode('ascii') + prefix + content + suffix + b'\x00'


def copy_tables(widget, sections):
    plain, fragment = table_formats(sections)
    if sys.platform != 'win32':
        widget.clipboard_clear()
        widget.clipboard_append(plain)
        widget.clipboard_append(fragment, type='text/html')
        return
    import win32clipboard as clip
    import pywintypes
    html_format = clip.RegisterClipboardFormat('HTML Format')
    data = windows_html(fragment)
    owner = widget.winfo_id()
    for attempt in range(5):
        try:
            clip.OpenClipboard(owner)
            break
        except pywintypes.error as exc:
            if exc.winerror != 5:
                raise
            if attempt == 4:
                raise RuntimeError('Clipboard đang bận. Bấm copy lại.') from exc
            time.sleep(0.015)
    try:
        clip.EmptyClipboard()
        clip.SetClipboardData(html_format, data)
        clip.SetClipboardText(plain, clip.CF_UNICODETEXT)
    finally:
        clip.CloseClipboard()
