"""Selectable ORDER cells, per-OB copy and tabular copying for production."""
import tkinter as tk
from tkinter import ttk, font
from functools import lru_cache

def sort_value(value):
    import re
    from datetime import datetime
    text=str(value).strip()
    for fmt in ('%d/%m/%Y','%Y-%m-%d','%d-%b-%y'):
        try:return (0,datetime.strptime(text,fmt).toordinal())
        except ValueError:pass
    try:return (1,float(text))
    except ValueError:pass
    return (2,tuple((1,int(p)) if p.isdigit() else (0,p.casefold()) for p in re.split(r'(\d+)',text)))

class ResultGrid(tk.Canvas):
    height_px=26

    def __init__(self,parent,columns,toolbar=True,station_report=None):
        self.names=[n for n,w in columns]
        self.widths=[w for n,w in columns]
        self.columns=columns
        self.base_widths=self.widths[:]
        self.warnings=set()
        self.render_job=None
        self.visible_range=None
        self.station_report=station_report
        self.copy_notice=None
        self.on_copy=None
        self.extra_menu=None
        self.sort_order=(None,False)
        if toolbar:
            bar=ttk.Frame(parent)
            bar.pack(fill='x')
            if station_report:
                options=ttk.Menubutton(bar,width=1)
                menu=tk.Menu(options,tearoff=False)
                menu.add_command(label='Bảng đang xem',command=self.copy_rows)
                menu.add_command(label='Báo cáo SX/TL theo trạm',command=lambda:self.copy_rows(by_station=True))
                options.configure(menu=menu)
                options.pack(side='right')
            ttk.Button(bar,text='Copy bảng',command=self.copy_rows).pack(side='right')
            self.copy_notice=tk.StringVar(master=parent)
            ttk.Label(bar,textvariable=self.copy_notice).pack(side='right',padx=6)
        frame=ttk.Frame(parent)
        frame.pack(fill='both',expand=True)
        super().__init__(frame,background='white',highlightthickness=0,borderwidth=0,xscrollincrement=1,takefocus=True)
        self.header=tk.Canvas(frame,height=self.height_px,width=1,background='#234663',highlightthickness=0,borderwidth=0,xscrollincrement=1)
        self.header.grid(row=0,column=0,sticky='ew')
        for axis in ('x','y'):
            bar=ttk.Scrollbar(frame,orient='horizontal' if axis=='x' else 'vertical',command=getattr(self,axis+'view'))
            bar.grid(row=1+int(axis=='x'),column=int(axis=='y'),sticky='ew' if axis=='x' else 'ns')
            if axis=='x':
                def sync(first,last,scrollbar=bar):
                    scrollbar.set(first,last)
                    self.sync_header()
                self.configure(xscrollcommand=sync)
            else:
                def vertical(first,last,scrollbar=bar):
                    scrollbar.set(first,last)
                    self.queue_view()
                self.configure(yscrollcommand=vertical)
        self.grid(row=1,column=0,sticky='nsew')
        frame.columnconfigure(0,weight=1);frame.rowconfigure(1,weight=1)
        self.cell_font=font.Font(root=self,family='Segoe UI',size=getattr(self._root(),'_ma_colors',{}).get('size',9))
        self.fit_text=lru_cache(maxsize=4096)(self.fit_text)
        self.rows=[];self.chosen=set();self.active=None
        for key,dy,dx in [('Up',-1,0),('Down',1,0),('Left',0,-1),('Right',0,1),('Home',-10**9,0),('End',10**9,0)]:
            self.bind('<'+key+'>',lambda e,y=dy,x=dx:self.navigate(y,x,e))
        self.bind('<Control-C>',self.copy_cell)
        self.bind('<Control-Shift-C>',lambda e:self.copy_rows() or 'break')
        self.bind("<Configure>",self.resize)
        self.bind("<Map>",lambda _:self.queue_view())
        self.draw(0,self.names)
        self.bind('<Button-1>',self.choose)
        self.bind('<Button-3>',self.menu)
        self.bind('<Control-c>',self.copy_cell)
        self.bind('<Control-a>',self.all)
        self.bind('<Control-A>',self.all)
        self.bind('<Prior>',lambda e:self.yview_scroll(-1,'pages') or 'break')
        self.bind('<Next>',lambda e:self.yview_scroll(1,'pages') or 'break')
        self.bind('<MouseWheel>',self._on_wheel)
        self.bind('<Shift-MouseWheel>',lambda e:self.xview_scroll(-int(e.delta/120)*20,'units'))
        self.bind('<Button-4>',lambda _:self.yview_scroll(-1,'units'))
        self.bind('<Button-5>',lambda _:self.yview_scroll(1,'units'))

        self.tip=None
        self.tip_key=None
        self.bind('<Motion>',self.hover)
        self.bind('<Leave>',self.hide_tip)
        self.bind('<Unmap>',self.hide_tip)
        self.bind('<F2>',self.read_active)

    def _on_wheel(self,event):
        if event.state & 1:
            self.xview_scroll(-int(event.delta/120)*20,'units')
        else:
            self.yview_scroll(-int(event.delta/120),'units')

    def hide_tip(self,event=None):
        if self.tip:self.tip.destroy()
        self.tip=None
        self.tip_key=None

    def hover(self,event):
        i=int(self.canvasy(event.y)//self.height_px)
        x=self.canvasx(event.x)
        for j,width in enumerate(self.widths):
            if x<width:break
            x-=width
        else:return self.hide_tip()
        if not 0<=i<len(self.rows):return self.hide_tip()
        value=str(self.rows[i][j])
        if self.tip_key==(i,j,value):return
        self.hide_tip()
        if self.fit_text(value,width-10)==value:return
        self.tip_key=(i,j,value)
        self.tip=tk.Toplevel(self)
        self.tip.overrideredirect(True)
        ttk.Label(self.tip,text=value,wraplength=480,padding=5,relief='solid').pack()
        self.tip.update_idletasks()
        left=max(0,min(event.x_root,self.winfo_screenwidth()-self.tip.winfo_reqwidth()))
        top=event.y_root+20
        if top+self.tip.winfo_reqheight()>self.winfo_screenheight():top=max(0,event.y_root-self.tip.winfo_reqheight()-4)
        self.tip.geometry(f'+{left}+{top}')

    def read_active(self,event):
        if self.active:
            from tkinter import messagebox
            i,j=self.active
            messagebox.showinfo(self.names[j],str(self.rows[i-1][j]),parent=self)
        return 'break'

    def enable_sort(self,records=lambda:None):
        self.sort_order=(None,False)
        def reorder(event):
            x=self.header.canvasx(event.x)
            for j,width in enumerate(self.widths):
                if x<width:break
                x-=width
            else:return
            reverse=self.sort_order==(j,False)
            self.sort_order=(j,reverse)
            self.sort_by_column(j,reverse,records())
        self.header.bind('<Button-1>',reorder)

    def sort_by_column(self,column,reverse,records):
        indices=sorted(range(1,len(self.rows)+1),key=lambda n:sort_value(self.rows[n-1][column]),reverse=reverse)
        mapping={old:new for new,old in enumerate(indices,1)}
        if records is not None:
            moved={mapping[k]:v for k,v in records.items() if k in mapping}
            records.clear()
            records.update(moved)
        self.rows=[self.rows[n-1] for n in indices]
        self.chosen={mapping[n] for n in self.chosen}
        self.warnings={mapping[n] for n in self.warnings}
        if self.active:self.active=(mapping[self.active[0]],self.active[1])
        self.visible_range=None
        self.draw(0,self.names)
        self.queue_view()

    def navigate(self,dy,dx,event):
        if not self.rows:return 'break'
        i,j=self.active or (1,0)
        row=max(1,min(len(self.rows),i+dy))
        col=max(0,min(len(self.names)-1,j+dx))
        selection=self.chosen|set(range(min(i,row),max(i,row)+1)) if event.state&1 else {row}
        self.active=(row,col)
        ResultGrid.selection_set(self,selection)
        h=self.height_px
        y=(row-1)*h
        top=self.canvasy(0)
        height=self.winfo_height()
        if y<top or y+h>top+height:
            self.yview_moveto((y if y<top else y+h-height)/max(height,len(self.rows)*h))
        x=sum(self.widths[:col])
        left=self.canvasx(0)
        if x<left or x+self.widths[col]>left+self.winfo_width():
            self.xview_moveto(max(0,x if x<left else x+self.widths[col]-self.winfo_width())/sum(self.widths))
        self.visible_range=None
        self.queue_view()
        self.event_generate('<<TreeviewSelect>>')
        return 'break'

    def see(self,key):
        if key in self.positions:self.yview_moveto((self.positions[key]-1)/max(1,len(self.rows)))

    def sync_header(self):
        width=sum(self.widths)
        if width:
            self.header.xview_moveto(self.canvasx(0)/width)

    def replace_rows(self,rows):
        self.rows=rows
        self.chosen.clear()
        self.warnings.clear()
        self.active=None
        self.visible_range=None
        self._region=(0,0,sum(self.widths),max(self.winfo_height(),len(rows)*self.height_px))
        self.configure(scrollregion=self._region)
        self.yview_moveto(0)
        self.queue_view()

    def update_cell(self,index,column,value):
        values=self.rows[index]
        if values[column]==value:return
        self.rows[index]=(*values[:column],value,*values[column+1:])
        i=index+1
        if self.visible_range and self.visible_range[0]<=i<=self.visible_range[1]:
            self.itemconfigure(f'text{i}_{column}',text=self.fit_text(str(value),self.widths[column]-10))

    def queue_view(self):
        if self.render_job is None:
            self.render_job=self.after_idle(self.render_view)

    def render_view(self):
        self.render_job=None
        if not self.winfo_ismapped():
            return
        height=self.winfo_height()
        region=(0,0,sum(self.widths),max(height,len(self.rows)*self.height_px))
        if region!=getattr(self,'_region',None):
            self._region=region
            self.configure(scrollregion=region)
        first=max(1,int(self.canvasy(0)//self.height_px))
        last=min(len(self.rows),first+height//self.height_px+3)
        bounds=(first,last,tuple(self.widths))
        if bounds==self.visible_range:
            return
        self.visible_range=bounds
        self.delete('all')
        for i in range(first,last+1):
            self.draw(i,self.rows[i-1])
        if self.active:
            i,j=self.active
            if first<=i<=last and j<len(self.widths):
                x=sum(self.widths[:j]);y=(i-1)*self.height_px
                self.create_rectangle(x+1,y+1,x+self.widths[j]-1,y+self.height_px-1,outline='#1263a5',width=2,tags='active')

    def resize(self,event):
        self.fit_width(event.width)
        self.queue_view()

    def fit_width(self,width):
        total=sum(self.base_widths)
        spare=max(0,width-total-1)
        widths=[w+spare*w//total for w in self.base_widths]
        if widths==self.widths:return
        self.widths=widths
        self.delete('all')
        self.draw(0,self.names)
        self.visible_range=None
        self.draw(0,self.names)
        self.queue_view()

    def show_columns(self,names):
        chosen=[(i,k,w) for i,(k,w) in enumerate(self.columns) if k in names]
        self.indices=[i for i,k,w in chosen]
        self.names=[k for i,k,w in chosen]
        self.widths=self.base_widths=[w for i,k,w in chosen]
        self.reset()
        self.fit_width(self.winfo_width())

    def selection_set(self,nodes):
        changed=self.chosen.symmetric_difference(nodes)
        self.chosen=set(nodes)
        for i in changed:
            if not self.visible_range or not self.visible_range[0]<=i<=self.visible_range[1]:continue
            self.delete(f'row{i}')
            self.draw(i,self.rows[i-1])

    def fit_text(self,text,width):
        if self.cell_font.measure(text)<=width:return text
        lo,hi=0,len(text)
        while lo<hi:
            mid=(lo+hi+1)//2
            if self.cell_font.measure(text[:mid]+'…')<=width:lo=mid
            else:hi=mid-1
        return text[:lo]+'…'

    def draw(self,i,values):
        surface=self if i else self.header
        sort_col,sort_desc=getattr(self,'sort_order',(None,False))
        if not i:
            self.header.delete('all')
            self.header.configure(scrollregion=(0,0,sum(self.widths),self.height_px))
            self.sync_header()
        x=0;y=max(0,i-1)*self.height_px
        palette=getattr(self._root(),'_ma_colors',{})
        color='#234663' if not i else palette.get('selection','#bfdaed') if i in self.chosen else '#fff2db' if i in self.warnings else '#f4f8fc' if i%2==0 else '#ffffff'
        foreground='white' if not i else '#6b4000' if (i in self.warnings and i not in self.chosen) else palette.get('text','#183449')
        if i and hasattr(self,'row_colors'):color,foreground=self.row_colors(i,color,foreground)
        header_font=getattr(self,'header_font',self.cell_font)
        active_font=header_font if not i else self.cell_font
        for j,(v,w) in enumerate(zip(values,self.widths)):
            label=str(v)
            if not i and sort_col==j:
                label+=(' ▼' if sort_desc else ' ▲')
            surface.create_rectangle(x,y,x+w,y+self.height_px,fill=color,outline='#648199' if not i else '#d5e0ea',tags=f'row{i}')
            surface.create_text(x+6,y+self.height_px/2,text=self.fit_text(label,w-12),fill=foreground,anchor='w',tags=(f'row{i}',f'text{i}_{j}'),font=active_font)
            x+=w
        

    def add(self,values,selected=False,warning=False):
        if hasattr(self,'indices'):values=[values[i] for i in self.indices]
        i=len(self.rows)+1
        if selected:self.chosen.add(i)
        if warning:self.warnings.add(i)
        self.rows.append(tuple(values));self.queue_view();return i

    def reset(self):
        self.visible_range=None;self.queue_view();self.delete('all');self.rows.clear();self.chosen.clear();self.warnings.clear();self.yview_moveto(0);self.active=None;self.draw(0,self.names)
        if self.copy_notice is not None:self.copy_notice.set('')

    def selection(self):
        return sorted(self.chosen)

    def choose(self,e):
        self.focus_set()
        i=1+int(self.canvasy(e.y)//self.height_px)
        if not 0<i<=len(self.rows):return
        x=self.canvasx(e.x);j=0
        while j<len(self.widths)-1 and x>=self.widths[j]:x-=self.widths[j];j+=1
        old=self.chosen.copy()
        if e.state&1 and self.active:self.chosen.update(range(min(self.active[0],i),max(self.active[0],i)+1))
        elif e.state&4:self.chosen.symmetric_difference_update({i})
        else:self.chosen={i}
        self.active=(i,j)
        for n in old^self.chosen:
            if self.visible_range and self.visible_range[0]<=n<=self.visible_range[1]:
                self.delete(f'row{n}');self.draw(n,self.rows[n-1])
        self.delete('active')
        x=sum(self.widths[:j]);y=(i-1)*self.height_px
        self.create_rectangle(x+1,y+1,x+self.widths[j]-1,y+self.height_px-1,outline='#1263a5',width=2,tags='active')

    def all(self,e):
        self.chosen=set(range(1,len(self.rows)+1))
        self.visible_range=None;self.queue_view()
        return 'break'

    def copy(self,value):
        self.clipboard_clear();self.clipboard_append(value)

    def menu(self,e):
        i=1+int(self.canvasy(e.y)//self.height_px)
        if not 0<i<=len(self.rows):return
        if i in self.chosen and len(self.chosen)>1 and not (e.state&5):
            self.focus_set()
            x=self.canvasx(e.x);j=0
            while j<len(self.widths)-1 and x>=self.widths[j]:x-=self.widths[j];j+=1
            self.active=(i,j)
            self.delete('active')
            rx=sum(self.widths[:j]);ry=(i-1)*self.height_px
            self.create_rectangle(rx+1,ry+1,rx+self.widths[j]-1,ry+self.height_px-1,outline='#1263a5',width=2,tags='active')
        else:
            ResultGrid.choose(self,e)
            if isinstance(self,KeyGrid):
                self.event_generate('<<TreeviewSelect>>')
        if self.active:
            self.copy_cell(e,True)

    def copy_cell(self,e,show=False):
        if self.active:
            i,j=self.active
            value=str(self.rows[i-1][j])
            parts=[]
            if self.names[j] in ('OB','Số OB','OB cũ','Số đơn','Số đơn INWH','Mã WHO SAP') or '/' in value:
                parts=[s.strip() for s in value.split('/') if s.strip()]
            if show:
                menu=tk.Menu(self,tearoff=False)
                if value:
                    short=value if len(value)<=42 else value[:39]+'…'
                    menu.add_command(label='Copy ô: '+short,command=lambda v=value:self.copy(v))
                for v in dict.fromkeys(parts):
                    if v!=value:
                        menu.add_command(label='Copy '+v,command=lambda v=v:self.copy(v))
                menu.add_separator()
                if getattr(self,'chosen',None):
                    menu.add_command(label=f'Copy dòng đã chọn ({len(self.chosen)} dòng)',command=lambda:self.copy_rows(selected_only=True))
                menu.add_command(label=f'Copy toàn bộ bảng ({len(self.rows)} dòng)',command=lambda:self.copy_rows(all_rows=True))
                if getattr(self,'station_report',None):
                    menu.add_command(label='Copy báo cáo SX/TL theo trạm',command=lambda:self.copy_rows(by_station=True))
                extra=getattr(self,'extra_menu',None)
                if extra:
                    menu.add_separator()
                    extra(menu,i,j)
                menu.tk_popup(self.winfo_pointerx(),self.winfo_pointery())
            else:self.copy(value)
        return 'break'

    def copy_rows(self,by_station=False,selected_only=False,all_rows=False):
        from zone_clipboard import copy_tables
        if all_rows:
            indices=list(range(1,len(self.rows)+1))
        elif selected_only:
            indices=sorted(self.chosen)
        else:
            indices=sorted(self.chosen) or list(range(1,len(self.rows)+1))
        if not indices:
            msg='Chưa có dòng để copy.'
            if self.copy_notice is not None:self.copy_notice.set(msg)
            if self.on_copy:self.on_copy(msg)
            return
        try:
            if by_station:
                title,headers,rows=self.station_report(indices)
            else:
                title,headers,rows='',self.names,[self.rows[i-1] for i in indices]
            copy_tables(self,[(title,headers,rows)])
            scope='báo cáo SX/TL' if by_station else 'bảng'
            msg=f'Đã copy {scope} · {len(rows)} dòng (Ctrl+V vào Excel / Teams).'
            if self.copy_notice is not None:
                self.copy_notice.set(msg)
            if self.on_copy:
                self.on_copy(msg)
        except Exception as exc:
            if self.copy_notice is not None:self.copy_notice.set('Copy chưa thành công · '+str(exc))
            elif self.on_copy:self.on_copy('Copy chưa thành công · '+str(exc))
            else:
                from tkinter import messagebox
                messagebox.showwarning('Copy bảng',str(exc),parent=self)


class KeyGrid(ResultGrid):
    """A virtual grid with stable business keys independent of display order."""
    def __init__(self,parent,columns,sortable=True):
        super().__init__(parent,columns,toolbar=False)
        self.keys=[]
        self.positions={}
        self.row_tags={}
        self.tag_colors={}
        self.sort_order=(None,False)
        if sortable:self.header.bind('<Button-1>',self.sort_rows)
        self.bind('<Control-A>',self.all)
        self.bind('<Button-4>',lambda _:self.yview_scroll(-1,'units'))
        self.bind('<Button-5>',lambda _:self.yview_scroll(1,'units'))

    def identify_row(self,y):
        i=int(self.canvasy(y)//self.height_px)
        return self.keys[i] if 0<=i<len(self.keys) else None

    def column_at(self,x):
        for j,width in enumerate(self.widths):
            if x<width:return j
            x-=width
        return None

    def identify_column(self,x):
        j=self.column_at(self.canvasx(x))
        return '' if j is None else '#'+str(j+1)

    def identify_region(self,x,y):
        return 'cell' if self.identify_row(y) is not None and self.identify_column(x) else ''

    def selection(self):
        return tuple(self.keys[i-1] for i in sorted(self.chosen))

    def selection_set(self,*keys):
        if len(keys)==1 and isinstance(keys[0],(list,set,tuple)):keys=keys[0]
        super().selection_set({self.positions[k] for k in keys if k in self.positions})
        self.event_generate('<<TreeviewSelect>>')

    def choose(self,event):
        super().choose(event)
        self.event_generate('<<TreeviewSelect>>')

    def all(self,event):
        super().all(event)
        self.event_generate('<<TreeviewSelect>>')
        return 'break'

    def get_children(self):
        return tuple(self.keys)

    def exists(self,key):
        return key in self.positions

    def item(self,key,option):
        if option=="values":return self.rows[self.positions[key]-1]
        raise ValueError(option)

    def set(self,key,column):
        return self.rows[self.positions[key]-1][int(column[1:])-1]

    def tag_configure(self,tag,**colors):
        self.tag_colors[tag]=colors

    def row_colors(self,i,background,foreground):
        if i and i not in self.chosen:
            colors=self.tag_colors.get(self.row_tags.get(self.keys[i-1]),{})
            return colors.get('background',background),colors.get('foreground',foreground)
        return background,foreground

    def append_row(self,values,key=None,tag=None):
        if key is None:key=len(self.keys)+1
        self.keys.append(key)
        self.positions[key]=len(self.keys)
        if tag:self.row_tags[key]=tag
        self.add(values)
        return key

    def clear_rows(self):
        self.keys.clear()
        self.positions.clear()
        self.row_tags.clear()
        self.reset()

    def sync_rows(self,entries):
        # Hold the top row and active cell by key when rows are inserted above them.
        keys=[key for key,values,tag in entries]
        values=[tuple(v) for key,v,tag in entries]
        tags={key:tag for key,v,tag in entries if tag}
        if keys==self.keys:
            bounds=self.visible_range
            old_rows,old_tags=self.rows,self.row_tags
            self.rows,self.row_tags=values,tags
            if bounds:
                for i in range(bounds[0],bounds[1]+1):
                    key=keys[i-1]
                    if values[i-1]!=old_rows[i-1] or tags.get(key)!=old_tags.get(key):
                        self.delete(f'row{i}')
                        self.draw(i,values[i-1])
                self.tag_raise('active')
            return
        selected=self.selection()
        active=(self.keys[self.active[0]-1],self.active[1]) if self.active else None
        top=max(0,int(self.canvasy(0)))
        anchor=self.keys[top//self.height_px] if top//self.height_px<len(self.keys) else None
        self.keys=keys
        self.positions={key:i for i,key in enumerate(keys,1)}
        self.rows=values
        self.row_tags=tags
        self.chosen={self.positions[k] for k in selected if k in self.positions}
        self.active=(self.positions[active[0]],active[1]) if active and active[0] in self.positions else None
        height=max(self.winfo_height(),len(keys)*self.height_px)
        self._region=(0,0,sum(self.widths),height)
        self.configure(scrollregion=self._region)
        if anchor in self.positions:
            self.yview_moveto(((self.positions[anchor]-1)*self.height_px+top%self.height_px)/height)
        self.visible_range=None
        self.draw(0,self.names)
        self.queue_view()

    def sort_rows(self,event):
        import re
        j=self.column_at(self.header.canvasx(event.x))
        if j is None:return
        reverse=self.sort_order==(j,False)
        self.sort_order=j,reverse
        def order(entry):
            return tuple((1,int(p)) if p.isdigit() else (0,p.casefold()) for p in re.split(r'(\d+)',str(entry[1][j])))
        self.sync_rows(sorted(((k,v,self.row_tags.get(k)) for k,v in zip(self.keys,self.rows)),key=lambda e:sort_value(e[1][j]),reverse=reverse))
        self.draw(0,self.names)


def make_filter_bar(parent, status_choices=('Tất cả',), on_change=None, grid=None, style='TFrame', search_label='Tìm nhanh', show_status=True, show_copy=True):
    """Build a uniform quick-search, status-filter, debounced trigger and Copy-table bar."""
    bar=ttk.Frame(parent,style=style)
    query_var=tk.StringVar()
    status_var=tk.StringVar(value=status_choices[0] if status_choices else 'Tất cả')
    job=[None]
    def fire(*_):
        if job[0] is not None:
            parent.after_cancel(job[0])
            job[0]=None
        if on_change:on_change()
    def schedule(*_):
        if job[0] is not None:parent.after_cancel(job[0])
        job[0]=parent.after(90,fire)
    lbl_style='Surface.TLabel' if 'Surface' in style else 'TLabel'
    ttk.Label(bar,text=search_label,style=lbl_style).pack(side='left',padx=(0,4))
    entry=ttk.Entry(bar,textvariable=query_var,width=22)
    entry.pack(side='left',padx=(0,4))
    def clear():
        if query_var.get():
            query_var.set('')
            fire()
        entry.focus_set()
    ttk.Button(bar,text='✕',width=2,command=clear).pack(side='left',padx=(0,8))
    status_box=None
    if show_status:
        ttk.Label(bar,text='Tình trạng',style=lbl_style).pack(side='left',padx=(0,4))
        status_box=ttk.Combobox(bar,textvariable=status_var,values=tuple(status_choices),width=22,state='readonly')
        status_box.pack(side='left',padx=(0,8))
        status_box.bind('<<ComboboxSelected>>',lambda _:fire())
    query_var.trace_add('write',schedule)
    entry.bind('<Escape>',lambda _:clear())
    if grid is not None:
        grid.bind('<Control-f>',lambda _:entry.focus_set() or 'break')
        if show_copy:
            ttk.Button(bar,text='Copy bảng',command=lambda:grid.copy_rows()).pack(side='right')
    return dict(frame=bar,query=query_var,entry=entry,status=status_var,status_box=status_box,fire=fire)
