"""Find existing Office workbooks without binding a file moniker that could open it."""
import os
from contextlib import contextmanager
import threading
from pathlib import Path


def key(path):
    return os.path.normcase(os.path.abspath(os.path.normpath(str(path))))


_locks = {}
_lock_guard = threading.Lock()


@contextmanager
def order_access(path):
    name = key(path)
    with _lock_guard:
        lock, count = _locks.get(name, (threading.RLock(), 0))
        _locks[name] = lock, count+1
    try:
        with lock:
            yield
    finally:
        with _lock_guard:
            count = _locks[name][1]-1
            if count:
                _locks[name] = lock, count
            else:
                del _locks[name]


def same_path(a,b):
    if key(a)==key(b):
        return True
    try:
        return os.path.samefile(a,b)
    except OSError:
        return False


def applications():
    import pythoncom
    import win32com.client as client
    import win32gui
    try:
        yield client.GetActiveObject('Excel.Application')
    except pythoncom.com_error:
        pass
    windows=[]
    def window(hwnd,_):
        try:
            if win32gui.GetClassName(hwnd)=='XLMAIN':
                windows.append(hwnd)
        except Exception:
            pass
        return True
    try:
        win32gui.EnumWindows(window,None)
    except Exception:
        from ctypes import windll, c_void_p
        hwnd=0
        while True:
            hwnd=windll.user32.FindWindowExW(c_void_p(0),c_void_p(hwnd),'XLMAIN',None)
            if not hwnd:
                break
            windows.append(hwnd)
    def child(hwnd,found):
        try:
            if win32gui.GetClassName(hwnd)=='EXCEL7':
                found.append(hwnd)
        except Exception:
            pass
        return True
    for hwnd in windows:
        children=[]
        try:
            win32gui.EnumChildWindows(hwnd,child,children)
        except Exception:
            continue
        for view in children:
            try:
                from ctypes import windll, byref, c_void_p, c_size_t
                answer=c_size_t()
                ok=windll.user32.SendMessageTimeoutW(c_void_p(view),0x003D,0,-16,2,800,byref(answer))
                result=answer.value if ok else 0
                if isinstance(result,tuple):
                    result=result[-1]
                if not result:
                    continue
                dispatch=pythoncom.ObjectFromLresult(result,pythoncom.IID_IDispatch,0)
                app=client.Dispatch(dispatch).Application
            except Exception:
                continue
            yield app
            break


def books(path=None):
    import pythoncom
    import win32com.client as client
    seen=set()
    instances=set()
    for app in applications():
        hwnd=int(app.Hwnd)
        if hwnd in instances:
            continue
        instances.add(hwnd)
        collection=app.Workbooks
        for i in range(1,int(collection.Count)+1):
            try:
                book=collection.Item(i)
                name=str(book.FullName)
            except pythoncom.com_error as exc:
                from zone_shift import bad_index, excel_1004
                if bad_index(exc) or excel_1004(exc):
                    continue
                raise
            if book.Path and (path is None or same_path(name,path)):
                seen.add(key(name))
                yield name,book
    # A registered file moniker can identify a workbook in another Excel instance.
    try:
        rot=pythoncom.GetRunningObjectTable()
        context=pythoncom.CreateBindCtx(0)
        enum=rot.EnumRunning()
    except pythoncom.com_error:
        return
    while True:
        entries=enum.Next(1)
        if not entries:
            break
        moniker=entries[0]
        try:
            name=moniker.GetDisplayName(context,None)
        except pythoncom.com_error:
            continue
        if not os.path.isabs(name) or Path(name).suffix.lower() not in ('.xlsb','.xlsm','.xlsx'):
            continue
        if key(name) in seen or (path is not None and not same_path(name,path)):
            continue
        try:
            obj=rot.GetObject(moniker).QueryInterface(pythoncom.IID_IDispatch)
            book=client.Dispatch(obj)
            fullname=str(book.FullName)
        except (pythoncom.com_error,AttributeError):
            if path is not None:
                raise ValueError('Excel đang bận với file ORDER. Thoát ô đang sửa hoặc hộp thoại rồi tải lại.')
            continue
        if same_path(name,fullname):
            seen.add(key(fullname))
            yield fullname,book


def find(path):
    return next((book for _,book in books(path)),None)


def pivot_options(book):
    """Read the template's model order and active item selections without refreshing Excel."""
    from zone_mail import clean,day,norm
    default=dict(models=[],filters={31:['']},note='Mẫu ORDER · Ca trống')
    try:
        pivot=book.Worksheets('Báo Cáo').PivotTables(1)
        grid=pivot.TableRange1.Value2
        header=next(r for r in grid if any(norm(v)=='khsx' for v in r) and any(norm(v)=='note' for v in r))
        start=next(i for i,v in enumerate(header) if norm(v)=='note')+1
        models=[clean(v).upper() for v in header[start:-1] if clean(v)]
        fields=pivot.PivotFields()
        filters={}
        for i in range(1,int(fields.Count)+1):
            f=fields.Item(i)
            col={'ca':31,'model':9,'khsx':26,'note':27,'tinhtrangcapdon':24}.get(norm(f.SourceName))
            if col is None or not int(f.Orientation):
                continue
            if col==31 and int(f.Orientation)==3 and not f.EnableMultiplePageItems:
                page=f.CurrentPage
                selected=clean(page.Name if hasattr(page,'Name') else page)
                if norm(selected) in ('all','tatca','tous','alle'):
                    continue
                if selected and selected[0]!='<':
                    filters[col]=['' if norm(selected) in ('blank','trong','vide','leer') else selected.casefold()]
                    continue
            if f.AllItemsVisible:
                continue
            visible=[]
            members=f.PivotItems()
            for j in range(1,int(members.Count)+1):
                item=members.Item(j)
                if item.Visible:
                    value=item.Value
                    token=clean(value).casefold()
                    if norm(value) in ('blank','trong','vide','leer'):token=''
                    if col==26 and day(value):token=day(value).isoformat()
                    visible.append(token)
            filters[col]=visible
        return dict(models=models,filters=filters,note='Bộ lọc Pivot · '+('Ca trống' if filters.get(31)==[''] else 'sheet Báo Cáo'))
    except Exception:
        return default


def shared_password(secret=None):
    """Retrieve or update the current Windows user's common ORDER credential."""
    if os.name!='nt':
        return None
    import ctypes as c
    from ctypes import wintypes as w
    class Credential(c.Structure):
        _fields_=[('Flags',w.DWORD),('Type',w.DWORD),('TargetName',w.LPWSTR),('Comment',w.LPWSTR),
                  ('LastWritten',w.FILETIME),('Size',w.DWORD),('Blob',c.c_void_p),('Persist',w.DWORD),
                  ('Count',w.DWORD),('Attributes',c.c_void_p),('Alias',w.LPWSTR),('UserName',w.LPWSTR)]
    dll=c.WinDLL('Advapi32',use_last_error=True)
    target='MA Logistics Flow / ORDER'
    if secret is not None:
        raw=secret.encode('utf-16-le')
        data=c.create_string_buffer(raw)
        record=Credential(Type=1,TargetName=target,Size=len(raw),Blob=c.addressof(data),Persist=2,UserName='ORDER')
        dll.CredWriteW.argtypes=[c.POINTER(Credential),w.DWORD]
        if not dll.CredWriteW(c.byref(record),0):
            raise OSError(c.get_last_error(),'Windows chưa lưu được mật khẩu ORDER')
        return
    ref=c.POINTER(Credential)()
    dll.CredReadW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.POINTER(c.POINTER(Credential))]
    if not dll.CredReadW(target,1,0,c.byref(ref)):
        return None
    try:
        return c.string_at(ref.contents.Blob,ref.contents.Size).decode('utf-16-le')
    finally:
        dll.CredFree.argtypes=[c.c_void_p]
        dll.CredFree(ref)
