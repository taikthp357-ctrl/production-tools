"""Read MB52 once for open ORDER materials and compare unrestricted stock by location."""
from collections import Counter
from datetime import datetime
from decimal import Decimal
import tkinter as tk
from tkinter import ttk
import zone_shift as sh
from zone_result_grid import ResultGrid


def demand(table,day,model,older=True,team='Tất cả'):
    result=[]
    for n,r in sh.rows(table):
        dt=sh.day(r[26])
        if not dt or dt.isoformat()>day or not older and dt.isoformat()!=day:continue
        shifts=[s.strip().upper() for s in sh.clean(r[11]).split('/')]
        if sh.clean(r[9]).upper()!=model or team!='Tất cả' and team not in shifts:continue
        if sh.clean(r[6])!='3093' or sh.state(r) not in ('pending',sh.PART) or sh.norm(r[27]) in ('huy','huydon'):continue
        ordered=Decimal(str(r[4]))
        issued=Decimal(str(r[22] or 0))
        if ordered>issued:
            result.append((n,r,dt,ordered-issued))
    return result


def read_mb52(codes,cfg):
    import zone18 as z
    import zone_inbound as inbound
    with z.lease():
        s=z.get_session(int(cfg['sap_session_idx']),cfg['sap_system'],cfg['sap_client'])
        z.start(s,'MB52')
        inbound.field(s,'WERKS-LOW','3093')
        for field in ('WERKS-HIGH','LGORT-LOW','LGORT-HIGH','MATNR-LOW','MATNR-HIGH','CHARG-LOW','CHARG-HIGH'):
            inbound.field(s,field,'',True)
        if len(codes)==1:inbound.field(s,'MATNR-LOW',codes[0])
        else:z.inline_select(s,'wnd[0]/usr/btn%_MATNR_%_APP_%-VALU_PUSH',codes)
        flat=z.optional(s,'wnd[0]/usr/radPA_FLT')
        if flat is not None:flat.select()
        z.require(s,'wnd[0]/tbar[1]/btn[8]').press()
        z.status(s)
        grid=inbound.result_grid(s)
        fields=('MATNR','WERKS','LGORT','LABST','MEINS')
        rows=inbound.paged_alv(s,grid,fields)
        totals=Counter()
        unknown=set()
        selected=set(codes)
        for row in rows:
            if row['WERKS']=='3093' and row['MATNR'] in selected and row['LGORT']:
                if row['MEINS'].upper()!='EA':
                    raise ValueError('Kiểm tra ĐVT MB52 của '+row['MATNR']+' trước khi so với nhu cầu EA.')
                key=row['MATNR'],row['LGORT']
                if row['LABST']=='':unknown.add(key)
                else:totals[key]+=z.number(row['LABST'],cfg)
        for key in unknown:totals.pop(key,None)
        return totals


def open_stock(page):
    if not page.table or not page.kh.get() or not page.model.get() or page.app.is_running:return
    day,model=page.kh.get(),page.model.get()
    if day=="Cả file ca":
        page.hint.set("Chọn ngày KHSX để tra MB52.");return
    win=tk.Toplevel(page.app.root)
    win.title('Check tồn MB52 · 3093 · '+day+' · '+model)
    win.geometry('1280x540')
    bar=ttk.Frame(win);bar.pack(fill='x')
    older=tk.BooleanVar(value=True);team=tk.StringVar(value='Tất cả');supplier=tk.StringVar(value='Tất cả')
    zero=tk.BooleanVar();hint=tk.StringVar(value='Chọn phạm vi rồi tra MB52.')
    table=page.table
    sources={}
    def fetch():
        if page.table is not table:
            hint.set('ORDER đã đổi. Mở lại Check tồn.');return
        codes=sorted({sh.clean(r[3]).upper() for _,r,_,_ in demand(table,day,model,older.get(),team.get())})
        if not codes:
            hint.set('Không có nhu cầu đang mở trong phạm vi đã chọn.')
            return
        sources.clear()
        hint.set('Đang tra MB52…')
        paint()
        def failed(error):
            if win.winfo_exists():hint.set('Chưa xác minh tồn · '+error)
            return False
        def ready(totals):
            if not win.winfo_exists():return
            sources.clear();sources.update(totals)
            hint.set('MB52 · Plant 3093 · '+datetime.now().strftime('%H:%M:%S'))
            paint()
        page.task('Đang đọc MB52…',lambda:read_mb52(codes,page.app.config),ready,failed)
    ttk.Button(bar,text='Tra MB52',command=fetch).pack(side='left')
    ttk.Checkbutton(bar,text='Gồm thiếu từ KHSX trước',variable=older,command=lambda:paint()).pack(side='left')
    for label,var,values in [('Ca chạy',team,['Tất cả','S1','S2','S3','S6','S7']),('NCC',supplier,['Tất cả'])]:
        ttk.Label(bar,text=label).pack(side='left')
        box=ttk.Combobox(bar,textvariable=var,values=values,state='readonly',width=18)
        box.pack(side='left');box.bind('<<ComboboxSelected>>',lambda e:paint())
    quick=tk.StringVar()
    ttk.Label(bar,text='Tìm nhanh').pack(side='left',padx=(6,2))
    q_entry=ttk.Entry(bar,textvariable=quick,width=16)
    q_entry.pack(side='left')
    ttk.Checkbutton(bar,text='Chỉ hết tồn kho',variable=zero,command=lambda:paint()).pack(side='left')
    grid=ResultGrid(win,[('KHSX',90),('Model',65),('Ca chạy',70),('NCC',165),('Mã NVL',135),('US',50),('Trạm',130),
                         ('SL OD',80),('Đã cấp',80),('DOH',54),('Tồn line',80),('Tồn kho',80),('Tình trạng',240)],False)
    grid.enable_sort()
    grid.on_copy=lambda msg:hint.set(msg)
    ttk.Button(bar,text='Copy bảng đang lọc',command=lambda:grid.copy_rows(all_rows=True)).pack(side='right')
    ttk.Label(win,textvariable=hint).pack(anchor='w')
    grid_job=[None]
    quick.trace_add('write',lambda *_:grid_job[0] and win.after_cancel(grid_job[0]) or grid_job.__setitem__(0,win.after(90,paint)))
    grid.bind('<Control-f>',lambda _:q_entry.focus_set() or 'break')
    def paint():
        grid_job[0]=None
        rows=demand(table,day,model,older.get(),team.get())
        box.configure(values=['Tất cả',*sorted({sh.clean(r[0]) for _,r,_,_ in rows if r[0]})])
        needs=Counter()
        for _,r,_,gap in rows:needs[sh.clean(r[3]).upper(),sh.clean(r[7])]+=gap
        grid.reset()
        q_norm=sh.norm(quick.get())
        for _,r,dt,gap in sorted(rows,key=lambda x:(x[2],sh.clean(x[1][0]),x[0])):
            code,loc,line=sh.clean(r[3]).upper(),sh.clean(r[7]),sh.clean(r[8])
            stock=sources.get((code,loc));on_line=sources.get((code,line))
            if supplier.get() not in ('Tất cả',sh.clean(r[0])) or zero.get() and stock!=0:continue
            state='Chưa xác minh tồn' if stock is None else 'Hết tồn kho' if stock==0 else 'Có tồn, chưa đủ cấp' if stock<needs[code,loc] else 'Đã có tồn lại' if sh.norm(r[27])=='hettonkhoma' else 'Đủ tồn kho'
            waiting=sh.pending_order(r)
            vals=(dt,model,r[11],sh.clean(r[0]),code,'',r[5],sh.clean(r[4]),sh.clean(r[22]),'','' if on_line is None else on_line,'' if stock is None else stock,state+(' · '+waiting if waiting else ''))
            if q_norm and q_norm not in sh.norm(' '.join(map(str,vals))):continue
            grid.add(vals,warning=stock==0)
        if grid.sort_order[0] is not None:
            grid.sort_by_column(*grid.sort_order,None)
    paint()
