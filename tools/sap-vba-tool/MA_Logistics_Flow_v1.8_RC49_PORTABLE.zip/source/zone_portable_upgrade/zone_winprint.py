"""Handle the native Windows dialogs for a single SAP PDF print job."""
from pathlib import Path
import os
import threading
import time

PRINTER = "Microsoft Print to PDF"
PRINT_TITLES = {"print","in"}
SAVE_TITLES = {"save print output as","lưu bản in dưới dạng","lưu đầu ra in dưới dạng"}
IDOK, IDCANCEL = 1,2
PRINT_ALL_ID, PRINT_COPIES_ID = 0x420,0x482
SAVE_FILENAME_IDS = {0x480,1001}
WM_COMMAND, WM_GETTEXT, WM_SETTEXT = 0x111,0x000D,0x000C
CB_FINDSTRINGEXACT, CB_SETCURSEL, CB_GETCURSEL, CBN_SELCHANGE = 0x158,0x14E,0x147,1
BM_GETCHECK = 0xF0


class WindowsPrintError(RuntimeError):
    pass


class NativePDFPrinter:
    def __init__(self,anchors):
        if os.name!="nt":
            raise WindowsPrintError("Tạo PDF từ SAP cần Windows và Microsoft Print to PDF.")
        import win32gui
        import win32print
        self.gui=win32gui
        self.anchors=tuple(handle for handle in anchors if handle and win32gui.IsWindow(handle))
        if not self.anchors:
            raise WindowsPrintError("Không xác định được cửa sổ SAP.")
        printer=win32print.OpenPrinter(PRINTER)
        try:
            info=win32print.GetPrinter(printer,2)
            if str(info.get("pDriverName","")).casefold()!=PRINTER.casefold():
                raise WindowsPrintError("Driver máy in PDF không khớp Microsoft Print to PDF.")
            if str(info.get("pPortName","")).upper()!="PORTPROMPT:":
                raise WindowsPrintError("Máy in PDF cần cổng PORTPROMPT để nhận đường dẫn lưu.")
        finally:
            win32print.ClosePrinter(printer)
        if win32print.GetDefaultPrinter().casefold()!=PRINTER.casefold():
            raise WindowsPrintError("Đặt Microsoft Print to PDF làm máy in mặc định của Windows trước khi tạo phiếu PDF.")
        self.prior=set(self.windows())

    def owned_by_sap(self,window):
        # Match the SAP owner chain, including a driver dialog owned by the print dialog.
        seen=set()
        while window and window not in seen:
            if window in self.anchors:
                return True
            seen.add(window)
            window=self.gui.GetWindow(window,4)  # GW_OWNER
        return False

    def windows(self):
        found=[]
        def collect(hwnd,_):
            if (self.gui.IsWindowVisible(hwnd) and self.gui.GetClassName(hwnd)=="#32770"
                    and self.owned_by_sap(hwnd)):
                found.append(hwnd)
            return True
        self.gui.EnumWindows(collect,None)
        return found

    def controls(self,window,kind):
        found=[]
        def collect(hwnd,_):
            if self.gui.GetClassName(hwnd)==kind and self.gui.IsWindowVisible(hwnd) and self.gui.IsWindowEnabled(hwnd):
                found.append(hwnd)
            return True
        self.gui.EnumChildWindows(window,collect,None)
        return found

    def message(self,hwnd,message,wparam=0,lparam=0):
        if not isinstance(lparam,int):
            self.gui.SendMessageTimeout(hwnd,0,0,0,2,2500)
            return self.gui.SendMessage(hwnd,message,wparam,lparam)
        _,value=self.gui.SendMessageTimeout(hwnd,message,wparam,lparam,2,2500)
        return value

    def text(self,hwnd):
        buffer=self.gui.PyMakeBuffer(2048*2)
        count=self.message(hwnd,WM_GETTEXT,2048,buffer)
        return bytes(buffer)[:count*2].decode("utf-16-le")

    def command(self,dialog,control_id):
        button=self.gui.GetDlgItem(dialog,control_id)
        if not button or not self.gui.IsWindowEnabled(button):
            raise WindowsPrintError("Không thấy nút xác nhận trên hộp thoại Windows.")
        self.gui.PostMessage(dialog,WM_COMMAND,control_id,button)

    def select_printer(self,dialog):
        matches=[]
        for combo in self.controls(dialog,"ComboBox"):
            index=self.message(combo,CB_FINDSTRINGEXACT,-1,PRINTER)
            if 0<=index<10000:
                matches.append((combo,index))
        if len(matches)!=1:
            raise WindowsPrintError("Không tìm thấy duy nhất Microsoft Print to PDF trong hộp in.")
        combo,index=matches[0]
        if self.message(combo,CB_GETCURSEL)!=index:
            self.message(combo,CB_SETCURSEL,index)
            self.message(self.gui.GetParent(combo),WM_COMMAND,
                         self.gui.GetDlgCtrlID(combo) | (CBN_SELCHANGE << 16),combo)
        if self.text(combo).strip().casefold()!=PRINTER.casefold():
            raise WindowsPrintError("Chưa xác minh được máy in PDF đã được chọn.")
        all_pages=self.gui.GetDlgItem(dialog,PRINT_ALL_ID)
        if not all_pages or self.message(all_pages,BM_GETCHECK)!=1:
            raise WindowsPrintError("Hộp in Windows cần chọn phạm vi All.")
        copies=self.gui.GetDlgItem(dialog,PRINT_COPIES_ID)
        if not copies:
            raise WindowsPrintError("Không xác minh được số bản trong hộp thoại Windows.")
        if self.text(copies).strip()!="1":
            if self.gui.IsWindowEnabled(copies):
                self.message(copies,WM_SETTEXT,0,"1")
            if self.text(copies).strip()!="1":
                raise WindowsPrintError("Hộp in Windows cần đúng một bản gốc để tạo PDF.")
        self.command(dialog,IDOK)

    def save_output(self,dialog,path):
        edits=[hwnd for hwnd in self.controls(dialog,"Edit") if self.gui.GetDlgCtrlID(hwnd) in SAVE_FILENAME_IDS]
        if len(edits)!=1:
            raise WindowsPrintError("Không nhận diện được ô tên file của hộp lưu PDF Windows.")
        self.message(edits[0],WM_SETTEXT,0,str(path))
        if self.text(edits[0])!=str(path):
            raise WindowsPrintError("Chưa xác minh được đường dẫn trong hộp lưu PDF Windows.")
        self.command(dialog,IDOK)

    def wait_dialog(self,titles,ignore,stop):
        deadline=time.monotonic()+20
        while not stop.is_set() and time.monotonic()<deadline:
            matches=[hwnd for hwnd in self.windows() if hwnd not in ignore
                     and self.gui.GetWindowText(hwnd).strip().casefold() in titles]
            if len(matches)>1:
                raise WindowsPrintError("Có nhiều hộp thoại in của SAP. Không xác định được tác vụ hiện tại.")
            if matches:
                return matches[0]
            stop.wait(.15)
        raise WindowsPrintError("Không nhận diện được hộp thoại in hoặc lưu PDF của phiên SAP.")

    def capture(self,trigger,path,*,stage=None):
        path=Path(path).resolve()
        report=stage or (lambda _name:None)
        stop=threading.Event()
        errors=[]
        def handle_dialogs():
            dialog=None
            try:
                dialog=self.wait_dialog(PRINT_TITLES|SAVE_TITLES,self.prior,stop)
                if self.gui.GetWindowText(dialog).strip().casefold() in PRINT_TITLES:
                    report("Xác nhận máy in PDF trong hộp thoại Windows")
                    self.select_printer(dialog)
                    dialog=self.wait_dialog(SAVE_TITLES,self.prior-{dialog},stop)
                report("Điền đường dẫn lưu PDF")
                self.save_output(dialog,path)
            except Exception as exc:
                errors.append(exc)
                if dialog and self.gui.IsWindow(dialog) and self.owned_by_sap(dialog):
                    try:
                        self.command(dialog,IDCANCEL)
                    except Exception:
                        pass
        worker=threading.Thread(target=handle_dialogs,daemon=True)
        worker.start()
        try:
            trigger()
        except Exception:
            stop.set()
            worker.join(3)
            raise
        worker.join(45)
        if worker.is_alive():
            stop.set()
            raise WindowsPrintError("Quá thời gian xác nhận hộp thoại PDF Windows.")
        if errors:
            raise errors[0]
