"""Pivot, end-of-shift summary and transactional Excel append."""
from collections import Counter, defaultdict
from datetime import date
from itertools import groupby

import zone_shift as sh

STATUS={'done':'Done',sh.PART:'Partial finished','pending':'Pending'}
TITLES=('Tình trạng cấp NVL','Kết quả cấp NVL')


def opening(row,header,old,identity=None):
    marked=(len(row)>33 and any(tok in sh.norm(row[33]) for tok in ('tapketcatruoc','hangtapket'))) or sh.norm(row[27]) in ('tapketcatruoc','hangtapketcatruoc')
    if old is not None:
        return float(old[22] or 0), marked or sh.gathered(old[27])
    if tuple(header[32:34])==(sh.BASE_QTY,sh.BASE_NOTE) and isinstance(row[32],(float,int)):
        return float(row[32]),marked
    if marked:return None,True
    if identity:
        from zone_mail import order_stamp,receiving_shift
        stamp=order_stamp(row[28],row[29])
        if stamp and receiving_shift(stamp,{'_team_system':identity[1]})==identity:return 0,False
    return None,None


def report_state(row):
    state=sh.state(row)
    if not sh.packing(row[2])[0] and state in STATUS:
        return state
    try:
        ordered=float(row[4])
        issued=float(row[22] or 0)
    except (ValueError,TypeError):
        return state if state in STATUS else 'pending'
    if issued<=0 or ordered<=0:return 'pending'
    return 'done' if issued>=ordered else sh.PART


def note_order(note):
    stages = ('chuaradon', 'daradonchocap', 'hettonkhoma', 'radoncaplai', 'hangtapket')
    key = sh.norm(note)
    return (stages.index(key) if key in stages else len(stages), key)


def report_note(row):
    note=sh.clean(row[27])
    if sh.norm(note)=='chocap':return 'Đã ra đơn, chờ cấp'
    if sh.packing(row[2])[0] and sh.norm(note) in ('','chuaradon','captheogio','hangthungcaptheogiogoi','hangthungtheogiogoi','goitheogio'):
        return 'Đã ra đơn, chờ cấp' if sh.pending_order(row) else ('Chưa ra đơn' if sh.norm(note)=='chuaradon' else 'Đã ra đơn, chờ cấp')
    return note or '(Trống)'


def scoped_models(table,first,last):
    models=set()
    for _,r in sh.rows(table):
        dt=sh.day(r[26])
        if (first or last) and (not dt or first and dt.isoformat()<first or last and dt.isoformat()>last):continue
        models.add(sh.clean(r[9]).upper() or 'Thiếu model')
    return sorted(models)


def prior_rows(table,baseline):
    if not baseline:return {}
    exact={k:r for _,r,k in sh.indexed(baseline)}
    def signature(r):
        return (sh.norm(r[3]),sh.clean(r[4]),sh.norm(r[5]),sh.norm(r[9]),sh.day(r[26]))
    old=defaultdict(list)
    counts=Counter()
    for _,r in sh.rows(baseline):old[signature(r)].append(r)
    for _,r in sh.rows(table):counts[signature(r)]+=1
    for _,r,k in sh.indexed(table):
        sig=signature(r)
        if k not in exact and counts[sig]==1 and len(old[sig])==1 and sig[-1] and all(sig[:-1]):
            candidate=old[sig][0]
            # A changed order date/time or issuer identifies a different request.
            if all(not sh.clean(r[i]) or not sh.clean(candidate[i]) or sh.clean(r[i])==sh.clean(candidate[i]) for i in (6,7,8,28,29,30)):
                exact[k]=candidate
    # When handover metadata changed, an identical allocated OB and slip
    # can disambiguate a carried material from other orders in the same area.
    def allocation(r):
        return (sh.norm(r[3]),sh.clean(r[4]),sh.norm(r[5]),sh.norm(r[9]),sh.day(r[26]),
                tuple((sh.clean(r[i]),sh.clean(r[i+1])) for i in (13,16,19) if sh.clean(r[i]) and sh.clean(r[i+1])))
    by_order=defaultdict(list)
    for _,r in sh.rows(baseline):
        sig=allocation(r)
        if all(sig):by_order[sig].append(r)
    frequency=Counter(allocation(r) for _,r in sh.rows(table))
    for _,r,k in sh.indexed(table):
        if k in exact:continue
        sig=allocation(r)
        if frequency[sig]==1 and len(by_order.get(sig,()))==1:exact[k]=by_order[sig][0]
    return exact

def pivot(table,full=False,all_rows=False,options=None,first='',last='',baseline=None,identity=None,include_gather=True):
    indexed=defaultdict(list)
    by_state=defaultdict(list)
    options=options or {}
    filters={col:set(values) for col,values in options.get('filters',{31:['']}).items()}
    order=options.get('models',[])
    models=set()
    prior=prior_rows(table,baseline)
    pending_since=options.get('pending_since','')
    for n,r,key in sh.indexed(table):
        state=STATUS.get(sh.state(r))
        if state is None:
            continue
        note=report_note(r)
        carried=False
        if identity and state=='Pending' and sh.gathered(r[27]):
            carried=bool(opening(r,table[0],prior.get(key),identity)[1])
            if carried:
                note='Hàng tập kết'
        def token(col):
            if col==26 and sh.day(r[col]):return sh.day(r[col]).isoformat()
            return sh.clean(r[col]).casefold()
        is_prior_partial=(state=='Partial finished' and sh.clean(r[31])=='1')
        completed_prior_partial=(state=='Done' and sh.clean(r[31])=='1' and (len(r)<=33 or sh.CARRIED_DONE not in sh.clean(r[33])))
        if any(token(col) not in selected for col,selected in filters.items()
               if not (col==31 and (is_prior_partial or completed_prior_partial))):
            continue
        if is_prior_partial and not all_rows:
            start,_=opening(r,table[0],prior.get(key),identity)
            try:issued_val=float(r[22] or 0)
            except (TypeError,ValueError):issued_val=None
            if not (start is not None and issued_val is not None and issued_val>start):
                continue
        model=sh.clean(r[9]).upper() or 'Thiếu model'
        kh=sh.day(r[26])
        dt=kh.isoformat() if kh else ''
        if (first or last) and (not dt or first and dt<first or last and dt>last):
            continue
        rec=(n,r,model)
        by_state[state].append(rec)
        models.add(model)
        hide_detail=(
            (carried and not include_gather)
            or (state=='Pending' and bool(pending_since) and bool(dt) and dt<pending_since)
        )
        if not hide_detail:
            key=(state,dt or 'Thiếu KHSX',note)
            indexed[key].append(rec)
    allowed=set(scoped_models(table,first,last))
    models=[m for m in dict.fromkeys(order) if m in allowed]+sorted(models-set(order))
    result=[]
    def add(status,dt,note,records,tag):
        counts=Counter(m for _,_,m in records)
        result.append(((status,dt,note,*[counts[m] or '' for m in models],len(records)),tag,records))
    for status in STATUS.values():
        total_records=sorted(by_state[status],key=lambda rec:(sh.day(rec[1][26]).isoformat() if sh.day(rec[1][26]) else 'Thiếu KHSX',note_order(report_note(rec[1])),rec[0]))
        if not total_records:
            if status in ('Done','Partial finished'):
                add(status,'','Tổng '+status,[],'state')
            continue
        group=sorted((k for k in indexed if k[0]==status), key=lambda k:(k[1],note_order(k[2])))
        if (full or status=='Pending' or (all_rows and status=='Partial finished')) and group:
            for dt,items in groupby(group,key=lambda k:k[1]):
                daily=[]
                for i,k in enumerate(items):
                    add(status if k==group[0] else '',dt if i==0 else '',k[2],indexed[k],
                        'gathered' if sh.norm(k[2])=='hangtapket' else 'detail')
                    daily.extend(indexed[k])
                add('',dt,'Tổng ngày',daily,'date')
        add(status,'','Tổng '+status,total_records,'state')
    all_records=[r for st in STATUS.values() for r in by_state[st]]
    add('Tổng cộng','','',all_records,'total')
    return models,result


def daily(table,first='',last='',baseline=None,identity=None):
    have=tuple(table[0][32:34])==(sh.BASE_QTY,sh.BASE_NOTE)
    prior=prior_rows(table,baseline)
    out={}
    materials=defaultdict(dict)
    for n,r,key in sh.indexed(table):
        when=sh.day(r[26])
        if not when:
            continue
        dt=when.isoformat()
        if first and dt<first or last and dt>last:
            continue
        model=sh.clean(r[9]).upper() or '(Trống)'
        status=report_state(r)
        note=sh.norm(r[27])
        old=prior.get(key)
        marker=sh.clean(r[31])=='1'
        material=sh.clean(r[3]).upper()
        summary=materials[dt,model].setdefault(material,dict(complete=True,supply=False,gather=False))
        summary['complete'] &= status=='done'
        start,was_gathered=opening(r,table[0],old,identity)
        known=start is not None
        supplied=known and float(r[22] or 0)>start and status in ('done',sh.PART)
        carried_done=marker and status=='done' and sh.CARRIED_DONE in sh.clean(r[33])
        summary['supply'] |= supplied and not carried_done
        summary['gather'] |= status=='pending' and sh.gathered(r[27]) and was_gathered is False
        group=out.setdefault((dt,model),dict(count=Counter(),shifts=set(),cartons={},known=True))
        c=group['count']
        if status=='pending' and sh.gathered(r[27]) and was_gathered is None:group['known']=False
        if status in ('done',sh.PART) and not known:c['unknown_supply']+=1
        c['order']+=1
        group['shifts'].update(v.strip().upper() for v in sh.clean(r[11]).split('/') if v.strip())
        boxed,_=sh.packing(r[2])
        if boxed:
            material=sh.clean(r[3]).upper()
            group['cartons'].setdefault(material,[]).append((n,sh.clean(r[2]),sh.clean(r[24]),sh.clean(r[27])))
        if status=='done':
            bucket='done'
        elif status==sh.PART:
            bucket='partial'
        elif sh.gathered(r[27]):
            bucket='gathered'
        elif note=='hettonkhoma':
            bucket='empty'
        else:
            bucket='pending'
        c[bucket]+=1
    for key,group in out.items():
        states={}
        for material,v in materials[key].items():
            if v['supply']:
                states[material]='new_done' if v['complete'] else 'new_partial'
            elif v['gather']:
                states[material]='new_gathered'
        group['count'].update(states.values())
        group['states']=states
    return out


def shift_rank(team):
    return sh.TEAMS.index(team) if team in sh.TEAMS else len(sh.TEAMS)


def report_row_order(item):
    dt,model,teams,_,_=item
    ranks=tuple(shift_rank(team) for team in teams.split('/'))
    return dt,ranks,teams,model


def snapshot(groups,overrides):
    items=[]
    for key,g in groups.items():
        c=g['count'].copy()
        gather,comment=overrides.get(key,(c['new_gathered'] if g['known'] or not c['gathered'] else None,''))
        if gather is not None and not 0<=gather<=c['gathered']:
            raise ValueError('Số tập kết ngoài phạm vi ORDER tại '+' · '.join(key))
        c['new_gathered']=gather
        c.material_states=g.get('states',{})
        items.append((key[0],key[1],'/'.join(sorted(g['shifts'],key=lambda team:(shift_rank(team),team))),c,comment))
    return sorted(items,key=report_row_order)


def shift_result_total(items):
    states=defaultdict(set)
    adjustments=0
    unknown=False
    for _,_,_,c,_ in items:
        counted=getattr(c,'material_states',{})
        for material,state in counted.items():
            states[material].add(state)
        if c['new_gathered'] is None:
            unknown=True
        else:
            adjustments+=c['new_gathered']-sum(v=='new_gathered' for v in counted.values())
    totals=Counter(unknown_supply=sum(c['unknown_supply'] for _,_,_,c,_ in items))
    for group in states.values():
        state=next(s for s in ('new_partial','new_done','new_gathered') if s in group)
        totals[state]+=1
    totals['new_gathered']=None if unknown else max(0,totals['new_gathered']+adjustments)
    return totals


def serial(dt):
    return (dt-date(1899,12,30)).days


def archive_info(sheet,index,workday,team,leader):
    line=4 if index==0 else 5
    expected={2:'ngay',3:'ca',4:'tl',**({7:'khsx',8:'xe',10:'order',11:'hoanthanh',14:'tapket'} if index==0 else {6:'khsx',7:'xe',9:'hoanthanh',10:'1phan',12:'tong'})}
    for col,value in expected.items():
        if sh.norm(sheet.Cells(line,col).Value2)!=value:
            raise ValueError('Sai mẫu tại '+sheet.Name+f' · cột {col}.')
    # Include Total/formulas and any manually entered notes, even with empty B.
    size=25 if index==0 else 16
    end=max(int(sheet.Cells(sheet.Rows.Count,k).End(-4162).Row) for k in range(1,size+1))
    if end>=line+2:
        keys=sheet.Range(f'B{line+2}:D{end}').Value2
        if any(sh.day(d)==workday and sh.norm(t)==sh.norm(team) and sh.norm(l)==sh.norm(leader) for d,t,l in keys):
            raise ValueError(f'{sheet.Name} đã có ngày {workday:%d/%m/%Y}, ca {team}, TL {leader}.')
    return end+1


def archive(path,workday,team,leader,items):
    if not items or not leader.strip():
        raise ValueError('Chọn phạm vi KHSX và nhập TL trước khi lưu.')
    if any(row[3]['unknown_supply'] for row in items):
        raise ValueError('Chọn file bàn giao để xác minh sản lượng cấp một phần trong ca.')
    if any(row[3]['new_gathered'] is None for row in items):
        raise ValueError('Còn số tập kết ca chưa xác minh. Chọn mốc đầu ca hoặc bấm đúp để nhập số đã đối chiếu.')
    with sh.excel_book(path,'',True) as book:
        sheets=[book.Worksheets(name) for name in TITLES]
        starts=[archive_info(s,i,workday,team,leader) for i,s in enumerate(sheets)]
        bounds=[]
        for i,(sheet,start) in enumerate(zip(sheets,starts)):
            subset=items if i==0 else [r for r in items if r[4] or sum(r[3][k] for k in ('new_done','new_partial','new_gathered'))]
            if not subset:
                # A zero-production shift still carries a searchable shift key and a total.
                subset=[(items[0][0],'—','',Counter(),'Chưa phát sinh sản lượng')]
            stop=start+len(subset)
            bounds.append((start,stop))
            left,right=('G','V') if i==0 else ('F','M')
            sheet.Range(f'B{start}:D{stop}').NumberFormat='@'
            sheet.Range(f'B{start}:B{stop}').NumberFormat='dd-mmm-yy'
            sheet.Range(f'{left}{start}:{left}{stop-1}').NumberFormat='dd-mmm'
            sheet.Range(f'{left}{start}:{right}{stop}').Borders.LineStyle=1
            sheet.Range(f'{left}{start}:{right}{stop}').HorizontalAlignment=-4108
            for offset,(dt,model,ca,c,note) in enumerate(subset):
                n=start+offset
                sheet.Range(f'B{n}:D{n}').Value2=((serial(workday),team,leader),)
                d=serial(date.fromisoformat(dt))
                if i==0:
                    sheet.Range(f'E{n}').NumberFormat='dd-mmm'
                    sheet.Range(f'E{n}').Value2=d
                    sheet.Range(f'G{n}:P{n}').Value2=((d,model,ca,*[c[k] for k in ('order','done','partial','pending','gathered','hourly','empty')]),)
                else:
                    sheet.Range(f'F{n}:K{n}').Value2=((d,model,ca,c['new_done'],c['new_partial'],c['new_gathered']),)
                    sheet.Range(f'L{n}').Formula=f'=SUM(I{n}:K{n})'
                if note:
                    cell=sheet.Range(f'{right}{n}')
                    cell.NumberFormat='@'
                    cell.Value2=note
            # Show each KHSX once per group; the metadata column E carries every date on the status sheet.
            pos=start
            for dt,group in groupby(subset,key=lambda row:row[0]):
                count=sum(1 for _ in group)
                if count>1:
                    sheet.Range(f'{left}{pos+1}:{left}{pos+count-1}').ClearContents()
                    sheet.Range(f'{left}{pos}:{left}{pos+count-1}').Merge()
                pos+=count
            sheet.Range(f'{left}{stop}').Value2='Total'
            for col in ('JKLMNOP' if i==0 else 'IJKL'):
                sheet.Range(f'{col}{stop}').Formula=f'=SUM({col}{start}:{col}{stop-1})'
            if i==1:
                counts=shift_result_total(items)
                nums=tuple(counts[k] for k in ('new_done','new_partial','new_gathered'))
                sheet.Range(f'I{stop}:L{stop}').Value2=((*nums,sum(nums)),)
            if i==0:
                for n in range(start,stop+1):
                    sheet.Range(f'Q{n}:U{n}').Formula=((f'=IFERROR((K{n}+L{n})/J{n},0)',f'=IFERROR(N{n}/J{n},0)',
                        f'=IFERROR(P{n}/J{n},0)',f'=IFERROR(O{n}/J{n},0)',f'=IFERROR((J{n}-M{n})/J{n},0)'),)
                sheet.Range(f'Q{start}:U{stop}').NumberFormat='0%'
            total=sheet.Range(f'{left}{stop}:{right}{stop}')
            total.Font.Bold=True
            total.Interior.Color=0xB3DAC6
            sheet.Range('G2' if i==0 else 'F4').Value2=f'{TITLES[i].upper()}  ·  {team}  {leader}  {workday:%d.%m.%Y}'
            sheet.Calculate()
            expected=sum(r[3]['order'] if i==0 else sum(r[3][k] for k in ('new_done','new_partial','new_gathered')) for r in subset)
            if i==1:expected=sum(nums)
            if sheet.Range(f'{"J" if i==0 else "L"}{stop}').Value2!=expected:
                raise ValueError('Tổng sau ghi khác bảng xem trước. Hủy lưu.')
        book.Save()
    return bounds


def overview(records):
    """Count source ORDER rows once, keeping drill-down records for each chart."""
    data={name:[] for name in STATUS.values()}
    models=defaultdict(list)
    notes=defaultdict(list)
    labels={}
    for record in records:
        _,row,model=record
        state=STATUS[sh.state(row)]
        data[state].append(record)
        if state=='Pending':
            models[model].append(record)
            label=report_note(row)
            token=sh.norm(label)
            labels.setdefault(token,label)
            notes[token].append(record)
    def ranked(entries):
        return sorted(entries,key=lambda pair:(-len(pair[1]),pair[0].casefold()))
    data.update(all=records,models=ranked(models.items()),notes=ranked((labels[k],v) for k,v in notes.items()))
    return data


def waterfall(records):
    days=defaultdict(list)
    shifts=defaultdict(lambda:defaultdict(list))
    for record in records:
        row=record[1]
        day=sh.day(row[26])
        group=day.isoformat() if day else 'Thiếu KHSX'
        team=sh.clean(row[11]).upper() or 'Thiếu ca chạy'
        days[group].append(record)
        shifts[group][team].append(record)
    def buckets(rows):
        groups=[[],[],[],[],[]]
        for record in rows:
            row=record[1]
            state=sh.state(row)
            if state=='done':index=0
            elif state==sh.PART:index=1
            elif state!='pending':index=2
            elif sh.packing(row[2])[0]:index=3
            else:index=4
            groups[index].append(record)
        return [rows,*groups]
    result=[]
    for day in sorted(days):
        result.append((day,'Tổng ngày',buckets(days[day])))
        for shift,rows in sorted(shifts[day].items()):
            result.append((day,shift,buckets(rows)))
    return result
