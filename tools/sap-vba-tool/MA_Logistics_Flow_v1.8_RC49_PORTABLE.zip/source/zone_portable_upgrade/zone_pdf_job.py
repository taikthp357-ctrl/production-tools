"""Run the Windows print and preview operations outside the main app."""
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import subprocess
import sys
import time
import traceback

JOB_FLAG = "--maflow-pdf-job"
STEP_TIMEOUT = 125
START_TIMEOUT = 40


class PrintJobError(RuntimeError):
    pass


def start_worker(folder, log):
    if not getattr(sys, "frozen", False):
        raise PrintJobError("Tiến trình in cần chạy từ MA Logistics Flow Portable.")
    # Reuse the active one-file application's extracted runtime.
    env = dict(os.environ)
    env.pop("PYINSTALLER_RESET_ENVIRONMENT", None)
    with log.open("ab") as stream:
        return subprocess.Popen(
            [sys.executable, JOB_FLAG, str(folder), str(log)],
            stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=env,
        )


def run_job(base, request, *, target=None, progress=None):
    """Monitor a child before publishing a successfully generated PDF."""
    logs = Path(base).resolve() / "data" / "pdf_logs"
    logs.mkdir(parents=True, exist_ok=True)
    log = logs / f"PDF_{datetime.now():%Y%m%d_%H%M%S_%f}_{os.getpid()}.log"
    log.touch(exist_ok=False)
    try:
        target = Path(target).resolve() if target is not None else None
        if target is not None:
            target.parent.mkdir(parents=True, exist_ok=True)
        root = target.parent if target is not None else logs
        with TemporaryDirectory(prefix="maflow_job_", dir=root, ignore_cleanup_errors=True) as temp:
            folder = Path(temp)
            (folder / "request.json").write_text(json.dumps(request, ensure_ascii=False), encoding="utf-8")
            result = supervise(folder, log, progress)
            if target is not None:
                staged = folder / "result.pdf"
                if not staged.is_file() or not staged.stat().st_size or result.get("pages", 0) < 1:
                    raise PrintJobError("Tiến trình in chưa trả về PDF hoàn chỉnh.")
                if target.exists():
                    raise PrintJobError("File PDF đích đã tồn tại.")
                staged.rename(target)
            return result
    except Exception as exc:
        with log.open("a", encoding="utf-8") as stream:
            print(f"{datetime.now():%H:%M:%S}  Điều phối: {exc}", file=stream)
        raise PrintJobError(f"{exc}\nNhật ký: {log}") from exc


def supervise(folder, log, progress):
    stage = "Khởi động tiến trình"
    proc = start_worker(folder, log)
    deadline = time.monotonic() + START_TIMEOUT
    try:
        with log.open("rb") as stream:
            while True:
                code = proc.poll()
                line = stream.readline()
                while line.endswith(b"\n"):
                    if line.startswith(b"MAFLOW_STAGE\t"):
                        event = json.loads(line.decode("utf-8").split("\t", 1)[1])
                        stage = event["stage"]
                        deadline = None if stage == "Chờ người dùng lưu PDF gốc tại Windows" else time.monotonic() + STEP_TIMEOUT
                        if progress:
                            progress(event)
                    line = stream.readline()
                if line:
                    stream.seek(-len(line), 1)
                if code is not None:
                    break
                if deadline is not None and time.monotonic() >= deadline:
                    raise PrintJobError(f"Quá thời gian chờ ở bước {stage}. Kiểm tra hộp thoại còn mở trong SAP hoặc Windows.")
                time.sleep(.15)
        status = folder / "result.json"
        if status.is_file() and code in (0, 1):
            result = json.loads(status.read_text(encoding="utf-8"))
            if not result.get("ok"):
                raise PrintJobError(f"{stage}: {result['error']}")
            if code == 0:
                return result
        raise PrintJobError(f"Tiến trình PDF đã thoát ở bước {stage} (mã 0x{code & 0xffffffff:08X}).")
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)


def sap_pdf(request, folder, stage):
    stage("Nạp SAP GUI")
    import sap_zone_core as core
    import zone18 as z
    orders = request["orders"]
    with z.lease():
        stage("Kết nối SAP")
        core.SapConnector.init_thread_com()
        try:
            session = z.get_session(request["session_idx"], request["system"], request["client"])
            expected = request.get("session_identity")
            if expected and list(z.identity(session)) != expected:
                raise PrintJobError("Phiên SAP hiện tại đã thay đổi. Tra lại MON trước khi in.")
            return z.print_whos(session, orders, request["warehouse"], request["copies"], stage=stage)
        finally:
            core.SapConnector.uninit_thread_com()


def worker(folder, log):
    """Frozen EXE entry point. The UI and this worker have independent processes."""
    folder = Path(folder)
    with open(log, "a", encoding="utf-8", buffering=1) as stream:
        sys.stdout = sys.stderr = stream
        import faulthandler
        faulthandler.enable(file=stream)
        try:
            current = {}

            def stage(name, **details):
                current.update(details)
                payload = dict(current, stage=name, time=datetime.now().isoformat(timespec="seconds"))
                stream.write("MAFLOW_STAGE\t" + json.dumps(payload, ensure_ascii=False) + "\n")
                stream.flush()

            stage("Khởi động")
            request = json.loads((folder / "request.json").read_text(encoding="utf-8"))
            if request["operation"] == "preview":
                stage("Mở file trong trình xem PDF")
                os.startfile(request["path"])
                result = {}
            elif request["operation"] == "inspect":
                from zone_pdf import PdfReader, WHO_HEADER
                whos={}
                for source in request["sources"]:
                    stage("Đọc WHO từ PDF")
                    for page in PdfReader(source, strict=True).pages:
                        whos.update(dict.fromkeys(WHO_HEADER.findall(page.extract_text() or "")))
                result={"whos":list(whos)}
            elif request["operation"] == "sample":
                from zone_pdf import PdfReader, PdfWriter, stamp_page
                stage("Xem thử vị trí số trên trang PDF")
                reader = PdfReader(request["source"])
                index = int(request["page"]) - 1
                if not 0 <= index < len(reader.pages):
                    raise PrintJobError(f"Chọn trang từ 1 đến {len(reader.pages)}.")
                writer = PdfWriter()
                page = writer.add_page(reader.pages[index])
                stamp_page(page, request["sample"], request["style"])
                writer.write(folder / "result.pdf")
                result = {"pages": 1}
            elif request["operation"] == "import":
                from zone_pdf import numbered_pdf
                result = numbered_pdf(folder / "result.pdf", request["orders"], request["copies"],
                                      request["skip_blank"], request["sources"], stage, request.get("style"))
            elif request["operation"] == "submit":
                result = sap_pdf(request, folder, stage)
            else:
                raise PrintJobError("Yêu cầu PDF không hợp lệ.")
            (folder / "result.json").write_text(json.dumps(dict(result, ok=True)), encoding="utf-8")
            return 0
        except Exception as exc:
            traceback.print_exc(file=stream)
            result = {"ok": False, "error": str(exc) or type(exc).__name__}
            (folder / "result.json").write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
            return 1
        finally:
            faulthandler.disable()
            sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
