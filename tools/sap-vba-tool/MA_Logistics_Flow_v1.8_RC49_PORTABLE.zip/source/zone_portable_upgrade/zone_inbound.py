"""Read-only IN NVL lookups. SAP writes belong to a later GR release."""
from datetime import datetime
import re

import zone18 as z

ALV="wnd[0]/usr/cntlGRID1/shellcont/shell"
VL33N_TABLE="wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV50A:1202/tblSAPMV50ATC_LIPS_OVER_INB"
IB=re.compile(r"[0-9]{8,10}")
MATERIAL=re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,39}")


def digits(value):
    value=str(value).strip()
    return value.lstrip("0") if value.isascii() and value.isdigit() else value


def request_rows(text, by_ib, source="VL06I"):
    result=[]
    for line_no,line in enumerate(text.splitlines(),1):
        if not line.strip():
            continue
        first_field=line.split("\t",1)[0].strip().casefold()
        if first_field in ("số ib","mã hàng","số inbound"):
            continue
        fields=[p.strip() for p in line.split("\t")] if "\t" in line else line.split()
        if fields[0].casefold() in ("ib","số ib","material","mã hàng"):
            continue
        workbook_row="\t" in line and len(fields)>=9 and MATERIAL.fullmatch(fields[0]) and (
            not fields[1] or IB.fullmatch(fields[1])) and bool(fields[4])
        if by_ib:
            ib=fields[1] if workbook_row else fields[0]
            if not IB.fullmatch(ib):
                raise z.StopRun(f"Dòng {line_no}: số IB không hợp lệ.")
            entry=dict(ib=ib)
            if workbook_row:
                entry.update(material=fields[0].upper(),qty=input_quantity(fields[4],line_no),
                             expected_sloc=fields[2],po=fields[7],po_item=fields[8],bill=fields[6])
            elif len(fields)>=3 and MATERIAL.fullmatch(fields[1]) and fields[2]:
                entry.update(material=fields[1].upper(),qty=input_quantity(fields[2],line_no))
                if len(fields)>=4 and fields[3]:
                    entry["unit"]=fields[3].upper()
        else:
            if workbook_row:
                fields=[fields[0],fields[4],fields[7],fields[6],fields[8]]
            if len(fields) not in (3,4,5,6) or not re.fullmatch(r"[0-9]{10}",fields[2]):
                raise z.StopRun(f"Dòng {line_no}: cần Mã hàng, SL, PO/SA và Bill nếu có.")
            if not MATERIAL.fullmatch(fields[0]):
                raise z.StopRun(f"Dòng {line_no}: mã hàng không hợp lệ.")
            entry=dict(material=fields[0].upper(),qty=input_quantity(fields[1],line_no),po=fields[2],
                       bill=fields[3] if len(fields)>=4 else "")
            if len(fields)>=5 and fields[4]:
                entry["po_item"]=fields[4]
            if len(fields)==6 and fields[5]:
                entry["unit"]=fields[5].upper()
            if source=="ZMME240" and (not entry["bill"] or not re.fullmatch(r"[\w. /-]{1,60}",entry["bill"])):
                raise z.StopRun(f"Dòng {line_no}: ZMME240 cần Bill hợp lệ.")
        if entry.get("po") and not re.fullmatch(r"[0-9]{10}",entry["po"]):
            raise z.StopRun(f"Dòng {line_no}: PO/SA phải có 10 chữ số.")
        if entry.get("po_item") and not re.fullmatch(r"[0-9]{1,6}",entry["po_item"]):
            raise z.StopRun(f"Dòng {line_no}: item PO/SA không hợp lệ.")
        if entry not in result:
            result.append(entry)
    if not result:
        raise z.StopRun("Dán dữ liệu trước khi tra.")
    return result


def input_quantity(text,line_no):
    try:
        amount=z.parse_sap_decimal(text,"AUTO")
    except ValueError as exc:
        raise z.StopRun(f"Dòng {line_no}: không đọc được số lượng.") from exc
    if amount<=0:
        raise z.StopRun(f"Dòng {line_no}: số lượng phải lớn hơn 0.")
    return str(amount)


# Exact captions only. Delivery item and reference item are separate business keys.
CAPTIONS = {
    'CPUTM': ('Time of Entry','Entry Time'), 'BKTXT': ('Doc.Header Text','Document Header Text'),
    'BUDAT': ('Posting Date',), 'XBLNR': ('Reference',),
    "VBELN": ("Delivery", "Inbound Delivery", "Delivery Number"),
    "POSNR": ("Delivery Item", "Delivery Item Number", "Itm"),
    "MATNR": ("Material", "Material Number"), "LFIMG": ("Delivery Qty", "Delivery Quantity", "Deliv. Qty"),
    "VRKME": ("Sales unit", "Sales UoM"), "MEINS": ("Base Unit of Measure", "Base Unit"),
    "LGORT": ("Storage location", "SLoc"), "WBSTA": ("Goods Movement Sts", "Goods Movement Status"),
    "LIFEX": ("External Delivery ID", "External Delivery Number"),
    "S_VGBEL": ("Reference document", "Reference Document Number"),
    "S_VGPOS": ("RefIt", "Reference item", "Reference document item"),
    "LIFNR": ("Supplier","Vendor","Supplier number"), "WERKS": ("Plant",), "CHARG": ("Batch",), "VFDAT": ("Shelf Life Expiration Date",),
    "EBELN": ("Purchasing Document",), "EBELP": ("Purchasing Document Item",),
    "EMATN": ("Material", "Material Number"), "MBLNR": ("Material Document",),
    "MJAHR": ("Material Document Year",), "BWART": ("Movement Type",),
}
TECH = {"S_VGBEL": ("VGBEL",), "S_VGPOS": ("VGPOS",), "EMATN": ("MATNR",)}


def norm_caption(value):
    return re.sub(r"[^\w]+", "", str(value).casefold())


def col_map(grid, keys):
    ids = z.columns(grid)
    found = {}
    unknown = []
    for key in keys:
        hits = [c for c in ids if c.upper() == key]
        if not hits:
            hits = [c for c in ids if c.upper() in TECH.get(key, ())]
        if len(hits) == 1:
            found[key] = hits[0]
        elif key in CAPTIONS:
            unknown.append(key)
    if unknown:
        titles = {}
        for c in ids:
            try:
                title = grid.GetDisplayedColumnTitle(c)
            except Exception:
                title = ""
            terms={norm_caption(title)}
            try:
                terms.update(norm_caption(t) for t in grid.GetColumnTitles(c))
            except Exception:
                pass
            titles[c] = terms
        for key in unknown:
            accepted = {norm_caption(t) for t in CAPTIONS[key]}
            hits = [c for c in ids if titles[c] & accepted and c not in found.values()]
            if len(hits) == 1:
                found[key] = hits[0]
    return found


def result_grid(session):
    grid = z.optional(session, ALV)
    if grid is not None:
        return grid
    matches = [c for c in walk(z.require(session, "wnd[0]/usr")) if getattr(c, "SubType", "") == "GridView"]
    if len(matches) != 1:
        raise z.StopRun("Chưa xác định được bảng kết quả SAP.")
    return matches[0]


def paged_alv(session,grid,required,extra=(),mapping=None):
    keys = tuple(dict.fromkeys((*required, *extra)))
    mapping = col_map(grid, keys) if mapping is None else mapping
    missing = [key for key in required if key not in mapping]
    if missing:
        labels = ", ".join(CAPTIONS.get(k, (k,))[0] for k in missing)
        raise z.StopRun("Bảng SAP thiếu cột hoặc tiêu đề trùng nhau: " + labels +
                        ". Các cột đọc được: " + ", ".join(z.columns(grid)))
    raw = z.read_mon_pages(session, grid, tuple(dict.fromkeys(mapping.values())), "Tra SAP")
    return [{k: row[c] for k,c in mapping.items()} for row in raw if any(row.values())]


NO_DELIVERIES=re.compile(r"\bno deliveries\b|không có giao hàng",re.I)


def vl06i_has_results(session):
    try:
        kind,message=z.status(session,allow_warnings=True)
    except z.StopRun as exc:
        if NO_DELIVERIES.search(str(exc)):
            return False
        raise
    if NO_DELIVERIES.search(message):
        return False
    if kind=="W":
        raise z.StopRun(message)
    return True


def field(session, name, value, optional_if_blank=False):
    for prefix in ("ctxt","txt"):
        item=z.optional(session,"wnd[0]/usr/"+prefix+name)
        if item is not None:
            item.Text=value
            return
    if not value and optional_if_blank:
        return
    raise z.StopRun("Không tìm thấy trường lọc "+name)


def dates(cfg):
    today=datetime.now().date()
    start=cfg.get("date_from","").strip()
    end=cfg.get("date_to","").strip()
    fmt="%d.%m.%Y"
    if not start and not end:
        return "", ""
    try:
        first=datetime.strptime(start,fmt).date() if start else None
        last=datetime.strptime(end,fmt).date() if end else today
    except ValueError as exc:
        raise z.StopRun("Ngày tra cứu cần theo DD.MM.YYYY.") from exc
    if first and first>last:
        raise z.StopRun("Ngày từ lớn hơn ngày đến.")
    return first.strftime(fmt) if first else "",last.strftime(fmt)


def vl06i(session, requests, cfg, global_cfg):
    by_ib="ib" in requests[0]
    if not by_ib and any(r.get("bill") for r in requests) and any(not r.get("bill") for r in requests):
        return (vl06i(session,[r for r in requests if not r.get("bill")],cfg,global_cfg)
                +vl06i(session,[r for r in requests if r.get("bill")],cfg,global_cfg))
    z.start(session,"VL06I")
    z.require(session,"wnd[0]/usr/btnBUTTON7").press()
    z.status(session)
    first,last=("", "") if by_ib else dates(cfg)
    field(session,"IT_LFDAT-LOW",first,True)
    field(session,"IT_LFDAT-HIGH",last,True)
    if by_ib:
        z.inline_select(session,"wnd[0]/usr/btn%_IT_VBELN_%_APP_%-VALU_PUSH",[r["ib"] for r in requests])
    else:
        z.inline_select(session,"wnd[0]/usr/btn%_IT_MATNR_%_APP_%-VALU_PUSH",
                        list(dict.fromkeys(r["material"] for r in requests)))
        filter_field, key=("IT_LIFEX","bill") if requests[0].get("bill") else ("IT_EBELN","po")
        z.inline_select(session,f"wnd[0]/usr/btn%_{filter_field}_%_APP_%-VALU_PUSH",
                        list(dict.fromkeys(r[key] for r in requests)))
    z.require(session,"wnd[0]").sendVKey(8)
    if not vl06i_has_results(session):
        return [dict(q,ib_state="Chưa thấy IB khớp",source="VL06I") for q in requests]
    grid=result_grid(session)
    keys=("VBELN","MATNR","LFIMG","POSNR","LGORT","WBSTA","VRKME","MEINS","S_VGBEL",
          "S_VGPOS","LIFEX","WERKS","CHARG","VFDAT","LIFNR")
    mapping=col_map(grid,keys)
    switch=z.optional(session,"wnd[0]/tbar[1]/btn[18]")
    toolbar=z.optional(session,"wnd[0]/tbar[1]")
    buttons=list(walk(toolbar)) if toolbar is not None else []
    if switch is not None:
        buttons.insert(0,switch)
    def caption(button):
        return " ".join(str(getattr(button,key,"") or "") for key in ("Text","Tooltip")).lower()
    action=next((b.press for b in buttons if "item view" in caption(b)),None)
    if action is None and hasattr(grid,"GetToolbarButtonId"):
        for i in range(int(getattr(grid,"ToolbarButtonCount",0) or 0)):
            key=grid.GetToolbarButtonId(i)
            labels=[]
            for attr in ("GetToolbarButtonText","GetToolbarButtonTooltip"):
                try:
                    labels.append(str(getattr(grid,attr)(key)).lower())
                except Exception:
                    pass
            if "item view" in " ".join(labels):
                action=lambda: grid.PressToolbarButton(key)
                break
    if action is None and switch is not None and "header" not in caption(switch) and "MATNR" not in mapping:
        action=switch.press
    if action is not None:
        action()
        z.idle(session)
        z.status(session)
        grid=result_grid(session)
        mapping=col_map(grid,keys)
    required=["VBELN","MATNR","LFIMG"]
    for key,column in (("po","S_VGBEL"),("po_item","S_VGPOS"),("bill","LIFEX")):
        if any(q.get(key) for q in requests):
            required.append(column)
    raw=paged_alv(session,grid,required,keys,mapping)
    return match_vl06i(raw,requests,by_ib,global_cfg)


def match_vl06i(raw,requests,by_ib,global_cfg):
    out=[]
    seen=set()
    for row in raw:
        if not row.get("VBELN") and not row.get("MATNR"):
            continue
        if not IB.fullmatch(row["VBELN"]) or not row["MATNR"]:
            raise z.StopRun("VL06I trả dòng thiếu số IB hoặc mã hàng.")
        if by_ib and not any(digits(q["ib"])==digits(row["VBELN"]) for q in requests):
            raise z.StopRun("VL06I trả dữ liệu ngoài danh sách IB.")
        matches=[i for i,q in enumerate(requests)
                 if (not by_ib or digits(row["VBELN"])==digits(q["ib"]))
                 and (not q.get("material") or row["MATNR"].upper()==q["material"])
                 and ((by_ib and not q.get("verify_candidate")) or (
                     (not q.get("po") or digits(row.get("S_VGBEL",""))==digits(q["po"]))
                     and (not q.get("po_item") or digits(row.get("S_VGPOS",""))==digits(q["po_item"]))
                     and (not q.get("bill") or row.get("LIFEX","").upper()==q["bill"].upper())))]
        if not matches:
            continue
        quantity=z.number(row["LFIMG"],global_cfg)
        if not by_ib:
            matches=[i for i in matches if requests[i].get("plan_lookup") or (quantity>0 and quantity==z.parse_sap_decimal(requests[i]["qty"],"US"))]
        if not matches:
            continue
        seen.update(matches)
        expected=list(dict.fromkeys(requests[i]["qty"] for i in matches if requests[i].get("qty")))
        target_sloc=list(dict.fromkeys(requests[i]["expected_sloc"] for i in matches if requests[i].get("expected_sloc")))
        changes=[]
        unit=row.get("VRKME") or row.get("MEINS","")
        if any(requests[i].get("unit") and requests[i]["unit"]!=unit.upper() for i in matches):
            changes.append("Cần đối chiếu ĐVT")
        if expected and any(quantity!=z.parse_sap_decimal(qty,"US") for qty in expected):
            changes.append("Lệch số lượng")
        if target_sloc and any(row.get("LGORT","")!=sloc for sloc in target_sloc):
            changes.append("Khác SLoc" if row.get("LGORT") else "Chưa có SLoc")
        if any(requests[i].get("po") and digits(row.get("S_VGBEL",""))!=digits(requests[i]["po"]) for i in matches):
            changes.append("Khác PO/SA")
        status=row.get("WBSTA","")
        state={"A":"Đang mở","B":"GR một phần","C":"Đã hoàn tất GR"}.get(status,f"Trạng thái SAP {status or 'chưa rõ'}")
        pos=row.get("POSNR","")
        if not pos.isdigit() or not int(pos):
            pos=""
            changes.append("VL06I chưa hiển thị Delivery Item")
        out.append(dict(ib=row["VBELN"],item=pos,material=row["MATNR"].upper(),qty=row["LFIMG"],
                        unit=unit,base_unit=row.get("MEINS",""),sloc=row.get("LGORT",""),
                        sap_status=status,supplier=row.get("LIFNR",""),plant=row.get("WERKS",""),batch=row.get("CHARG",""),expiry=row.get("VFDAT",""),
                        po=row.get("S_VGBEL",""),po_item=row.get("S_VGPOS",""),bill=row.get("LIFEX",""),
                        expected_qty="/".join(expected),expected_sloc="/".join(target_sloc),
                        ib_state=" · ".join([state,*changes]),source="VL06I"))
    out.extend(dict(q,ib_state="Chưa thấy IB khớp",source="VL06I") for i,q in enumerate(requests) if i not in seen)
    return out


def zmme(session, requests, cfg, global_cfg):
    z.start(session,"ZMME240")
    for name in ("S_ASN","S_TRXID1","S_CONTAI","S_REPDAT","S_LIFNR","S_PL","S_PICKUP","S_ATA","S_NOTE"):
        for bound in ("LOW","HIGH"):
            field(session,f"{name}-{bound}","",True)
    z.inline_select(session,"wnd[0]/usr/btn%_S_HOUSE_%_APP_%-VALU_PUSH",[r["bill"] for r in requests])
    z.require(session,"wnd[0]/usr/radP_CONCH").Select()
    z.require(session,"wnd[0]/usr/radP_BOTH").Select()
    z.require(session,"wnd[0]/tbar[1]/btn[8]").press()
    z.status(session)
    data=paged_alv(session,result_grid(session),("TRXID1","PART_NAME","QUANTITY","HOUSEBILL","VGBEL","STATUS"))
    matched=[]
    for r in data:
        if not r["HOUSEBILL"]:
            continue
        if any(r["PART_NAME"].upper()==q["material"] and digits(r["VGBEL"])==digits(q["po"]) and
               r["HOUSEBILL"].upper()==q["bill"].upper() and
               z.number(r["QUANTITY"],global_cfg)==z.parse_sap_decimal(q["qty"],"US") for q in requests):
            matched.append(dict(ib=r["TRXID1"],item="",material=r["PART_NAME"].upper(),qty=r["QUANTITY"],
                                po=r["VGBEL"],bill=r["HOUSEBILL"],sap_status=r["STATUS"],
                                ib_state="Ứng viên • cần đối chiếu item VL06I" if IB.fullmatch(r["TRXID1"]) else "Chưa có số IB",
                                source="ZMME240"))
    for q in requests:
        if not any(r["material"]==q["material"] and digits(r["po"])==digits(q["po"]) and
                   r["bill"].upper()==q["bill"].upper() and z.number(r["qty"],global_cfg)==z.parse_sap_decimal(q["qty"],"US") for r in matched):
            matched.append(dict(q,ib_state="Chưa thấy IB khớp",source="ZMME240"))
    return matched


def verify_zmme(session,rows,cfg,global_cfg):
    requests=[dict(ib=row["ib"],material=row["material"],po=row["po"],bill=row["bill"],verify_candidate=True,
                   qty=str(z.number(row["qty"],global_cfg)))
              for row in rows if row["ib_state"].startswith("Ứng viên")]
    if not requests:
        return rows
    try:
        verified=vl06i(session,requests,cfg,global_cfg)
    except z.StopRun as exc:
        return [dict(row,ib_state="Chưa xác minh item VL06I",ib_note=str(exc))
                if row["ib_state"].startswith("Ứng viên") else row for row in rows]
    return [*verified,*(row for row in rows if not row["ib_state"].startswith("Ứng viên"))]


def purchase(session, selected, cfg):
    z.start(session,"ME2N")
    pos=[r["po"] for r in selected if r.get("po")]
    mats=[r["material"] for r in selected if r.get("material")]
    if not pos or not mats:
        raise z.StopRun("Cần có PO/SA và mã hàng để tra ME2N.")
    if cfg.get("me2n_scope"):
        field(session,"LISTU",cfg["me2n_scope"])
    z.inline_select(session,"wnd[0]/usr/btn%_EN_EBELN_%_APP_%-VALU_PUSH",pos)
    z.inline_select(session,"wnd[0]/usr/btn%_S_MATNR_%_APP_%-VALU_PUSH",mats)
    z.require(session,"wnd[0]/tbar[1]/btn[8]").press()
    z.status(session)
    data=paged_alv(session,result_grid(session),("EBELN","EBELP","EMATN","MGLIEF","FRGKE","LOEKZ"),("MEINS",))
    return [[r for r in data if digits(r["EBELN"])==digits(q.get("po","")) and r["EMATN"].upper()==q.get("material","").upper()
             and (not q.get("po_item") or digits(r["EBELP"])==digits(q["po_item"]))] for q in selected]


def purchase_result(request,items,global_cfg):
    if not request.get("po") or not request.get("material"):
        return "Thiếu PO/SA hoặc mã","Cần mã hàng và số PO/SA để đối chiếu ME2N."
    if not items:
        return "Chưa thấy item PO/SA","Chưa thấy item khớp PO/SA và mã hàng trong ME2N."
    detail=" • ".join(f"{r['EBELN']}/{r['EBELP']} còn {r['MGLIEF']} {r.get('MEINS','')} "
                      f"(release {r['FRGKE'] or 'trống'}, khóa/xóa {r['LOEKZ'] or 'trống'})" for r in items)
    usable={}
    for row in items:
        if row["FRGKE"] in ("B","C") or row["LOEKZ"] in ("L","S"):
            continue
        key=(digits(row["EBELN"]),digits(row["EBELP"]))
        unit=row.get("MEINS","").upper()
        value=(z.number(row["MGLIEF"],global_cfg),unit)
        if key in usable and usable[key]!=value:
            return "Cần đối chiếu item",detail
        usable[key]=value
    if not usable:
        return "PO/SA khóa hoặc chưa release",detail
    units={unit for _,unit in usable.values()}
    if len(units)!=1 or "" in units or (request.get("unit") and request["unit"].upper() not in units):
        return "Cần đối chiếu ĐVT",detail
    expected=request.get("expected_qty")
    if expected and "/" in expected:
        return "Cần đối chiếu SL yêu cầu",detail
    if expected:
        required=z.parse_sap_decimal(expected,"US")
    elif request.get("qty"):
        required=(z.number(request["qty"],global_cfg) if "sap_status" in request
                  else z.parse_sap_decimal(request["qty"],"US"))
    else:
        return "Chưa có SL yêu cầu",detail
    available=sum(max(qty,0) for qty,_ in usable.values())
    state="Đủ SL PO/SA" if available>=required else "Thiếu SL PO/SA"
    if len(usable)>1 and state=="Đủ SL PO/SA":
        state="Đủ tổng SL · nhiều item"
    if not request.get("unit"):
        state+=" · tham chiếu ĐVT PO"
    return state,f"Cần {required}, còn {available} {next(iter(units))}. {detail}"


def receive_queue(session, selected, cfg):
    warehouse=cfg["warehouse"]
    tree=z.mon_start(session,warehouse)
    tree.expandNode("T000000001")
    tree.doubleClickNode("MQUEUE0001")
    z.idle(session)
    z.require(session,"wnd[1]/usr/chkP_QIN").Selected=False
    z.require(session,"wnd[1]/usr/chkP_QOUT").Selected=False
    z.require(session,"wnd[1]/tbar[0]/btn[8]").press()
    z.status(session)
    keys=("BUSOBJ_KEY","ERRMESS")
    data=paged_alv(session,z.grid_with(z.mon_grids(session),keys),keys,("QSTATE","QNAME"))
    return [[r for r in data if digits(r["BUSOBJ_KEY"])==digits(q.get("ib",""))] for q in selected]


def material_docs(session, selected, cfg):
    z.start(session,"MB51")
    first,last=dates(cfg)
    for name in ("MATNR","CHARG","LIFNR","KUNNR","BWART","SOBKZ","AUFNR","EBELN","KOSTL",
                 "MAT_KDAU","MAT_KDPO","PS_PSP_P","RSNUM","USNAM","VGART","MBLNR"):
        for bound in ("LOW","HIGH"):
            field(session,f"{name}-{bound}","",True)
    field(session,"BUDAT-LOW",first,True)
    field(session,"BUDAT-HIGH",last,True)
    field(session,"WERKS-LOW",cfg.get("plant",""),True)
    field(session,"WERKS-HIGH","",True)
    ibs=[r["ib"] for r in selected if r.get("ib")]
    if not ibs:
        raise z.StopRun("Cần IB để tra Material Document.")
    refs=list(dict.fromkeys(value for ib in ibs for value in (ib,ib.zfill(10))))
    z.inline_select(session,"wnd[0]/usr/btn%_XBLNR_%_APP_%-VALU_PUSH",refs)
    z.require(session,"wnd[0]/tbar[1]/btn[8]").press()
    z.status(session)
    keys=("XBLNR","MATNR","MBLNR","MJAHR","BWART")
    data=paged_alv(session,result_grid(session),keys,("ZEILE","MENGE","MEINS","BUDAT","WERKS"))
    result=[]
    for q in selected:
        ib=digits(q.get("ib",""))
        hits=[r for r in data if ib and q.get("material") and
              re.search(r"(?<![0-9])0*"+re.escape(ib)+r"$",r["XBLNR"]) and
              r["MATNR"].upper()==q["material"].upper() and r["MBLNR"] and r["MJAHR"]]
        result.append(hits)
    return result


def walk(control, depth=0):
    yield control
    if depth>=15 or not getattr(control,"ContainerType",False):
        return
    children=control.Children
    for i in range(children.Count):
        yield from walk(children(i),depth+1)


def visible_table_rows(session,table_id):
    table=z.require(session,table_id)
    total=int(table.RowCount)
    index=0
    while index<total:
        first=int(table.VerticalScrollbar.Position)
        visible=int(table.VisibleRowCount)
        if not first<=index<first+visible:
            table.VerticalScrollbar.Position=index
            z.idle(session)
            table=z.require(session,table_id)
            first=int(table.VerticalScrollbar.Position)
            visible=int(table.VisibleRowCount)
        end=min(total,first+visible)
        if not first<=index<end or int(table.RowCount)!=total:
            raise z.StopRun("Chưa đọc đủ các trang của bảng SAP.")
        for absolute in range(index,end):
            yield table,absolute-first
        index=end


def bom_master(session, material, plant, usage, key_date=None):
    if not plant:
        raise z.StopRun("Cần Plant trước khi tra BOM master.")
    z.start(session,"CS03")
    field(session,"RC29N-MATNR",material)
    field(session,"RC29N-WERKS",plant)
    field(session,"RC29N-STLAN",usage)
    if key_date:
        field(session,"RC29N-DATUV",key_date.strftime("%d.%m.%Y"))
    z.require(session,"wnd[0]").sendVKey(0)
    z.idle(session)
    popup=z.optional(session,"wnd[1]")
    if popup is not None:
        pieces=[]
        for name in ("txtMESSTXT1","txtMESSTXT2"):
            msg=z.optional(session,"wnd[1]/usr/"+name)
            if msg is not None:
                pieces.append(str(msg.Text))
        text=" ".join(pieces)
        if re.search(r"no (?:valid |material )*bom|bom .*does not exist|bom .*not found",text,re.I):
            popup.Close()
            raise z.StopRun(text)
    z.status(session)
    keys=("IDNRK","MENGE","MEINS")
    controls=[x for x in walk(z.require(session,"wnd[0]/usr")) if getattr(x,"SubType","")=="GridView"]
    matches=[x for x in controls if set(keys)<=set(z.columns(x))]
    if matches:
        return paged_alv(session,z.grid_with(matches,keys),keys,("OJTXP","DATUB"))
    result=[]
    table_id="wnd[0]/usr/tblSAPLCSDITCMAT"
    table=z.require(session,table_id)
    if not int(table.RowCount):
        return result
    indices={}
    for i in range(int(table.Columns.Count)):
        try:
            key=str(table.GetCell(0,i).Name).upper().split("-")[-1]
        except Exception:
            continue
        if key in (*keys,"OJTXP","DATUB"):
            indices[key]=i
    if not set(keys)<=indices.keys():
        raise z.StopRun("Bảng BOM master thiếu cột mã linh kiện, số lượng hoặc ĐVT.")
    for table,row in visible_table_rows(session,table_id):
        values={k:str(table.GetCell(row,i).Text).strip() for k,i in indices.items()}
        if not values["IDNRK"] or values["IDNRK"].startswith(("_","---")):
            continue
        result.append(values)
    return result


def focus_ib_item(session, item):
    """Resolve the actual delivery item on VL33N before opening its components."""
    table=z.require(session,VL33N_TABLE)
    columns={}
    if not int(table.RowCount):
        raise z.StopRun("VL33N chưa hiển thị item của IB.")
    for column in range(int(table.Columns.Count)):
        try:
            key=str(table.GetCell(0,column).Name).upper()
        except Exception:
            continue
        if key in ("LIPS-POSNR","LIPS-MATNR","LIPS-CHARG"):
            columns[key]=column
    if not {"LIPS-POSNR","LIPS-MATNR"} <= columns.keys():
        raise z.StopRun("VL33N cần hiển thị mã hàng và Delivery Item để xác minh BOM.")
    pos=digits(item.get("item",""))
    if pos and not re.fullmatch("[0-9]{1,6}",pos):
        raise z.StopRun("Delivery Item không hợp lệ.")
    candidates=[]
    def identity(table,row):
        return {key:str(table.GetCell(row,c).Text).strip().upper() for key,c in columns.items()}
    for absolute,(table,row) in enumerate(visible_table_rows(session,VL33N_TABLE)):
        cells=identity(table,row)
        actual=digits(cells["LIPS-POSNR"])
        if not actual.isdigit() or cells["LIPS-MATNR"]!=item["material"].upper():
            continue
        if pos and pos!=actual:
            continue
        batch=cells.get("LIPS-CHARG")
        if item.get("batch") and batch is not None and batch!=item["batch"].upper():
            continue
        candidates.append((absolute,cells))
        if pos:
            break
        if len(candidates)>1:
            raise z.StopRun("Nhiều item VL33N cùng khớp mã hàng. Hiện cột Delivery Item trên VL06I rồi tra lại.")
    if not candidates:
        raise z.StopRun("Không tìm thấy item khớp IB, mã hàng và batch trên VL33N.")
    absolute,expected=candidates[0]
    table=z.require(session,VL33N_TABLE)
    first=int(table.VerticalScrollbar.Position)
    if not first<=absolute<first+int(table.VisibleRowCount):
        table.VerticalScrollbar.Position=absolute
        z.idle(session)
        table=z.require(session,VL33N_TABLE)
    row=absolute-int(table.VerticalScrollbar.Position)
    if not 0<=row<int(table.VisibleRowCount) or identity(table,row)!=expected:
        raise z.StopRun("Dòng VL33N thay đổi. Tra lại IB trước khi kiểm BOM.")
    table.GetCell(row,columns["LIPS-MATNR"]).SetFocus()


def bom_ib(session, item, cfg):
    """Look only at the Components display for the exact IB item (never confirm Edit Components)."""
    ib=item.get("ib","")
    if not IB.fullmatch(ib) or not item.get("material") or "sap_status" not in item:
        raise z.StopRun("Tra IB và mã hàng trong VL06I trước khi kiểm BOM.")
    z.start(session,"VL33N")
    field(session,"LIKP-VBELN",ib)
    z.require(session,"wnd[0]").sendVKey(0)
    z.status(session)
    window=z.require(session,"wnd[0]")
    displayed=window.findByName("LIKP-VBELN","GuiCTextField")
    if digits(displayed.Text)!=digits(ib):
        raise z.StopRun("VL33N không xác nhận đúng IB đang mở.")
    focus_ib_item(session,item)
    button=window.findByName("BT_COMP_T","GuiButton")
    button.press()
    z.idle(session)
    popup=z.optional(session,"wnd[1]")
    if popup is None:
        z.status(session)
        raise z.StopRun("Sắp xếp layout VL33N để mở phần hiển thị Components.")
    title=str(popup.Text).casefold()
    msg=z.optional(session,"wnd[1]/usr/txtMESSTXT1")
    if "information" in title and msg is not None and "no components found" in str(msg.Text).casefold():
        popup.Close()
        return "Thiếu component trên IB", []
    if "display" not in title or "component" not in title:
        raise z.StopRun("Chưa xác minh đây là cửa sổ Display Components.")
    keys=("IDNRK","MENGE","MEINS")
    stock_field=cfg.get("component_stock_column","").strip()
    try:
        grid=z.grid_with([c for c in walk(popup) if getattr(c,"SubType","")=="GridView"],keys)
        if stock_field and stock_field not in z.columns(grid):
            raise z.StopRun("Thiếu cột tồn linh kiện đã cấu hình.")
        data=paged_alv(session,grid,keys,tuple(filter(None,("OJTXP",stock_field))))
    finally:
        popup.Close()
    if not data:
        return "Thiếu component trên IB",data
    if not stock_field:
        return "Có component • chưa xác minh tồn",data
    needed={}
    balances={}
    for row in data:
        key=(row["IDNRK"],row["MEINS"])
        required=z.number(row["MENGE"],cfg)
        if not str(row.get(stock_field,"")).strip():
            raise z.StopRun("Ô tồn linh kiện trống.")
        stock=z.number(row[stock_field],cfg)
        needed[key]=needed.get(key,0)+required
        if key in balances and balances[key]!=stock:
            raise z.StopRun("Số tồn linh kiện cùng mã/ĐVT không nhất quán.")
        balances[key]=stock
        row["available"]=str(stock)
    return ("Thiếu tồn linh kiện" if any(needed[k]>balances[k] for k in needed) else "Đủ linh kiện trên item"),data
