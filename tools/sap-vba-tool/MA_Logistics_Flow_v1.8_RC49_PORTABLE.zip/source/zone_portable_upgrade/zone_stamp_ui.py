"""Edit the PDF number style saved by the portable application."""
from pathlib import Path
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from zone_pdf import ANCHORS, DEFAULT_STYLE, MM, checked_style, placement

ANCHOR_NAMES=("Trên trái","Trên giữa","Trên phải","Dưới trái","Dưới giữa","Dưới phải","Tự đặt")
OPTIONS={
    "anchor":dict(zip(ANCHORS,ANCHOR_NAMES)),
    "family":{name:name for name in ("Helvetica","Times","Courier")},
    "style":{"regular":"Thường","bold":"Đậm","italic":"Nghiêng","bolditalic":"Đậm nghiêng"},
    "frame":{"none":"Không khung","rectangle":"Chữ nhật","ellipse":"Bầu dục"},
}


def edit_style(parent, initial, sample, persist, preview, post_ui):
    win=tk.Toplevel(parent)
    win.title("Chỉnh số phiếu PDF")
    win.transient(parent)
    win.grab_set()
    win.resizable(False,False)
    left=ttk.Frame(win,padding=12)
    left.grid(row=0,column=0,sticky="ns")
    right=ttk.Frame(win,padding=12)
    right.grid(row=0,column=1,sticky="n")
    fields={}
    labels=(("anchor","Vị trí"),("size","Cỡ chữ (pt)"),("family","Phông chữ"),("style","Kiểu chữ"),
            ("color","Màu chữ và viền"),("frame","Khung số"),("border","Nét khung (pt)"),
            ("pad","Đệm trong (mm)"),("margin","Lề an toàn (mm)"),("x","Cách trái (mm)"),("y","Cách trên (mm)"))
    for row,(k,caption) in enumerate(labels):
        ttk.Label(left,text=caption).grid(row=row,column=0,sticky="w",padx=(0,12),pady=3)
        value=tk.StringVar(master=win)
        fields[k]=value
        if k in OPTIONS:
            control=ttk.Combobox(left,values=list(OPTIONS[k].values()),textvariable=value,width=16,state="readonly")
        elif k=="color":
            control=ttk.Entry(left,textvariable=value,width=18)
        else:
            low,high,step={"size":(8,72,1),"margin":(0,50,1),"border":(.3,4,.1),"pad":(.5,8,.5),
                           "x":(0,10000,1),"y":(0,10000,1)}[k]
            control=ttk.Spinbox(left,from_=low,to=high,increment=step,textvariable=value,width=16)
        control.grid(row=row,column=1,sticky="w")
    def pick_color():
        chosen=win.tk.call("tk_chooseColor","-parent",win,"-title","Màu số phiếu")
        if chosen: fields["color"].set(chosen)
    ttk.Button(left,text="Chọn màu",command=pick_color).grid(row=4,column=2,padx=4)
    fields["white"]=tk.BooleanVar(master=win)
    ttk.Checkbutton(left,text="Nền trắng sau số",variable=fields["white"]).grid(row=11,columnspan=2,sticky="w")
    ttk.Label(right,text="Đặt số trên trang A4 ngang (sơ đồ)").pack(anchor="w")
    scale=.49
    pw,ph=297*MM,210*MM
    canvas=tk.Canvas(right,width=int(pw*scale+12),height=int(ph*scale+12),bg="#edf2f5",highlightthickness=0,cursor="crosshair")
    canvas.pack(pady=5)
    note=tk.StringVar(master=win)
    ttk.Label(right,textvariable=note,wraplength=390).pack(anchor="w")
    busy=False
    syncing=False
    source=""
    page_var=tk.StringVar(master=win,value="1")
    def settings():
        values={k:v.get() for k,v in fields.items()}
        for k,mapping in OPTIONS.items():
            values[k]=next((i for i,label in mapping.items() if label==values[k]),"")
        return checked_style(values)
    def redraw(*_):
        if syncing:return
        canvas.delete("all")
        canvas.create_rectangle(5,5,5+pw*scale,5+ph*scale,fill="white",outline="#8695a3")
        try:
            s=settings()
            x,y,w,h,_,_=placement(pw,ph,sample,s)
            m=s["margin"]*MM*scale
            canvas.create_rectangle(5+m,5+m,5+pw*scale-m,5+ph*scale-m,outline="#a3afba",dash=(3,3))
            l,t=5+x*scale,5+y*scale
            r,b=l+w*scale,t+h*scale
            if s["frame"]!="none" or s["white"]:
                draw=canvas.create_oval if s["frame"]=="ellipse" else canvas.create_rectangle
                draw(l,t,r,b,outline=s["color"] if s["frame"]!="none" else "",fill="white" if s["white"] else "")
            family={"Helvetica":"Arial","Times":"Times New Roman","Courier":"Courier New"}[s["family"]]
            font=(family,-max(1,round(s["size"]*scale)),"bold" if "bold" in s["style"] else "normal",
                  "italic" if "italic" in s["style"] else "roman")
            canvas.create_text((l+r)/2,(t+b)/2,text=sample,fill=s["color"],font=font)
            note.set(f"{sample}  ·  cách trái {x/MM:.1f} mm  ·  cách trên {y/MM:.1f} mm\nBấm hoặc kéo trên sơ đồ để đặt vị trí.")
        except ValueError as exc:
            note.set(str(exc))
        except RuntimeError as exc:
            note.set(str(exc))
    def custom(key):
        if not syncing and key in ("x","y"):
            fields["anchor"].set(OPTIONS["anchor"]["custom"])
        redraw()
    for key,var in fields.items():
        var.trace_add("write",lambda *_,k=key:custom(k))
    def fill(values):
        nonlocal syncing
        syncing=True
        for k,v in {**DEFAULT_STYLE,**values}.items():
            if k in fields:
                fields[k].set(OPTIONS[k].get(v,"") if k in OPTIONS else v)
        syncing=False
        redraw()
    def place(event):
        if 5<=event.x<=pw*scale+5 and 5<=event.y<=ph*scale+5:
            fields["x"].set(round((event.x-5)/scale/MM,1))
            fields["y"].set(round((event.y-5)/scale/MM,1))
    canvas.bind("<Button-1>",place)
    canvas.bind("<B1-Motion>",place)
    fill(initial)
    def close():
        if not busy:
            win.destroy()
            if parent.winfo_exists() and isinstance(parent,tk.Toplevel):
                parent.grab_set()
    win.protocol("WM_DELETE_WINDOW",close)
    def save():
        if busy:return
        try:
            value=settings()
            placement(pw,ph,sample,value)
            persist(value)
        except Exception as exc:
            messagebox.showwarning("Chỉnh số phiếu",str(exc),parent=win)
            return
        close()
    bar=ttk.Frame(right)
    bar.pack(fill="x",pady=6)
    filelabel=tk.StringVar(master=win,value="Chọn PDF để xem thử trên trang thực tế.")
    def choose():
        nonlocal source
        path=filedialog.askopenfilename(parent=win,title="Chọn PDF để xem thử",filetypes=[("PDF","*.pdf")])
        if path:
            source=path
            filelabel.set(Path(path).name)
    ttk.Button(bar,text="Chọn PDF mẫu",command=choose).pack(side="left")
    ttk.Label(bar,text="Trang").pack(side="left",padx=4)
    ttk.Entry(bar,textvariable=page_var,width=4).pack(side="left")
    def show():
        nonlocal busy
        if busy:return
        if not source: choose()
        if not source:return
        try:
            s=settings()
            page=int(page_var.get())
            if page<1:raise ValueError("Số trang bắt đầu từ 1.")
        except (ValueError,RuntimeError) as exc:
            note.set(str(exc))
            return
        busy=True
        request=dict(operation="sample",source=source,page=page,sample=sample,style=s)
        def done(error):
            nonlocal busy
            busy=False
            if win.winfo_exists():
                note.set(error or "Đã mở trang mẫu trong trình xem PDF.")
        def work():
            try:
                target=Path(tempfile.mkdtemp(prefix="MAFlow_preview_"))/"Xem_thu.pdf"
                preview(request,target)
                error=""
            except Exception as exc:
                error=str(exc)
            post_ui(lambda:done(error))
        threading.Thread(target=work,daemon=True).start()
    ttk.Button(bar,text="Xem thử",command=show).pack(side="left",padx=5)
    ttk.Label(right,textvariable=filelabel,wraplength=390).pack(anchor="w")
    buttons=ttk.Frame(win,padding=10)
    buttons.grid(row=1,columnspan=2,sticky="ew")
    ttk.Button(buttons,text="Khôi phục mặc định",command=lambda:fill(DEFAULT_STYLE)).pack(side="left")
    ttk.Button(buttons,text="Lưu kiểu số",command=save).pack(side="right")
    ttk.Button(buttons,text="Hủy",command=close).pack(side="right",padx=6)
