"""One table definition for the report screen, clipboard and three shift images."""
from collections import Counter
from dataclasses import dataclass, field
from datetime import date
from itertools import accumulate, groupby

import zone_daily as daily
import zone_shift as sh


@dataclass
class Row:
    values: tuple
    kind: str = 'detail'
    key: object = None


@dataclass
class Table:
    title: str
    headers: list
    widths: list
    rows: list
    group_dates: bool = False
    spans: list = field(default_factory=list)


@dataclass
class Cell:
    bounds: tuple
    text: str
    fill: str
    color: str
    bold: bool
    size: int
    align: str


@dataclass
class Sheet:
    table: Table
    width: int
    height: int = 0
    cells: list = field(default_factory=list)
    bottom: list = field(default_factory=list)
    right: list = field(default_factory=list)


STATUS_HEADERS=['KHSX','Xe','Ca SX','Order','Hoàn\nthành','1 phần','Pending','Tập kết','Hết tồn','Tỷ lệ\ncấp','Tỷ lệ\ntập kết','Tỷ lệ\nhết tồn','Tổng\ntỷ lệ','Ghi chú']
RESULT_HEADERS=['KHSX','Xe','Ca SX','Hoàn thành','1 phần','Tập kết','Tổng','Ghi chú']
INK='#142b42'
BORDER='#8295a6'
WHITE='#ffffff'
STATE_COLORS={'Done':('#dcefe3','#245638'),'Partial finished':('#dcecf1','#224f60'),
              'Pending':('#ffedcc','#67400f')}


def shift_title(name,identity):
    return name.upper()+('   ·   '+identity if identity else '')


def display_date(dt):
    try:
        return date.fromisoformat(dt).strftime('%d/%m/%Y')
    except (ValueError,TypeError):
        return dt


def pivot_table(table,identity,full=False,include_all=False,materials=False,options=None,first='',last='',baseline=None,shift_identity=None,include_gather=True):
    models,lines=daily.pivot(table,full or materials,include_all,options,first,last,baseline,shift_identity,include_gather)
    headers=['Trạng thái','KHSX','NOTE',*models,'Tổng']
    widths=[108,94,159,*[max(59,len(m)*9+10) for m in models],66]
    if materials:
        headers.insert(3,'Mã hàng')
        widths.insert(3,140)
    rows=[]
    for vals,tag,records in lines:
        cells=list(vals)
        cells[1]=display_date(cells[1])
        if materials:
            cells.insert(3,'')
        rows.append(Row(tuple(cells),tag,records))
        if materials and tag in ('detail','gathered'):
            by_mat={}
            for record in records:
                by_mat.setdefault(sh.clean(record[1][3]),[]).append(record)
            for mat,group in sorted(by_mat.items()):
                counts=Counter(rec[2] for rec in group)
                rows.append(Row(('','','',mat,*[counts[m] or '' for m in models],len(group)),'material',group))
    result=Table(shift_title('Báo cáo cấp NVL',identity),headers,widths,rows)
    # (first row, end row, first column, end column, label, style, detail row)
    state_start=date_start=0
    categories=4 if materials else 3
    for i,row in enumerate(rows):
        if row.kind=='date':
            dt=row.values[1]
            result.spans.append((date_start,i,1,2,dt,'group_date',i))
            result.spans.append((i,i+1,1,categories,'Tổng ngày '+dt,'date',i))
            date_start=i+1
        elif row.kind in ('state','total'):
            name=row.values[0]
            if state_start<i:
                result.spans.append((state_start,i,0,1,name,'group_status',i))
            label=row.values[2] or name
            result.spans.append((i,i+1,0,categories,label,row.kind,i))
            state_start=date_start=i+1
    return result


def status_values(c):
    supplied=c['done']+c['partial']
    values=(supplied,c['gathered'],c['empty'],c['order']-c['pending'])
    count=c['order']
    ratios=[f'{(200*v+count)//(2*count)}%' if count else '—' for v in values]
    return tuple(c[k] for k in ('order','done','partial','pending','gathered','empty'))+tuple(ratios)


def result_values(c):
    done,partial,gathered=c['new_done'],c['new_partial'],c['new_gathered']
    if c['unknown_supply']:
        return done,'Chờ mốc',('Chờ chốt' if gathered is None else gathered),'Chờ mốc'
    if gathered is None:
        return done,partial,'Chờ chốt','Chờ chốt'
    return done,partial,gathered,done+partial+gathered


def shift_tables(items,identity):
    status=Table(shift_title('Tình trạng cấp NVL',identity),STATUS_HEADERS,
        [93,78,75,52,62,53,64,58,57,53,56,57,54,155],[],True)
    result=Table(shift_title('Kết quả cấp NVL',identity),RESULT_HEADERS,
        [108,105,100,110,85,92,92,263],[],True)
    totals=Counter()
    complete=True
    for dt,model,ca,c,note in items:
        prefix=(display_date(dt),model,ca)
        status.rows.append(Row((*prefix,*status_values(c),note),key=(dt,model)))
        rv=result_values(c)
        if rv[3]!=0 or note:
            result.rows.append(Row((*prefix,*rv,note),key=(dt,model)))
        totals.update({k:v for k,v in c.items() if v is not None})
        complete &= c['new_gathered'] is not None
    if not complete:
        totals['new_gathered']=None
    if not items:
        for table in (status,result):
            table.rows.append(Row(('Không có dòng ORDER trong phạm vi KHSX.',),'empty'))
        return status,result
    if not result.rows:
        result.rows.append(Row(('Chưa phát sinh sản lượng trong ca.',),'empty'))
    status.rows.append(Row(('Tổng','','',*status_values(totals),''),'total'))
    from zone_daily import shift_result_total
    result.rows.append(Row(('Tổng mã','','',*result_values(shift_result_total(items)),''),'total'))
    return status,result


def wrap(text,width,measure,size,bold):
    lines=[]
    for paragraph in str(text).split('\n'):
        line=''
        for word in paragraph.split():
            candidate=(line+' '+word).strip()
            if line and measure(candidate,size,bold)>width:
                lines.append(line)
                line=''
            if measure(word,size,bold)>width:
                for char in word:
                    if line and measure(line+char,size,bold)>width:
                        lines.append(line)
                        line=''
                    line+=char
            else:
                line=(line+' '+word).strip()
        lines.append(line)
    return '\n'.join(lines)


def layout(table,measure):
    width=sum(table.widths)
    sheet=Sheet(table,width)
    right=list(accumulate(table.widths))
    left=[0]+right[:-1]
    sheet.right=right
    def cell(x,y,end,bottom,text,fill=WHITE,ink=INK,bold=False,size=12,align='center'):
        sheet.cells.append(Cell((x,y,end,bottom),str(text),fill,ink,bold,size,align))
    title=wrap(table.title,width-24,measure,16,True)
    y=14+22*len(title.splitlines())
    cell(0,0,width,y,title,'#1e405c','#ffffff',True,16,'left')
    labels=[wrap(v,w-8,measure,12,True) for v,w in zip(table.headers,table.widths)]
    stop=y+10+16*max(len(v.split('\n')) for v in labels)
    for i,label in enumerate(labels):
        cell(left[i],y,right[i],stop,label,'#dce8ef',bold=True)
    sheet.bottom=[stop]
    y=stop
    date_blocks=[]
    covered=set()
    for start,end,col,until,*_ in table.spans:
        covered.update((i,j) for i in range(start,end) for j in range(col,until))
    scheme={'total':('#29516a','#ffffff'),'state':('#d8e9e2','#193f37'),
            'date':('#fae8ab','#574318'),'group_date':('#f1f6fa',INK),
            'group_status':('#e2edf3','#153c55'),'material':('#f5f8fa',INK)}
    for index,row in enumerate(table.rows):
        bold=row.kind in ('total','state','date')
        if row.kind=='empty':
            cell(0,y,width,y+30,row.values[0],align='left')
            y+=30
            sheet.bottom.append(y)
            continue
        labels=[wrap(v,w-10,measure,12,bold) if (index,j) not in covered else ''
                for j,(v,w) in enumerate(zip(row.values,table.widths))]
        stop=y+7+16*max(len(v.split('\n')) for v in labels)
        bg,fg=scheme.get(row.kind,(WHITE,INK))
        if row.kind=='state':
            bg,fg=STATE_COLORS.get(row.values[0],(bg,fg))
        for i,label in enumerate(labels):
            if (index,i) in covered:continue
            if i==0 and row.kind=='detail' and table.group_dates:
                date_blocks.append((label,y,stop))
                continue
            if i<3 and row.kind=='total' and table.group_dates:
                if i==0:cell(0,y,right[2],stop,'Tổng',bg,fg,True)
                continue
            header=table.headers[i].replace('\n',' ')
            fill,ink=bg,fg
            if row.kind not in ('state','total','date'):
                note=sh.norm(label) if header=='NOTE' else ''
                if note=='hettonkhoma' or header=='Hết tồn' and label not in ('','0'):
                    fill,ink='#fce6e2','#8a241d'
                elif note=='chuaradon' or label=='Chờ chốt':
                    fill,ink='#ffefcc','#794900'
                elif note=='hangtapket' or header=='Tập kết' and label not in ('','0'):
                    fill,ink='#e7effa','#284b77'
                elif header in ('Hoàn thành','1 phần','Pending') and label not in ('','0'):
                    state={'Hoàn thành':'Done','1 phần':'Partial finished','Pending':'Pending'}[header]
                    fill,ink=STATE_COLORS[state]
                elif header=='Cấp theo giờ' and label not in ('','0'):
                    fill,ink='#deefed','#14554d'
            align='left' if header in ('NOTE','Ghi chú','Mã hàng') else 'center'
            cell(left[i],y,right[i],stop,label,fill,ink,bold,align=align)
        y=stop
        sheet.bottom.append(y)
    for _,seq in groupby(date_blocks,key=lambda rec:rec[0]):
        dates=list(seq)
        cell(0,dates[0][1],right[0],dates[-1][2],dates[0][0],'#edf4f7',bold=True)
    for start,end,col,until,label,style,_ in table.spans:
        fill,ink=scheme[style]
        if style in ('state','group_status'):
            name=label if style=='group_status' else table.rows[start].values[0]
            fill,ink=STATE_COLORS.get(name,(fill,ink))
        cell(left[col],sheet.bottom[start],right[until-1],sheet.bottom[end],label,fill,ink,True)
    sheet.height=y
    return sheet
