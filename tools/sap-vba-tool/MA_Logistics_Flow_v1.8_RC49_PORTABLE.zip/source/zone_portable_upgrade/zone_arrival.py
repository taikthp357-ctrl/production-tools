"""Compare supplier plans, inbound deliveries and BOM components for plant 3093."""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
import re
import zone18 as z
import zone_inbound as sap
from zone_mail import day, quantity


ABSENT_BOM=re.compile(r'no (?:valid |material )*bom|bom .*does not exist|bom .*not found|không có bom',re.I)


def master_at(session,material,usage,key_date):
    try:
        lines=sap.bom_master(session,material,'3093',usage,key_date)
        return lines,('ok' if lines else 'absent'),''
    except Exception as exc:
        message=str(exc)
        return [],('absent' if ABSENT_BOM.search(message) else 'unknown'),message


def check_plans(session, rows, cfg, main, low_percent, expiry_days, assumed_unit=''):
    plant='3093'
    today=date.today()
    cfg={**main, **cfg}
    master_cache={}
    by_ib=list(dict.fromkeys(r['ib'] for r in rows if re.fullmatch(r'185\d{5,7}',r.get('ib',''))))
    data=[]
    lookup_errors={}
    if by_ib:
        try:
            data=sap.vl06i(session,[{'ib':ib} for ib in by_ib],cfg,main)
        except Exception as exc:
            lookup_errors['ib']=str(exc)
    po_requests=[dict(po=r['po'],material=r['material'],qty=r['qty'],plan_lookup=True)
                 for r in rows if not r.get('ib') and r.get('po','').isdigit()]
    if po_requests:
        try:
            data.extend(sap.vl06i(session,po_requests,cfg,main))
        except Exception as exc:
            lookup_errors['po']=str(exc)
    demand=defaultdict(Decimal)
    stock={}
    affected=defaultdict(set)
    components={}
    notes=[[] for r in rows]
    usages=defaultdict(list)
    def note(i,msg):
        if msg and msg not in notes[i]:
            notes[i].append(msg)
    for i,r in enumerate(rows):
        material=r['material']
        if r.get('plant') and r['plant']!=plant:
            note(i,'Ngoài Plant 3093')
            continue
        key_date=day(r.get('delivery')) or day(r.get('arrival_plan'))
        master_key=(material,key_date)
        if master_key not in master_cache:
            usage=cfg.get('bom_usage','1')
            master,state,detail=master_at(session,material,usage,key_date)
            warning=''
            validity=''
            if state!='ok':
                warning=('Thiếu BOM master 3093' if state=='absent' else 'Chưa xác minh BOM 3093')+(' · '+detail if detail else '')
            elif expiry_days:
                horizon=max(today,key_date or today)+timedelta(days=expiry_days)
                future,future_state,detail=master_at(session,material,usage,horizon)
                if future_state=='absent':
                    warning=f'BOM 3093 sắp hết hiệu lực · có ở ngày kiểm, thiếu ở mốc {horizon:%d/%m/%Y}'
                elif future_state=='unknown':
                    warning=f'Chưa xác minh hiệu lực BOM đến {horizon:%d/%m/%Y} · '+detail
                else:
                    validity=f'Có BOM tại ngày kiểm và mốc {horizon:%d/%m/%Y}'
                    changes={m['IDNRK'] for m in master}-{m['IDNRK'] for m in future}
                    if changes:
                        warning=f'Danh mục BOM thay đổi tại {horizon:%d/%m/%Y} · cần đối chiếu '+', '.join(sorted(changes))
            master_cache[master_key]=(master,warning,validity)
        master,err,validity=master_cache[master_key]
        note(i,err)
        for m in master:
            expires=day(m.get('DATUB'))
            if expires and (expires-today).days<=expiry_days:
                note(i,f"Linh kiện {m['IDNRK']} "+('hết hiệu lực' if expires<today else 'sắp hết hiệu lực')+f' {expires:%d/%m/%Y}')
        r['bom_validity']=validity or ('Có ngày kết thúc trong CS03' if any(day(m.get('DATUB')) for m in master) else 'Chưa xác minh thời hạn BOM')
        if r.get('ib') and r['ib'] not in by_ib:
            note(i,'Số IB ngoài dải 185* · xác minh')
            continue
        error=lookup_errors.get('ib' if r.get('ib') else 'po')
        if error:
            note(i,'Lỗi tra VL06I · '+error)
            continue
        if not r.get('po') or not r.get('po_item'):
            note(i,'Thiếu PO/SA hoặc item tham chiếu trên mail')
        hits=[v for v in data if 'sap_status' in v and v.get('material')==material
              and (not r.get('ib') or v['ib']==r['ib'])
              and (r.get('ib') or r.get('po'))
              and (not r.get('po') or sap.digits(v['po'])==sap.digits(r['po']))
              and (not r.get('po_item') or sap.digits(v['po_item'])==sap.digits(r['po_item']))]
        if not hits:
            note(i,'Chưa thấy IB khớp số chứng từ, PO/item và mã hàng')
            continue
        if any(v.get('plant')!=plant for v in hits):
            note(i,'Plant trên IB khác 3093 hoặc chưa hiển thị')
            continue
        ibs={v['ib'] for v in hits}
        if len(ibs)!=1:
            note(i,'Nhiều IB cùng khớp · cần xác nhận')
            continue
        r['sap_ib']=next(iter(ibs))
        r['sap_gr']=' / '.join(sorted({v.get('sap_status') or '?' for v in hits}))
        units={v['unit'].upper() for v in hits}
        unit=r.get('unit','').upper() or assumed_unit
        if not unit or units!={unit}:
            note(i,'Đối chiếu ĐVT mail / IB · SAP '+','.join(sorted(units)))
        identities=[(v['ib'],v['item'],v.get('batch',''),v['material']) for v in hits]
        if any(v['item'].lstrip('0').startswith('9') for v in hits) and any(not v['item'].lstrip('0').startswith('9') for v in hits):
            note(i,'Có item cha và batch split · kiểm tra SL trước khi cộng')
            continue
        if len(set(identities))!=len(hits) or (len(hits)>1 and any(not v['item'] for v in hits)):
            note(i,'Item/batch chưa đủ để cộng số lượng duy nhất')
            continue
        total=sum(z.number(v['qty'],main) for v in hits)
        r['sap_qty']=str(total)+' '+','.join(sorted(units))
        if quantity(r['qty'])!=total:
            note(i,'Lệch SL kế hoạch / IB')
        for identity,v in zip(identities,hits):
            usages[identity].append((i,v))
    for identity,links in usages.items():
        i,v=links[0]
        if len(links)>1:
            for idx,_ in links:
                note(idx,'Nhiều dòng kế hoạch cùng trỏ tới item IB · kiểm tra mail trùng / điều chỉnh')
        try:
            state,lines=sap.bom_ib(session,v,cfg)
        except Exception as exc:
            for idx,_ in links:
                note(idx,'Chưa đọc được BOM trên IB · '+str(exc))
            continue
        master,_,_=master_cache[(v['material'],day(rows[i].get('arrival_plan')))]
        expected={m['IDNRK'] for m in master if m.get('IDNRK')}
        actual={m['IDNRK'] for m in lines}
        for idx,_ in links:
            if not lines:
                note(idx,state)
            if expected-actual:
                note(idx,'Đối chiếu linh kiện master vắng trên IB: '+', '.join(sorted(expected-actual)))
            if actual-expected and expected:
                note(idx,'Linh kiện IB khác master: '+', '.join(sorted(actual-expected)))
        if v['sap_status']=='C':
            for idx,_ in links:
                note(idx,'IB đã hoàn tất GR · đã kiểm danh mục BOM')
            continue
        if v['sap_status']!='A':
            for idx,_ in links:
                note(idx,'GR một phần hoặc chưa rõ · cần SL còn phải nhận')
            continue
        for m in lines:
            # A single balance may only be reused inside the same stock scope.
            scope=v.get('sloc','')
            if cfg.get('stock_per_vendor'):
                scope=(scope+'/'+v['supplier']) if scope and v.get('supplier') else ''
            key=(scope,m['IDNRK'],m['MEINS'])
            for idx,_ in links:
                affected[key].add(idx)
            need=z.number(m['MENGE'],cfg)
            if need<=0 or not key[0] or not key[2]:
                components[key]='Thiếu nhu cầu dương, SLoc hoặc ĐVT'
                continue
            demand[key]+=need
            value=m.get('available')
            if value is None:
                components[key]='Chưa có tồn linh kiện đã xác minh'
            elif key in stock and stock[key]!=Decimal(value):
                components[key]='Tồn đọc được không đồng nhất'
            else:
                stock[key]=Decimal(value)
    for key,indices in affected.items():
        for i in indices:
            if key in components:
                note(i,key[1]+' · '+components[key])
                continue
            remaining=stock[key]-demand[key]
            if remaining<0:
                note(i,f'Thiếu linh kiện {key[1]} · thiếu {-remaining} {key[2]}')
            elif remaining<=demand[key]*Decimal(str(low_percent))/100:
                note(i,f'Sắp hết linh kiện {key[1]} · còn {remaining} {key[2]}')
    for i,r in enumerate(rows):
        r['status']=' | '.join(notes[i]) or 'Khớp kế hoạch · đủ BOM cho các item đã kiểm'
    return rows
