"""Acceptance tests for MA Logistics Flow v1.8 RC49 (prior-shift Partial finished hidden until checkbox ticked)."""
from contextlib import ExitStack
from datetime import date
import os
from pathlib import Path
import sys
import tempfile
import time
import tkinter as tk
from unittest.mock import patch


def wait(root, ready, timeout=4.0):
    end = time.monotonic() + timeout
    while not ready():
        if time.monotonic() > end:
            raise TimeoutError('Timed out waiting for Tk report paint')
        root.update()
        time.sleep(0.01)


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_daily as daily
    import zone_shift as sh
    import zone_workspace as ws

    assert z.VERSION in ('1.8 RC49', '1.8 RC50', '1.8 RC51'), z.VERSION

    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, state, issued, base_qty=None, ca='', model='LIMO', kh='2026-11-27', note='Đã ra đơn, chờ cấp'):
        r = [None] * 35
        r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = mat, 10, 'ST1', '3093', 'P', 'L1', model, 'S6'
        r[22], r[24], r[26], r[27], r[31], r[32] = issued, state, kh, note, ca, base_qty
        return r

    # 1. Logic check: untouched S7->S6 partial (AF='1', issued==base_qty) stays 0 when unchecked, shows when ticked;
    #    once current shift supplies more (issued > base_qty) OR creates a new partial (AF=''), it shows even when unchecked.
    shift_id = (date(2026, 11, 27), 'S6')
    r_untouched = mk_row('P_S7_IDLE', 'Partial finished', issued=4, base_qty=4, ca='1')
    r_progressed = mk_row('P_S7_INC', 'Partial finished', issued=6, base_qty=4, ca='1', model='VF5')
    r_fresh_pend = mk_row('P_PEND', 'Pending', issued=0, base_qty=0, ca='', model='VF6', note='Chưa ra đơn')
    tbl = [header, r_untouched, r_progressed, r_fresh_pend]

    _, piv_off = daily.pivot(tbl, full=False, all_rows=False, options={'filters': {31: ['']}}, identity=shift_id)
    t_off = {vals[0]: vals[-1] for vals, tag, _ in piv_off if tag in ('state', 'total')}
    assert t_off == {'Done': 0, 'Partial finished': 1, 'Pending': 1, 'Tổng cộng': 2}, t_off

    _, piv_on = daily.pivot(tbl, full=False, all_rows=True, options={'filters': {31: ['']}}, identity=shift_id)
    t_on = {vals[0]: vals[-1] for vals, tag, _ in piv_on if tag in ('state', 'total')}
    assert t_on == {'Done': 0, 'Partial finished': 2, 'Pending': 1, 'Tổng cộng': 3}, t_on
    assert not any(tag == 'detail' and any(sh.state(r[1]) == sh.PART for r in recs) for _, tag, recs in piv_on)
    _, piv_full = daily.pivot(tbl, full=True, all_rows=True, options={'filters': {31: ['']}}, identity=shift_id)
    assert any(tag == 'detail' and any(sh.state(r[1]) == sh.PART for r in recs) for _, tag, recs in piv_full)

    # 2. Pure untouched S6 start (0 progressed partials): unchecked => Tổng Partial finished == 0; ticked => shows carried 2 rows
    tbl_clean = [
        header,
        mk_row('P_S7_1', 'Partial finished', issued=3, base_qty=3, ca='1', model='LIMO'),
        mk_row('P_S7_2', 'Partial finished', issued=5, base_qty=5, ca='1', model='VF6'),
        mk_row('PEND_1', 'Pending', issued=0, base_qty=0, ca='', model='VF5', note='Chưa ra đơn'),
    ]
    with tempfile.TemporaryDirectory() as tmp:
        z._SCHEMA_READY.clear()
        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': False}))
            os.environ['LOCALAPPDATA'] = tmp
            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                wb = Path(tmp) / '261127_THEO DOI ORDER NVL_P_S6.xlsb'
                wb.write_bytes(b's6')
                page = app.shift_page
                page.activate(wb, None, (tbl_clean, (1, 1, 0, 0)))
                rep_tab = next(t for t in app.notebook.tabs() if 'báo cáo' in app.notebook.tab(t, 'text').lower())
                app.notebook.select(rep_tab)
                rep = page.reporting
                wait(root, lambda: bool(rep.sheets) and not rep.computing)

                assert rep.all.get() is False and rep.full.get() is False
                rows_off = rep.sheets[0].table.rows
                tot_off = {r.values[0]: r.values[-1] for r in rows_off if r.kind in ('state', 'total')}
                assert tot_off == {'Done': 0, 'Partial finished': 0, 'Pending': 1, 'Tổng cộng': 1}, tot_off

                rep.all.set(True)
                rep.paint()
                wait(root, lambda: bool(rep.sheets) and not rep.computing)
                rows_on = rep.sheets[0].table.rows
                tot_on = {r.values[0]: r.values[-1] for r in rows_on if r.kind in ('state', 'total')}
                assert tot_on == {'Done': 0, 'Partial finished': 2, 'Pending': 1, 'Tổng cộng': 3}, tot_on
                # Summary row Tổng Partial finished stays right after Tổng Done when Mở Done và cấp một phần is OFF
                assert rows_on[0].values[0] == 'Done' and rows_on[1].values[0] == 'Partial finished' and rows_on[1].kind == 'state', rows_on
                rep.full.set(True)
                rep.paint()
                wait(root, lambda: bool(rep.sheets) and not rep.computing)
                rows_expanded = rep.sheets[0].table.rows
                assert any(r.kind == 'detail' and any(rec[1][3] == 'P_S7_1' for rec in r.key) for r in rows_expanded), rows_expanded
                assert not errors, errors
            finally:
                root.destroy()
                z._SCHEMA_READY.clear()

    print('All RC49 acceptance tests (prior-shift Partial finished excluded until checkbox ticked + in-shift progress included) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
