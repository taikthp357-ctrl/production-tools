"""Acceptance tests for MA Logistics Flow v1.8 RC47 (OUT NVL + BBGN PDF)."""
from contextlib import ExitStack, contextmanager
from datetime import date, datetime
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as mb
from types import SimpleNamespace as S
from unittest.mock import patch


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_bbbg as bbbg
    import zone_cleanup as cleanup_mod
    import zone_excel_live as live
    import zone_mail as mail
    import zone_order_result as order_result
    import zone_qty as qty_mod
    import zone_search as search
    import zone_shift as sh
    import zone_workspace as ws

    assert z.VERSION in ('1.8 RC47', '1.8 RC48', '1.8 RC49', '1.8 RC50', '1.8 RC51'), z.VERSION

    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, state='Pending', kh='2026-11-27', note='Chưa ra đơn', qty=10, issued=0,
               ob1='', sp1='', issued1=None, packing='EA'):
        r = [None] * 35
        r[2], r[3], r[4], r[5] = packing, mat, qty, 'ST1'
        r[6], r[7], r[8], r[9], r[11] = '3093', 'P', 'L1', 'VF5', 'S6'
        r[13], r[14], r[15] = ob1, sp1, issued1
        r[22], r[24], r[26], r[27] = issued, state, kh, note
        r[28], r[29], r[30] = date(2026, 11, 27), 0.3, 'Trung'
        return r

    sched = {'day_start': '06:00', 'night_start': '18:00'}

    # 1. ODBS · theo Plan on live running shift from 06:00 (0-minute gap), explicit ODBS vs pre-shift normal OD
    m_plan_start = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td><td>Ca</td></tr>'
                 '<tr><td>MAT_PLAN_0600</td><td>10</td><td>P</td><td>ST1</td><td>27.11.2026</td><td>S6</td></tr></table>',
        Body='Dear team WH\nSX gửi OD theo KHSX plan cho S6 ngày 27.11.2026',
        Subject='OD NVL VF5 cho KHSX ngày 27.11.2026 ca S6',
        SenderName='Trung',
        EntryID='m_plan_0600',
        ReceivedTime=datetime(2026, 11, 27, 6, 0),
    ), 'out')
    assert mail.natural_odbs_kind(m_plan_start, m_plan_start['rows'][0], sched) == 'plan'
    assert mail.is_natural_odbs(m_plan_start, m_plan_start['rows'][0], sched)
    assert mail.row_note_text(m_plan_start) == 'ODBS · theo Plan'

    m_explicit = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td><td>Ca</td></tr>'
                 '<tr><td>MAT_EXPLICIT</td><td>10</td><td>P</td><td>ST1</td><td>27.11.2026</td><td>S6</td></tr></table>',
        Body='Dear WH\nEm gửi ODBS cho ca S6 ngày 27',
        Subject='ODBS VF5 27.11',
        SenderName='Phuc',
        EntryID='m_explicit',
        ReceivedTime=datetime(2026, 11, 27, 5, 55),
    ), 'out')
    assert mail.natural_odbs_kind(m_explicit, m_explicit['rows'][0], sched) == 'odbs'
    assert mail.row_note_text(m_explicit) == 'ODBS'

    m_preshift = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td><td>Ca</td></tr>'
                 '<tr><td>MAT_PRESHIFT</td><td>10</td><td>P</td><td>ST1</td><td>27.11.2026</td><td>S6</td></tr></table>',
        Body='Dear WH\nSX gửi OD theo plan cho S6 ngày 27.11.2026',
        Subject='OD theo plan S6 27.11',
        SenderName='Trung',
        EntryID='m_preshift',
        ReceivedTime=datetime(2026, 11, 26, 21, 10),
    ), 'out')
    assert mail.natural_odbs_kind(m_preshift, m_preshift['rows'][0], sched) == ''
    assert not mail.is_natural_odbs(m_preshift, m_preshift['rows'][0], sched)

    # 2. Decimal arithmetic precision in zone_shift.plan & zone_search.fifo_quantities (no float drift)
    r_dec = mk_row('MAT_DEC', state='Partial finished', kh='2026-11-27', note='Cấp một phần', qty=0.3, issued=0.1)
    planned_fifo = sh.plan([header, r_dec], None, None, sh.FIFO, {'plant': '3093', 'sloc_from': 'P', 'sloc_to': 'L1'})
    assert len(planned_fifo) == 1 and planned_fifo[0]['qty'] == 0.2, planned_fifo
    r_dec_box = mk_row('MAT_DEC_BOX', state='Partial finished', kh='2026-11-27', note='Cấp một phần',
                       qty=10.3, issued=0.1, packing='10')
    planned_short = sh.plan([header, r_dec_box], None, None, sh.SHORT_BOX,
                            {'plant': '3093', 'sloc_from': 'P', 'sloc_to': 'L1'})
    assert len(planned_short) == 1 and planned_short[0]['boxes'] == 2 and planned_short[0]['qty'] == 20, planned_short
    fifo_res = search.fifo_quantities([
        {'kh': '2026-11-27', 'row': 2, 'ordered': 0.3, 'issued': 0.1, 'pack': 0, 'material': 'MAT_DEC', 'station': 'ST1'},
        {'kh': '2026-11-27', 'row': 3, 'ordered': 0.1, 'issued': 0, 'pack': 1, 'material': 'MAT_DBOX', 'station': 'ST1'},
        {'kh': '2026-11-27', 'row': 4, 'ordered': 0.2, 'issued': 0, 'pack': 1, 'material': 'MAT_DBOX', 'station': 'ST1'},
    ])
    assert fifo_res[0]['qty'] == 0.2 and fifo_res[2]['boxes'] == 1 and fifo_res[2]['qty'] == 0.9, fifo_res

    # 3. Merged-OB slot support in zone_qty + multi-batch INWH slip extension in zone_order_result.edits
    r_merged = mk_row('MAT_MERGED', state='Partial finished', kh='2026-11-27', note='Cấp một phần',
                      qty=100, issued=40, ob1='1012345678/1012345679', sp1='26-01', issued1=40)
    assert qty_mod.usable(r_merged, 13)
    otable = qty_mod.OrderTable([header, r_merged])
    key_merged = next(iter(otable.by_key))
    assert (key_merged, 13) in otable.tickets
    derived_state, derived_note = qty_mod.derived(r_merged)
    assert derived_state == 'Partial finished' and derived_note == 'Cấp một phần', (derived_state, derived_note)
    r_merged_wait = mk_row('MAT_MERGED', state='Pending', kh='2026-11-27', note='Chưa ra đơn',
                           qty=100, issued=0, ob1='1012345678/1012345679', sp1='26-01', issued1=None)
    assert qty_mod.derived(r_merged_wait) == ('Pending', 'Đã ra đơn, chờ cấp')

    r_who = mk_row('MAT_WHO', state='Pending', kh='2026-11-27', note='Đã ra đơn, chờ cấp',
                   qty=100, issued=0, ob1='1013301111', sp1='26-01', issued1=None)
    t_who = [header, r_who]
    key_who = next(k for _, _, k in sh.indexed(t_who))
    edits_ok = order_result.edits(t_who, [{
        'source': {'origin': key_who, 'row': 2},
        'pairs': [('1013301111', '26-01/26-02')],
        'valid': True,
        'mock': False,
    }])
    assert edits_ok == {2: [(15, '26-01/26-02')]}, edits_ok
    try:
        order_result.edits(t_who, [{
            'source': {'origin': key_who, 'row': 2},
            'pairs': [('1013301111', '26-03')],
            'valid': True,
            'mock': False,
        }])
    except ValueError as exc:
        assert 'số đơn khác' in str(exc)
    else:
        raise AssertionError('Unrelated INWH slip on existing OB must raise ValueError')

    # 4. MailPage deleted copy_saved + ODBS · theo Plan UI/handover + Cleanup Ctrl+F + Cancel OB clipboard + BBBG issue note
    with tempfile.TemporaryDirectory() as tmp:
        z._SCHEMA_READY.clear()
        tmp_dir = Path(tmp)
        s7_path = tmp_dir / '261126_THEO DOI ORDER NVL_P_S7.xlsb'
        s6_path = tmp_dir / '271126_THEO DOI ORDER NVL_P_S6.xlsb'
        s7_path.write_bytes(b's7')
        s6_path.write_bytes(b's6')

        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': False}))
            stack.enter_context(patch.object(mail, 'prior_files', return_value=([], [])))
            stack.enter_context(patch.object(mail, 'closed_entries', return_value=[]))
            stack.enter_context(patch.object(mb, 'showinfo'))
            os.environ['LOCALAPPDATA'] = tmp

            # Persist one ODBS · theo Plan row in S7 and pre-seed another ODBS link in S6 to verify unconditional inherit_odbs
            r_plan = mk_row('MAT_PLAN_0600', kh='2026-11-27', note='Chưa ra đơn', qty=10)
            r_pre = mk_row('MAT_PRE', kh='2026-11-27', note='Chưa ra đơn', qty=5)
            tok_plan = mail.mail_token(m_plan_start, 0)
            tok_pre = mail.mail_token(m_explicit, 0)
            mail.odbs_links(s7_path, [('plan:' + tok_plan, 'order:' + mail.order_bindings([header, r_plan])[2][0])])
            mail.odbs_links(s6_path, [(tok_pre, 'order:' + mail.order_bindings([header, r_pre])[2][0])])

            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                page = app.shift_page
                s6_raw = [header, r_plan, r_pre]
                page.auto_base = (s6_path, (s7_path, [header, r_plan]))
                page.activate(s6_path, None, (s6_raw, (1, 1, 0, 0)))
                root.update()

                # Both inherited 'plan' row and pre-existing row are active; MAT_PLAN_0600 renders 'ODBS · theo Plan' while Excel cell stays 'Chưa ra đơn'
                row_values = {row[1]: row for row in page.tree.rows}
                assert 'MAT_PLAN_0600' in row_values, page.tree.rows
                assert 'ODBS · theo Plan · Chưa ra đơn' in row_values['MAT_PLAN_0600'], row_values['MAT_PLAN_0600']
                assert 'ODBS · theo Plan' in row_values['MAT_PLAN_0600'][-1], row_values['MAT_PLAN_0600']
                assert r_plan[27] == 'Chưa ra đơn'

                # Deleted copy_saved row must surface 'Cần đối chiếu' & warn (NOT Done · 0 mail cần xem)
                msg_deleted = {
                    'id': 'M_DEL', 'received': '2026-11-27 08:00:00', 'sender': 'Trung', 'subject': 'OD XOA 27/11',
                    'issues': [], 'skipped': 0, 'plan_counts': {'2026-11-27': {'H': 0}},
                    'rows': [{'material': 'MAT_DELETED', 'qty': '15', 'warehouse': 'P', 'model': 'VF5',
                              'plan': '2026-11-27', 'station': 'ST1', 'leader': '', 'person': 'Trung',
                              'production_shift': 'S6', 'mail_token_v2': 'tok_deleted_1'}]
                }
                mail.receipts(tmp_dir, ['tok_deleted_1'])
                with patch.object(live, 'find', return_value=None):
                    app.out_mail.audit([msg_deleted], {}, app.out_mail.cfg, current=[header])
                del_row = msg_deleted['rows'][0]
                assert del_row['match_state'] == 'review', del_row
                dates, choice, groups, summary, _ = app.out_mail.build_view([msg_deleted], 'Tất cả', [header], {})
                assert groups['M_DEL'][4] == 'warn' and '1 mail cần xem' in summary and 'Done ·' not in groups['M_DEL'][3][2], (groups['M_DEL'], summary)
                app.out_mail.messages = [msg_deleted]
                app.out_mail.groups = groups
                app.out_mail.expanded = {'M_DEL'}
                app.out_mail.show_groups()
                assert any('Cần đối chiếu · App từng ghi nhưng hiện thiếu trong ORDER' in str(r) for r in app.out_mail.tree.rows), app.out_mail.tree.rows

                # Incomplete missing-person & missing-Kho rows stay 'review'
                msg_inc = {
                    'id': 'M_INC', 'received': '2026-11-27 08:05:00', 'sender': 'Trung', 'subject': 'OD THIEU NGUOI',
                    'issues': [], 'skipped': 0, 'plan_counts': {'2026-11-27': {'H': 0}},
                    'rows': [
                        {'material': 'MAT_NO_PERSON', 'qty': '5', 'warehouse': 'P', 'model': 'VF5',
                         'plan': '2026-11-27', 'station': 'ST1', 'leader': '', 'person': '',
                         'production_shift': 'S6', 'mail_token_v2': 'tok_inc_1',
                         'match_state': 'review', 'status': 'Thiếu người OD'},
                        {'material': 'MAT_NO_KHO', 'qty': '5', 'warehouse': '', 'model': 'VF5',
                         'plan': '2026-11-27', 'station': 'ST1', 'leader': '', 'person': 'Trung',
                         'production_shift': 'S6', 'mail_token_v2': 'tok_inc_2'},
                    ]
                }
                with patch.object(live, 'find', return_value=None):
                    mail.audit_workbooks([msg_inc], s6_path, None, {}, {}, current=[header],
                                         schedule=app.out_mail.cfg, scan_gaps={'files': [], 'errors': [], 'rows': []})
                assert msg_inc['rows'][0]['match_state'] == 'review', msg_inc['rows'][0]
                assert msg_inc['rows'][1]['match_state'] == 'review', msg_inc['rows'][1]

                # Concurrency guards: auto() skips while running; refresh_cached_mail reschedules when running
                app.is_running = True
                scheduled = []
                with patch.object(app.out_mail, 'scan', side_effect=AssertionError('auto() must skip when app.is_running')):
                    app.out_mail.auto()
                app.out_mail.audit_pending = True
                with patch.object(app.root, 'after', side_effect=lambda ms, fn: scheduled.append((ms, fn))):
                    app.out_mail.refresh_cached_mail()
                assert app.out_mail.audit_pending and scheduled and scheduled[0][0] == 300
                app.is_running = False

                # CleanupView.leave() rebinds <Control-f> back to page.quick_entry without TclError
                app.show_order_page()
                app.mock_mode_var.set(False)
                cleanup_mod.cleanup_dialog(page)
                assert page.cleanup is not None
                root.update()
                page.cleanup.leave()
                assert page.cleanup is None
                root.update()
                root.focus_force()
                page.tree.focus_set()
                root.update()
                assert root.focus_get() is page.tree, root.focus_get()
                page.tree.event_generate('<Control-f>')
                root.update()
                assert root.focus_get() is page.quick_entry, root.focus_get()

                # Cancel OD 'Copy OB để cancel' copies OB cleanly without zone_clipboard.copy_html error
                r_cancel = mk_row('MAT_CANCEL', state='Pending', kh='2026-11-27', note='Đã ra đơn, chờ cấp',
                                  qty=10, ob1='1019998888', sp1='26-09')
                page.table = qty_mod.OrderTable([header, r_cancel])
                page._row_lookup = page.table.by_key
                page.stamp = sh.signature(s6_path)
                page.revision += 1
                msg_cancel = {
                    'id': 'M_CANC', 'received': '2026-11-27 10:00:00', 'sender': 'Trung',
                    'subject': 'CANCEL OD NVL MAT_CANCEL 27.11', 'issues': ['Cancel OD'],
                    'cancel_mail': True, 'skipped': 0, 'plan_counts': {'2026-11-27': {'H': 0}},
                    'rows': [{'material': 'MAT_CANCEL', 'qty': '10', 'warehouse': 'P', 'model': 'VF5',
                              'plan': '2026-11-27', 'station': 'ST1', 'leader': '', 'person': 'Trung',
                              'production_shift': 'S6', 'mail_token_v2': 'tok_c_1'}]
                }
                app.out_mail.audit_revision = page.revision
                app.out_mail.audit_table = page.table
                app.out_mail.audit_path = str(s6_path)
                app.out_mail.needs_paint = False
                app.out_mail.display = {('M_CANC',): (msg_cancel, None)}
                app.out_mail.tree.selection = lambda: (('M_CANC',),)
                before_wins = set(root.winfo_children())
                app.out_mail.revise()
                root.update()
                dlg = next(w for w in root.winfo_children() if w not in before_wins and isinstance(w, tk.Toplevel))
                copy_btn = None
                def find_btn(w):
                    nonlocal copy_btn
                    for c in w.winfo_children():
                        if isinstance(c, ttk.Button) and str(c.cget('text')) == 'Copy OB để cancel':
                            copy_btn = c
                        find_btn(c)
                find_btn(dlg)
                assert copy_btn is not None
                copy_btn.invoke()
                root.update()
                assert '1019998888' in root.clipboard_get(), root.clipboard_get()
                dlg.destroy()

                # zone_bbbg.issue preserves 'Chỉ lập BBBG' NOTE on ORDER row instead of overwriting it
                r_chi_bbbg = mk_row('MAT_CHILAP', state='Pending', kh='2026-11-27', note='Chỉ lập BBBG', qty=25)
                issue_tbl = [header, r_chi_bbbg]
                key_chi = next(k for _, _, k in sh.indexed(issue_tbl))
                page.table = qty_mod.OrderTable(issue_tbl)
                page._row_lookup = page.table.by_key
                page.path = s6_path
                class MockCell:
                    def __init__(self):
                        self.Value2 = None
                        self.HasFormula = False
                mock_cells = {}
                class MockSheet:
                    def Cells(self, n, col):
                        return mock_cells.setdefault((n, col), MockCell())
                    def Calculate(self):
                        for (_, _col), c in mock_cells.items():
                            pass
                mock_book = S(Save=lambda: None)
                @contextmanager
                def mock_writable(*_a):
                    yield mock_book, MockSheet(), True
                with patch.object(bbbg, 'writable_order', side_effect=mock_writable), \
                     patch.object(sh, 'values', return_value=issue_tbl), \
                     patch.object(bbbg, 'render', side_effect=lambda t, items, dest, *a, **k: Path(dest).write_bytes(b'%PDF-1.4\n')):
                    files = bbbg.issue(page, tmp_dir / 'tpl.xlsx', {key_chi: 25}, '2026-11-27', False,
                                       sender_info={'name': 'A', 'emp_id': '1', 'dept': 'Kho', 'title': 'NV', 'phone': '09'},
                                       receiver_info={'dept': 'Sản xuất'}, internal_prod=True)
                    assert len(files) == 1
                    assert mock_cells[(2, 15)].Value2 == 'BBBG-01'
                    assert mock_cells[(2, 28)].Value2 == 'Chỉ lập BBBG', mock_cells[(2, 28)].Value2

                assert not errors, errors
            finally:
                root.destroy()
                z._SCHEMA_READY.clear()

    # 5. BBGN PDF export: switched ActivePrinter + real Excel COM export preserving Windows default printer
    assert bbbg._pdf_printer_name().lower().startswith('microsoft print to pdf on '), bbbg._pdf_printer_name()
    fake_app = S(ActivePrinter='HPRT N41(1) on Ne01:')
    fake_book = S(Application=fake_app)
    restored = bbbg._switch_pdf_printer(fake_book)
    assert restored is not None and fake_app.ActivePrinter.lower().startswith('microsoft print to pdf')
    restored[0].ActivePrinter = restored[1]
    assert fake_app.ActivePrinter == 'HPRT N41(1) on Ne01:'

    real_tpl = Path(r'C:\Users\taikt\.gemini\antigravity\brain\a0f42e3e-18fc-421c-98a4-d5270ce26da2\.user_uploaded\media_1795679674654_90875b7c.xlsx')
    if real_tpl.is_file():
        import win32print
        default_before = win32print.GetDefaultPrinter()
        with tempfile.TemporaryDirectory() as tmp:
            tpl_copy = Path(tmp) / 'FVN_SX_KHO03.06.02.xlsx'
            shutil.copy2(real_tpl, tpl_copy)
            pdf_out = Path(tmp) / 'BBBG-01.pdf'
            bbbg.render(
                tpl_copy,
                [(['LTV', None, None, 'BIW25111743AA', 50, 'CO2Kiểm'], 50)],
                pdf_out,
                'BBBG-01',
                '2026-11-27',
                {'name': 'Phạm Tiến Tài', 'emp_id': '3740570', 'dept': 'Kho', 'title': 'Data', 'phone': '0934243740'},
                {'dept': 'Sản xuất'},
                internal_prod=True,
                approver_name='',
            )
            data = pdf_out.read_bytes()
            assert data.startswith(b'%PDF-') and len(data) > 10000, len(data)
            pages = len(re.findall(rb'/Type\s*/Page(?![sA-Za-z])', data))
            assert pages == 1, f'Expected 1 A4 page, got {pages}'
        default_after = win32print.GetDefaultPrinter()
        assert default_after == default_before, (default_before, default_after)

    print('All RC47 acceptance tests (ODBS · theo Plan live-shift & handover, Decimal FIFO, merged-OB & INWH multi-batch, deleted copy_saved guard, Ctrl+F focus restore, Cancel OB clipboard, Ch\u1ec9 l\u1eadp BBBG preserve & real COM A4 PDF) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
