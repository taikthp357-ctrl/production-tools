"""Acceptance tests for MA Logistics Flow v1.8 RC51 (A4 Portrait top-pinned BBGN layout)."""
from contextlib import contextmanager
from pathlib import Path
import re
import shutil
import sys
import tempfile
from types import SimpleNamespace as S
from unittest.mock import patch


def make_portrait_fake_sheet():
    class FakeFont:
        def __init__(self, size=11):
            self.Bold = False
            self.Size = size

    class FakeBorder:
        def __init__(self):
            self.LineStyle = -4142
            self.Weight = 2

    class FakeCell:
        def __init__(self, r, c, value=None):
            self.r, self.c = r, c
            self.Value2 = value
            self.NumberFormat = 'General'
            self.HorizontalAlignment = 0
            self.VerticalAlignment = 0
            self.WrapText = False
            self.Font = FakeFont(12 if r >= 33 else 11)
            self.MergeArea = self
            self._borders = {}

        def Cells(self, r, c):
            return self

        def Borders(self, idx):
            return self._borders.setdefault(idx, FakeBorder())

        def ClearContents(self):
            self.Value2 = None

    class FakeRange:
        def __init__(self, hidden_map, label):
            self.hidden_map = hidden_map
            self.label = label
            self.Value2 = None
            self.RowHeight = 28 if str(label) == '1' else 30
            self.Top = 0 if str(label) == '1' else 40
            self.ColumnWidth = 15
            self.Left = (int(label) - 1) * 50 if str(label).isdigit() else 0
            self.Width = 50

        @property
        def Hidden(self):
            return self.hidden_map.get(self.label, False)

        @Hidden.setter
        def Hidden(self, val):
            self.hidden_map[self.label] = bool(val)

        @property
        def MergeArea(self):
            return self

        def ClearContents(self):
            self.Value2 = None

    class FakeSheet:
        def __init__(self):
            self.cells = {}
            self.rows_map = {}
            self.cols_map = {}
            self.hidden_log = {}
            self.exported = []
            self.PageSetup = S(
                LeftHeader='', CenterHeader='', RightHeader='old',
                LeftFooter='', CenterFooter='Page &P of &N', RightFooter='',
                Zoom=100, FitToPagesWide=1, FitToPagesTall=1,
                PrintArea='', PaperSize=9, Orientation=2,
                LeftMargin=36, RightMargin=36, TopMargin=36, BottomMargin=36,
                HeaderMargin=18, FooterMargin=18,
                CenterHorizontally=False, CenterVertically=True,
            )
            self.Shapes = [S(Top=2.2, Left=999.5, Width=81.1, Height=46.7, Placement=1, TopLeftCell=S(Row=1, Column=11))]
            defaults = {
                (11, 11): 'Ghi chú (nếu có)',
                (12, 2): 'Mã Hàng Hóa (Part No.)',
                (12, 3): 'Tên/ Batch hoặc Serial',
                (31, 1): 'Tổng (Total)',
                (33, 6): 'An ninh xác nhận\n(Security Signature)',
                (34, 1): 'Người bàn giao (Handoverer)',
                (34, 3): 'Phê duyệt (Approval)',
                (35, 1): 'Họ và Tên:\n(Full name)',
                (35, 3): 'Họ và Tên:\n(Full name)',
                (35, 6): 'Họ và Tên:\n(Full name)',
                (35, 8): 'Họ và Tên:\n(Full name)',
                (4, 3): 'BÊN BÀN GIAO',
                (4, 7): 'BÊN NHẬN BÀN GIAO',
                (5, 1): 'Họ và Tên:',
                (6, 1): 'Mã NV:',
                (7, 1): 'Bộ Phận:',
                (8, 1): 'Chức vụ:',
                (9, 1): 'Số điện thoại:',
            }
            for (r, c), v in defaults.items():
                self.cells[(r, c)] = FakeCell(r, c, v)

        def Cells(self, r, c):
            if (r, c) not in self.cells:
                self.cells[(r, c)] = FakeCell(r, c)
            return self.cells[(r, c)]

        def Range(self, addr):
            return FakeRange(self.hidden_log, addr)

        def Rows(self, label):
            return self.rows_map.setdefault(str(label), FakeRange(self.hidden_log, str(label)))

        def Columns(self, c):
            return self.cols_map.setdefault(str(c), FakeRange(self.hidden_log, str(c)))

        def ExportAsFixedFormat(self, fmt, path):
            self.exported.append((fmt, path))

    return FakeSheet()


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import zone18 as z
    import zone_bbbg as bbbg
    import zone_shift as sh

    assert z.VERSION == '1.8 RC51', z.VERSION

    # 1. Mocked sheet verifies Portrait (Orientation=1), top-aligned (CenterVertically=False), footer cleared, G31 total, F33 Font 10
    sheet = make_portrait_fake_sheet()
    @contextmanager
    def fake_book(*_a):
        yield S(Worksheets=[sheet])
    sender = {'name': 'Phạm Tiến Tài', 'emp_id': '3740570', 'dept': 'Kho', 'title': 'Data', 'phone': '934243740'}
    items_2 = [
        (['GESTAMP AUTOMOTIVE', None, None, 'BIW71003037AB', 50, 'Hùng/Vĩ'], 50),
        (['GESTAMP AUTOMOTIVE', None, None, 'BIW71003038AB', 30, 'Hùng/Vĩ'], 30),
    ]
    with patch.object(sh, 'excel_book', side_effect=fake_book):
        bbbg.render(Path('t.xlsx'), items_2, Path('BBBG-01.pdf'), 'BBBG-01', '2026-11-27', sender, {'dept': 'Sản xuất'}, True)

    ps = sheet.PageSetup
    assert ps.PaperSize == 9 and ps.Orientation == 1, (ps.PaperSize, ps.Orientation)
    assert ps.CenterHorizontally is True and ps.CenterVertically is False
    assert ps.LeftMargin == 10 and ps.TopMargin == 10 and ps.HeaderMargin == 4 and ps.FooterMargin == 4
    assert ps.CenterFooter == '' and ps.RightHeader == ''
    assert ps.FitToPagesWide == 1 and ps.FitToPagesTall == 1 and ps.PrintArea == '$A$1:$K$36'
    assert sheet.Cells(31, 7).Value2 == 80 and sheet.Cells(31, 7).Font.Bold is True
    assert sheet.Cells(33, 6).Font.Size == 10
    assert sheet.Cells(13, 3).WrapText is True and sheet.Cells(13, 3).HorizontalAlignment == -4108
    assert sheet.cols_map['3'].ColumnWidth == 22.0 and sheet.cols_map['4'].ColumnWidth == 16.0 and sheet.cols_map['7'].ColumnWidth == 16.0

    # 2. Real Excel COM test: export BOTH 1-item (5 kept rows) and 18-item BBGN slips as A4 Portrait pinned at top
    real_tpl = Path(r'C:\Users\taikt\.gemini\antigravity\brain\a0f42e3e-18fc-421c-98a4-d5270ce26da2\.user_uploaded\media_1795679674654_90875b7c.xlsx')
    if real_tpl.is_file():
        with tempfile.TemporaryDirectory() as tmp:
            tpl_copy = Path(tmp) / 'FVN_SX_KHO03.06.02.xlsx'
            shutil.copy2(real_tpl, tpl_copy)

            for label, items_list, expected_sum in (
                ('BBBG-01', [(['GESTAMP AUTOMOTIVE', None, None, 'BIW71003037AB', 180, 'NVL chạy FG · Hùng/Vĩ'], 180)], 180),
                ('BBBG-02', [(['GESTAMP AUTOMOTIVE', None, None, f'BIW710030{idx:02d}AB', 10, 'KV03'] , 10) for idx in range(1, 19)], 180),
            ):
                pdf_out = Path(tmp) / f'{label}.pdf'
                bbbg.render(tpl_copy, items_list, pdf_out, label, '2026-11-27', sender, {'dept': 'Sản xuất'}, True)
                data = pdf_out.read_bytes()
                assert data.startswith(b'%PDF-') and len(data) > 10000
                pages = len(re.findall(rb'/Type\s*/Page(?![sA-Za-z])', data))
                assert pages == 1, f'{label}: expected 1 Portrait page, got {pages}'
                boxes = re.findall(rb'/MediaBox\s*\[\s*0\s+0\s+([0-9.]+)\s+([0-9.]+)\s*\]', data)
                assert boxes, f'{label}: MediaBox missing'
                w_pt, h_pt = float(boxes[0][0]), float(boxes[0][1])
                assert w_pt < h_pt and 590 <= w_pt <= 600 and 838 <= h_pt <= 846, f'{label}: expected A4 Portrait 595x842, got {w_pt}x{h_pt}'
                try:
                    from pypdf import PdfReader
                    txt = PdfReader(str(pdf_out)).pages[0].extract_text()
                    assert label in txt and str(expected_sum) in txt
                    assert 'Page 1 of 1' not in txt, f'{label}: unwanted footer Page 1 of 1 remains'
                except ImportError:
                    pass

    print('All RC51 acceptance tests (A4 Portrait 595x842 top-pinned layout, column balancing, F33 wrap/font, G31 Total, clean footer & 18-row fit) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
