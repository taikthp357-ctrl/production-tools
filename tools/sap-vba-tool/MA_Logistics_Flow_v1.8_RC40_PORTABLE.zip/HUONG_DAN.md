# MA Logistics Flow Portable 1.8 RC40

Giải nén gói, mở **MA_Logistics_Flow.exe** và kiểm tra tiêu đề **Portable 1.8 RC40**. Trong **OUT NVL → Tra cứu KHSX / Model**, mở **Nhập SL…** khi đã chọn ca và đã tắt Mô phỏng.

## Thao tác trong RC40

- **OUT NVL → Tra cứu KHSX / Model → Dọn OD theo ngày…**. Chọn ngày KHSX, chọn các dòng Pending hoặc Cấp một phần cần đóng rồi bấm **Đóng các dòng chọn**. App hiển thị SL ORDER, đã cấp, còn thiếu và OB. Nếu một dòng có OB chờ cấp, cần đối soát lượt đó trước khi đóng. Sheet **OD_DA_DONG** lưu nội dung trước khi dọn, gồm cả lượng đã cấp.
- **OUT NVL → Check mail OD** nhận diện ODBS khi tiêu đề hoặc ghi chú dòng có dấu hiệu rõ như “ODBS” hoặc “OD bổ sung”. Với mail tiêu đề OD thông thường nhưng phát sinh bổ sung trong ca, chọn thư hoặc dòng kho P, bấm **Xác nhận ODBS…**. Nếu đang lọc ngày KHSX, chỉ xác nhận những dòng của ngày đang xem. Dùng **Tình trạng → ODBS** trong **Tra cứu KHSX / Model**. Ví dụ app hiện **ODBS · Chưa ra đơn**, còn NOTE trong Excel vẫn là **Chưa ra đơn**. Nhãn lưu trong dữ liệu ứng dụng trên máy.
- **Cấu hình → Mail OD** chứa thư mục Outlook, chu kỳ tự quét, số ngày quét lại, mật khẩu file ca và giờ bắt đầu S6/S7. Bấm **Lưu cấu hình** để áp dụng. Khoảng **Nhận từ … đến …** vẫn chọn ngay tại Check mail OD cho mỗi lượt quét. Có thể chuyển tab khi quét hoặc đọc đối chiếu ORDER.
- **Báo cáo** đặt nút **Chọn ORDER bàn giao…** ở mép phải thanh trên. **Kết quả ra đơn…** mở danh sách kết quả do app tạo cho file ca đang chọn. Khi có kết quả, có thể tra/in OB hoặc ghi OB và số đơn vào ORDER.

## Báo cáo và hàng HSD trong RC39

- Trong từng ngày KHSX, hai bảng của **Báo cáo cuối ca** xếp theo Ca SX từ S1, S2, S3, S6 đến S7, sau đó theo model trong cùng nhóm ca. Dòng chạy nhiều ca xếp theo ca đầu tiên. Ví dụ VF8 chạy S1/S3 được giữ trên một dòng trong nhóm bắt đầu từ S1. Dòng thiếu thông tin ca nằm cuối ngày. Khi sao chép, xuất ảnh và lưu cuối ca vào Excel, các dòng giữ cùng thứ tự.
- Vào **Cấu hình → OUT NVL → Danh sách HSD**. Dán một cột mã hoặc nhập file XLSX/XLSM. App đọc sheet đang hoạt động đã lưu trong Excel. Bảng nhiều cột cần có tiêu đề Mã NVL, Mã vật tư hoặc Material ở dòng đầu. Mã có số 0 đầu nên lưu ở định dạng Text. Chọn **Áp dụng → Lưu cấu hình**. App lưu danh sách đã nhập và tự chọn **FIFO + FEFO**. Khi danh mục thay đổi, nhập lại danh sách.
- Khi ra đơn, mã trong danh sách ưu tiên batch có HSD (VFDAT) sớm nhất. Cùng HSD thì ưu tiên ngày giờ nhập sớm hơn. Các mã còn lại theo FIFO. Với lượt xuất có hàng HSD, layout Available Stock cần có cột VFDAT. App báo mã và batch nếu HSD của dòng tồn khả dụng bị thiếu hoặc sai định dạng. Có thể chọn FIFO hoặc FEFO cho toàn bộ mã như ở bản cũ.

## Thao tác trong RC38

- **Báo cáo cấp NVL** đếm từng dòng theo cột Tình trạng cấp đơn và bộ lọc Pivot của sheet Báo Cáo. Chọn KHSX **Tất cả** để gồm ngày cũ. Tích **Cấp một phần ca trước** nếu muốn thêm các dòng Partial bàn giao mang dấu 1 ở cột Ca.
- **Tập kết ca trước** mặc định bỏ chọn. Dòng Pending còn ghi Hàng tập kết và đã có bằng chứng bàn giao sẽ ẩn. Tích ô này để xem lại với nhãn **Tập kết ca trước**. Dòng tập kết vừa phát sinh vẫn hiện. Trên Báo cáo cấp NVL, dòng chưa có mốc giữ trạng thái theo ORDER. Báo cáo cuối ca tiếp tục phân biệt sản lượng phát sinh và số còn thiếu mốc.
- **Tạo file từ ca trước** ghi dấu bàn giao vào bản sao, xóa các cụm Done từ dưới lên rồi kiểm tra số dòng và dấu tập kết trước khi lưu. Với file tạo bằng RC38, dấu bàn giao nằm trong file ca mới. Khi mở file cũ, app tìm đúng ca liền trước và có thể dùng bản bàn giao từng lưu trong lịch sử trên máy nếu file nguồn đã được chuyển đi. Dùng **Chọn ORDER bàn giao…** để chỉ định bản đã chốt khi cần.
- Nếu Excel báo lỗi khi tạo hoặc đọc, xem tên file và bước trong thông báo. Các lỗi thao tác đã ghi nằm ở `data/order_errors.log` trong thư mục ứng dụng. Phiên bản dùng lại mật khẩu chung đã lưu của tài khoản Windows.

## Thao tác trong RC37

Trong Báo cáo cấp NVL hoặc Tổng quan, tích **Ẩn Pending ngày cũ** để ẩn các lượt Pending có KHSX trước ngày bắt đầu ca. Chọn KHSX Tất cả để xem cả Done và cấp một phần của các ngày cũ theo quy tắc ca. Các ca sử dụng gồm S1, S2, S3, S6 và S7.

## Thao tác trong RC36

- Trong Check mail OD, chọn thư hoặc dòng rồi bấm Xác nhận đã copy. Hộp xác nhận hiện số thư và số dòng. Nếu đang lọc theo ngày KHSX, thao tác áp dụng cho các dòng thuộc ngày đang xem. App lưu xác nhận và tiếp tục hiển thị kết quả đối chiếu với ORDER.
- Khi Excel đã lưu và xác minh lô mới, tab Mail cập nhật số dòng đã copy. Dấu xác nhận và dấu đã ghi được dùng khi quét lại hoặc thử ghi lại. Khi quay về tab Mail từ Excel, app có thể đọc lại ORDER đang mở để cập nhật dữ liệu vừa nhập tay.
- Với OD thêm cuối bảng, app tìm dòng cuối có thông tin nghiệp vụ và kiểm tra vùng ghi. Nếu vùng này có dữ liệu lẻ, thông báo chỉ rõ địa chỉ ô để đối chiếu.
- Bỏ tích Tập kết ca trước để loại các lượt đã tập kết theo file bàn giao. Khi các thông tin bàn giao khác cách ghi, app kiểm tra thêm mã, SL, trạm, model, KHSX, OB và số phiếu để nhận diện lượt duy nhất. Lượt chưa đủ căn cứ được trình bày riêng ở dòng Tập kết · chưa xác định ca. Bảng chi tiết một mã luôn có cột Mã NVL.

## Thao tác trong RC35

- Check mail OD đọc cả mẫu SG, VF89 và mẫu tiêu đề US/SG của VF8NP. Mail thiếu Kho cho tra lịch sử trong file ca. Chỉ các dòng xác định kho P mới được chọn để ghi. VF89 có phạm vi VF8 và VF9. Một dòng thư giữ nguyên một lượng yêu cầu.
- Bấm tiêu đề cột để sắp xếp, bấm lại để đảo chiều. Trong bảng mail, dòng con đi cùng thư. Rê chuột vào ô bị cắt hoặc chọn ô rồi nhấn F2 để đọc nguyên văn. Ctrl+C lấy cả nội dung.
- Tại Báo cáo, dùng Chọn ORDER bàn giao để đối chiếu ca trước nếu mở file được lập bằng tay và app chưa tìm được mốc đúng. Bỏ chọn Tập kết ca trước để loại các lượt đã tập kết ở mốc bàn giao. Khi nhiều dòng giống nhau và thiếu dấu nhận diện, app giữ các dòng chưa xác định trong báo cáo.
- Tại OUT NVL, nút Dọn OD quá D+2 mở danh sách OD hết tồn đủ điều kiện. Chọn dòng và xác nhận để lưu lịch sử đóng OD.

## Nhập SL và sao chép

- Trong bảng, chọn ô bằng chuột hoặc bốn phím mũi tên. Ctrl+C sao chép nguyên ô, Ctrl+Shift+C sao chép các dòng đã chọn cùng tiêu đề để dán vào Excel. Khi đang sửa SL, Ctrl+C sao chép chữ đã bôi đen trong ô nhập. Bấm ô SL hoặc Enter ở dòng chọn để sửa. Trong ô tìm, Enter mở lượt đầu của kết quả.
- Với OB ghép, Ctrl+C lấy nguyên chuỗi. Ở bảng ORDER, chuột phải cho chọn từng OB. Trong Outlook, bấm tam giác hoặc dùng Alt+phải/trái để bung hoặc thu thư.
- Khi Excel cùng ca thay đổi, app đối chiếu lại các thư đã đọc. Nếu cửa sổ chi tiết báo ORDER đã cập nhật, mở lại chi tiết. Khi kết quả Tra mã được xóa do dữ liệu đổi, bấm Tra lại.
- Nếu có nhiều file cùng ngày và ca, chọn theo đường dẫn và giờ sửa. Khi nhập tay lượng có dấu phân cách mơ hồ, nhập lại lượng EA rõ ràng, ví dụ 1500 hoặc 1.5.

## Bảng dữ liệu RC33

- Trong **Check mail OD** và **Hàng về / BOM**, bấm ▶ hoặc bấm đúp tiêu đề thư để xem các dòng mã. Khi quét lại, app giữ thư đang bung, dòng đang chọn và vị trí cuộn nếu dòng đó vẫn thuộc kết quả.
- Trong menu **ORDER**, chọn **Dọn OD hết tồn quá D+2**. Bảng ORDER chuyển sang các dòng đủ điều kiện của ngày KHSX đã chọn. Dùng Ctrl hoặc Shift để chọn nhiều dòng. **Quay lại ORDER** khôi phục bộ lọc, lựa chọn và vị trí trước đó. **Đóng các dòng chọn** hiển thị xác nhận trước khi ghi vào Excel.
- Các bảng dữ liệu OUT, IN, BBBG và đối chiếu dùng cách hiển thị của bảng Chi tiết mã · ORDER. Màu tiêu đề, dòng chọn và đường kẻ bám theo cùng vị trí cột khi cuộn ngang.

## Nhập nhiều phiếu

- Gõ mã, trạm, số phiếu hoặc đuôi OB vào ô tìm. Enter mở ô SL ở kết quả đầu tiên theo thứ tự đang hiển thị. Có thể bấm tiêu đề cột để đổi thứ tự.
- Gõ `28+15` rồi Enter để hiện `43` và sang lượt kế tiếp. Shift+Enter đi lên. Ctrl+F quay về ô tìm để nhập tiếp phiếu khác. Ctrl+S lưu toàn bộ ô đã sửa.
- Có thể chuyển sang Check mail OD, quét Outlook rồi quay lại để nhập tiếp. Bộ lọc, vị trí và chữ đang gõ trong ô được giữ khi chuyển tab. Mở thư bằng mũi tên cạnh tiêu đề để xem các dòng.
- Sau khi lưu, dòng trạng thái hiển thị số ô SL đã xác minh. Nếu Excel từ chối ghi hoặc có người sửa dòng đang nhập, xem số dòng, mã và lượt trong thông báo. **Đọc lại ORDER** cho đối chiếu số Excel với số đang nhập. Bản nháp được giữ trong phiên đang mở. Nếu OB của dòng đã đổi, kiểm tra lại phiếu trước khi xử lý tiếp.
- Báo cáo cấp NVL tính số liệu ở nền khi mở tab. Ảnh trong tab KHSX giữ tỉ lệ và vừa cả chiều rộng lẫn chiều cao khi đổi kích thước cửa sổ.

## Kết quả kiểm thử RC32

Bộ thử dùng 419 dòng ORDER, mỗi dòng ba lượt, tổng cộng 1.257 lượt. Giao diện Tk và mã lưu được nạp từ gói EXE. Bộ mô phỏng Excel ghi file XLSX thật bằng openpyxl. Dịch vụ Outlook, SAP và ổ mạng của kho chưa được chạy trực tiếp trên Windows trong lần thử này.

| Trung vị trên cloud | RC31 | RC32 |
|---|---:|---:|
| Mở bảng lần đầu sau khi đã nạp ca, đến khi gõ được | 45,5 ms | 22,1 ms |
| Mở lại bảng, đến khi gõ được | 40,3 ms | 1,6 ms |
| Gõ nhanh cả chuỗi 45776 và Enter, đến khi chọn đúng lượt | 39,3 ms | 2,2 ms |
| Riêng từ sau ký tự cuối, nhấn Enter đến khi chọn đúng lượt | 2,0 ms | 2,1 ms |
| Sau khi bộ ghi XLSX trả về, đến khi ô tìm nhận bàn phím | 129,0 ms | 19,8 ms |

Mỗi phiên bản chạy năm phiên đo hoàn chỉnh, mỗi phiên mở lại bảng năm lần. Dòng đo sau lưu bắt đầu sau thao tác ghi file, nên không bao gồm thời gian Excel thực tế lưu qua UNC. Trong lượt đo thăm dò trước đó, hai tiến trình kiểm thử RC31 trên Linux thoát bất thường. Các số trong bảng lấy từ loạt đo hoàn chỉnh.

Bài thử quét mail song song kiểm tra hai mã cùng OB `1013345776`. Mã thứ nhất nhận `43` ở SL2, mã thứ hai nhận `15` ở SL3 sau một lần lưu. Đã mở lại XLSX để kiểm tra các ô này và các ô kế bên. Các bài thử khác bao gồm SL1, ghi hai dòng liền theo lô, Excel bận, sửa tay gây xung đột, hủy đổi ca để giữ nháp, thu phóng ảnh KHSX, cuộn ngang bảng và mở báo cáo sau khi lưu.

## Khi thử trên máy kho

Dùng bản sao file ca và ghi hai lượt có OB chung. Khi Outlook đang quét, nhập hai SL liên tiếp rồi nhấn Ctrl+S một lần. Mở lại file trong Excel để kiểm tra đúng mã, đúng lượt và đối chiếu thời gian phản hồi qua ổ chung.

## RC31

Đọc **Ke_hoach_RC31.md** để xem thay đổi, cách chọn bộ dữ liệu và các bước kiểm tra trước khi dùng chung. Giải nén gói rồi mở MA_Logistics_Flow.exe.

## RC30

Các bảng chi tiết có đường phân ô. Khi nhập SL thực cấp cho một lượt OB, có thể gõ 28+15 hoặc nhiều số hạng, sau đó Enter để hiện tổng. Ctrl+S lưu số tổng vào SL của lượt đã chọn.

## RC29

Trong Tra cứu KHSX / Model, chọn Nhập SL để cập nhật các phiếu trong toàn file ca. Gõ mã, trạm, số đơn hoặc vài số cuối OB. Chọn dòng để nhập SL của đúng lượt, Enter xuống dòng, Ctrl+F tìm tiếp. Ctrl+S lưu toàn bộ các ô đã sửa. Đọc lại ORDER để xử lý xung đột với Excel và giữ những ô còn đang nhập. Đồng bộ NOTE lệch áp dụng cho các dòng có phiếu hợp lệ. Lượt có nhiều OB ghép chung một ô cần đối soát riêng trong Excel.

## RC28

Lập BBBG dùng mẫu BBGN trên ổ chung và lưu số phiếu vào ORDER của ca đang mở. Dùng Đổi mẫu để chọn thủ công. Phiếu in có giờ lập thực tế. SL nguyên hiển thị gọn. Bảng tra cứu đặt Số đơn, OB và Tình trạng cạnh nhau. Báo cáo sắp xếp NOTE theo tiến trình xử lý trong từng KHSX.

## RC27

Trong Check mail OD, chọn các dòng rồi bấm **Xác nhận đã copy** để đối chiếu với dòng có cùng mã, số lượng, model và KHSX. Bản ghi xác nhận được lưu trong SQLite của app. Giữ thư mục data khi nâng cấp.

Tra mã cho phép hiện lại các dòng đã cấp đủ ngày trước. **Copy gửi SX/TL** tạo tin nhắn theo dòng OD. **Copy bảng** dùng khi dán vào Excel. Trong báo cáo cấp NVL, dùng hai ô riêng để xem cấp một phần và tập kết bàn giao.

## RC26 · Ghi nhanh mail OD

Chọn khoảng ngày nhận và KHSX riêng. Mail bình thường cùng ca chỉ đối chiếu ORDER hiện tại. Bôi đen mail rồi chọn Ghi dòng thiếu, hoặc xác nhận OD mới cho các dòng còn nghi vấn. App dùng ca cùng nhóm model/KHSX trong mail và giữ S6/S7 trên một dòng với đúng SL OD. Trạm chưa rõ được tra theo mã và model trong ORDER. Dòng ghi theo khối tối đa 100, lưu một lần. Khi ORDER thay đổi sau đối chiếu, bấm Đối chiếu ORDER trước khi tiếp tục.

## Check mail OD theo KHSX

Bấm **Quét Outlook**, rồi chọn KHSX. Dòng trạng thái ghi đường dẫn Outlook thực tế. Mặc định app đọc Inbox và thư mục tên NVL ở gốc hoặc ngay dưới Inbox của cùng hộp thư. Nếu chọn thư mục trong **Cài đặt**, app chỉ đọc thư mục đã chọn. Với NVL ở tài khoản khác, chọn đúng NVL của tài khoản đó.

Mail chỉ có kho H vẫn hiện theo KHSX và ghi số dòng H. Dòng P được đối chiếu với sheet ORDER theo từng dòng. Thư OD nhận diện được ngày nhưng chưa đọc được bảng vẫn xuất hiện để xem lại. Nút **Kiểm lượt quét** hiển thị nguồn và thư gặp lỗi. Lệnh **Ghi dòng thiếu vào ORDER** chỉ áp dụng cho các dòng P đã xác minh thiếu và được người dùng chọn.

## Tra cứu, lưu Excel và bàn giao nội bộ

Chọn ngày KHSX hoặc **Cả file ca**, chọn model và ca chạy. Ô lọc nhận mã, trạm hoặc tình trạng. Bấm tiêu đề để sắp xếp. Đã cấp lấy từ Total cấp trong ORDER. OB và số phiếu thể hiện riêng. Bôi đen các dòng cần ra đơn rồi bấm nút bên dưới.

Mô phỏng giữ kết quả các lượt trong phiên theo file. Bỏ tích Mô phỏng rồi chọn kết quả thật và bấm **Ghi OB và số đơn vào ORDER** để lưu. Khi app lưu workbook Excel đang mở, các thay đổi đang có trên workbook đó cũng được lưu. Với file cùng tên, đóng workbook cũ trong Excel trước khi thay. App theo dõi thay đổi trên đĩa. Có thể dùng Tải lại ORDER để đọc ngay.

**Lập BBBG** dùng cho các dòng Hết tồn kho MA của một ngày KHSX. Chọn dòng trước khi mở hoặc dán mã và SL. Bấm đúp để sửa SL. Mã xuất hiện nhiều lần sẽ có bước chọn dòng theo model và trạm. Chọn mẫu mới qua nút **Chọn mẫu BBBG**. Mẫu cùng bố cục biểu mẫu 14/07/2026 được hỗ trợ. Mỗi trạm nhận phiếu riêng, tối đa 18 dòng mỗi tờ. PDF nằm ở thư mục BBBG theo ngày cạnh ORDER. Mở PDF để in, hoặc dùng **Phiếu đã lập** để in lại. Mô phỏng xuất riêng vào BBBG_MO_PHONG. Chế độ thật lưu số BBBG ở ô SP và đổi NOTE sang Đã ra đơn, chờ cấp. Người dùng ghi SL thực nhận sau khi ký.

MB51 lọc plant 3093, kho xuất 1005, loại giao dịch 311–312. MB52 giữ tồn kho và tồn line, để trống US và DOH chờ quy tắc nghiệp vụ.

## Thay file ORDER cùng tên

Đóng bản Excel cũ, chép xong bản mới vào đúng đường dẫn rồi bấm **Tải lại ORDER**. RC23 sửa lỗi PyOleMissing khi mở workbook có mật khẩu qua Excel.

## Báo cáo RC22

Chọn ngày KHSX trước, sau đó chọn model. Một ngày chỉ hiện model có dòng ORDER trong ngày. Khoảng ngày lấy hợp các model trong khoảng, còn Tất cả lấy model của toàn bộ ORDER. Khi đổi phạm vi ngày, các model thuộc phạm vi mới được tích sẵn.

Các ô tổng đầu trang đếm số dòng ORDER trong phạm vi đang xem. Màu xanh lá là hoàn thành, xanh lam là cấp một phần, vàng là Pending. Bảng có kẻ ô theo model, xếp model nhiều Pending lên trước. Bấm đúp số để xem nguồn. Menu Biểu đồ cho chọn Pending theo model, lý do Pending, khối lượng theo ngày, tỷ trọng trạng thái và thác nước. Chế độ phát sinh trong ca vẫn đối chiếu lượng đầu ca.

Hàng thùng trên báo cáo dùng Total cấp. Chưa cấp tính Pending, cấp một phần khi lớn hơn 0 và chưa đủ SL ORDER, đủ hoặc vượt SL ORDER tính Done. Báo cáo không tạo nhóm riêng theo giờ. Mẫu Excel cuối ca cũ giữ vị trí cột để tương thích.

## Sử dụng RC20

Trong **OUT NVL → Ra đơn từ ORDER**, chọn KHSX và model rồi bấm **Check tồn → Tra MB52**. Bảng đọc tồn unrestricted theo Plant 3093, tách SLoc kho và line theo dòng ORDER. Bật **Gồm thiếu từ KHSX trước** để kiểm tra các dòng cũ vẫn còn mở trong file đang dùng. Lọc theo NCC hoặc **Chỉ hết tồn kho**, rồi bấm **Copy bảng đang lọc**. Ô US chờ bổ sung. Tồn trống là chưa xác minh, số 0 là kết quả MB52. Khi cùng mã có nhiều trạm, so tồn kho với tổng nhu cầu trong phạm vi, giữ từng trạm trong bảng gửi.

**Kết quả…** mở cửa sổ riêng để ghi Excel hoặc in. **Ra đơn / Tra OB ▾** chuyển giữa ra tay và tra/in. Trong **Tra mã / Cấp bù**, bật **Hiện KHSX sau ngày tra** để thêm ngày mới ở cuối danh sách. Tra MB51 đọc phía kho xuất 1005 và kho đối ứng theo cấu hình OUT.

**Báo cáo** có nút tải lại ORDER. Bỏ tích **Gồm dòng bàn giao** để đếm Done và Partial phát sinh theo chênh lệch SL. App dùng mốc lưu lúc tạo ca hoặc đọc file ca trước. Lượng đã có từ ca trước chỉ xuất hiện trong Done hoặc Partial khi bật Gồm dòng bàn giao. Pending thể hiện nhu cầu còn chờ. Tập kết phát sinh dựa vào thay đổi NOTE so với đầu ca. Trong Tổng quan có nút chọn model và menu chọn biểu đồ theo ngày.

**Check mail OD** đối chiếu theo file ca nhận. Khi thông tin mã, SL, trạm, KHSX và người OD khớp duy nhất, app nhận biết cách ghi LIMO/Dùng chung/LIMO RHD/LIMO LHD trong lô gốc. Ca làm việc theo file S1/S2/S3 tương ứng 06–14h, 14–22h, 22–06h. S6/S7 mặc định 06–18h và 18–06h. Lọc KHSX gồm ngày trong mail và ngày trong ORDER.

## Nâng cấp RC19

- Chọn KHSX rồi chọn model theo ORDER, kể cả KHSX các ngày tới. App tự chọn loại khi model chỉ có một loại hàng. Dòng cần kiểm tra hiện lý do trong bảng, chỉ các dòng đủ điều kiện được chọn sẵn ở chế độ ra đơn thường.
- Tra mã lấy hai ngày trước mốc, ngày làm mốc và ORDER tương lai trong file đang mở. Hàng thùng hiển thị cấp theo giờ/gọi, SL đã cấp và lượng còn lại khi có số liệu. Bấm Nguồn tra để xem file bàn giao chưa đọc được.
- Tổng quan hiển thị thác nước theo ngày KHSX và Ca chạy trong ORDER. Các cột dùng số dòng, mỗi dòng chỉ tính một lần trong tổng ngày. Bấm đúp vào cột để kiểm tra mã/trạm.
- Bảng ORDER có kẻ ô, hàng xen màu, dòng chọn màu xanh và dòng cần kiểm tra màu vàng. Kết quả ra đơn thu gọn khi trống.

## Nâng cấp RC18

Đóng app cũ trước khi chuyển phiên bản. Để giữ lịch sử trên cùng máy, giữ nguyên thư mục data và config.json. Trong OUT NVL → Tra OB / In phiếu → Thao tác → Lịch sử có thể mở lại các lượt tra đã lưu trong ngữ cảnh SAP tương ứng.

Tra mã hiển thị KHSX, SL OD, đã cấp, còn thiếu và ca có phát sinh đã xác minh. Mã chưa tìm thấy cũng có dòng riêng. OB hoặc phiếu có SL trống giữ NOTE theo ORDER. Khi còn thiếu và đã có phiếu chờ cấp, cần kiểm tra phiếu đó trước khi cấp bù. Chọn một ô rồi Ctrl+C để sao chép. Nếu ô có nhiều OB, chọn đúng số trong danh sách. Chọn các dòng rồi bấm Copy gửi SX/TL để sao chép bảng.

Check mail OD dùng ca nhận để kiểm tra dòng khớp duy nhất theo nghiệp vụ khi ngày OD lệch giờ nhận. Mở file ca đã chọn trong Excel để xem cả dữ liệu chưa lưu. File lịch sử đang đóng sử dụng mật khẩu chung và kết quả đọc lại được dùng đến khi file thay đổi.

## Nâng cấp RC17

1. Khi bắt đầu ca mới, chọn ngày và ca. App tìm file bàn giao theo thứ tự S7 hôm trước → S6 hôm nay → S7 hôm nay. Kiểm tra tên file nguồn trước khi tạo. Khi file ca đã tồn tại, mở tiếp file đó. Mốc đầu ca lưu lượng đã cấp và tình trạng bàn giao của các dòng còn theo dõi.
2. Trong **Check mail OD → Cài đặt**, đặt giờ bắt đầu S6/S7 và nhập một lần mật khẩu dùng chung cho các file. Trên Windows, mật khẩu được lưu theo tài khoản người dùng. Chọn **Mở file ca trong Excel** từ app để dùng phiên Excel đang mở hoặc mở file theo mật khẩu đã lưu.
3. **Quét Outlook** tìm thư theo giờ nhận. Một mail KHSX ngày mai vẫn thuộc ca nhận hôm nay. Kiểm tra dòng tổng để biết số dòng P có trong file ca nhận, số dòng tìm thấy qua bàn giao và số còn thiếu. **Kiểm lượt quét** tìm các dòng Excel chưa thấy mail tương ứng trong các file đã đọc. Kiểm tra thư mục Outlook, các file ca và thời gian quét khi có cảnh báo. Dòng thiếu trong file gốc nhưng đã sang file ca sau được giữ để truy nguyên.
4. **Ghi dòng thiếu vào ORDER…** cho phép chọn mail hoặc từng dòng P. App đối chiếu lại trước khi ghi vào file đang dùng, đọc lại kết quả và lưu dấu dòng đã ghi. Excel có dữ liệu nhưng thiếu dấu của app chỉ cho biết dòng đã có trong file. Mail điều chỉnh, thiếu nguồn và các dòng có nhiều khả năng khớp cần kiểm tra riêng.
5. **OUT NVL → Tra mã / Cấp bù** nhận mã hoặc văn bản dán. Chọn ngày KHSX làm mốc để xem ngày đó và hai ngày trước. Kiểm tra các dòng theo trạm/zone trước khi ra đơn cấp bù theo FIFO. **Tra MB51** mở lịch sử để đối chiếu thêm. Với hàng thùng, chọn **Thùng còn thiếu** khi cấp bù, hoặc **Cả model · 1 lượt** khi cần ra thêm một lượt nguyên thùng theo model.
6. Trong **Báo cáo cuối ca**, mã tập kết đầu ca rồi cấp đủ trong ca chỉ tính một Done. Mã cấp thêm nhưng còn thiếu tính một cấp một phần. Dòng bàn giao giữ nguyên lượng cấp có sản lượng ca bằng 0. **Copy ảnh ▾** chọn một bảng để dán trực tiếp vào Teams.

## Bắt đầu ca và ra đơn

- **Bắt đầu / đổi ca…** trên thanh đầu trang chọn hoặc tạo file ORDER. Mật khẩu mở file được dùng lại trong phiên. **Chọn ORDER đang mở…** dùng file của ca trong Excel. Nếu có nhiều file ca, chọn đúng đường dẫn. **Tải lại ORDER** đọc lại ngay cả những ô vừa sửa và đã nhấn Enter nhưng chưa lưu. Dòng tên nguồn hiển thị trạng thái và giờ đọc. Khi file đóng, app mở riêng để đọc và dùng lại mật khẩu trong phiên. **Thông báo** mở nhật ký thao tác.
- **OUT NVL → Ra đơn dán tay** nhận Mã hàng, SL, Trạm, Zone tùy chọn, mỗi vật tư một dòng. Dán từ Excel bằng Tab để giữ nguyên tên trạm có dấu cách.
- **Ra đơn từ ORDER** dùng KHSX, loại hàng và các model còn nhu cầu. Bấm vào bảng rồi Ctrl+A để chọn tất cả. Cột Packing trong file ca quyết định EA/thùng. Bảng Hàng thường hiển thị SL ORDER và SL ra. Sau khi chạy, OB và số phiếu hiện tại đây.
- Chọn các dòng ở **Kết quả ra đơn → Ghi OB và số đơn vào ORDER…**, kiểm tra bản xem trước rồi xác nhận. Kết quả SAP thật đủ số phiếu mới được ghi. **Tra / in OB kết quả** mở danh sách OB đã chọn để tra và in. **Tra OB / In phiếu** vẫn nhận được OB nhập từ bên ngoài.

### Ra thêm một lượt thùng

Trong **Ra đơn từ ORDER**, chọn **Loại hàng → Thùng cấp thêm**, sau đó chọn KHSX, model và dòng **Cấp thiếu** hoặc **Done**. Bảng hiện SL ORDER, đã cấp, còn thiếu, OB/số đơn cũ và SL lượt mới. **ORDER ▾ → Tra OB đang có của dòng chọn** tra các OB trong file. Dòng có OB chưa điền SL cấp được đánh dấu để kho đối soát. Chế độ bổ sung mở với danh sách chưa chọn dòng nào. Mỗi dòng được chọn sẽ ra một lượt nguyên thùng theo Packing của ORDER, kể cả khi số còn thiếu nhỏ hơn lượt mới.

Nếu dòng Done đã xóa khi bàn giao, vào **ORDER ▾ → Lấy dòng thùng Done ca trước…**. Chọn file bàn giao, đánh dấu dòng, xem số thùng rồi xác nhận ghi yêu cầu mới vào cuối ORDER hiện tại. App giữ KHSX, model và trạm, dùng ngày giờ lập yêu cầu mới và ghi người OD là “Bổ sung kho P”. Kiểm tra và bấm ra đơn tại bảng hàng thùng. File ca trước được dùng để đọc. Dòng đã đưa vào file ca này được nhận diện khi mở lại.

Sau khi có kết quả SAP, dùng **Ghi OB và số đơn vào ORDER…**. Hàng thùng dùng lần lượt OB1–3, rồi nối bằng dấu gạch chéo. Cột AI **Theo dõi lượt thùng bổ sung** lưu dấu cho từng yêu cầu. App chỉ sử dụng AI khi cột trống hoặc đúng tiêu đề. Khi còn lượt bổ sung chờ SL cấp, app giữ dòng Done qua bàn giao. Dấu AF/AH giúp báo cáo phân biệt dòng Done từ ca trước. Nhập SL cấp thực tế vào đúng ô SL tương ứng của OB. Nếu nhiều OB dùng chung một ô SL, tra OB rồi chọn **ORDER ▾ → Chốt lượt đã cấp ở ô ghép nhiều OB…** khi đã cấp đủ lượt mới.

## Báo cáo cuối ca

**KHSX** dùng chung cho Báo cáo cấp NVL, Báo cáo cuối ca và Tổng quan. Chọn một ngày, **Khoảng ngày…** hoặc **Tất cả**. Phạm vi đã chọn đi theo cả ba ảnh PNG, dữ liệu sao chép và hai sheet khi lưu.

**Báo cáo cấp NVL** gom mỗi trạng thái thành một ô dọc, mỗi ngày trong trạng thái thành một ô KHSX căn giữa các dòng NOTE. Dòng vàng là tổng ngày, dòng cuối mỗi trạng thái là tổng trạng thái. Hết tồn có nền đỏ nhạt, chưa ra đơn màu hổ phách và tập kết màu xanh lam. Bấm đúp ô trạng thái, ô ngày, dòng NOTE hoặc số ở cột model để tra đúng các dòng ORDER. Mở **Chi tiết bảng** để hiện Done, cấp một phần hoặc từng mã vật tư.

**Tổng quan** hiển thị tổng ORDER, Done, cấp một phần, Pending và số dòng cần kiểm tra nếu có. Thác nước tách dòng Pending hàng thùng và hàng thường theo ngày và ca chạy. Bấm đúp chỉ tiêu hoặc thanh để xem các dòng liên quan.

**Báo cáo cuối ca** có bảng Tình trạng và bảng Kết quả. Cột **Cấp theo giờ** đếm mã vật tư hàng thùng riêng trong mỗi cặp KHSX/model, theo cột Packing cùng quy ước với Ra đơn từ ORDER. Cùng mã có nhiều dòng trong nhóm được tính một lần. Bấm đúp ô để xem mã, packing và số dòng nguồn. Các dòng bàn giao được xử lý theo phạm vi ca như trước. Dòng thùng đã Done, cấp một phần, tập kết hoặc hết tồn vẫn có trạng thái tương ứng. Pending trong bảng Tình trạng là các dòng còn lại sau khi phân loại. Tỷ lệ theo giờ dùng số mã thùng chia cho Order theo mẫu. Tổng tỷ lệ dùng số dòng đã phân loại chia cho Order để mỗi dòng được tính một lần. Bảng Kết quả chỉ ghi sản lượng phát sinh.

Trong **Tệp Excel ▾**, **Đọc ORDER bàn giao đầu ca…** chọn nguồn để xác định tập kết phát sinh với file cũ. **Chọn Excel lưu báo cáo…** chọn đích BC Cấp NVL. **Lưu cuối ca…** ghi tiếp hai sheet và kiểm tra trùng ca. Thiếu mốc thì bấm đúp dòng model để chốt tập kết và ghi chú.

**Xuất 3 ảnh PNG…** tạo một thư mục gồm Báo cáo cấp NVL thu gọn, Tình trạng và Kết quả. Thiếu TL hoặc có ô chờ chốt thì có thể xuất bộ ảnh có nhãn BẢN TẠM.

Trong **Ra đơn từ ORDER**, dùng **ORDER ▾** để tải lại, chọn workbook đang mở hoặc đối soát dòng. Kéo thanh chia giữa hai bảng để thay đổi chiều cao phần chọn dòng và phần kết quả.

## Kiểm tra mail

**OUT NVL → Check mail OD**. Chọn file ORDER của ca rồi bấm **Quét Outlook** hoặc **Nhập file .msg…**. App tự đối chiếu các dòng kho P và hiện KHSX ngay trên dòng tổng của mail. Dùng bộ lọc KHSX để xem một ngày. **Đối chiếu ORDER** cập nhật kết quả sau khi sửa Excel.

Ngày nhận mail đối chiếu với **Ngày order và Giờ order** của Excel (cùng ngày, chênh tối đa 5 phút). Ngày chạy lấy riêng từ **KHSX** trên từng dòng. App kiểm thêm mã, số lượng, model, trạm/TL và người OD. Mail nhận trước ngày chạy vẫn khớp. Nếu ngày giờ Excel khác ngày giờ nhận, kết quả hiển thị hai mốc để kiểm tra.

Các dòng còn thiếu được tìm trong các file ORDER ca trước cùng thư mục, từ một ngày trước mail cũ nhất của đợt quét đến ca hiện tại. Kết quả **Done ca trước** ghi rõ file và dòng đã xác minh. Dòng mang sang nhiều file chỉ được dùng một lần. Nếu file nằm ở thư mục tháng trước, cần mật khẩu riêng hoặc có hai bản cùng ca, dùng **Mở ORDER ca trước…** để chọn đúng bản. Chọn ORDER của ca hiện tại vẫn giữ nguyên ở tab Ra đơn. Mail điều chỉnh/gửi lại vẫn có cảnh báo trên dòng tổng.

**IN NVL → Hàng về và BOM**. Chọn một thư mục Outlook tập trung mail kế hoạch của các NCC, hoặc mở nhiều file .msg. Phần mềm đọc bảng trong thư và bảng .xlsx/.xlsm có tiêu đề nhận diện được. Mail mới gửi trực tiếp và thư chuyển tiếp đều dùng được. Trong thư mục kế hoạch đã chọn, mẫu chưa đọc được xuất hiện trong danh sách cần kiểm tra. Quét Outlook lấy thư ba ngày gần nhất. Có thể mở mail cũ từ file.

**Kiểm IB và BOM 3093**. App kiểm PO/SA, item tham chiếu, mã, số IB, số lượng, ĐVT và Plant trong VL06I. Nếu mail thiếu IB, app tìm theo PO và mã. Khi mail thiếu ĐVT, mặc định yêu cầu kiểm tra. Số lượng IB thể hiện lượng trên chứng từ. Trạng thái GR xuất hiện ở phần chi tiết. Nhấp đúp dòng để xem kết quả.

CS03 kiểm BOM master của mã tại Plant 3093 và kiểm lại tại mốc mặc định 7 ngày. VL33N kiểm component theo item IB. Nếu cột tồn đã xác minh được khai báo tại Cấu hình → IN NVL, app cộng nhu cầu của các item đang mở trong đợt kiểm và cảnh báo khi thiếu hoặc khi tồn còn lại bằng hoặc dưới 10% nhu cầu. Có thể chỉnh cả hai ngưỡng. Chọn phạm vi tồn theo NCC cho nguồn tồn riêng nhà cung cấp hoặc SLOC cho nguồn tồn chung. Khi SAP thiếu cột, thiếu SLoc, thiếu NCC cần thiết hoặc GR một phần, app ghi rõ mục cần đối chiếu.

Tự quét mặc định tắt. Chọn 1 hoặc 2 giờ ở từng tab để nhận cảnh báo trong app khi app đang mở. Tab OUT yêu cầu mở workbook lần đầu trong phiên. Tab IN chỉ tự dùng phiên SAP ở màn hình chính, trừ khi đã chọn phiên dành riêng cho app. Cảnh báo hiển thị trên máy người vận hành.

**PDF**. Nút Mở PDF cho phép chọn file nếu chưa có kết quả gần nhất. Chọn PDF gốc đọc WHO trong file. Nếu thiếu danh sách theo dõi, nhập hoặc sửa số ứng với từng WHO rồi đóng số trực tiếp. Có thể chọn bỏ trang trắng.


## Số phiếu trên PDF

Mặc định in đúng số đã gán, ví dụ **20-03**, Helvetica đậm 18 pt, dưới phải, lề 10 mm, nền trong và không khung. Mở **Cấu hình → OUT NVL → Chỉnh số phiếu PDF** hoặc **Chọn PDF gốc → Chỉnh số phiếu**. Chọn góc hoặc bấm/kéo trên sơ đồ A4 ngang để đặt khoảng cách từ trái và trên theo mm. Có thể chọn phông, cỡ, màu, kiểu chữ, độ dày viền, nền trắng và khung chữ nhật hoặc bầu dục.

Để xem trên đúng khổ giấy, chọn **Chọn PDF mẫu**, nhập số trang rồi bấm **Xem thử**. App mở bản mẫu một trang trong trình xem PDF. Bấm **Lưu kiểu số** để dùng cho những lần xuất sau. **Khôi phục mặc định** cho phép thử lại giá trị ban đầu trước khi lưu.

## Tra IN NVL theo cột

VL06I đọc các trường theo mã kỹ thuật hoặc tiêu đề cột. Với bảng Item đã có mã hàng và số lượng, app đọc ngay các dòng vật tư và bỏ dòng tổng. **Delivery** là IB, **External Delivery ID** là mã giao hàng ngoài, **Reference document / RefIt** là chứng từ và item tham chiếu. Batch hiển thị ngay trên bảng. Mở **Chi tiết dòng** để xem Plant, Bill và PO/SA. Nếu VL06I thiếu Delivery Item, app vẫn hiện vật tư. Khi bấm **Kiểm tra BOM trên IB**, app đối chiếu trực tiếp item trong VL33N theo IB, mã hàng và batch khi có. Nếu có nhiều item cùng khớp, app yêu cầu hiển thị Delivery Item để phân biệt.

Các bước VL06I, ZMME240, ME2N và MB51 sử dụng bảng SAP đang hiển thị. Nếu bảng thiếu cột bắt buộc, thông báo chỉ rõ cột cần bổ sung.

## Kế hoạch và luồng vận hành RC9

| Bước | Người thao tác | Kết quả cần đạt |
|---|---|---|
| 1. Chọn phạm vi | Trong OUT NVL, tra OB rồi bấm **Lấy PDF từ SAP**. Kiểm tra danh sách WHO, INWH và OB. | Mỗi WHO đủ điều kiện xuất hiện một lần. Có thể bỏ chọn từng WHO. |
| 2. Đặt số liên tại SAP | Trong **Cấu hình → OUT NVL**, đặt **Số liên tại SAP** bằng **2**. Bấm **Gửi sang SAP**. | App đưa danh sách WHO vào F00112, điền và đọc lại Number of Copies ở màn hình chính và ô Number trên hộp Print của SAP. |
| 3. Lưu PDF gốc | Ở Windows chọn **Microsoft Print to PDF**, để Copies bằng **1**, bấm OK, đặt tên rồi lưu. Nếu SAP tách thành nhiều lượt, lưu mỗi file với tên riêng. | Có một hoặc nhiều PDF gốc cho toàn bộ WHO đã chọn. |
| 4. Đóng số | Bấm **Chọn PDF gốc**, đối chiếu danh sách, bật **Bỏ trang trắng** nếu cần, rồi bấm **Chọn file và đóng số**. Có thể chọn nhiều file cùng lúc. | App đọc WHO và chỉ số Trang x/y, đối chiếu đủ số liên của từng trang và đóng cùng một số INWH lên các liên của WHO đó. |
| 5. Kiểm tra và in giấy | PDF thành phẩm tự mở. Có thể mở lại bằng **Mở PDF đã đóng số**. Khi in giấy chọn một bản trong trình xem. | Các trang cùng một liên nằm liền nhau. File thành phẩm có tiền tố PHIEU_INWH trong thư mục PDF cấu hình. |

Nếu đã có PDF từ SAP, dùng **Chọn PDF gốc** với bảng kết quả hiện tại hoặc mở đúng lượt từ **Lịch sử**. Đối với lượt cũ thiếu thông tin kho, tra lại MON để lấy ánh xạ. App giữ số đã gán. Nếu PDF chỉ có WHO đầu tiên, thiếu liên, thừa liên hoặc chứa WHO ngoài phạm vi, app báo chi tiết và giữ nguyên file gốc. Bổ sung file còn thiếu rồi chọn lại cả bộ PDF của lượt. Kết quả chỉ được ghi là đã lưu PDF sau khi file đóng số đạt kiểm tra.

## Kiểm tra trên máy vận hành

1. Lấy hai WHO đủ điều kiện, trong đó một WHO có từ hai trang. Ghi lại cặp WHO và INWH trên hộp xác nhận.
2. Kiểm tra số 2 trên F00112 và popup SAP Print nếu đang thao tác từng bước. Lưu tất cả file Windows trả ra. Đối chiếu mỗi trang nội dung của mỗi WHO xuất hiện hai lần, kể cả trang tiếp theo.
3. Thử một file thiếu WHO hoặc chỉ có một liên. Hộp báo phải chỉ rõ WHO hoặc số trang cần bổ sung.
4. Nhập đủ file. Kiểm tra số INWH trên hai liên và lựa chọn giữ hoặc bỏ trang trắng. Nhật ký chẩn đoán nằm trong data/pdf_logs.

## Tra MON và xử lý WHO

- **Tra OB** đưa toàn bộ danh sách vào nút chọn nhiều giá trị của **LE Delivery**. MON chạy một bộ lọc cho danh sách vừa dán.
- App mở **Outbound Delivery Order Item** để đọc cặp OB/Document EWM rồi mở **Warehouse Task** để lấy WHO và mã hàng theo Document đã xác minh. Kết quả giữ từng OB riêng và loại bỏ WHO lặp.
- **Tra lại MON** xác minh lại toàn bộ OB trong bảng hiện tại, kể cả khi một dòng đang được chọn. Chọn dòng hoặc chọn cả OB vẫn dùng để xác định phạm vi in.
- **Nhật ký thao tác** ghi rõ bước SAP và cột thiếu nếu layout khác. Bảng phân biệt OB có WHO, chờ WHO, chưa thấy trong MON và lỗi tra cứu.
- Nếu cửa sổ lọc MON từ lượt RC2 vẫn còn mở, đóng popup đó trước khi bắt đầu lượt mới.

## Gán số đơn, sao chép và in

| Thao tác | Phạm vi và kết quả |
|---|---|
| **Gán số đơn** | Mặc định lấy tất cả WHO đủ điều kiện trong kết quả hiện tại, mỗi WHO một số. Muốn gán riêng, chọn **Thao tác → Gán số đơn cho dòng đã chọn**. |
| **Gợi ý số** | Giữ số đã gán, điền tiếp theo tiền tố và số bắt đầu, bỏ qua số đã dùng. Một mã ở hai WHO in được sẽ hiện dạng `WH-01/WH-02`. |
| **Copy 3 cột** | Sao chép OB, mã hàng và số đơn INWH. Ô chưa gán để trống. |
| **Xuất Excel** | Giữ bảng 3 cột và thêm bảng chi tiết có WHO in được, WHO đã xác minh, trạng thái và ghi chú. |
| **Lấy PDF từ SAP (N WHO)** | Lấy toàn bộ WHO đủ điều kiện của lượt hiện tại, kể cả khi chưa chọn dòng. Gộp WHO trùng. Hộp xác nhận hiện WHO, INWH, OB, số bản và tùy chọn **Bỏ trang trắng**. |
| **Thao tác → Lấy PDF từ SAP cho dòng đã chọn** | Chỉ lấy WHO đủ điều kiện của các dòng đang chọn. Dùng khi muốn in một phần. |
| **Mở PDF đã đóng số** | Mở lại file thành phẩm gần nhất trong trình xem PDF của Windows. |

App cuộn bảng Item/WT từng vùng. Cột Status trống hoặc `C` xác nhận đủ điều kiện theo quy tắc in. Dòng mã có tất cả WT là `A` vẫn hiện WHO để đối chiếu và ghi **Không in · toàn A**. Nếu cùng WHO có mã hàng khác đủ điều kiện, WHO có thể được chọn từ dòng mã đó. Khi chưa đọc đủ WT hoặc chưa xác minh được WHO bị gộp, app hiển thị trạng thái cần kiểm tra. Chọn **Thao tác → Chi tiết dòng đã chọn** để xem lý do.

## Kế hoạch nâng cấp và phạm vi RC5

| Hạng mục | Thay đổi trong RC5 | Cách kiểm tra |
|---|---|---|
| Kết nối SAP | Chỉ số `-1` tự lấy phiên đầu tiên đang rảnh, đã đăng nhập và khớp System/Client. Chỉ số từ `0` chọn một phiên cụ thể trong nhóm khớp. | Mở nhiều cửa sổ cho `PSV/908` và bấm **Thử kết nối**. |
| OUT NVL | Tách **Tra OB / In phiếu** và **Ra đơn từ ORDER**. | Dán OB vào chế độ tra và kiểm tra model ở tab Ra đơn từ ORDER. |
| Phạm vi in | Bảng tra chỉ hiện OB của lượt vừa chọn. App đối chiếu MON theo OB → Document EWM → WHO → mã hàng và in đúng WHO đã chọn. | Tra hai OB, chọn một OB hoặc một WHO trong hộp xác nhận, đối chiếu nội dung PDF. |
| Số đơn INWH | Đánh số theo WHO. Mã cùng OB có hai WHO xuất một dòng với số dạng `WH-01/WH-02`. | Tra một mã có hai WHO, kiểm tra số ghép và dán bảng theo dõi vào Excel. |
| IN NVL | Nạp cấu hình đã xác nhận từ workbook GR. Giao diện tách ô tìm IB, bảng kết quả và chi tiết dòng. | Đối chiếu màn hình cấu hình rồi tra một IB có dữ liệu thật. |

## Kết nối SAP

Mặc định `PSV/908` và chỉ số `-1`. Nếu phiên khớp đầu tiên đang bận, app dùng phiên khớp đang rảnh tiếp theo như bản v1.7. Nếu cần cố định một cửa sổ cho tool, đặt chỉ số phiên trong **Cấu hình → Chung**. App dùng các phiên đã đăng nhập sẵn.

## OUT NVL

1. Vào **Tra OB / In phiếu**. Dán mỗi OB một dòng, hoặc dán bảng Excel có OB ở cột đầu. Tắt **Mô phỏng** để tra dữ liệu thật.
2. Bấm **Tra OB**. Bảng hiển thị **Sẵn sàng in**, **Chờ WHO**, **Chưa thấy OB trong MON**, **Chưa xác minh Document** **Không in · toàn A** hoặc **Lỗi tra MON**. **Tra lại MON** tra cả danh sách OB hiện có trong bảng.
3. Bấm **Lấy PDF từ SAP (N WHO)**, xác nhận danh sách rồi lưu file qua Windows. Bấm **Chọn PDF gốc** để đóng số và xem kết quả. Xem các bước chi tiết ở đầu tài liệu.
4. Với OB có sẵn, app giữ số INWH đã gán cho WHO. WHO chưa có số sẽ được đề xuất theo tiền tố và số bắt đầu, rồi ghi vào bảng khi tạo PDF thành công. Có thể bấm **Gán số đơn** trước để nhập số theo ý muốn. Nếu bản RC1 từng dùng chung một số cho nhiều WHO, kiểm tra lại các số tương ứng rồi lưu.
5. Click vào một ô rồi Ctrl+C để chép riêng ô. Dùng **Copy 3 cột** hoặc **Xuất Excel** để trả bảng theo dõi. **Thao tác → Lịch sử** mở các lượt đã lưu. Tra lại MON trước khi in từ dữ liệu lịch sử.

Chế độ **Ra đơn từ ORDER** nhận các dòng Excel theo ngày KHSX, model và loại hàng. Trình tự là đọc tồn MON, gom nhóm, xác nhận MIGO 311 rồi tra WHO. Nếu bật **Tự gửi WHO sang SAP sau khi ra đơn mới**, tác vụ in chỉ áp dụng cho OB vừa tạo. Nếu SAP trả Material Document hoặc mất phản hồi sau Post, mở **Cấu hình → Chung → Đối soát Post** trước khi chạy lại.

## IN NVL đối chiếu workbook GR

Nguồn VBA trong workbook `240101_MA Log_GR Tool_V7_1(5).xlsm`, sheet `GR_EWM_V1`.

| Nghiệp vụ | Workbook | App |
|---|---|---|
| Tra IB có sẵn | `Check_Inbound_Qty`, VL06I `/DAT`, đối chiếu A mã hàng, B IB, E số lượng | Dán số IB, khối gọn IB–mã–SL–ĐVT hoặc A:I. Khi có dữ liệu đối chiếu, hiện lệch SL/SLoc/PO cùng trạng thái WBSTA. |
| Tìm IB | `Find_Inbound_VL06I`, `Find_Inbound_ZMME240` | Tra theo mã, PO/SA, SL và Bill nếu có. ZMME240 trả ứng viên, app dùng VL06I để kiểm chứng số IB và item. |
| Số lượng còn PO/SA | `Check_PO_SA_Availability`, ME2N | So SL yêu cầu với SL còn, lọc đúng item nếu có, bỏ số lượng từ các item bị khóa/xóa hoặc release B/C theo quy tắc workbook. Khi nhiều item cùng ĐVT, hiện tổng và ghi chú. Kết quả theo từng dòng, chưa phân bổ số lượng giữa các IB dùng chung PO. |
| Queue, chứng từ GR | `Check_Queued` trong MON và `Get_Mat_Doc` trong MB51 | Tra ở `VF02`/monitor `SAP`, MB51 theo IB và mã hàng. MB51 trả số chứng từ, năm và movement type. |
| BOM | Workbook kiểm trong `Change_Inb_Multi` và có nhánh sửa VL32N | App đọc component qua VL33N, tra BOM master CS03 và cuộn nhiều trang. Chỉ báo tồn linh kiện khi đã cấu hình cột tồn đã đối chiếu. |

Ngày tra mặc định để trống theo workbook. Plant và SLoc đọc từ IB. ME2N đọc các cột của bảng hiện tại. Trong workbook, macro ME2N chọn theo số thứ tự dòng.

RC5 phục vụ tra cứu IN NVL. Tạo/sửa/xóa IB, cập nhật batch, xử lý Queue và post GR trong VBA vẫn thuộc luồng thao tác riêng. Phần đối chiếu SL PO/SA hỗ trợ kiểm tra, còn đối chiếu phân bổ khi nhiều IB dùng chung PO thực hiện theo quy trình kho.

## Kiểm thử

PDF mẫu 58 trang gồm 23 WHO, mỗi WHO có hai liên. Khi giữ trang trắng, PDF kết quả có 58 trang. Khi bỏ 8 trang trắng, PDF còn 50 trang và giữ các trang nối tiếp có dữ liệu hàng. Đã kiểm tra trường hợp chia nhiều file, thiếu WHO, thiếu liên, chọn trùng file, chọn lại PDF đã đóng số và WHO ngoài danh sách. Bước gửi danh sách qua F00112 và đặt số 2 ở hai màn hình đã kiểm tra bằng mô phỏng. Cần xác nhận thao tác thực tế trên phiên SAP và Windows của kho.
