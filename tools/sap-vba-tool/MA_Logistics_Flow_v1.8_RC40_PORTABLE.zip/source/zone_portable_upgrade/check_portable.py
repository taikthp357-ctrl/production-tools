"""Exercise the modules unpacked from the delivered Windows EXE."""
import importlib.abc
import importlib.util
import marshal
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as S
from unittest.mock import patch
import zlib

from build_portable import archive,payload,pyz_entries


class EmbeddedSource(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def __init__(self,modules):
        self.modules=modules
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split(".")[0] not in ("sap_zone_core","sap_zone_gui","zone18","zone_ui18",
                                          "zone_cleanup","zone_workspace","zone_bbbg","zone_qty","zone_stock","zone_result_grid","zone_search","zone_shift","zone_shift_ui","zone_daily","zone_report_ui","zone_report_tables","zone_report_png","zone_excel_live","zone_order_result","zone_mail","zone_mail_ui","zone_arrival",
                                          "zone_inbound","zone_numbers","zone_pdf","zone_winprint","zone_pdf_job",
                                          "pypdf","xml"):
            return None
        if fullname not in self.modules:
            raise ModuleNotFoundError(f"No module named '{fullname}' in the EXE",name=fullname)
        kind,_=self.modules[fullname]
        return importlib.util.spec_from_loader(fullname,self,is_package=kind==1)
    def create_module(self,spec):
        return None
    def exec_module(self,module):
        module.__file__=module.__name__+".py"
        exec(marshal.loads(zlib.decompress(self.modules[module.__name__][1])),module.__dict__)


def check_mon_batch(z, core):
    obs=["1013303852","1013303848","1013303851"]
    first,second,missing=obs
    events=[]
    clipboard=[]
    low=S(Text="old")
    high=S(Text="old")
    parent_path=z.MON_ALV+"shellcont[0]/shell"
    details_path=z.MON_ALV+"shellcont[1]/shell"
    control_ids={
        "wnd[1]/usr/txtS_ERP_H-LOW":low,
        "wnd[1]/usr/txtS_ERP_H-HIGH":high,
    }
    objects={}
    phase="closed"
    def open_node(node):
        nonlocal phase
        assert node=="N000000010"
        events.append(node)
        phase="filter"
    def filter_button(old_phase,new_phase,event):
        def action():
            nonlocal phase
            assert phase==old_phase
            events.append(event)
            phase=new_phase
        return S(press=action)
    def get_control(path,_raise=True):
        if path=="wnd[1]":
            return object() if phase in ("filter","multiple") else None
        if path=="wnd[0]/sbar":
            return S(MessageType="S",Text="")
        if phase=="filter":
            return control_ids.get(path)
        if phase=="multiple":
            return objects.get(path)
        if path==parent_path:
            return parent
        if path==details_path:
            return {"items":item_grid,"tasks":task_grid}.get(phase)
        return None
    scrolls=[]
    class Grid:
        SubType="GridView"
        VisibleRowCount=2
        def __init__(self,data,fields):
            self.data=data
            self.RowCount=len(data)
            self.ColumnOrder=S(Count=len(fields),ElementAt=fields.__getitem__)
            self.first=0
        @property
        def FirstVisibleRow(self):
            return self.first
        @FirstVisibleRow.setter
        def FirstVisibleRow(self,value):
            scrolls.append(value)
            self.first=min(value,max(0,self.RowCount-self.VisibleRowCount))
        def GetCellValue(self,index,key):
            assert self.first<=index<self.first+self.VisibleRowCount
            return self.data[index][key]
        def GetColumnSortType(self,key):
            assert key=="WHO"
            return "Ascending"
    def press_parent(button):
        nonlocal phase
        assert events[-1]=="SelectedRows"
        events.append(button)
        assert (phase,button) in (("headers","N000000011"),("items","N000000096"))
        phase={"N000000011":"items","N000000096":"tasks"}[button]
    # The top grid does not contain either join key, as in the Windows report.
    parent=Grid([dict(CREATED_BY="SAP"),dict(CREATED_BY="SAP")],("CREATED_BY",))
    parent.selectAll=lambda:events.append("SelectedRows")
    parent.pressToolbarButton=press_parent
    items=[dict(ERP_NUMBER=first,DOCNO_H="0000123",MATNR="A"),
           dict(ERP_NUMBER=second,DOCNO_H="0000124",MATNR="A"),
           dict(ERP_NUMBER="1013303899",DOCNO_H="0000125",MATNR="A")]
    tasks=[dict(DOCNO="123",MATNR="A",WHO="6029140750",TOSTAT="A"),
           dict(DOCNO="0000123",MATNR="B",WHO="",TOSTAT=""),
           dict(DOCNO="123",MATNR="A",WHO="6029140751",TOSTAT="C"),
           dict(DOCNO="123",MATNR="A",WHO="6029140752",TOSTAT="A"),
           dict(DOCNO="124",MATNR="A",WHO="",TOSTAT=""),
           dict(DOCNO="125",MATNR="A",WHO="6029140755",TOSTAT=""),
           dict(DOCNO="",MATNR="",WHO="",TOSTAT="")]
    item_grid=Grid(items,("ERP_NUMBER","DOCNO_H","MATNR"))
    task_grid=Grid(tasks,("DOCNO","MATNR","WHO","TOSTAT"))
    control_ids.update({
        z.MON_LE_DELIVERY_FILTER:filter_button("filter","multiple","Open multiple"),
        "wnd[1]/tbar[0]/btn[8]":filter_button("filter","headers","Execute"),
    })
    objects.update({
        "wnd[2]/tbar[0]/btn[16]":filter_button("multiple","multiple","Clear"),
        "wnd[2]/tbar[0]/btn[24]":filter_button("multiple","multiple","Paste"),
        "wnd[2]/tbar[0]/btn[8]":filter_button("multiple","filter","Apply"),
    })
    session=S(Busy=False,findById=get_control)
    with patch.object(z,"mon_start",return_value=S(doubleClickNode=open_node)) as begin,patch.object(
        core.MonStockService,"copy_to_clipboard",side_effect=lambda data:clipboard.append(data) or True,
    ):
        results=z.query_whos(session,obs)
    assert begin.call_count==1
    assert low.Text==high.Text=="" and clipboard==["\r\n".join(obs)]
    assert events==["N000000010","Open multiple","Clear","Paste","Apply","Execute",
                    "SelectedRows","N000000011","SelectedRows","N000000096"]
    assert scrolls==[2,2,4,6]
    assert results[first]["materials"]=={"A":["6029140750","6029140751","6029140752"],"B":["6029140750"]}
    assert z.wt_print_result(results[first],"A")[1:3]==(["6029140751"],"In được một phần")
    assert z.wt_print_result(results[first],"B")[1:3]==(["6029140750"],"Sẵn sàng in")
    assert z.wt_print_result(results[second],"A")[1:3]==([],"Chưa kiểm tra hết WT")
    assert results[missing]==dict(state="Chưa thấy OB trong MON",materials={})
    assert z.wt_print_result(dict(state="Chờ WHO",materials={"A":["6029140752"]},
                                  wt_status={"A":{"6029140752":{"A"}}}),"A")[1:3]==([],"Không in · toàn A")
    grouped=[dict(DOCNO="123",MATNR="A",WHO="6029140752"),dict(DOCNO="123",MATNR="B",WHO="")]
    z.resolve_wt_groups(grouped)
    assert not grouped[-1]["WHO"]
    task_grid.GetCellValue=lambda _i,_key:None
    try:
        z.read_mon_pages(session,task_grid,("WHO",),"WT")
    except z.MonIncomplete:
        pass
    else:
        raise AssertionError("An unloaded cell must not be treated as a blank WT status.")

    items[1]["DOCNO_H"]="123"
    indexes,documents=z.mon_out_index(obs,items)
    results=z.match_mon_tasks(indexes,documents,tasks)
    assert results[first]["state"]==results[second]["state"]=="Chưa xác minh Document"
    assert results[first]["materials"]==results[second]["materials"]=={"A":[]}


def check_inbound(inbound, ui, z):
    cfg={"sap_number_format":"US"}
    workbook="MA-1\t185900001\t1005\t\t200\t\tBILL-1\t5300000000\t10"
    request=inbound.request_rows(workbook,True)[0]
    assert (request["ib"],request["qty"],request["po_item"],request["expected_sloc"])==("185900001","200","10","1005")
    no_ib=workbook.replace("185900001","")
    assert inbound.request_rows(no_ib,False)[0]["bill"]=="BILL-1"
    assert inbound.request_rows(no_ib,False)[0]["po_item"]=="10"

    line=dict(VBELN="0185900001",POSNR="000010",MATNR="MA-1",LFIMG="190",LGORT="3001",
              WBSTA="A",S_VGBEL="5300000000",S_VGPOS="00010",LIFEX="BILL-1",MEINS="EA")
    second=dict(line,POSNR="000020",MATNR="MA-2",WBSTA="C",S_VGPOS="00020")
    response=inbound.match_vl06i([line,second],[request,dict(ib="185900012")],True,cfg)
    assert len(response)==2 and response[0]["expected_qty"]=="200"
    assert response[0]["ib_state"]=="Đang mở · Lệch số lượng · Khác SLoc"
    assert response[1]["ib_state"]=="Chưa thấy IB khớp"
    exact=inbound.request_rows("MA-2\t190\t5300000000\tBILL-1\t20",False)
    assert inbound.match_vl06i([line,second],exact,False,cfg)[0]["ib_state"]=="Đã hoàn tất GR"
    verify=dict(ib="185900001",material="MA-1",qty="190",bill="BILL-1",po="5300000000",ib_state="Ứng viên")
    alternate=dict(verify,ib="",ib_state="Chưa có số IB")
    with patch.object(inbound,"vl06i",return_value=response[:1]) as vl:
        resolved=inbound.verify_zmme(object(),[verify,alternate],{},cfg)
    assert vl.call_args.args[1][0]["verify_candidate"] and resolved[0]["item"]=="000010"
    assert resolved[1]["ib_state"]=="Chưa có số IB"
    off_context=dict(request,verify_candidate=True,bill="WRONG")
    assert inbound.match_vl06i([line],[off_context],True,cfg)[0]["ib_state"]=="Chưa thấy IB khớp"
    with patch.object(inbound,"vl06i",side_effect=z.StopRun("layout")):
        assert inbound.verify_zmme(object(),[verify],{},cfg)[0]["ib_state"]=="Chưa xác minh item VL06I"

    po_line=dict(EBELN="5300000000",EBELP="00010",MGLIEF="170",MEINS="EA",FRGKE="",LOEKZ="")
    req=dict(request,unit="EA")
    blocked=dict(po_line,EBELP="00020",MGLIEF="500",LOEKZ="L")
    assert inbound.purchase_result(req,[po_line,po_line,blocked],cfg)[0]=="Thiếu SL PO/SA"
    assert inbound.purchase_result(req,[dict(po_line,MGLIEF="200")],cfg)[0]=="Đủ SL PO/SA"
    assert inbound.purchase_result(req,[dict(po_line,FRGKE="B")],cfg)[0]=="PO/SA khóa hoặc chưa release"
    assert inbound.purchase_result(req,[dict(po_line,MEINS="KG")],cfg)[0]=="Cần đối chiếu ĐVT"
    with patch.object(inbound,"receive_queue",return_value=[[dict(ERRMESS="Có lỗi")]]) as monitor:
        queue=ui.InboundPage.fetch("Queue",object(),[response[0],verify],{},cfg,"VL06I")
    assert len(monitor.call_args.args[1])==1 and queue[1][0]=="Chưa xác minh item VL06I"

    class Table:
        RowCount=5
        VisibleRowCount=2
        first=2
        @property
        def Position(self):
            return self.first
        @Position.setter
        def Position(self,value):
            self.first=min(value,self.RowCount-self.VisibleRowCount)
        @property
        def VerticalScrollbar(self):
            return self
    table=Table()
    session=S(Busy=False,findById=lambda *_:table)
    read=[table.first+index for table,index in inbound.visible_table_rows(session,"BOM")]
    assert read==list(range(5))


def check_shift_reports():
    from collections import Counter
    import zone_daily as daily
    import zone_shift as sh
    import zone_report_tables as tables
    header=[None]*34
    for col,name in sh.FIELD_NAMES.items():header[col]=name
    def row(material,packing,state,note,day,model='VF6'):
        values=[None]*34
        for i,v in {2:packing,3:material,4:10,9:model,24:state,26:day,27:note}.items():
            values[i]=v
        return values
    first,last='2026-11-19','2026-11-20'
    table=[header,row('A','Thùng giấy 70pcs','Done','',first),
           row('A','Thùng giấy 70pcs','Pending','Chưa ra đơn',first),
           row('B',15,'Pending','Hết tồn kho MA',first),row('C',0,'Pending','Cấp theo giờ',first),
           row('A','Thanh nhôm 40pcs','Pending','Chờ',last)]
    table[1][22]=10
    groups=daily.daily(table,first,first)
    items=daily.snapshot(groups,{})
    c=items[0][3]
    assert (c['order'],c['done'],c['hourly'],c['pending'])==(4,1,0,2)
    assert len(groups[first,'VF6']['cartons']['A'])==2
    assert tables.status_values(c)[-1]=='50%'
    carton=row('D',20,'Pending','Cấp theo giờ',last,'VF8')
    for qty,expected in [(0,'pending'),(4,sh.PART),(10,'done'),(12,'done')]:
        carton[22]=qty
        assert daily.report_state(carton)==expected
    sample=table+[carton]
    assert daily.scoped_models(sample,first,first)==['VF6']
    assert daily.scoped_models(sample,last,last)==['VF6','VF8']
    assert daily.scoped_models(sample,first,last)==['VF6','VF8']
    assert daily.report_note(carton)=='Đã ra đơn, chờ cấp'
    assert len(tables.status_values(c))+4==len(tables.STATUS_HEADERS)
    pivot=tables.pivot_table(table,'',True,False,True)
    spans=pivot.spans
    assert sum(s[5]=='group_date' for s in spans)==3
    assert sum(s[5]=='group_status' for s in spans)==2
    for lo,hi,col,end,label,kind,target in spans:
        assert hi>lo and len(pivot.rows[target].key)==pivot.rows[target].values[-1]
    scoped=tables.pivot_table(table,'',first=first,last=first)
    ov=daily.overview(scoped.rows[-1].key)
    assert len(ov['all'])==4 and len(ov['Pending'])==3
    assert sum(len(v) for _,v in ov['notes'])==3
    assert tables.pivot_table(table,'',first='2027-01-01').rows[-1].values[-1]==0

    # A copied S6 workbook can still contain the previous shift's opening column.
    from copy import deepcopy
    from datetime import date
    header[32:34]=[sh.BASE_QTY,sh.BASE_NOTE]
    shift=(date(2026,11,21),'S6')
    prior=[header, row('P',20,'Partial finished','Đã ra đơn, chờ cấp',last),
           row('G',20,'Pending','Hàng tập kết',last),row('D',20,'Done','',last)]
    for r,qty in zip(prior[1:],(4,0,10)):
        r[22],r[32]=qty,0
    active=deepcopy(prior)
    def totals(include):
        _,lines=daily.pivot(active,all_rows=include,baseline=prior,identity=shift)
        assert all(v[0]!='Kiểm tra' for v,_,_ in lines)
        return {v[0]:v[-1] for v,tag,_ in lines if tag in ('state','total')}
    active[1][31]=1
    assert totals(False)=={'Done':1,'Partial finished':0,'Pending':1,'Tổng cộng':2}
    assert totals(True)=={'Done':1,'Partial finished':1,'Pending':1,'Tổng cộng':3}
    active[1][22]=6
    assert daily.daily(active,baseline=prior,identity=shift)[last,'VF6']['count']['new_partial']==1
    active[1][22]=10
    assert totals(True)['Partial finished']==1  # Pivot uses the ORDER status column.
    assert daily.daily(active,baseline=prior,identity=shift)[last,'VF6']['count']['new_done']==1
    active[2][32:34]=[None,'Tập kết ca trước']
    details=daily.pivot(active,identity=shift,include_gather=False)[1]
    assert not any(rec[1][3]=='G' for rec in details[-1][2])
    assert daily.snapshot(daily.daily(active,identity=shift),{})[0][3]['new_gathered']==0


def check_mail_and_cartons():
    from copy import deepcopy
    from datetime import date
    import zone_mail as mail
    import zone_shift as sh
    import zone_order_result as wr
    from zone_daily import daily
    head=[None]*34
    for col,name in sh.FIELD_NAMES.items():
        head[col]=name
    for col,name in {28:'Ngày order',29:'Giờ order',30:'Người order'}.items():
        head[col]=name
    def row(material,state):
        line=[None]*34
        for col,value in {2:70,3:material,4:210,5:'KV-12',6:3093,7:1005,8:3001,9:'Limo',11:'S3',
                         13:'1012345001',22:210 if state=='Done' else 70,24:state,26:'20-Nov-26',
                         27:'Đã ra đơn, chờ cấp',28:'2026-11-18',29:(12*60+58)/1440,30:'Yến'}.items():
            line[col]=value
        return line
    active=[head,row('A','Partial finished')]
    old=[head,row('A','Partial finished'),row('B','Done')]
    def request(material):
        return dict(material=material,qty=210,station='KV-12',model='LIMO',plan='20-Nov-26',person='Yến')
    msg=dict(id='1',received='2026-11-18 12:58:39',rows=[request('A'),request('B')])
    mail.reconcile_order([msg],active,[('S7',mail.order_index(old))])
    assert [r['match_state'] for r in msg['rows']]==['current','history']
    msg['received']='2026-11-19 12:58:39'
    mail.reconcile_order([msg],active,[('S7',mail.order_index(old))])
    assert all(r['match_state']=='review' and '18/11' in r['status'] for r in msg['rows'])
    msg['received']='2026-11-18 12:58:39'
    msg['rows']=[request('B'),request('B')]
    mail.reconcile_order([msg],active,[('S7',mail.order_index(old)),('S6',mail.order_index(old))])
    assert [r['match_state'] for r in msg['rows']]==['history','review']
    other=deepcopy(msg)
    other['id']='2'
    mail.reconcile_order([msg,other],active,[('S7',mail.order_index(old))])
    assert all(r['match_state']=='review' for m in (msg,other) for r in m['rows'])
    msg['rows']=[request('B')]
    mail.reconcile_order([msg],active,[],['S7'])
    assert msg['rows'][0]['match_state']=='unverified'
    assert mail.day('21-Nov-26')==date(2026,11,21)
    cfg=dict(plant='3093',sloc_from='1005',sloc_to='3001')
    assert not sh.plan(old,None,None,'Thùng',cfg)
    extra=sh.plan(old,None,None,sh.EXTRA,cfg)
    assert len(extra)==2 and all(r['boxes']==3 and r['qty']==210 for r in extra)
    assert [r['material'] for r in wr.archived_cartons(old,active,cfg)]==['B']
    new=extra[1]
    result=dict(mock=False,valid=True,source=new,pairs=[('1012345002','20-02')])
    change=wr.edits(old,[result])[3]
    assert (17,'1012345002') in change and (18,'20-02') in change and all(c!=14 for c,_ in change)
    after=deepcopy(old)
    after[0].append(sh.TRACK)
    for r in after[1:]:
        r.append(None)
    for c,v in change:
        after[2][c-1]=v
    assert wr.edits(after,[result])=={}
    assert sh.round_open(after[2]) and sh.handover(after)[0]==[]
    assert sh.plan(after,None,None,sh.EXTRA,cfg)[1]['problem']
    after[2][31:34]=sh.opening_values(after[2])
    assert not any(g['count'].get('new_done',0) for g in daily(after).values())
    after[2][18]=210
    assert not sh.round_open(after[2]) and sh.handover(after)[0]==[3]
    # A full three-slot row appends to OB1, preserving every legacy OB.
    for i in (13,16,19):
        old[2][i]='101234500'+str((i-13)//3+1)
    new=sh.plan(old,None,None,sh.EXTRA,cfg)[1]
    change=wr.edits(old,[dict(result,source=new,pairs=[('1012345004','20-04')])])[3]
    assert (14,'1012345001/1012345004') in change and (15,'/20-04') in change

    from datetime import datetime
    assert mail.receiving_shift(datetime(2026,11,20,5,59),{})==(date(2026,11,19),'S7')
    assert mail.receiving_shift(datetime(2026,11,20,6,0),{})==(date(2026,11,20),'S6')
    head[32:34]=sh.BASE_QTY,sh.BASE_NOTE
    staged=row('TEST','Done')
    staged[27],staged[32],staged[33]='Hàng tập kết',70,'Tập kết ca trước'
    counts=next(iter(daily([head,staged]).values()))['count']
    assert (counts['new_done'],counts['new_partial'],counts['new_gathered'])==(1,0,0)


    import zone_search as search
    from pathlib import Path
    from unittest.mock import patch
    changed=row('BIW32013648AA','Pending')
    changed[26]='21-Nov-26'
    changed[14]='19-02'
    changed[15]=None
    changed[22]=0
    msg={'id':'shift','received':'2026-11-19 13:31:00','issues':[],'rows':[dict(request(changed[3]),plan='21-Nov-26')]}
    index=mail.order_index([head,changed])
    with patch.object(mail,'workbook_evidence',return_value=([head,changed],(date(2026,11,19),'S6'),
                      {(date(2026,11,19),'S6'):('S6',index)},[])):
        mail.audit_workbooks([msg],'unused',None,{}, {})
    assert msg['rows'][0]['match_state']=='current' and msg['rows'][0]['origin_line']==2
    assert search.row_info(changed)[:2]==('','')
    changed[22]=changed[15]=180
    assert 'còn 30 EA' in search.row_info(changed)[-1] and 'cần ra đơn' not in search.row_info(changed)[-1]
    changed[17]='19-03'
    assert 'chờ cấp 19-03' in search.row_info(changed)[-1] and sh.pending_order(changed)
    groups,_,review=search.lookup(' '.join(['BIW32013648AA']+[f'BIW0000{i}XX' for i in range(6)]),
                     date(2026,11,21),[(Path('orders'),[head,changed])],[])
    assert len(groups)==1 and len(review)==6

    future=row('BIW32012580AA','Pending')
    future[26]='22-Nov-26'
    future[27]='Chưa ra đơn'
    future[9]='VF8NP'
    future[13]=future[22]=None
    checked=list(future)
    checked[9]='LIMO'
    checked[3]='BIW32012585AA'
    checked[27]='Hết tồn kho MA'
    table=[head,future,checked]
    groups,_,review=search.lookup('32012580\n32012585',date(2026,11,21),[(Path('orders'),table)],[])
    assert len(groups)==2 and not review
    assert all('Chưa ra đơn' not in search.row_info(r)[-1] for r in table[1:])
    available=[r for r in sh.candidates(table,cfg) if r['mode']=='Thùng']
    assert {r['model'] for r in available}=={'VF8NP','LIMO'}
    assert [r['model'] for r in available if not r['problem']]==['VF8NP']
    assert len(sh.plan(table,None,None,'Thùng',cfg))==1
    from zone_daily import waterfall
    chart=waterfall([(2,future,'VF8NP'),(3,checked,'LIMO')])
    assert len(chart)==2 and chart[0][:2]==('2026-11-22','Tổng ngày')
    assert [len(v) for v in chart[0][2]]==[2,0,0,0,2,0]


def check_outlook_filter():
    from datetime import datetime
    import zone_mail as mail
    from zone_shift import FIELD_NAMES
    selected='2026-11-23'
    fields=['No','Ngày OD','Model','Mã','SL OD','Kho','Trạm','KHSX','TL','Người OD']
    def record(lines,subject='OD NVL VF5 KHSX 23.11.2026 CA S6'):
        body='<table>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in r)+'</tr>' for r in [fields,*lines])+'</table>'
        return mail.extract(S(HTMLBody=body,Body='',Subject=subject,SenderName='WH',EntryID='id',ReceivedTime=datetime(2026,11,21,13,35)),'out')
    h=[1,'11/21/2026','VF5','SUB72000061',30,'H','KV15','23.11.2026','TL','A']
    p=[2,'11/21/2026','VF5','BIW10001',40,'P','KV15','23.11.2026','TL','A']
    assert mail.visible_out(record([h]),selected)==([],1,True)
    assert mail.visible_out(record([h]),'2026-11-22')==([],0,False)
    msg=record([h,p])
    headers=[None]*35
    for col,name in FIELD_NAMES.items():headers[col]=name
    headers[28:31]=["Ngày order","Giờ order","Người order"]
    identity=datetime(2026,11,21).date(),'S6'
    sources={identity:('ORDER',{})}
    with patch.object(mail,'workbook_evidence',return_value=([headers],identity,sources,[])):
        mail.audit_workbooks([msg],'261121_THEO DOI ORDER NVL_P_S6.xlsb',None,{}, {},schedule={})
    rows,omitted,visible=mail.visible_out(msg,selected)
    assert visible and omitted==1 and [r['match_state'] for r in rows]==['missing']
    other=[*p];other[7]='22.11.2026'
    assert mail.visible_out(record([h,other]),selected)==([],1,True)
    assert mail.visible_out(record([],'OD KHSX VF8NP NGÀY 23-Nov-26'),selected)[2]
    class Folders(list):
        Count=property(len)
        def Item(self,i):return self[i-1]
    nvl=S(Name='NVL',EntryID='nvl')
    inbox=S(Name='Inbox',EntryID='in',Folders=Folders(),Parent=S(Folders=Folders([nvl])))
    session=S(GetDefaultFolder=lambda _:inbox,GetFolderFromID=lambda *ids:nvl)
    assert mail.scan_folders(session,'out',None)==[inbox,nvl]
    assert mail.scan_folders(session,'out',['nvl','store'])==[nvl]


def check_shift_order_and_stock(z,core):
    import zone_ui18 as ui
    import zone_daily as daily
    from contextlib import ExitStack
    assert ui.material_column([['STT','Mã NVL'],[1,'0012'],[2,'HsD'],[3,'HSD']])==['0012','HSD']
    assert ui.material_column([['0007'],[''],['m1']])==['0007','M1']
    from collections import Counter
    groups={}
    for dt in ('2026-11-27','2026-11-26'):
        for model,teams in [('VF5',{'S7'}),('LIMO',{'S6'}),('VF8',{'S3','S1'}),('VF9',{'S3'}),('WILD',{'S2'}),('X',set())]:
            groups[dt,model]=dict(count=Counter(),shifts=teams,known=True)
    items=daily.snapshot(groups,{})
    assert [i[2] for i in items]==['S1/S3','S2','S3','S6','S7','']*2
    assert items[0][0]=='2026-11-26'
    config=dict(core.DEFAULT_CONFIG,allocation_strategy=z.MIXED_STRATEGY,fefo_materials=['hsd'],available_column='AV',available_unit_column='MEINS',available_node='NODE')
    zone=core.ZoneManager()
    requests=[dict(material=m,qty=1,station='Zone 4',input_zone='4') for m in ('HSD','FIFO')]
    def row(m,batch,gr,expiry):
        return dict(MATNR=m,CHARG=batch,LGPLA='BIN',OWNER=config['ewm_owner'],LGTYP=config['ewm_storage_type'],
                    UI_WDATU=gr,UI_WDATT='08:00:00',VFDAT=expiry,MEINS='EA',AV='1')
    stock=[row('HSD','EARLY-GR','01.11.2026','28.12.2026'),row('HSD','EARLY-EXP','08.11.2026','01.12.2026'),
           row('FIFO','LATE-GR','10.11.2026',''),row('FIFO','FIRST-GR','02.11.2026','')]
    cols=list(stock[0])
    grid=S(ColumnOrder=S(Count=len(cols),ElementAt=cols.__getitem__),RowCount=len(stock),
           GetCellValue=lambda i,k:stock[i][k],GetColumnTitles=lambda key:['Available Qty BUoM'])
    tree=S(GetNodeTextByKey=lambda key:'Available Stock',doubleClickNode=lambda _:None)
    with ExitStack() as stack:
        for name,value in [('mon_start',tree),('mon_grids',[grid]),('idle',None),('optional',S(Text='')),
                           ('require',S(press=lambda:None)),('inline_select',None),('status',None)]:
            stack.enter_context(patch.object(z,name,return_value=value))
        result=z.stock_for(None,['HSD','FIFO'],config)
        groups,shortages,_=core.AllocationEngine(zone,5,20).allocate(requests,result)
        assert not shortages
        assert {(r['material'],r['batch']) for g in groups for r in g['lines']}=={('HSD','EARLY-EXP'),('FIFO','FIRST-GR')}
        stock[0]['VFDAT']=''
        try:z.stock_for(None,['HSD','FIFO'],config)
        except z.StopRun as exc:assert 'EARLY-GR' in str(exc) and 'HSD' in str(exc)
        else:raise AssertionError('Listed batch has no expiry')
        stock[:]=stock[2:]
        cols.remove('VFDAT')
        grid.RowCount=len(stock)
        grid.ColumnOrder.Count=len(cols)
        assert len(z.stock_for(None,['FIFO'],config))==2


def check(path):
    _,entries,_=archive(path.read_bytes())
    assert {"pyexpat.pyd","_ctypes.pyd","libffi-8.dll"}<=entries.keys()
    mods=pyz_entries(payload(next(e for e in entries.values() if e[3]==b"z")))
    assert {"ctypes","ctypes.wintypes","ctypes._endian","ctypes.util","tkinter.font","zone_report_tables","zone_report_png","zone_excel_live","secrets","hmac","uuid","platform","pypdf","zone18","zone_ui18","zone_inbound",
            "zone_pdf","zone_winprint","zone_pdf_job"}<=mods.keys()
    sys.meta_path.insert(0,EmbeddedSource(mods))
    assert {"zone_cleanup","zone_workspace","zone_qty","tkinter.colorchooser"}<=mods.keys()
    from zone_qty import entry_amount
    from zone_cleanup import eligible,open_ob,untouched
    from zone_result_grid import ResultGrid
    from datetime import date
    from unittest.mock import Mock
    assert entry_amount('28+15')==43
    r=[None]*35
    r[24],r[27],r[26],r[13]='Pending','Hết tồn kho MA','2026-11-20','Hết tồn'
    assert eligible(r) and untouched(r) and not open_ob(r)
    r[24]='Partial finished'
    r[27]='Chưa ra đơn'
    r[13]='1013306168'
    assert eligible(r) and open_ob(r)=='1013306168'
    r[15]=200
    assert eligible(r) and not open_ob(r)
    r[24]='Done'
    assert not eligible(r)
    canvas=S(render_job=None,winfo_ismapped=lambda:True,winfo_height=lambda:520,widths=[100]*10,
             rows=[('x',)*10]*1257,height_px=26,canvasy=lambda y:0,visible_range=None,active=None,
             delete=Mock(),draw=Mock(),configure=Mock())
    ResultGrid.render_view(canvas)
    ResultGrid.render_view(canvas)
    assert canvas.draw.call_count==24 and canvas.configure.call_count==1
    canvas.canvasy=lambda y:1240*26
    ResultGrid.render_view(canvas)
    assert canvas.draw.call_args.args[0]==1257
    check_outlook_filter()
    check_shift_reports()
    check_mail_and_cartons()
    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_inbound as inbound
    import zone_ui18 as ui
    check_inbound(inbound,ui,z)
    check_shift_order_and_stock(z,core)
    try:
        from pypdf import PdfWriter
        from pypdf.xmp import XmpInformation
    except ImportError as exc:
        raise AssertionError("PDF validator could not import from EXE archive") from exc
    assert isinstance(sys.modules["xml.dom.expatbuilder"].__loader__,EmbeddedSource)
    metadata=XmpInformation.create()
    metadata.dc_title={"x-default":"Portable PDF check"}
    assert XmpInformation(metadata.stream).dc_title=={"x-default":"Portable PDF check"}
    assert list(inbound.request_rows("Số IB\n185900001\tDữ liệu khác",True))==[{"ib":"185900001"}]
    assert inbound.request_rows("MA-1\t200\t5300000000\tBill A",False,"ZMME240")[0]["qty"]=="200"
    assert z.parse_obs("1013306168\tTEST-PART\t19-01\t6029140750")==["1013306168"]
    assert z.ordered_date("31.03.2026")<z.ordered_date("01.04.2026")
    assert z.receipt("S","Material document 5001234567 posted")==("","5001234567")
    assert z.receipt("E","Outbound Delivery 1013306168")==("","")
    assert z.receipt("S","Outbound Delivery 1013306168 created")==("1013306168","")
    check_mon_batch(z,core)
    calls=[]
    from zone_result_grid import ResultGrid
    grid=S(active=(2,0),rows=[('1013306168',),('1013306169',)],names=['OB'],copy=calls.append)
    grid.copy_cell=lambda event:ResultGrid.copy_cell(grid,event)
    app=S(tree=grid)
    gui.SapZoneApp._on_tree_copy_shortcut(app)
    assert calls==['1013306169']
    grid.active=None
    gui.SapZoneApp._on_tree_copy_shortcut(app)
    assert calls==['1013306169']
    sample=ui.InboundPage.fetch("IB",None,[{"ib":"185900001"}],{"sloc":""},{},"VL06I")
    assert sample[0]["ib"]=="185900001" and sample[0]["source"]=="Mô phỏng"
    class Collection(list):
        @property
        def Count(self): return len(self)
        def __call__(self,index): return self[index]
    def ses(system,client,ident,busy=False):
        return S(Info=S(SystemName=system,Client=client,User="TEST",Transaction="MIGO"),Id=ident,Busy=busy)
    first=ses("PSV","908","psv1")
    selected=ses("PSV","908","psv2")
    engine=S(Children=Collection([S(Children=Collection([ses("QAS","100","qas"),first,selected,
                                                       ses("PSV","908","psv3"),ses("PSV","908","psv4")]))]))
    client=S(GetObject=lambda _who:S(GetScriptingEngine=engine))
    with patch.object(core,"win32com",S(client=client)):
        assert z.get_session(1,"PSV","908") is selected
        assert z.get_session(-1,"PSV","908") is first
        first.Busy=True
        assert z.get_session(-1,"PSV","908") is selected
        for index,system,cl in [(0,"PSV","908"),(-1,"PRD","200")]:
            try: z.get_session(index,system,cl)
            except z.StopRun: pass
            else: raise AssertionError("Ambiguous or mismatched SAP session accepted.")
    with tempfile.TemporaryDirectory() as folder,patch.object(core,"get_base_dir",return_value=folder):
        temp=Path(folder)
        text=temp/"fake.pdf"
        text.write_text("A placeholder PDF")
        assert not z.pdf_valid(text)
        pdf=temp/"valid.pdf"
        writer=PdfWriter()
        writer.add_blank_page(width=100,height=100)
        writer.write(pdf)
        assert z.pdf_valid(pdf)
        core.ConfigManager.save_config({**core.DEFAULT_CONFIG,"sap_system":"QAS","inbound":{"plant":"3001"}})
        read=core.ConfigManager.load_config()
        assert read["sap_system"]=="QAS" and read["inbound"]["plant"]=="3001" and read["inbound"]["warehouse"]=="VF02"
        assert "vl06i_layout" not in read["inbound"]
        assert inbound.dates(read["inbound"])==("","")
        core.ConfigManager.save_config({**core.DEFAULT_CONFIG,"inbound":{"vl06i_layout":"","zmme_layout":"/CUSTOM"}})
        assert "vl06i_layout" not in core.ConfigManager.load_config()["inbound"]
        assert "zmme_layout" not in core.ConfigManager.load_config()["inbound"]
        cfg=dict(core.DEFAULT_CONFIG)
        p=z.Pipeline(cfg,core.ZoneManager())
        output=p.run([dict(material="TEST",qty=5,station="Zone 4",input_zone="4")],is_mock=True)
        assert output["success"] and output["records"] and not output["pdf_files"] and z.latest_result() is None,output
        target=ses("PSV","908","s1")
        writes=[]
        window=S(sendVKey=lambda n:writes.append((n,len(z.pending()))))
        target.findById=lambda name,*args:window if name=="wnd[0]" else None
        group=dict(group_id="ONE",lines=[dict(material="TEST",batch="B",qty=1,unit="EA")])
        def fake_post(s,g,p,f,t):
            s.findById("wnd[0]").sendVKey(11)
            try: s.findById("wnd[0]").sendVKey(11)
            except z.StopRun: pass
            return True,"5001234567"
        with patch.object(z,"legacy_post",side_effect=fake_post),patch.object(z,"verify_migo"),patch.object(z,"status",return_value=("S","Material document 5001234567 posted")):
            try: z.post_with_checkpoint(target,z.identity(target),group,cfg,"R1")
            except z.StopRun: pass
            else: raise AssertionError("Material Document interpreted as OB.")
        assert writes==[(11,1)] and z.pending()[0][3]=="5001234567"
        token=z.pending()[0][0]
        z.resolve_pending(token,"1013306168","OB được xác minh trong SAP")
        assert not z.pending() and z.latest_result()["records"][0]["ob"]=="1013306168"
        with patch.object(z,"legacy_post",side_effect=AssertionError("Duplicate must stop before SAP")):
            try: z.post_with_checkpoint(target,z.identity(target),group,cfg,"R2")
            except z.StopRun as exc: assert "1013306168" in str(exc)
            else: raise AssertionError("Repeat should request confirmation.")
        original=[dict(ob="1013306168",material="TEST",sodon="19-01",who="6029140750")]
        with patch.object(z,"get_session",return_value=target),patch.object(z,"query_whos",return_value={"1013306168":dict(state="Chờ WHO",materials={})}):
            result=z.Pipeline(cfg,core.ZoneManager()).run_who_lookup_for_obs(["1013306168"],original)
        assert not result["success"] and result["records"][0]["sodon"]=="19-01"
        assert result["records"][0]["who"]=="(Chờ WHO)"
        cfg["auto_print_pdf"]=True
        cfg["pdf_output_folder"]=folder
        unrelated=dict(ob="1013306169",material="OLD",sodon="19-04",who="6029140754")
        with patch.object(z,"get_session",return_value=target),patch.object(
            z,"query_whos",return_value={"1013306168":dict(state="Chờ WHO",materials={
                "TEST":["6029140750","6029140751"],"TEST2":["6029140751"],"BLOCKED":["6029140752"]},
                wt_status={"TEST":{"6029140750":{""},"6029140751":{"C"}},"TEST2":{"6029140751":{"A"}},
                           "BLOCKED":{"6029140752":{"A"}}})}),patch.object(z,"make_pdf_job") as printer:
            result=z.Pipeline(cfg,core.ZoneManager()).run_who_lookup_for_obs(["1013306168"],[*original,unrelated])
        printer.assert_not_called()
        assert result["success"] and {r["ob"] for r in result["records"]}=={"1013306168"}
        assert result["records"][0]["sodon"]=="19-01/Chưa gán"
        assert z.printable_whos(result["records"])==["6029140750","6029140751"]
        completed=dict(result["records"][0])
        z.apply_order_numbers(completed,{"6029140750":"19-01","6029140751":"19-02"})
        assert completed["sodon"]=="19-01/19-02"
        assert z.tracking_values(completed)==("1013306168","TEST","19-01/19-02","6029140750/6029140751")
        assert z.tracking_values(result["records"][1])==("1013306168","TEST2","","")
        assert result["records"][2]["state"]=="Không in · toàn A"
        assert z.tracking_values(result["records"][2])[2:]==("","")
        output_file=temp/"tracking.xlsx"
        z.export_tracking([completed,*result["records"][1:]],output_file)
        from openpyxl import load_workbook
        book=load_workbook(output_file)
        assert [cell.value for cell in book["KET_QUA_3_COT"][2]]==["1013306168","TEST","19-01/19-02"]
        assert book["KET_QUA_CHI_TIET"]["E4"].value=="6029140752"
        assert book["KET_QUA_CHI_TIET"]["D4"].value is None
        book.close()
        z.mark_printed([completed,*result["records"][1:]],["6029140751"])
        assert completed["state"]=="Đã in một phần"
        assert result["records"][1]["state"]=="Không in · toàn A"
        z.mark_printed([completed],["6029140750"])
        assert completed["state"]=="Đã lưu PDF"
        status_cases=[({"1013306168":dict(state="Chưa thấy OB trong MON",materials={})},"Chưa thấy OB trong MON"),
                      (z.StopRun("ALV thiếu cột"),"Lỗi tra MON")]
        for value,state in status_cases:
            with patch.object(z,"get_session",return_value=target),patch.object(
                z,"query_whos",side_effect=[value],
            ):
                lookup=z.Pipeline(cfg,core.ZoneManager()).run_who_lookup_for_obs(["1013306168"])
            assert lookup["records"][0]["state"]==state and not z.printable_whos(lookup["records"])
    print("Embedded modules, copy cell stale selection, IB input, FIFO, paged MON, WT print status, tracking Excel, three-OB filter and Document/WHO joins, SAP session, checkpoints, retry, PDF validity and simulated workflows passed.")


if __name__=="__main__":
    check(Path(sys.argv[1]))
