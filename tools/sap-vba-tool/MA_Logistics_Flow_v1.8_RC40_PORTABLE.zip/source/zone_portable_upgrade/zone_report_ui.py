from bisect import bisect_right
from functools import lru_cache
from pathlib import Path
import threading
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,font as tkfont
import zone_daily as daily
import zone_shift as sh
import zone_report_tables as tables
from zone_report_png import export_set
from zone_order_result import file_key

PIVOT='Báo cáo cấp NVL'
END='Báo cáo cuối ca'
OVERVIEW='Tổng quan'


class ReportPage:
    def __init__(self,page,parent,grid):
        self.page=page
        self.grid=grid
        self.mode=tk.StringVar(value=PIVOT)
        self.full=tk.BooleanVar()
        self.materials=tk.BooleanVar()
        self.all=tk.BooleanVar()
        self.gather=tk.BooleanVar()
        self.hide_old_pending=tk.BooleanVar(value=False)
        self.base_name=''
        self.first=tk.StringVar()
        self.last=tk.StringVar()
        self.leader=tk.StringVar(value=page.app.config.get('report_leader',''))
        self.file=page.app.config.get('daily_report','')
        self.overrides={}
        self.base=self.current=self.option_mode=None
        self.items=[]
        self.sheets=[]
        self.positions=[]
        self.chart_data=None
        self.model_vars={}
        chart_names=page.app.config.get('overview_charts',['Theo model','Lý do Pending'])
        self.chart_types={k:tk.BooleanVar(value=k in chart_names) for k in ('Theo model','Lý do Pending','Theo ngày KHSX','Tỷ trọng trạng thái','Thác nước')}
        self.fonts={}
        self.measure=lru_cache(maxsize=12000)(lambda text,size,bold:self.font(size,bold).measure(text))
        nav=ttk.Frame(parent)
        nav.pack(fill='x',padx=8,pady=(0,3))
        for label in (PIVOT,END,OVERVIEW):
            ttk.Radiobutton(nav,text=label,value=label,variable=self.mode,command=self.paint).pack(side='left',padx=4)
        ttk.Button(nav,text='Chọn ORDER bàn giao…',command=self.open_base).pack(side='right')
        ttk.Button(nav,text='Xuất 3 ảnh PNG…',command=self.images).pack(side='right')
        file_button=ttk.Menubutton(nav,text='Tệp Excel ▾')
        self.file_menu=tk.Menu(file_button,tearoff=False,postcommand=self.file_commands)
        file_button.configure(menu=self.file_menu)
        file_button.pack(side='right',padx=5)
        ttk.Button(nav,text='Tải lại ORDER',command=page.reload).pack(side='right',padx=3)
        self.model_bar=ttk.Frame(parent)
        self.model_bar.pack(fill='x',padx=8)
        self.options=ttk.Frame(parent)
        self.options.pack(fill='x',padx=8,pady=3,before=self.model_bar)
        footer=ttk.Frame(parent)
        footer.pack(side='bottom',fill='x',padx=8,pady=2)
        ttk.Label(footer,textvariable=page.title,width=40,anchor='w').pack(side='left',fill='x',expand=True)
        ttk.Label(footer,textvariable=page.report_hint,width=45,anchor='e').pack(side='right',fill='x',expand=True)
        frame=ttk.Frame(parent,padding=6)
        frame.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(frame,background='#edf2f5',highlightthickness=0)
        self.canvas.grid(row=0,column=0,sticky='nsew')
        sy=ttk.Scrollbar(frame,command=self.scroll)
        sx=ttk.Scrollbar(frame,orient='horizontal',command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        sy.grid(row=0,column=1,sticky='ns')
        sx.grid(row=1,column=0,sticky='ew')
        frame.columnconfigure(0,weight=1)
        frame.rowconfigure(0,weight=1)
        self.pending_draw=None
        self.dirty=True
        self.revision=0
        self.computing=False
        self.sticky=None
        self.canvas.bind('<Map>',lambda _:self.paint() if self.dirty else self.queue_draw())
        self.canvas.bind('<Configure>',self.queue_draw)
        self.canvas.bind('<Button-1>',self.click)
        self.canvas.bind('<MouseWheel>',lambda e:self.scroll('scroll',-int(e.delta/120),'units'))
        self.canvas.bind('<Button-4>',lambda e:self.scroll('scroll',-1,'units'))
        self.canvas.bind('<Button-5>',lambda e:self.scroll('scroll',1,'units'))
        self.canvas.bind('<Button-1>',lambda e:self.canvas.focus_set(),add='+')
        self.canvas.bind('<Next>',lambda e:self.scroll('scroll',1,'pages'))
        self.canvas.bind('<Prior>',lambda e:self.scroll('scroll',-1,'pages'))
        self.canvas.bind('<Control-c>',lambda e:self.copy())
        self.caption_job=None
        self.leader.trace_add('write',self.queue_title)

    def font(self,size,bold):
        key=(size,bold)
        if key not in self.fonts:
            self.fonts[key]=tkfont.Font(root=self.canvas,family='Segoe UI',size=-size,weight='bold' if bold else 'normal')
        return self.fonts[key]

    def queue_title(self,*args):
        if self.caption_job is not None:self.canvas.after_cancel(self.caption_job)
        self.caption_job=self.canvas.after(250,self.refresh_title)

    def refresh_title(self):
        self.caption_job=None
        self.paint()

    def reset(self,path,stamp):
        if self.current!=(path,stamp):
            self.overrides={}
        if not self.current or self.current[0]!=path:
            self.model_vars.clear()
            self.base=None
            self.base_name=''
            self.first.set('')
            self.last.set('')
        self.current=path,stamp
        self.option_mode=None

    def optionbar(self):
        view=self.mode.get()
        scope=(view,self.first.get(),self.last.get())
        if self.option_mode==scope:return
        self.option_mode=scope
        for w in self.options.winfo_children():w.destroy()
        for widget in self.model_bar.winfo_children():widget.destroy()
        if view==OVERVIEW:
            def set_models(on):
                for model in models:self.model_vars[model].set(on)
                self.paint()
            ttk.Button(self.model_bar,text='Tất cả',command=lambda:set_models(True)).pack(side='left')
            ttk.Button(self.model_bar,text='Bỏ chọn',command=lambda:set_models(False)).pack(side='left')
            models=daily.scoped_models(self.page.table,self.first.get(),self.last.get()) if self.page.table else []
            for model in models:
                if model not in self.model_vars:self.model_vars[model]=tk.BooleanVar(value=True)
                ttk.Checkbutton(self.model_bar,text=model,variable=self.model_vars[model],command=self.paint).pack(side='left')
            chart=ttk.Menubutton(self.options,text='Biểu đồ ▾')
            menu=tk.Menu(chart,tearoff=False)
            def save_charts():
                self.page.app.config['overview_charts']=[k for k,v in self.chart_types.items() if v.get()]
                from sap_zone_core import ConfigManager
                ConfigManager.save_config(self.page.app.config)
                self.paint()
            for key,var in self.chart_types.items():menu.add_checkbutton(label=key,variable=var,command=save_charts)
            chart.configure(menu=menu);chart.pack(side='right')
        dates=sorted({day.isoformat() for _,r in sh.rows(self.page.table) if (day:=sh.day(r[26]))}) if self.page.table else []
        ttk.Label(self.options,text='KHSX').pack(side='left')
        self.date_choice=tk.StringVar(value=self.date_caption())
        picker=ttk.Combobox(self.options,state='readonly',width=23,textvariable=self.date_choice,
                            values=['Tất cả',*[tables.display_date(d) for d in dates],'Khoảng ngày…'])
        picker.pack(side='left',padx=(4,10))
        def select(event):
            choice=self.date_choice.get()
            if choice=='Tất cả':self.apply_dates('','')
            elif choice=='Khoảng ngày…':
                self.date_choice.set(self.date_caption())
                self.choose_range(dates)
            else:
                value=dates[picker.current()-1]
                self.apply_dates(value,value)
        picker.bind('<<ComboboxSelected>>',select)
        if view==PIVOT:
            menu=ttk.Menubutton(self.options,text='Chi tiết bảng ▾')
            actions=tk.Menu(menu,tearoff=False)
            for text,var in [('Mở Done và cấp một phần',self.full),('Hiện từng mã hàng',self.materials)]:
                actions.add_checkbutton(label=text,variable=var,command=self.paint)
            menu.configure(menu=actions)
            menu.pack(side='left')
        if view in (PIVOT,OVERVIEW):
            ttk.Checkbutton(self.options,text='Ẩn Pending ngày cũ',variable=self.hide_old_pending,command=self.paint).pack(side='left')
            ttk.Checkbutton(self.options,text='Cấp một phần ca trước',variable=self.all,command=self.paint).pack(side='left',padx=6)
            ttk.Checkbutton(self.options,text='Tập kết ca trước',variable=self.gather,command=self.paint).pack(side='left')
        if view==END:
            ttk.Label(self.options,text='TL').pack(side='left')
            ttk.Entry(self.options,textvariable=self.leader,width=16).pack(side='left',padx=4)
            ttk.Button(self.options,text='Lưu cuối ca…',command=lambda:self.fresh(self.export)).pack(side='right')
        menu=ttk.Menubutton(self.options,text='Copy ảnh ▾')
        items=tk.Menu(menu,tearoff=False)
        for i,name in enumerate((PIVOT,*daily.TITLES)):
            items.add_command(label=name,command=lambda idx=i:self.copy_image(idx))
        menu.configure(menu=items)
        menu.pack(side='right')
        if view!=OVERVIEW:
            ttk.Button(self.options,text='Copy bảng',command=self.copy).pack(side='right',padx=3)

    def date_caption(self):
        first,last=self.first.get(),self.last.get()
        if not first and not last:return 'Tất cả'
        if first==last:return tables.display_date(first)
        return tables.display_date(first)+' – '+tables.display_date(last)

    def apply_dates(self,first,last):
        if (first,last)!=(self.first.get(),self.last.get()):self.model_vars.clear()
        self.first.set(first)
        self.last.set(last)
        self.date_choice.set(self.date_caption())
        self.paint()

    def choose_range(self,dates):
        if not dates:return
        win=tk.Toplevel(self.page.app.root)
        win.title('Khoảng KHSX')
        win.transient(self.page.app.root)
        win.grab_set()
        fields=[]
        for i,(label,current) in enumerate((('Từ ngày',self.first.get() or dates[0]),('Đến ngày',self.last.get() or dates[-1]))):
            ttk.Label(win,text=label).grid(row=i,column=0,padx=8,pady=5,sticky='w')
            var=tk.StringVar(value=tables.display_date(current))
            ttk.Combobox(win,textvariable=var,values=[tables.display_date(d) for d in dates],state='readonly',width=13).grid(row=i,column=1,padx=8)
            fields.append(var)
        def apply():
            first,last=[sh.day(v.get()).isoformat() for v in fields]
            if first>last:
                messagebox.showinfo('Khoảng KHSX','Ngày kết thúc phải từ ngày bắt đầu trở đi.',parent=win)
                return
            win.destroy()
            self.apply_dates(first,last)
        ttk.Button(win,text='Áp dụng',command=apply).grid(row=2,column=1,pady=8)

    def file_commands(self):
        menu=self.file_menu
        menu.delete(0,'end')
        menu.add_command(label='Tải lại ORDER',command=self.page.reload)
        menu.add_command(label='Mở file ca trong Excel',command=self.page.show_excel)
        menu.add_command(label='Chọn ORDER đang mở…',command=self.page.choose_open)
        menu.add_separator()
        menu.add_command(label='Đọc ORDER bàn giao đầu ca…'+('  ·  '+self.base_name if self.base_name else ''),
                         command=self.open_base)
        menu.add_command(label='Chọn Excel lưu báo cáo…'+('  ·  '+Path(self.file).name if self.file else ''),command=self.pick)

    def pick(self):
        file=filedialog.askopenfilename(parent=self.page.app.root,title='Chọn BC Cấp NVL trong thư mục BC Daily NVL',
            initialdir=str(Path(self.file).parent) if self.file else None,filetypes=[('Excel','*.xlsx *.xlsm *.xlsb')])
        if file:
            self.file=file
            self.paint()
        return file

    def open_base(self):
        if not self.page.path or self.page.app.is_running:
            return
        filename=filedialog.askopenfilename(parent=self.page.app.root,title='Chọn ORDER bàn giao đã lưu lúc đầu ca',
                    initialdir=self.page.folder,filetypes=[('ORDER','*.xlsb *.xlsm *.xlsx')])
        if not filename:
            return
        path=Path(filename)
        if path.resolve()==self.page.path.resolve():
            messagebox.showinfo('Mốc đầu ca','Chọn bản bàn giao riêng của ca, trước khi phát sinh công việc.')
            return
        def ready(result):
            self.base=result[0]
            self.base_name=path.name
            self.overrides={}
            self.paint()
        self.page.read_order(path,ready)

    def identity(self):
        ca=sh.parsed_name(self.page.path) if self.page.path else None
        return '   ·   '.join(filter(None,(('Ca '+ca[1]) if ca else '',self.leader.get().strip(),
                                           ca[0].strftime('%d.%m.%Y') if ca else '',
                    'KHSX '+self.date_caption() if self.first.get() or self.last.get() else '')))

    def excel_options(self):
        return self.page.pivots.get(file_key(self.page.path),{}) if self.page.path else {}

    def report_options(self, use_excel=True):
        options=dict((self.excel_options() or {}) if use_excel else {})
        shift=sh.parsed_name(self.page.path) if self.page.path else None
        if self.hide_old_pending.get() and shift:
            options['pending_since']=shift[0].isoformat()
        return options

    def daily_view(self):
        self.groups=daily.daily(self.page.table,self.first.get(),self.last.get(),self.base,sh.parsed_name(self.page.path))
        self.items=daily.snapshot(self.groups,self.overrides)
        return tables.shift_tables(self.items,self.identity())

    def pivot_view(self,compact=False):
        return tables.pivot_table(self.page.table,self.identity(),False if compact else self.full.get(),
                  self.all.get(),False if compact else self.materials.get(),self.report_options(),self.first.get(),self.last.get(),self.base,sh.parsed_name(self.page.path),self.gather.get())

    def paint(self):
        self.revision+=1
        self.sheets=[]
        self.positions=[]
        self.chart_data=None
        self.chart_hits=[]
        self.groups={}
        self.items=[]
        self.sticky=None
        self.chart_states={}
        self.dirty=not self.canvas.winfo_ismapped()
        if self.dirty:return
        self.optionbar()
        self.canvas.delete('all')
        self.canvas.yview_moveto(0)
        if not self.page.table:
            self.page.report_hint.set('Chọn ORDER đang mở hoặc bắt đầu ca để xem báo cáo.')
            self.canvas.configure(scrollregion=(0,0,1,1))
            return
        if self.computing:return
        self.computing=True
        version=self.revision
        table=self.page.table
        base=self.base
        mode=self.mode.get()
        first,last=self.first.get(),self.last.get()
        title,shift_id=self.identity(),sh.parsed_name(self.page.path)
        full,all_rows,materials=self.full.get(),self.all.get(),self.materials.get()
        gather,options=self.gather.get(),self.report_options()
        overview_options=self.report_options(False)
        overrides=dict(self.overrides)
        models={m for m,v in self.model_vars.items() if v.get()}
        self.page.report_hint.set('Đang tính báo cáo…')
        def compute():
            if mode==OVERVIEW:
                _,lines=daily.pivot(table,all_rows=all_rows,options=overview_options,first=first,last=last,baseline=base,identity=shift_id,include_gather=gather)
                states={rec[0]:vals[0] for vals,tag,records in lines if tag=='state' for rec in records}
                return states,[rec for rec in lines[-1][2] if rec[2] in models]
            if mode==PIVOT:
                return [tables.pivot_table(table,title,full,all_rows,materials,options,first,last,base,shift_id,gather)]
            groups=daily.daily(table,first,last,base,shift_id)
            items=daily.snapshot(groups,overrides)
            return groups,items,tables.shift_tables(items,title)
        def ready(data,error):
            self.computing=False
            if not self.canvas.winfo_ismapped():
                self.dirty=True
                return
            if version!=self.revision:
                self.paint()
                return
            if error:
                self.page.report_hint.set('Lỗi tính báo cáo · '+error)
                return
            if mode==OVERVIEW:
                self.chart_states,self.chart_data=data
                self.page.report_hint.set('Số dòng ORDER theo KHSX và model · Bấm đúp cột để xem dòng nguồn.')
                self.canvas.xview_moveto(0)
                self.draw()
                return
            if mode==PIVOT:
                definitions=data
                hint=('Gồm dòng cấp một phần bàn giao' if all_rows else 'Đếm dòng ORDER theo trạng thái và bộ lọc Pivot')+' · Bấm đúp ô để xem dòng ORDER.'
            else:
                self.groups,self.items,definitions=data
                unknown=sum(item[3]['new_gathered'] is None for item in self.items)
                hint='Bấm đúp dòng model để xem hoặc chốt tập kết.'
                missing=sum(r[3]['unknown_supply'] for r in self.items)
                if missing:hint+=f' · {missing} dòng đã cấp thiếu mốc SL đầu ca.'
                if unknown:hint+=f'  ·  {unknown} nhóm chờ chốt số tập kết.'
                if first and last and first>last:hint='Ngày KHSX bắt đầu lớn hơn ngày kết thúc.'
            if mode==PIVOT:
                hint+=' · Mốc bàn giao: '+(self.base_name or 'chưa chọn · dùng dấu đầu ca nếu có')
            self.page.report_hint.set(hint)
            self.layout_sheets(definitions)
        def worker():
            try:
                data=compute()
            except Exception as exc:
                self.page.app.post_ui(lambda msg=str(exc):ready(None,msg))
            else:
                self.page.app.post_ui(lambda:ready(data,None))
        threading.Thread(target=worker,daemon=True).start()

    def layout_sheets(self,definitions):
        self.sheets=[tables.layout(t,self.measure) for t in definitions]
        offset=8
        for sheet in self.sheets:
            self.positions.append(offset)
            offset+=sheet.height+14
        width=max(s.width+16 for s in self.sheets)
        self.canvas.configure(scrollregion=(0,0,width,offset),yscrollincrement=18)
        self.draw()

    def scroll(self,*args):
        self.canvas.yview(*args)
        self.queue_draw()
        return 'break'

    def queue_draw(self,event=None):
        if self.pending_draw is None:
            self.pending_draw=self.canvas.after_idle(self.draw)

    def draw_chart(self):
        from collections import defaultdict
        c=self.canvas
        width=max(c.winfo_width()-2,740)
        self.chart_hits=[]
        states=('Done','Partial finished','Pending')
        labels=('Hoàn thành','Cấp một phần','Pending')
        colors=('#207052','#257798','#a46512')
        ink='#17364b';line='#b7c8d3'
        def rect(x,y,w,h,fill,border=line):
            c.create_rectangle(x,y,x+w,y+h,fill=fill,outline=border)
        def label(x,y,value,size=13,bold=False,color=ink,anchor='w'):
            c.create_text(x,y,text=str(value),anchor=anchor,fill=color,font=self.font(size,bold))
        def hit(x,y,w,h,rows):
            if rows:self.chart_hits.append((x,y,x+w,y+h,rows))
        records=self.chart_data
        totals=defaultdict(list);models=defaultdict(lambda:defaultdict(list))
        days=defaultdict(list);notes=defaultdict(list)
        for rec in records:
            state=self.chart_states[rec[0]]
            totals[state].append(rec)
            models[rec[2]][state].append(rec)
            dt=sh.day(rec[1][26])
            days[dt.isoformat() if dt else 'Thiếu KHSX'].append(rec)
            if state=='Pending':notes[daily.report_note(rec[1])].append(rec)
        label(10,18,'KHSX '+self.date_caption()+'   ·   Số dòng ORDER trong phạm vi báo cáo',15,True)
        gap=8;cw=(width-20-len(states)*gap)/(1+len(states))
        for i,(title,color,rows) in enumerate(zip(('Tổng dòng',*labels),(ink,*colors),(records,*[totals[k] for k in states]))):
            x=10+i*(cw+gap)
            rect(x,36,cw,63,'white');rect(x,36,4,63,color,color)
            label(x+12,53,title,13,True,color);label(x+12,81,len(rows),23,True,color)
            hit(x,36,cw,63,rows)
        y=113
        if not records:
            label(12,y+15,'Không có dòng trong phạm vi đang chọn.')
            c.configure(scrollregion=(0,0,width,max(y+40,c.winfo_height())))
            return
        headers=('Model','Tổng dòng',*labels)
        panel=(width-28)/2
        def ranking(x,top,w,title,groups,color):
            groups=sorted(groups,key=lambda a:(-len(a[1]),a[0]))
            height=52+24*max(len(groups),1)
            rect(x,top,w,height,'white')
            label(x+10,top+19,title,15,True)
            maximum=max([1,*[len(r) for _,r in groups]])
            if not groups:label(x+10,top+47,'Không có dòng Pending')
            for j,(name,rows) in enumerate(groups):
                yy=top+45+j*24
                cap=w*.44
                text=name
                while len(text)>1 and self.measure(text,12,False)>cap-20:text=text[:-2]+'…'
                label(x+10,yy,text,12)
                start=x+cap
                rect(start,yy-5,w-cap-48,10,'#e8eff3','#e8eff3')
                if rows:rect(start,yy-5,(w-cap-48)*len(rows)/maximum,10,color,color)
                label(x+w-10,yy,len(rows),13,True,anchor='e');hit(x,yy-11,w,22,rows)
            return height
        sections=[]
        if self.chart_types['Theo model'].get():
            sections.append(('Pending theo model',[(m,g['Pending']) for m,g in models.items() if g['Pending']],colors[2]))
        if self.chart_types['Lý do Pending'].get():sections.append(('Lý do Pending',list(notes.items()),'#447593'))
        if self.chart_types['Theo ngày KHSX'].get():
            sections.append(('Khối lượng theo ngày KHSX',[(tables.display_date(k),v) for k,v in days.items()],'#426589'))
        if self.chart_types['Tỷ trọng trạng thái'].get():
            rect(10,y,width-20,65,'white');label(20,y+16,'Tỷ trọng trạng thái',14,True)
            x=20
            for i,key in enumerate(states):
                rows=totals[key];w=(width-40)*len(rows)/len(records)
                if w:
                    rect(x,y+32,w,20,colors[i],colors[i])
                    if w>45:label(x+w/2,y+42,f'{len(rows)/len(records):.0%}',12,True,'white','center')
                    hit(x,y+32,w,20,rows);x+=w
            y+=73
        if self.chart_types['Thác nước'].get():
            rect(10,y,width-20,145,'white');label(20,y+17,'Thác nước · phân bổ tổng dòng',14,True)
            step=(width-40)/(1+len(states));remaining=len(records)
            for i,(name,rows,color) in enumerate(zip(('Tổng dòng',*labels),(records,*[totals[k] for k in states]),(ink,*colors))):
                upper=remaining
                lower=remaining-len(rows) if i else 0
                x=20+i*step
                top=y+108-52*upper/len(records);base=y+108-52*lower/len(records)
                rect(x+8,top,step-16,max(1,base-top),color,color)
                label(x+step/2,top-10,len(rows),12,True,color,'center')
                label(x+step/2,y+127,name,12,False,ink,'center')
                if i:remaining=lower
                if i<len(states):
                    level=y+108-52*remaining/len(records)
                    c.create_line(x+step-8,level,x+step+8,level,fill=line,dash=(2,2))
                hit(x,y+36,step,100,rows)
            y+=153
        for i in range(0,len(sections),2):
            pair=sections[i:i+2]
            heights=[ranking(10+j*(panel+8),y,panel if len(pair)==2 else width-20,*entry) for j,entry in enumerate(pair)]
            y+=max(heights)+8
        label(10,y+14,'Trạng thái theo model',16,True);y+=30
        col=(width-20)/len(headers)
        def table_row(name,values,top,head=False,index=0):
            for j,value in enumerate((name,*values)):
                x=10+j*col
                rect(x,top,col,28,'#284961' if head else '#f3f7fa' if index%2 else 'white')
                text=value if head or j==0 else len(value)
                label(x+col/2,top+14,text,13,head or j==1,'white' if head else colors[j-2] if j>=2 and text else ink,'center')
                if not head and j:hit(x,top,col,28,value)
        table_row(headers[0],headers[1:],y,True);y+=28
        for idx,(name,g) in enumerate(sorted(models.items(),key=lambda a:(-len(a[1]['Pending']),a[0]))):
            groups=[g[k] for k in states]
            table_row(name,[sum(groups,[]),*groups],y,index=idx);y+=28
        c.configure(scrollregion=(0,0,width,max(y+12,c.winfo_height())),yscrollincrement=20)

    def draw(self):
        self.pending_draw=None
        c=self.canvas
        c.delete('all')
        top=c.canvasy(0)-4
        bottom=top+c.winfo_height()+10
        if self.chart_data is not None:
            self.draw_chart()
            return
        for sheet,offset in zip(self.sheets,self.positions):
            if sheet.height+offset<top or offset>bottom:continue
            for cell in sheet.cells:
                x,y,r,b=cell.bounds
                y+=offset
                b+=offset
                if b<top or y>bottom:continue
                x+=8
                r+=8
                c.create_rectangle(x,y,r,b,fill=cell.fill,outline=tables.BORDER,width=1)
                if cell.text:
                    middle=(y+b)/2 if b-y<c.winfo_height() else (max(y,top)+min(b,bottom))/2
                    c.create_text(x+5 if cell.align=='left' else (x+r)/2,middle,
                        text=cell.text,anchor='w' if cell.align=='left' else 'center',justify=cell.align,
                        font=self.font(cell.size,cell.bold),fill=cell.color)

        self.sticky=None
        for sheet,start in zip(self.sheets,self.positions):
            if start+sheet.bottom[0]<=top+4<start+sheet.height:
                y=top+4
                cells=sheet.cells[1:1+len(sheet.table.headers)]
                for cell in cells:
                    x,t,r,b=cell.bounds
                    c.create_rectangle(x+8,y,r+8,y+b-t,fill=cell.fill,outline=tables.BORDER)
                    c.create_text((x+r)/2+8,y+(b-t)/2,text=cell.text,font=self.font(cell.size,True))
                self.sticky=(y,y+cells[0].bounds[3]-cells[0].bounds[1])
                break

    def click(self,event):
        x,y=self.canvas.canvasx(event.x)-8,self.canvas.canvasy(event.y)
        if self.chart_data is not None:
            for left,top,right,bottom,records in self.chart_hits:
                if left<=x+8<right and top<=y<bottom:
                    self.detail(records,'Tổng')
                    break
            return
        if self.sticky and self.sticky[0]<=y<self.sticky[1]:return
        for sheet,start in zip(self.sheets,self.positions):
            if not start<=y<start+sheet.height or not 0<=x<sheet.width:continue
            index=bisect_right(sheet.bottom,y-start)-1
            if index<0 or index>=len(sheet.table.rows):return
            row=sheet.table.rows[index]
            if row.key is None:return
            col=bisect_right(sheet.right,x)
            for first,end,left,right,_,_,target in sheet.table.spans:
                if first<=index<end and left<=col<right:
                    row=sheet.table.rows[target]
                    break
            self.detail(row.key,sheet.table.headers[col])
            return

    def detail(self,data,heading):
        root=self.page.app.root
        if self.mode.get() in (PIVOT,OVERVIEW):
            if heading not in ('Trạng thái','KHSX','NOTE','Tổng','Mã hàng'):
                data=[rec for rec in data if rec[2]==heading]
            from zone_search import order_detail
            source=self.page.table
            def order(win,rows):
                p=self.page
                if not rows or source is not p.table:
                    messagebox.showinfo('Ra đơn OD','Chọn dòng trong báo cáo hiện hành.',parent=win);return
                pop=tk.Toplevel(win);pop.title('Chọn loại hàng');pop.transient(win);pop.grab_set()
                def choose(kind):
                    if source is not p.table:
                        pop.destroy()
                        messagebox.showinfo('ORDER','Dữ liệu đã đổi · mở lại chi tiết.',parent=win)
                        return
                    selected={n for n,_,_ in rows}
                    pop.destroy();win.destroy()
                    p.app.show_order_page()
                    p.kh.set('Cả file ca');p.model.set('Tất cả');p.kind.set(kind)
                    p.team_filter.set('Tất cả');p.status_filter.set('Tất cả');p.quick.set('')
                    p.paint()
                    nodes=[node for node,r in p.lines.items() if r['row'] in selected and not r['problem']]
                    p.tree.selection_set(nodes)
                    p.hint.set(f'{len(nodes)}/{len(rows)} dòng phù hợp {kind}. Kiểm tra và bấm Ra đơn các dòng đã chọn.')
                for kind in ('Thường','Thùng'):
                    ttk.Button(pop,text='Hàng '+kind.lower(),command=lambda k=kind:choose(k)).pack(side='left',padx=6,pady=6)
            order_detail(root,[(n,r,self.page.path.name) for n,r,m in data],order)
            return
        c=self.groups[data]['count']
        g,note=self.overrides.get(data,(c['new_gathered'] if self.groups[data]['known'] or not c['gathered'] else None,''))
        win=tk.Toplevel(root)
        win.title('Chốt '+ ' · '.join(data))
        win.transient(root);win.grab_set()
        fields=[]
        for label,val in [('Tập kết phát sinh ca này',g),('Ghi chú',note)]:
            row=ttk.Frame(win,padding=5);row.pack(fill='x')
            ttk.Label(row,text=label,width=25).pack(side='left')
            var=tk.StringVar(value='' if val is None else str(val));fields.append(var)
            ttk.Entry(row,textvariable=var,width=32).pack(side='left')
        def save():
            try:
                g,n=(v.get().strip() for v in fields)
                update={**self.overrides,data:(int(g) if g else None,n)}
                daily.snapshot(self.groups,update)
                self.overrides=update
                win.destroy();self.paint()
            except ValueError as exc:
                messagebox.showwarning('Chốt số',str(exc),parent=win)
        ttk.Button(win,text='Áp dụng',command=save).pack(pady=6)

    def fresh(self,action):
        p=self.page
        if not p.path or p.app.is_running:return
        def ready(result):
            p.activate(p.path,p.passwords[file_key(p.path)],result)
            action()
        p.read_order(p.path,ready)

    def copy_image(self,index):
        from zone_report_png import windows_png
        def copy():
            table=self.pivot_view() if index==0 else self.daily_view()[index-1]
            if not self.leader.get().strip() or index==2 and any(r[3]['new_gathered'] is None or r[3]['unknown_supply'] for r in self.items):
                table.title+=' · BẢN TẠM'
            layout=tables.layout(table,self.measure)
            self.page.task('Đang copy ảnh…',lambda:windows_png(layout,None),
                           lambda _:self.page.report_hint.set('Đã copy ảnh · Ctrl+V vào Teams'),report_only=True)
        self.fresh(copy)

    def export(self):
        p=self.page
        if p.app.is_running or not p.path:return
        self.daily_view()
        if not self.items:return
        try:
            workday,team=sh.parsed_name(p.path)
            leader=self.leader.get().strip()
            if not leader or any(row[3]['new_gathered'] is None for row in self.items):
                raise ValueError('Nhập TL và chốt các ô TK ca đang chờ trước khi lưu.')
            if not self.file and not self.pick():return
            if sh.signature(p.path)!=p.stamp:
                raise ValueError('File ORDER vừa thay đổi. Tải lại và kiểm tra số chốt.')
            data=list(self.items)
            if not messagebox.askyesno('Lưu cuối ca',f'{workday:%d/%m/%Y} · {team} · {leader}\n{len(data)} nhóm KHSX/model · {sum(r[3]["order"] for r in data)} dòng ORDER\n{self.file}\nGhi tiếp vào hai sheet?',parent=p.app.root):
                return
            dest=self.file
            def done(bounds):
                import sap_zone_core as core
                p.app.config.update(daily_report=dest,report_leader=leader)
                core.ConfigManager.save_config(p.app.config)
                p.report_hint.set('Đã lưu Tình trạng dòng %d–%d và Kết quả dòng %d–%d.'%(*bounds[0],*bounds[1]))
                p.app.status_text_var.set(p.report_hint.get())
                messagebox.showinfo('Đã lưu cuối ca',p.report_hint.get(),parent=p.app.root)
            expected=p.table
            def save():
                sh.verify_view(p.path,p.password,expected)
                return daily.archive(dest,workday,team,leader,data)
            p.task('Đang lưu báo cáo…',save,done,report_only=True)
        except Exception as exc:
            messagebox.showwarning('Báo cáo cuối ca',str(exc),parent=p.app.root)

    def images(self):
        p=self.page
        if p.app.is_running:return
        if not p.table:
            messagebox.showinfo('Xuất ảnh','Chọn file ORDER trước khi xuất ảnh.',parent=p.app.root)
            return
        pair=self.daily_view()
        if not self.items:
            messagebox.showinfo('Xuất ảnh','Không có dòng trong khoảng KHSX đã chọn.',parent=p.app.root)
            return
        reasons=[]
        if not self.leader.get().strip():reasons.append('chưa nhập TL')
        if any(c['unknown_supply'] for _,_,_,c,_ in self.items):reasons.append('thiếu mốc SL đầu ca')
        if any(c['new_gathered'] is None for _,_,_,c,_ in self.items):reasons.append('còn số tập kết chờ chốt')
        if reasons and not messagebox.askyesno('Xuất bản tạm',', '.join(reasons).capitalize()+'. Xuất ba ảnh với nhãn BẢN TẠM?',parent=p.app.root):
            self.mode.set(END)
            self.paint()
            return
        parent=filedialog.askdirectory(parent=p.app.root,title='Chọn nơi lưu bộ 3 ảnh báo cáo ca')
        if not parent:return
        definitions=(self.pivot_view(compact=True),*pair)
        for table in definitions:
            if reasons:table.title+='   ·   BẢN TẠM'
        sheets=[tables.layout(table,self.measure) for table in definitions]
        day,team=sh.parsed_name(p.path)
        expected=p.table
        filters=self.excel_options() or None
        def write():
            sh.verify_view(p.path,p.password,expected,filters)
            return export_set(parent,f'Bao_cao_{day:%Y%m%d}_{team}',sheets)
        def ready(folder):
            p.report_hint.set(f'Đã xuất 3 ảnh vào {folder}')
            from os import startfile
            try:startfile(str(folder))
            except OSError:messagebox.showinfo('Đã xuất 3 ảnh',str(folder),parent=p.app.root)
        p.task('Đang xuất 3 ảnh…',write,ready,report_only=True)

    def copy(self):
        if not self.sheets:return
        sections=[]
        for sheet in self.sheets:
            t=sheet.table
            lines=[t.title,'\t'.join(h.replace('\n',' ') for h in t.headers)]
            lines.extend('\t'.join(str(v) for v in row.values) for row in t.rows)
            sections.append('\n'.join(lines))
        self.page.app.copy_text('\n\n'.join(sections))
