"""MA Logistics Flow SAP adapters and outbound workflow."""
from collections import Counter
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from decimal import Decimal
import hashlib
import json
import os
import re
import sqlite3
import threading
import time

from zone_numbers import parse_sap_decimal, parse_sap_datetime_sort_key

APP_NAME = "MA Logistics Flow"
VERSION = "1.8 RC40"
INBOUND_DEFAULT = {"warehouse": "VF02", "plant": "", "sloc": "", "date_from": "", "date_to": "",
                   "me2n_scope": ""}
OB = re.compile(r"10[0-9]{8}")
WHO = re.compile(r"60[0-9]{8}")
WORK = threading.local()
LOCK = threading.Lock()


class StopRun(RuntimeError):
    pass


def require(obj, name):
    try:
        return obj.findById(name)
    except Exception as exc:
        raise StopRun("Không tìm thấy điều khiển SAP: " + name) from exc


def optional(obj, name):
    # SAP's Raise=False distinguishes missing controls from COM failures.
    try:
        return obj.findById(name, False)
    except TypeError:
        try:
            return obj.findById(name)
        except (KeyError, AttributeError):
            return None


def idle(session, timeout=20):
    deadline = time.monotonic() + timeout
    while session.Busy:
        if time.monotonic() >= deadline:
            raise StopRun("SAP quá thời gian chờ. Kiểm tra cửa sổ đang mở.")
        time.sleep(.08)


def status(session, allow_warnings=False):
    idle(session)
    if optional(session, "wnd[1]") is not None:
        raise StopRun("SAP có hộp thoại cần kiểm tra trực tiếp.")
    bar = require(session, "wnd[0]/sbar")
    if bar.MessageType in ("A", "E") or (bar.MessageType == "W" and not allow_warnings):
        raise StopRun(str(bar.Text))
    return str(bar.MessageType), str(bar.Text)


def start(session, transaction):
    idle(session)
    if optional(session, "wnd[1]") is not None:
        raise StopRun("Đóng hoặc xử lý hộp thoại SAP trước khi chạy.")
    session.StartTransaction(transaction)
    idle(session)
    if str(session.Info.Transaction).upper() != transaction.upper():
        raise StopRun(f"SAP chưa vào đúng giao dịch {transaction}.")


def identity(session):
    info = session.Info
    return (str(info.SystemName).upper(), str(info.Client), str(info.User), str(session.Id))


def get_session(session_idx=-1, preferred_sys="", preferred_client=""):
    if core.win32com is None:
        raise StopRun("Cần SAP GUI Scripting trên Windows và phiên đã đăng nhập.")
    system=preferred_sys.strip().upper()
    client=preferred_client.strip()
    if not system or not client:
        raise StopRun("Cấu hình System và Client trước khi kết nối.")
    engine = core.win32com.client.GetObject("SAPGUI").GetScriptingEngine
    matched=0
    for ci in range(engine.Children.Count):
        connection = engine.Children(ci)
        for si in range(connection.Children.Count):
            session = connection.Children(si)
            try:
                info=session.Info
                matches=(str(info.SystemName).strip().upper()==system and
                         str(info.Client).strip()==client and bool(str(info.User).strip()))
                busy=bool(session.Busy) if matches else False
            except Exception:
                continue
            if not matches:
                continue
            if session_idx<0 and not busy:
                return session
            if session_idx==matched:
                if busy:
                    raise StopRun("Phiên SAP chỉ định đang bận.")
                return session
            matched+=1
    if not matched:
        raise StopRun(f"Không tìm thấy phiên SAP đã đăng nhập khớp {system}/{client}.")
    if session_idx<0:
        raise StopRun(f"Cả {matched} phiên {system}/{client} đang bận.")
    raise StopRun("Chỉ số phiên vượt số phiên SAP khớp cấu hình.")


@contextmanager
def lease():
    if not LOCK.acquire(blocking=False):
        raise StopRun(f"Có tác vụ {APP_NAME} đang chạy.")
    handle = None
    acquired = False
    try:
        if os.name == "nt":
            import win32event
            import win32api
            handle = win32event.CreateMutex(None, False, "Local\\SAP_ZONE_PORTABLE_WORK")
            acquired = win32event.WaitForSingleObject(handle, 0) in (0, 128)
            if not acquired:
                raise StopRun(f"Một cửa sổ {APP_NAME} khác đang xử lý.")
        yield
    finally:
        if handle is not None:
            if acquired:
                win32event.ReleaseMutex(handle)
            win32api.CloseHandle(handle)
        LOCK.release()


def db():
    shared=getattr(core,"_shared_journal",None)
    if shared:
        conn=sqlite3.connect(Path(shared).resolve().as_uri()+"?mode=rw",uri=True,timeout=10)
        conn.execute("PRAGMA synchronous=FULL")
        return conn
    path = Path(core.get_base_dir()) / "data" / "sap_zone_v18.sqlite"
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("""CREATE TABLE IF NOT EXISTS post_group(
       token TEXT PRIMARY KEY, run_id TEXT NOT NULL, state TEXT NOT NULL,
       snapshot TEXT NOT NULL, material_doc TEXT NOT NULL DEFAULT '',
       ob TEXT NOT NULL DEFAULT '', message TEXT NOT NULL DEFAULT '',
       changed TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS post_request(
       request_key TEXT NOT NULL, token TEXT NOT NULL UNIQUE)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS run_result(
       run_id TEXT PRIMARY KEY, document TEXT NOT NULL, changed TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    return conn


@contextmanager
def journal():
    conn = db()
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def pending():
    with journal() as conn:
        return conn.execute("""SELECT token,run_id,state,material_doc,ob,message
                               FROM post_group WHERE state IN ('POST_INTENT','POST_UNKNOWN')
                               ORDER BY changed,token""").fetchall()


def save_result(summary):
    with journal() as conn:
        conn.execute("INSERT OR REPLACE INTO run_result(run_id,document) VALUES(?,?)",
                     (summary["run_id"], json.dumps(summary, ensure_ascii=False, default=str)))


def latest_result():
    with journal() as conn:
        for (payload,) in conn.execute("SELECT document FROM run_result ORDER BY changed DESC,rowid DESC"):
            summary = json.loads(payload)
            if summary.get("records"):
                return summary
    return None


def output_context(config):
    return [str(config.get(key,"")).strip().upper() for key in
            ("sap_system","sap_client","ewm_warehouse")]


def output_history(config):
    context=output_context(config)
    with journal() as conn:
        return [summary for (payload,) in conn.execute(
                "SELECT document FROM run_result ORDER BY changed DESC,rowid DESC")
                if (summary:=json.loads(payload)).get("records")
                and summary.get("context",context)==context]


def known_orders(records):
    numbers={}
    for row in records:
        for who,value in row.get("who_numbers",{}).items():
            if WHO.fullmatch(who) and valid_order_number(value):
                numbers.setdefault(who,value)
        if "print_whos" in row:
            continue
        whos=row.get("who","").split("/")
        values=row.get("sodon","").split("/")
        # An RC1 number shared by several WHO cannot identify an individual WHO.
        if len(whos)==len(values):
            for who,value in zip(whos,values):
                if WHO.fullmatch(who) and valid_order_number(value):
                    numbers.setdefault(who,value)
    return numbers


def valid_order_number(value):
    return isinstance(value,str) and bool(re.fullmatch(r"[0-9A-Za-z_-]{1,26}",value))


def apply_order_numbers(row,numbers):
    whos=printable_whos([row])
    if whos:
        row["who_numbers"]={who:numbers[who] for who in whos if who in numbers}
        row["sodon"]="/".join(numbers.get(who,"Chưa gán") for who in whos)


def printable_whos(records):
    return list(dict.fromkeys(who for row in records for who in row.get("print_whos",row.get("who","").split("/"))
                              if WHO.fullmatch(who)))


def tracking_values(row):
    whos=printable_whos([row])
    numbers=known_orders([row])
    # Keep each position aligned with the eligible WHO when one remains unnumbered.
    sodon="/".join(numbers.get(who,"") for who in whos) if any(who in numbers for who in whos) else ""
    return (row.get("ob",""),row.get("material",""),sodon,"/".join(whos))


def export_tracking(records,path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    book=Workbook()
    tracking=book.active
    tracking.title="KET_QUA_3_COT"
    detail=book.create_sheet("KET_QUA_CHI_TIET")
    tracking.append(("Số OB","Mã hàng","Số đơn"))
    detail.append(("Số OB","Mã hàng","Số đơn (INWH)","WHO in được","WHO xác minh","Trạng thái","Ghi chú"))
    for row in records:
        values=tracking_values(row)
        tracking.append(values[:3])
        detail.append((*values,row.get("who",""),row.get("state",""),row.get("detail","")))
    for sheet,widths in ((tracking,(16,23,28)),(detail,(16,23,28,32,32,25,72))):
        for column,width in zip("ABCDEFG",widths):
            sheet.column_dimensions[column].width=width
        for cell in sheet[1]:
            cell.fill=PatternFill("solid",fgColor="153A6A")
            cell.font=Font(bold=True,color="FFFFFF")
        for line in sheet.iter_rows(min_row=2):
            for cell in line:
                if cell.value is not None:
                    cell.data_type="s"
        sheet.freeze_panes="A2"
        sheet.auto_filter.ref=sheet.dimensions
    target=Path(path)
    temporary=target.with_name(f".{target.name}.{os.getpid()}.tmp")
    try:
        book.save(temporary)
        os.replace(temporary,target)
    finally:
        book.close()
        temporary.unlink(missing_ok=True)


def mark_printed(records, whos):
    printed=set(whos)
    for row in records:
        eligible=set(printable_whos([row]))
        newly_printed=eligible & printed
        if newly_printed:
            done=eligible & (newly_printed | set(row.get("printed_whos",())))
            row["printed_whos"]=sorted(done)
            all_whos={who for who in row.get("who","").split("/") if WHO.fullmatch(who)}
            row["state"]="Đã lưu PDF" if done==all_whos else "Đã in một phần"


def available_order_numbers(prefix,first,records):
    used={number for row in records for number in row.get("sodon","").split("/") if number}
    used.update(known_orders(records).values())
    while True:
        value=f"{prefix}{first:02d}"
        if value not in used:
            yield value
        first+=1


def resolve_pending(token, ob, note):
    note = note.strip()
    if len(note) < 15 or (ob and not OB.fullmatch(ob)):
        raise StopRun("Nhập số OB đúng hoặc để trống nếu SAP xác nhận chưa Post, kèm ghi chú đối soát.")
    with journal() as conn:
        row = conn.execute("SELECT run_id,snapshot FROM post_group WHERE token=? AND state IN ('POST_INTENT','POST_UNKNOWN')", (token,)).fetchone()
        if not row:
            raise StopRun("Không tìm thấy nhóm đang chờ đối soát.")
        run_id, snapshot = row
        if ob:
            snapshot = json.loads(snapshot)
            materials = dict.fromkeys(l["material"] for l in snapshot["group"]["lines"])
            current=conn.execute("SELECT document FROM run_result WHERE run_id=?",(run_id,)).fetchone()
            result=json.loads(current[0]) if current else {"run_id":run_id,"records":[]}
            saved={(r["ob"],r["material"]) for r in result["records"]}
            result["records"].extend(dict(ob=ob,material=m,who="(Chờ WHO)",sodon="") for m in materials if (ob,m) not in saved)
            result["message"]="Đã đối soát OB. Chọn Tra lại MON."
            conn.execute("INSERT OR REPLACE INTO run_result(run_id,document) VALUES(?,?)",
                         (run_id,json.dumps(result,ensure_ascii=False)))
            conn.execute("UPDATE post_group SET state='POSTED',ob=?,message=?,changed=CURRENT_TIMESTAMP WHERE token=?", (ob,note,token))
        else:
            conn.execute("UPDATE post_group SET state='NOT_POSTED',message=?,changed=CURRENT_TIMESTAMP WHERE token=?", (note,token))


def parse_obs(text):
    result = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.split("\t")[0].strip().lower() in ("số ob", "ob"):
            continue
        fields = [line.split("\t")[0].strip()] if "\t" in line else line.split()
        if any(not OB.fullmatch(field) for field in fields):
            raise StopRun("Chỉ nhập số OB 10 chữ số bắt đầu bằng 10. Khi dán bảng, đặt OB ở cột đầu.")
        result.extend(fields)
    return list(dict.fromkeys(result))


def receipt(message_type, message):
    if message_type != "S" or re.search(r"not (?:posted|created|saved)|failed|không|error",message,re.I):
        return "", ""
    delivery = re.search(r"(?:outbound\s+delivery|delivery)\s*(?:number\s*)?[:#]?\s*(10\d{8})\b",message,re.I)
    material = re.search(r"(?:material\s+document|chứng từ vật tư)\s*(?:number\s*)?[:#]?\s*(\d{10})\b",message,re.I)
    return delivery[1] if delivery else "", material[1] if material else ""


def verify_migo(session,group,cfg):
    window=require(session,"wnd[0]")
    finder=core.MigoPostingService._find_child_by_name
    for name,prop,expected in (("GODYNPRO-ACTION","Key","A08"),("GODYNPRO-REFDOC","Key","R10"),
                               ("GODEFAULT_TV-BWART","Text","311")):
        control=finder(window,name)
        if control is None or str(getattr(control,prop)).strip()!=expected:
            raise StopRun("MIGO chưa xác nhận "+name+" = "+expected)
    table=core.MigoPostingService._find_child_by_id_contains(window,"tblSAPLMIGOTV_GOITEM")
    if table is None:
        raise StopRun("Chưa xác minh bảng MIGO trước Post.")
    # Read technical cells. Layout descriptions may move, so do not read a fixed screen column.
    lines=group["lines"]
    col_count=int(table.Columns.Count)
    if len(lines)>int(table.VisibleRowCount):
        raise StopRun("Bảng MIGO chưa hiển thị đủ dòng. Hãy mở rộng bảng trước khi chạy lại.")
    field_names=("MATNR","CHARG","ERFMG","ERFME","WERKS","LGORT","UMLGO")
    matched={}
    for col in range(col_count):
        try:
            cell=table.GetCell(0,col)
            match=re.search(r"GOITEM-([A-Z0-9]+)(?:\[|$)",str(cell.Name).upper())
            if match is None:
                match=re.search(r"GOITEM-([A-Z0-9]+)(?:\[|$)",str(cell.Id).upper())
            name=match[1] if match else ""
        except Exception:
            continue
        if name in field_names:
            matched[name]=col
    if set(matched)!=set(field_names):
        raise StopRun("Layout MIGO thiếu cột kỹ thuật: "+", ".join(sorted(set(field_names)-set(matched))))
    for i,row in enumerate(lines):
        actual={key:str(table.GetCell(i,col).Text).strip().upper() for key,col in matched.items()}
        expect={"MATNR":row["material"],"CHARG":row["batch"],"ERFME":row["unit"],
                "WERKS":cfg["plant"],"LGORT":cfg["sloc_from"],"UMLGO":cfg["sloc_to"]}
        if any(actual[key]!=str(value).upper() for key,value in expect.items()) or number(actual["ERFMG"],cfg)!=Decimal(str(row["qty"])):
            raise StopRun(f"Dòng MIGO {i+1} không khớp mã, số lượng, kho, Batch hoặc ĐVT.")
    for i in range(len(lines),int(table.VisibleRowCount)):
        if str(table.GetCell(i,matched["MATNR"]).Text).strip():
            raise StopRun("Có dòng MIGO ngoài kế hoạch.")


class GuardedWindow:
    def __init__(self, window, owner):
        self._window = window
        self._owner = owner

    def __getattr__(self, name):
        return getattr(self._window, name)

    def sendVKey(self, key):
        if key == 11:
            self._owner.before_post()
        return self._window.sendVKey(key)


class GuardedPost:
    """Preserve the tested GOITEM filling routine and intercept its Save."""
    def __init__(self, session, before_post):
        self.session = session
        self.before_post = before_post

    def __getattr__(self, name):
        return getattr(self.session, name)

    def findById(self, path, *args):
        control = self.session.findById(path, *args)
        if path == "wnd[0]" and control is not None:
            return GuardedWindow(control, self)
        if path in ("wnd[0]/tbar[1]/btn[23]", "wnd[0]/tbar[0]/btn[11]"):
            raise StopRun("Hãy xác minh giao dịch trước khi dùng nút Post dự phòng.")
        return control

    def SendCommand(self, command):
        if str(command).upper().strip() == "MIGO_POST":
            raise StopRun("Bỏ lệnh Post dự phòng. Tra cứu trạng thái SAP.")
        return self.session.SendCommand(command)


def post_with_checkpoint(session, expected, group, cfg, run_id, approve_repeat=None):
    plant, source, dest = (str(cfg[key]) for key in ("plant", "sloc_from", "sloc_to"))
    snapshot = {"session":expected, "group":group, "plant":plant, "from":source, "to":dest}
    # Avoid including the MIGO group label or ephemeral SAP session in the business key.
    request = [expected[:2], plant, source, dest, sorted(
        (l["material"],l["batch"],str(l["qty"]),l.get("station",""),l.get("zone","")) for l in group["lines"])]
    request_key = hashlib.sha256(json.dumps(request,ensure_ascii=False).encode()).hexdigest()
    token = hashlib.sha256((run_id+":"+group["group_id"]+":"+request_key).encode()).hexdigest()
    with journal() as conn:
        previous=conn.execute("""SELECT g.ob FROM post_group g JOIN post_request r ON r.token=g.token
                                 WHERE r.request_key=? AND g.state='POSTED' ORDER BY g.changed DESC LIMIT 1""",
                              (request_key,)).fetchone()
    if previous and (not approve_repeat or not approve_repeat(previous[0])):
        raise StopRun("Nhóm giống OB "+previous[0]+". Xác nhận đây là yêu cầu xuất mới trước khi Post.")
    sent = False
    def intent():
        nonlocal sent
        if sent:
            raise StopRun("Đã gửi Post, chờ đối soát.")
        if identity(session) != expected or str(session.Info.Transaction).upper() != "MIGO":
            raise StopRun("Phiên SAP hoặc giao dịch MIGO đã thay đổi.")
        status(session)
        verify_migo(session,group,cfg)
        with journal() as conn:
            try:
                conn.execute("INSERT INTO post_group(token,run_id,state,snapshot) VALUES(?,?,?,?)",
                             (token,run_id,"POST_INTENT",json.dumps(snapshot,ensure_ascii=False)))
                conn.execute("INSERT INTO post_request VALUES(?,?)",(request_key,token))
            except sqlite3.IntegrityError as exc:
                raise StopRun("Nhóm này đã có lần Post trong nhật ký. Kiểm tra trước khi chạy lại.") from exc
        sent = True
    detail = ""
    try:
        accepted, detail = legacy_post(GuardedPost(session,intent),group,plant,source,dest)
        if not sent:
            raise StopRun(str(detail) if not accepted else "Chưa ghi nhận lệnh Post.")
        kind, message = status(session)
        ob, material_doc = receipt(kind,message)
        if not ob:
            # Keep Material Document as separate evidence; never treat it as an OB.
            with journal() as conn:
                conn.execute("UPDATE post_group SET material_doc=?,message=? WHERE token=?",(material_doc,message,token))
            raise StopRun("SAP chưa trả số Outbound Delivery xác thực. " + message)
        with journal() as conn:
            conn.execute("UPDATE post_group SET state='POSTED',material_doc=?,ob=?,message=? WHERE token=?",(material_doc,ob,message,token))
            old=conn.execute("SELECT document FROM run_result WHERE run_id=?",(run_id,)).fetchone()
            partial=json.loads(old[0]) if old else {"run_id":run_id,"records":[],"message":"Chờ WHO"}
            for material in dict.fromkeys(l["material"] for l in group["lines"]):
                partial["records"].append(dict(ob=ob,material=material,sodon="",who="(Chờ WHO)"))
            conn.execute("INSERT OR REPLACE INTO run_result(run_id,document) VALUES(?,?)",
                         (run_id,json.dumps(partial,ensure_ascii=False)))
        return ob
    except Exception as exc:
        if sent:
            with journal() as conn:
                conn.execute("UPDATE post_group SET state='POST_UNKNOWN',message=? WHERE token=?",(str(exc),token))
            raise StopRun("Chờ đối soát MIGO. " + str(exc)) from exc
        raise


def columns(grid):
    order = grid.ColumnOrder
    return [str(order.ElementAt(i)) for i in range(order.Count)]


def rows(grid, required, extra=()):
    available = columns(grid)
    missing = set(required) - set(available)
    if missing:
        raise StopRun("Layout SAP thiếu cột kỹ thuật " + ", ".join(sorted(missing)))
    keys = list(required) + [key for key in extra if key in available and key not in required]
    return [{key:str(grid.GetCellValue(i,key)).strip() for key in keys}
            for i in range(int(grid.RowCount))]


def mon_start(session, warehouse):
    start(session,"/SCWM/MON")
    if optional(session,"wnd[1]") is not None:
        require(session,"wnd[1]/usr/ctxtP_LGNUM").Text = warehouse
        require(session,"wnd[1]/usr/ctxtP_MONIT").Text = "SAP"
        require(session,"wnd[1]/tbar[0]/btn[8]").press()
        status(session)
    title = str(require(session,"wnd[0]").Text)
    if not re.search(r"(?<!\w)"+re.escape(warehouse)+r"(?!\w)",title,re.I):
        raise StopRun("Chưa xác minh được kho MON trong tiêu đề: " + title)
    return require(session,"wnd[0]/usr/shell/shellcont[0]/shell")


MON_ALV = "wnd[0]/usr/shell/shellcont[1]/shell/"


def mon_grids(session, suffixes=(0,1)):
    grids=[]
    for slot in suffixes:
        obj=optional(session, MON_ALV + f"shellcont[{slot}]/shell")
        if obj is not None and getattr(obj,"SubType","")=="GridView":
            grids.append(obj)
    return grids


def grid_with(grids, keys):
    matches=[obj for obj in grids if set(keys)<=set(columns(obj))]
    if len(matches)!=1:
        raise StopRun("Cần đúng một bảng SAP có cột " + ", ".join(keys))
    return matches[0]


MON_ODO_ITEM = ("ERP_NUMBER", "DOCNO_H")
MON_WT_ITEM = ("DOCNO", "MATNR", "WHO")
MON_LE_DELIVERY_FILTER = "wnd[1]/usr/btn%_S_ERP_H_%_APP_%-VALU_PUSH"
MON_NO_DATA = re.compile(r"\bno (?:data (?:found|selected)|documents found|deliveries found|warehouse tasks found)\b",re.I)


class MonIncomplete(StopRun):
    pass


def read_mon_pages(session,grid,keys,stage):
    count=int(grid.RowCount)
    data=[]
    while len(data)<count:
        index=len(data)
        first=int(grid.FirstVisibleRow)
        visible=int(grid.VisibleRowCount)
        if not first<=index<first+visible:
            grid.FirstVisibleRow=index
            idle(session)
        first=int(grid.FirstVisibleRow)
        end=min(count,first+int(grid.VisibleRowCount))
        if int(grid.RowCount)!=count or not first<=index<end:
            raise MonIncomplete(f"{stage}: mới kiểm tra được {index}/{count} dòng MON.")
        for row in range(index,end):
            values={key:grid.GetCellValue(row,key) for key in keys}
            if any(value is None for value in values.values()):
                raise MonIncomplete(f"{stage}: SAP chưa trả đủ dữ liệu ở dòng {row+1}/{count}.")
            data.append({key:str(value).strip() for key,value in values.items()})
            if not any(data[-1].values()):
                try:
                    total_level=int(grid.GetRowTotalLevel(row))
                except Exception:
                    total_level=0
                if total_level<=0 and row+1<count:
                    raise MonIncomplete(f"{stage}: dòng {row+1}/{count} chưa nạp dữ liệu.")
            if "WHO" in values and not data[-1]["WHO"] and data[-1].get("DOCNO") and data[-1].get("MATNR"):
                try:
                    tooltip=str(grid.GetCellTooltip(row,"WHO")).strip().lstrip("0")
                except Exception:
                    continue
                if WHO.fullmatch(tooltip):
                    data[-1]["WHO"]=tooltip
    if int(grid.RowCount)!=count:
        raise MonIncomplete(f"{stage}: số dòng thay đổi trong lúc đọc MON.")
    return data


def wt_status_column(grid,available):
    for key in ("TOSTAT","WT_STATUS","STATUS"):
        if key in available:
            return key
    hits=[]
    for key in available:
        titles=grid.GetColumnTitles(key)
        if any(str(title).strip().casefold() in {"status","wt status","warehouse task status","trạng thái"}
               for title in titles):
            hits.append(key)
    if len(hits)!=1:
        raise MonIncomplete("Warehouse Task: chưa xác định cột Status trong layout MON.")
    return hits[0]


def resolve_wt_groups(tasks):
    # Only bridge omissions bounded by readable WHO in the same Document on a WHO-sorted grid.
    previous=None
    pending=[]
    for row in tasks:
        doc=mon_document_key(row["DOCNO"])
        who=mon_document_key(row["WHO"])
        if previous and (not doc or not row["MATNR"] or doc!=previous[0]):
            previous=None
            pending.clear()
        if WHO.fullmatch(who) and doc and row["MATNR"]:
            if previous and who>=previous[1]:
                for blank in pending:
                    blank["WHO"]=previous[1]
            previous=(doc,who)
            pending.clear()
        elif not row["WHO"] and previous:
            pending.append(row)
        else:
            previous=None
            pending.clear()


def mon_out_detail_rows(session, stage, required, extra=()):
    grid=optional(session,MON_ALV+"shellcont[1]/shell")
    if grid is None or getattr(grid,"SubType","")!="GridView":
        raise StopRun(f"{stage}: SAP chưa trả bảng kết quả ở khung dưới.")
    available=columns(grid)
    missing=[key for key in required if key not in available]
    if missing:
        visible=", ".join(available[:24]) or "(trống)"
        raise StopRun(f"{stage}: thiếu cột {', '.join(missing)}. Cột đang có: {visible}.")
    keys=[*required,*(key for key in extra if key in available and key not in required)]
    if required!=MON_WT_ITEM:
        return read_mon_pages(session,grid,keys,stage)
    if not int(grid.RowCount):
        return []
    status_key=wt_status_column(grid,available)
    tasks=read_mon_pages(session,grid,[*keys,status_key],stage)
    if any(not row["WHO"] and row["MATNR"] and row["DOCNO"] for row in tasks):
        try:
            ascending=str(grid.GetColumnSortType("WHO")).strip().casefold()=="ascending"
        except Exception:
            ascending=False
        if ascending:
            resolve_wt_groups(tasks)
    for row in tasks:
        row["WT_STATUS"]=row[status_key].upper()
    return tasks


def mon_document_key(value):
    return value.lstrip("0") if value.isascii() and value.isdigit() else value.upper()


def mon_out_index(obs, items):
    reports={ob:dict(state="Chưa thấy OB trong MON",materials={}) for ob in obs}
    documents={}
    for row in items:
        ob=mon_document_key(row["ERP_NUMBER"])
        if ob not in reports:
            continue
        report=reports[ob]
        document=mon_document_key(row["DOCNO_H"])
        if not document:
            if report["state"]!="Chờ WHO":
                report["state"]="Chưa xác minh Document"
            continue
        report["state"]="Chờ WHO"
        documents.setdefault(document,set()).add(ob)
        material=(row.get("MATNR") or row.get("PRODUCT") or row.get("PRODUCTNO") or "").upper()
        if material:
            report["materials"].setdefault(material,[])
    return reports,documents


def match_mon_tasks(reports, documents, tasks):
    ambiguous={ob for owners in documents.values() if len(owners)>1 for ob in owners}
    for ob in ambiguous:
        reports[ob]["state"]="Chưa xác minh Document"
        reports[ob]["detail"]="Document EWM đang khớp nhiều OB trong lượt."
    missing_document=False
    for row in tasks:
        if not row["DOCNO"] and row["MATNR"]:
            missing_document=True
            continue
        owners=documents.get(mon_document_key(row["DOCNO"]),set())
        if len(owners)!=1:
            continue
        ob=next(iter(owners))
        if ob in ambiguous:
            continue
        report=reports[ob]
        material=row["MATNR"].upper()
        if not material:
            if row["WHO"]:
                report["detail"]="Có dòng Warehouse Task thiếu mã hàng."
                report["state"]="Chưa kiểm tra hết WT"
            continue
        whos=report["materials"].setdefault(material,[])
        who=mon_document_key(row["WHO"])
        if WHO.fullmatch(who):
            if who not in whos:
                whos.append(who)
            statuses=report.setdefault("wt_status",{}).setdefault(material,{})
            statuses.setdefault(who,set()).add(row.get("WT_STATUS"))
        else:
            report.setdefault("wt_unresolved",set()).add(material)
    if missing_document:
        for report in reports.values():
            if report["state"]=="Chờ WHO":
                report.update(state="Chưa kiểm tra hết WT",detail="Có dòng WT thiếu Document để đối chiếu.")
    return reports


def wt_print_result(report,material):
    whos=report["materials"].get(material,[])
    state=report["state"]
    if state!="Chờ WHO":
        return whos,[],state,report.get("detail",""),True
    statuses=report.get("wt_status",{}).get(material,{})
    unresolved=material in report.get("wt_unresolved",())
    eligible=[]
    blocked=[]
    review=[]
    for who in whos:
        values=statuses.get(who,set())
        if values.intersection({"","C"}):
            eligible.append(who)
        elif values=={"A"} and not unresolved:
            blocked.append(who)
        else:
            review.append(who)
    if eligible:
        state="In được một phần" if blocked or review or unresolved else "Sẵn sàng in"
    elif review or unresolved:
        state="Chưa kiểm tra hết WT"
    elif blocked:
        state="Không in · toàn A"
    details=[]
    if blocked:
        details.append("Toàn A: "+"/".join(blocked))
    if review:
        details.append("Cần kiểm tra Status: "+"/".join(review))
    if unresolved:
        details.append("Có WT chưa xác minh được WHO.")
    needs_review=state not in {"Sẵn sàng in","In được một phần","Không in · toàn A"} or bool(review or unresolved)
    return whos,eligible,state," · ".join(details),needs_review


def query_whos(session, obs):
    obs=list(dict.fromkeys(obs))
    if not obs or any(not OB.fullmatch(ob) for ob in obs):
        raise StopRun("Danh sách OB không hợp lệ.")
    cfg=getattr(WORK,"config",{})
    tree=mon_start(session,cfg.get("ewm_warehouse","VF02"))
    tree.doubleClickNode("N000000010")
    idle(session)
    fields=("wnd[1]/usr/txtS_ERP_H-LOW","wnd[1]/usr/ctxtS_ERP_H-LOW")
    field=next((value for name in fields if (value:=optional(session,name)) is not None),None)
    if field is None:
        raise StopRun("LE Delivery: chưa mở được bộ lọc OB trong MON.")
    for name in fields:
        high=optional(session,name.replace("-LOW","-HIGH"))
        if high is not None:
            high.Text=""
    if optional(session,MON_LE_DELIVERY_FILTER) is not None:
        field.Text=""
        inline_select(session,MON_LE_DELIVERY_FILTER,obs,window=2)
    elif len(obs)==1:
        field.Text=obs[0]
    else:
        raise StopRun("LE Delivery: không thấy nút chọn nhiều giá trị để nạp danh sách OB.")
    require(session,"wnd[1]/tbar[0]/btn[8]").press()
    kind,message=status(session,allow_warnings=True)

    reports,documents=mon_out_index(obs,[])
    if MON_NO_DATA.search(message):
        return reports
    if kind=="W":
        raise StopRun("LE Delivery: "+message)
    parent=optional(session,MON_ALV+"shellcont[0]/shell")
    if parent is None or getattr(parent,"SubType","")!="GridView":
        raise StopRun("Outbound Delivery Order: chưa đọc được bảng chứng từ ở khung trên.")
    if not int(parent.RowCount):
        return reports

    parent.selectAll()
    parent.pressToolbarButton("N000000011")
    status(session)
    items=mon_out_detail_rows(session,"Outbound Delivery Order Item",MON_ODO_ITEM,
                              ("MATNR","PRODUCT","PRODUCTNO"))
    reports,documents=mon_out_index(obs,items)
    if not documents:
        for report in reports.values():
            report["state"]="Chưa xác minh Document"
            report["detail"]="MON có bảng chứng từ nhưng chưa đọc được cặp OB và Document EWM khớp."
        return reports

    try:
        parent=require(session,MON_ALV+"shellcont[0]/shell")
        parent.selectAll()
        parent.pressToolbarButton("N000000096")
        kind,message=status(session,allow_warnings=True)
        if MON_NO_DATA.search(message):
            return match_mon_tasks(reports,documents,[])
        if kind=="W":
            raise StopRun(message)
        tasks=mon_out_detail_rows(session,"Warehouse Task",MON_WT_ITEM)
    except Exception as exc:
        for report in reports.values():
            if report["state"]=="Chờ WHO":
                state="Chưa kiểm tra hết WT" if isinstance(exc,MonIncomplete) else "Lỗi tra MON"
                report.update(state=state,detail=str(exc))
        return reports
    return match_mon_tasks(reports,documents,tasks)


def number(value, cfg):
    return parse_sap_decimal(value, cfg.get("sap_number_format","EU"))


def ordered_date(date, clock=""):
    day, sec=parse_sap_datetime_sort_key(date,clock)
    if day in ("INVALID_DATE","99999999") or (clock and sec=="999999"):
        raise StopRun("Ngày nhập hoặc HSD không đọc được: "+date)
    return day + "_" + sec


def inline_select(session, button, values, window=1):
    require(session,button).press()
    idle(session)
    modal=f"wnd[{window}]"
    require(session,modal+"/tbar[0]/btn[16]").press()
    if not core.MonStockService.copy_to_clipboard("\r\n".join(dict.fromkeys(values))):
        raise StopRun("Không đưa được danh sách lọc vào clipboard.")
    require(session,modal+"/tbar[0]/btn[24]").press()
    require(session,modal+"/tbar[0]/btn[8]").press()
    idle(session)


MIXED_STRATEGY = "FIFO + FEFO"


def fefo_scope(materials,cfg):
    mode=cfg.get("allocation_strategy","FIFO")
    if mode=="FEFO":
        return set(materials)
    if mode=="FIFO":
        return set()
    if mode!=MIXED_STRATEGY:
        raise StopRun("Chiến lược cấp hàng không hợp lệ: "+str(mode))
    listed={str(m).strip().upper() for m in cfg.get("fefo_materials",[])}
    return {m for m in materials if m.upper() in listed}


def stock_for(session, materials, cfg):
    warehouse=cfg["ewm_warehouse"]
    tree=mon_start(session,warehouse)
    code=cfg.get("available_node","").strip()
    if code and "overview" in str(tree.GetNodeTextByKey(code)).casefold():
        raise StopRun("Node được cấu hình là Stock Overview. Cần Available Stock.")
    if not code:
        keys=tree.GetAllNodeKeys()
        hits=[str(key) for key in keys if str(tree.GetNodeTextByKey(key)).strip().casefold()=="available stock"]
        if len(hits)!=1:
            raise StopRun("Không xác định duy nhất node Available Stock. Xác nhận node trong Cấu hình Xuất NVL.")
        code=hits[0]
    tree.doubleClickNode(code)
    idle(session)
    for field,value in [("S_LGTYP-LOW",cfg["ewm_storage_type"]),("S_OWNER-LOW",cfg["ewm_owner"])]:
        obj=optional(session,"wnd[1]/usr/ctxt"+field)
        if obj is None:
            obj=require(session,"wnd[1]/usr/txt"+field)
        obj.Text=value
    inline_select(session,"wnd[1]/usr/btn%_S_MATNR_%_APP_%-VALU_PUSH",materials,2)
    require(session,"wnd[1]/tbar[0]/btn[8]").press()
    status(session)
    fields=("MATNR","CHARG","LGPLA","OWNER","LGTYP","UI_WDATU")
    grid=grid_with(mon_grids(session),fields)
    available=cfg.get("available_column","").strip()
    if not available:
        hits=[]
        for col in columns(grid):
            captions=" ".join(str(x) for x in grid.GetColumnTitles(col)).casefold()
            if "avail" in captions or "khả dụng" in captions:
                hits.append(col)
        if len(hits)!=1:
            raise StopRun("Không xác định cột Available Qty. Chọn tên kỹ thuật trong Cấu hình Xuất NVL.")
        available=hits[0]
    fefo=fefo_scope(materials,cfg)
    dates=("VFDAT",) if fefo else ()
    unit=cfg.get("available_unit_column","").strip()
    captions=" ".join(str(x) for x in grid.GetColumnTitles(available)).casefold()
    if not unit:
        if "auom" in captions:
            raise StopRun("Chọn cột đơn vị tương ứng với Available Qty AUoM trong Cấu hình.")
        if "buom" not in captions:
            raise StopRun("Xác nhận tên kỹ thuật cột đơn vị của tồn khả dụng trong Cấu hình.")
        unit="MEINS"
    data=rows(grid,tuple(dict.fromkeys((*fields,available,*dates,unit))),("UI_WDATT",))
    result=[]
    for row in data:
        if row["MATNR"] not in materials or row["OWNER"].lstrip("0")!=cfg["ewm_owner"].lstrip("0") or row["LGTYP"]!=cfg["ewm_storage_type"]:
            raise StopRun("Kết quả Available Stock không khớp mã/Owner/Storage Type đã lọc.")
        quantity=number(row[available],cfg)
        if quantity<=0:
            continue
        if not row[unit] or not row["CHARG"] or not row["LGPLA"]:
            raise StopRun("Tồn khả dụng thiếu đơn vị, Batch hoặc Bin.")
        try:
            if row["MATNR"] in fefo:
                expiry=ordered_date(row["VFDAT"]).split("_")[0]
                receipt=ordered_date(row["UI_WDATU"],row.get("UI_WDATT","")) if row["UI_WDATU"] else "99999999_999999"
                sort_key=expiry+"_"+receipt
            else:
                sort_key=ordered_date(row["UI_WDATU"],row.get("UI_WDATT",""))
        except StopRun as exc:
            raise StopRun(f"{row['MATNR']} · batch {row['CHARG']} · {exc}") from exc
        result.append(dict(material=row["MATNR"],batch=row["CHARG"],bin=row["LGPLA"],unit=row[unit],available_qty=float(quantity),
                           allocated_qty=0,sort_key=sort_key))
    return result


def pdf_valid(path):
    if not path:
        return False
    try:
        from pypdf import PdfReader
        with open(path,"rb") as f:
            reader=PdfReader(f,strict=True)
            if reader.is_encrypted or not len(reader.pages):
                return False
            for page in reader.pages:
                contents=page.get_contents()
                if contents is not None:
                    contents.get_data()
        return True
    except Exception:
        return False


def first_copy_field(session):
    root = require(session, "wnd[0]/usr")
    stack = [root]
    fields = []
    labels = []
    while stack:
        node = stack.pop()
        kind = str(node.Type)
        if kind == "GuiLabel" and str(node.Text).strip().casefold() in (
            "number of copies", "số bản in", "số liên", "số bản sao"
        ):
            labels.append(node)
        if kind in ("GuiTextField", "GuiCTextField") and node.Changeable:
            fields.append(node)
        if getattr(node, "ContainerType", False):
            stack.extend(node.Children(i) for i in range(node.Children.Count))
    names = {"P_COPIES", "P_COPY", "P_TDCOP", "P_TDCOPIES", "P_ANZDR", "P_ANZ"}
    matches = [f for f in fields if str(f.Name).upper() in names or any(
        abs(f.ScreenTop-label.ScreenTop) <= 5 and f.ScreenLeft > label.ScreenLeft
        for label in labels)]
    if len(matches) != 1:
        raise StopRun("Chưa nhận diện duy nhất ô Number of Copies trên F00112. Kiểm tra tên kỹ thuật của ô qua F1.")
    return matches[0]


def write_copies(field, copies):
    field.Text = str(copies)
    if str(field.Text).strip().lstrip("0") != str(copies):
        raise StopRun("SAP chưa nhận đúng số liên ở Number of Copies.")


def print_whos(session, who_list, warehouse_num="VF02", copies=2, pdf_output_path=None, *, stage=None):
    if pdf_output_path:
        raise StopRun("Lưu PDF gốc qua Windows, sau đó dùng Chọn PDF gốc trong OUT NVL.")
    if not who_list or any(not WHO.fullmatch(who) for who in who_list) or not 1 <= copies <= 20:
        raise StopRun("Danh sách WHO hoặc số liên không hợp lệ.")
    report = stage or (lambda name: None)
    report("Mở màn hình in SAP F00112")
    idle(session)
    if optional(session,"wnd[1]") is not None:
        raise StopRun("SAP có hộp thoại cần kiểm tra trước khi in.")
    require(session,"wnd[0]/tbar[0]/okcd").Text="/n"
    require(session,"wnd[0]").sendVKey(0)
    status(session)
    tree=require(session,"wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell")
    tree.doubleClickNode("F00112")
    status(session)
    require(session,"wnd[0]/usr/ctxtP_LGNUM").Text=warehouse_num
    button=optional(session,"wnd[0]/usr/btn%_S_WHO_%_APP_%-VALU_PUSH")
    if button is not None:
        inline_select(session,"wnd[0]/usr/btn%_S_WHO_%_APP_%-VALU_PUSH",who_list)
    elif len(who_list)==1:
        require(session,"wnd[0]/usr/txtS_WHO-LOW").Text=who_list[0]
        high=optional(session,"wnd[0]/usr/txtS_WHO-HIGH")
        if high is not None:
            high.Text=""
    else:
        raise StopRun("Màn hình in thiếu trường chọn nhiều WHO.")
    write_copies(first_copy_field(session), copies)
    require(session,"wnd[0]").sendVKey(8)
    idle(session)
    if optional(session,"wnd[1]") is None:
        grid=require(session,"wnd[0]/usr/cntlGRID1/shellcont/shell")
        if "WHO" not in columns(grid):
            raise StopRun("Bảng in SAP thiếu cột WHO để đối chiếu.")
        whos={mon_document_key(row["WHO"]) for row in read_mon_pages(session,grid,("WHO",),"Danh sách in SAP")
              if row["WHO"]}
        if whos!=set(who_list):
            raise StopRun("Danh sách trả về khi in khác danh sách WHO đã chọn.")
        grid.selectAll()
        require(session,"wnd[0]/tbar[1]/btn[13]").press()
        idle(session)
    qty=optional(session,"wnd[1]/usr/ctxtSSFPP-TDCOPIES")
    if qty is None:
        qty=require(session,"wnd[1]/usr/txtSSFPP-TDCOPIES")
    device=optional(session,"wnd[1]/usr/ctxtSSFPP-TDDEST")
    if device is None:
        device=optional(session,"wnd[1]/usr/txtSSFPP-TDDEST")
    if device is not None and str(device.Text).strip().upper()!="LOCL":
        raise StopRun("Thiết bị đầu ra trong màn hình in SAP cần là LOCL để tạo PDF qua Windows.")
    write_copies(qty, copies)
    trigger=require(session,"wnd[1]/tbar[0]/btn[86]")
    report("Chờ người dùng lưu PDF gốc tại Windows")
    trigger.press()
    return {"submitted": len(who_list)}


def make_pdf_job(config, orders, *, progress=None, session_identity=None):
    from zone_pdf_job import run_job
    request=dict(operation="submit", orders=list(orders), session_idx=int(config["sap_session_idx"]),
                 system=config["sap_system"], client=config["sap_client"], warehouse=config["ewm_warehouse"],
                 copies=int(config.get("sap_print_copies",2)), session_identity=session_identity)
    return run_job(core.get_base_dir(),request,progress=progress)


class Pipeline:
    def __init__(self, config, zone_mgr):
        self.config = dict(config)
        self.zone_mgr = zone_mgr
        self.stop_requested = False
        self.run_id = datetime.now().strftime("RUN_%Y%m%d_%H%M%S_%f")

    def request_stop(self):
        self.stop_requested = True

    def step(self, progress, message):
        if self.stop_requested:
            raise StopRun("Đã dừng theo yêu cầu. Xem kết quả đã lưu.")
        if self.progress_cb:
            self.progress_cb(progress)
        if self.status_cb:
            self.status_cb(message)

    @contextmanager
    def access(self, mock):
        WORK.config=self.config
        try:
            with lease():
                if mock:
                    yield None
                    return
                core.SapConnector.init_thread_com()
                try:
                    yield get_session(int(self.config.get("sap_session_idx",-1)),self.config["sap_system"],self.config["sap_client"])
                finally:
                    core.SapConnector.uninit_thread_com()
        finally:
            WORK.config={}

    def summary(self):
        return dict(success=False,run_id=self.run_id,records=[],groups=[],shortages=[],unmapped=[],
                    pdf_files=[],message="",failures=[],context=output_context(self.config))

    def finish(self, result, mock):
        if not mock:
            save_result(result)
        return result

    def numbering(self):
        prefix=str(self.config.get("sodon_prefix", "")).strip() or datetime.now().strftime("%d-")
        first=int(self.config.get("sodon_start",1))
        if first < 1 or first > 999999 or not re.fullmatch(r"[0-9A-Za-z_-]{1,20}",prefix):
            raise StopRun("Tiền tố hoặc số bắt đầu INWH không hợp lệ.")
        return prefix, first

    def lookup(self, result, session, obs, existing, mock, new_order=False):
        obs=list(dict.fromkeys(obs))
        history=[] if mock else [r for run in output_history(self.config) for r in run["records"]]
        prior=[*existing,*history]
        numbers=known_orders(prior)
        counter=available_order_numbers(*self.numbering(),prior) if new_order else None
        self.step(62,f"Đang lọc MON một lượt cho {len(obs)} OB…")
        reports={}
        if not mock:
            try:
                reports=query_whos(session,obs)
            except Exception as exc:
                reports={ob:dict(state="Lỗi tra MON",materials={},detail=str(exc)) for ob in obs}
            if new_order:
                for _ in range(2):
                    missing=[ob for ob in obs if reports[ob]["state"]=="Chưa thấy OB trong MON"]
                    if not missing:
                        break
                    self.step(73,f"Đợi đồng bộ rồi tra lại {len(missing)} OB vừa tạo chưa thấy trong MON…")
                    time.sleep(2.5)
                    try:
                        reports.update(query_whos(session,missing))
                    except Exception as exc:
                        result["failures"].append(f"Lượt tra lại {len(missing)} OB: {exc}")
                        break
        self.step(82,"Đang ghép Document EWM, WHO và mã hàng…")
        for index,ob in enumerate(obs):
            old={row["material"]:row for row in reversed(prior)
                 if row["ob"]==ob and row["material"] not in ("","(Chưa xác định)")}
            if mock:
                example={m:[str(6029000000+(index+1)*100+i)] for i,m in enumerate(old or ["DEMO-NVL"])}
                report=dict(state="Chờ WHO",materials=example,
                            wt_status={m:{who:{""} for who in whos} for m,whos in example.items()})
            else:
                report=reports[ob]
            mapping=report["materials"]
            materials=list(dict.fromkeys([*mapping,*old])) if new_order else list(mapping) or list(old)
            materials=materials or ["(Chưa xác định)"]
            for material in materials:
                whos,eligible,state,detail,needs_review=wt_print_result(report,material)
                if counter:
                    for who in eligible:
                        if who not in numbers:
                            numbers[who]=next(counter)
                row=dict(ob=ob,material=material,
                         who="/".join(whos) if whos else "(Chờ WHO)" if state=="Chờ WHO" else "",
                         sodon=old.get(material,{}).get("sodon","") if not whos else "",
                         print_whos=eligible,state=state,detail=detail)
                apply_order_numbers(row,numbers)
                if needs_review:
                    result["failures"].append(f"{ob} · {material} • {detail or state}")
                result["records"].append(row)
        if not mock:
            save_result(result)

    def auto_print(self,result,expected):
        if not self.config.get("auto_print_pdf",False) or result["failures"]:
            return
        whos=printable_whos(result["records"])
        if not whos:
            return
        try:
            self.step(90,"Đang gửi danh sách WHO sang F00112…")
            make_pdf_job(self.config,whos,progress=lambda event:self.step(95,event["stage"]),
                         session_identity=expected)
            result["submitted_whos"]=whos
        except Exception as exc:
            result["failures"].append("Lỗi in PDF: "+str(exc))

    def run(self, requests, progress_cb=None, status_cb=None, is_mock=False):
        result=self.summary()
        result["is_mock"]=bool(is_mock)
        self.progress_cb,self.status_cb=progress_cb,status_cb
        try:
            self.numbering()
            if not requests:
                raise StopRun("Chưa có yêu cầu hợp lệ.")
            if any(not 0 < row["qty"] < float("inf") for row in requests):
                raise StopRun("Số lượng yêu cầu phải là số dương hữu hạn.")
            limits=self.config.get("max_materials_per_group",5),self.config.get("max_lines_per_group",20)
            if not 1<=int(limits[0])<=5 or not 1<=int(limits[1])<=20:
                raise StopRun("Giới hạn nhóm tối đa 5 mã và 20 dòng.")
            with self.access(is_mock) as session:
                if not is_mock and pending():
                    raise StopRun("Có nhóm đang chờ đối soát. Mở Cấu hình chung → Đối soát Post.")
                self.step(15,"Đang tải tồn khả dụng và lập nhóm.")
                expected=identity(session) if session is not None else None
                materials=list(dict.fromkeys(row["material"] for row in requests))
                if is_mock:
                    stock=[dict(material=m,batch="DEMO",bin="A1",unit="EA",available_qty=sum(r["qty"] for r in requests if r["material"]==m),
                                allocated_qty=0,sort_key="20260401_000000") for m in materials]
                else:
                    stock=stock_for(session,materials,self.config)
                groups,shortages,unmapped=core.AllocationEngine(self.zone_mgr,*map(int,limits)).allocate(requests,stock)
                result.update(groups=groups,shortages=shortages,unmapped=unmapped)
                if shortages:
                    details=" | ".join(f"{r['material']}: cần {r['required']}, có {r['allocated']}, thiếu {r['shortage']}" for r in shortages[:10])
                    raise StopRun("Tồn không đủ cho yêu cầu. " + details)
                if not groups:
                    raise StopRun("Chưa lập được nhóm có thể xử lý.")
                if not is_mock and any(l.get("unit")!="EA" for group in groups for l in group["lines"]):
                    raise StopRun("Có dòng tồn khả dụng chưa ở đơn vị EA. Cần xác nhận đơn vị trước khi Post.")
                if requests and all("line_id" in r for r in requests):
                    from zone_shift import check_allocated
                    check_allocated(requests,groups)
                    if getattr(self,"order_file",None):
                        from zone_order_result import group_sources
                        result.update(order_file=self.order_file,order_requests=requests,
                                      order_groups=group_sources(requests,groups),order_obs=[])
                if getattr(self,"claim_order",None):
                    self.claim_order()
                known=[]
                for index,group in enumerate(groups):
                    self.step(40+int(20*index/max(1,len(groups))), "MIGO 311 • Nhóm "+group["group_id"])
                    ob=(str(1090000000+self.config.get("mock_ob_offset",0)+index) if is_mock else post_with_checkpoint(session,expected,group,self.config,self.run_id,getattr(self,"approve_repeat",None)))
                    known.append(ob)
                    if "order_obs" in result:
                        result["order_obs"].append(ob)
                    for material in dict.fromkeys(l["material"] for l in group["lines"]):
                        result["records"].append(dict(ob=ob,material=material,who="(Chờ WHO)",sodon=""))
                    if not is_mock:
                        save_result(result)
                original=list(result["records"])
                result["records"]=[]
                try:
                    self.lookup(result,session,known,original,is_mock,new_order=True)
                finally:
                    present={(r["ob"],r["material"]) for r in result["records"]}
                    result["records"].extend(r for r in original if (r["ob"],r["material"]) not in present)
            if not is_mock:
                self.auto_print(result,expected)
            result["success"]=not result["failures"]
            result["message"]=("Mô phỏng hoàn tất." if is_mock else f"Đã tạo {len(known)} OB.") + (" Cần xử lý: "+" | ".join(result["failures"][:4]) if result["failures"] else "")
            if result.get("submitted_whos"):
                result["message"]+=" Đã gửi WHO sang SAP. Lưu PDF tại Windows rồi bấm Chọn PDF gốc."
        except Exception as exc:
            result["message"]=str(exc)
        return self.finish(result,is_mock)

    def run_who_lookup_for_obs(self, ob_list, existing_records=None, progress_cb=None, status_cb=None, is_mock=False):
        result=self.summary()
        result["lookup"]=True
        result["is_mock"]=bool(is_mock)
        self.progress_cb,self.status_cb=progress_cb,status_cb
        existing=list(existing_records or [])
        try:
            obs=parse_obs("\n".join(ob_list))
            if not obs:
                raise StopRun("Chưa nhập OB.")
            with self.access(is_mock) as session:
                self.lookup(result,session,obs,existing,is_mock)
            result["success"]=not result["failures"]
            ready=len(printable_whos(result["records"]))
            counts=Counter(row["state"] for row in result["records"])
            blocked=counts["Không in · toàn A"]
            review=sum(count for state,count in counts.items()
                       if state not in {"Sẵn sàng in","In được một phần","Không in · toàn A"})
            result["message"]=f"Đã tra {len(obs)} OB · {ready} WHO in được · {blocked} dòng toàn A · {review} dòng cần kiểm tra."
            if result["failures"]:
                result["message"]+=" Xem Nhật ký thao tác để biết chi tiết."
        except Exception as exc:
            result["message"]=str(exc)
        return self.finish(result,is_mock)


def install(namespace):
    global core, legacy_post
    import sys
    core=sys.modules[namespace["__name__"]]
    legacy_post=core.MigoPostingService.post_group
    old_load=core.ConfigManager.load_config
    def load_config(cls):
        cfg=old_load()
        cfg["inbound"]={**INBOUND_DEFAULT,**(cfg.get("inbound") or {})}
        for key in ("vl06i_layout","zmme_layout","me2n_layout","mb51_layout"):
            cfg["inbound"].pop(key,None)
        return cfg
    core.ConfigManager.load_config=classmethod(load_config)

    def save_config(cls,cfg):
        path=Path(cls.get_path())
        temp=path.with_name(path.name+"."+str(os.getpid())+".tmp")
        try:
            with temp.open("w",encoding="utf-8") as stream:
                json.dump(cfg,stream,ensure_ascii=False,indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp,path)
            return True
        finally:
            temp.unlink(missing_ok=True)

    def test_connection(session_idx=-1,preferred_sys="",preferred_client=""):
        # The Portable UI initializes COM around this informational check.
        try:
            session=get_session(session_idx,preferred_sys,preferred_client)
            system,client,user,_=identity(session)
            return {"ok":True,"system":system,"client":client,"user":user,"tcode":str(session.Info.Transaction)}
        except Exception as exc:
            return {"ok":False,"error":str(exc)}

    core.ConfigManager.save_config=classmethod(save_config)
    core.SapConnector.test_connection=staticmethod(test_connection)
    core.SapConnector.get_session=staticmethod(get_session)
    # The legacy routine still fills the MIGO form. Unknown popups are left for review.
    core.SapConnector.dismiss_popups=staticmethod(lambda *_args,**_kwargs:"")
    core.SapZonePipeline=Pipeline
    core.WhoPrintService.print_whos=staticmethod(print_whos)
    core.extract_ob_numbers=parse_obs
