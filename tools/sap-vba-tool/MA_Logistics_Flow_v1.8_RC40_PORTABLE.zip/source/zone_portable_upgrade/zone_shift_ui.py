from collections import Counter
from datetime import date
from pathlib import Path
import re
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

import sap_zone_core as core
import zone_shift as shift
import zone_order_result as order_result
import zone18 as z


def display_obs(slots):
    return ' / '.join(value.strip() for slot in slots for value in slot.split('/')
                      if value.strip() and shift.norm(value) not in ('hetton','hettonkhoma',''))


def grid(parent,headers):
    from zone_result_grid import KeyGrid
    tree=KeyGrid(parent,headers,sortable=True)
    tree.configure(width=min(sum(tree.widths),max(320,parent.winfo_screenwidth()-80)))
    return tree


def choose_matching_order(parent,paths):
    from datetime import datetime
    dialog=tk.Toplevel(parent)
    dialog.title('Chọn ORDER của ca')
    dialog.transient(parent)
    ttk.Label(dialog,text='Có nhiều file cùng ngày và ca. Chọn file để mở.').pack(anchor='w')
    listing=tk.Listbox(dialog,width=100,height=min(10,len(paths)),exportselection=False)
    listing.pack(fill='both',expand=True)
    for path in paths:
        modified=datetime.fromtimestamp(path.stat().st_mtime).strftime('%d/%m/%Y %H:%M:%S')
        listing.insert('end',f'{modified}   {path}')
    result=[]
    def accept(event=None):
        if listing.curselection():
            result.append(paths[listing.curselection()[0]])
            dialog.destroy()
    ttk.Button(dialog,text='Mở file đã chọn',command=accept).pack(side='right')
    ttk.Button(dialog,text='Hủy',command=dialog.destroy).pack(side='right')
    listing.bind('<Double-1>',accept)
    listing.bind('<Return>',accept)
    dialog.grab_set()
    listing.focus_set()
    parent.wait_window(dialog)
    if parent.winfo_exists():parent.grab_set()
    return result[0] if result else None


class ShiftPage:
    def __init__(self,app,order,reports,on_run):
        self.app,self.on_run=app,on_run
        self.path=self.password=self.table=self.stamp=None
        self.folder=app.config.get('order_folder','')
        self.title=tk.StringVar(value='Chưa chọn ca làm việc')
        self.hint=tk.StringVar()
        self.report_hint=tk.StringVar()
        self.report_mode=tk.StringVar(value='Tình trạng cấp NVL')
        self.model=tk.StringVar()
        self.kh=tk.StringVar()
        self.kind=tk.StringVar(value='Tất cả')
        self.passwords={}
        self.sources={}
        self.pivots={}
        self._candidates=[]
        self.qty_editor=None
        self.qty_view_changed=False
        self.odbs_origins=set()
        self.odbs_saved=set()
        self.cached_receipts=[]
        self.demo_runs={}
        self.lookup_result=None
        self.lines={}
        from tkinter import Menu
        main=ttk.Frame(order,padding=(6,3))
        main.pack(fill='both',expand=True)
        self.revision=0
        self.cleanup=None
        toolbar=self.toolbar=ttk.Frame(main)
        toolbar.pack(fill='x')
        bar=ttk.Frame(toolbar)
        numbered=ttk.Frame(toolbar)
        actions=ttk.Frame(toolbar)
        bar.grid(row=0,column=0,sticky='w')
        toolbar.columnconfigure(1,weight=1)
        for label,var,width in [('KHSX',self.kh,12),('Model',self.model,12),('Loại hàng',self.kind,16)]:
            ttk.Label(bar,text=label).pack(side='left',padx=(0,4))
            combo=ttk.Combobox(bar,textvariable=var,width=width,state='readonly')
            combo.pack(side='left',padx=(0,10))
            if var is self.kh:
                self.dates=combo
            elif var is self.model:
                self.models=combo
            else:
                combo.configure(values=('Tất cả','Thùng','Thường',shift.SHORT_BOX,shift.MODEL_ROUND,shift.EXTRA))
            combo.bind('<<ComboboxSelected>>',self.filter_changed)
        dropdown=ttk.Menubutton(actions,text='ORDER ▾')
        menu=Menu(dropdown,tearoff=False)
        menu.add_command(label='Tải lại ORDER',command=self.reload)
        menu.add_command(label='Chọn ORDER đang mở…',command=self.choose_open)
        menu.add_separator()
        from zone_bbbg import open_form
        menu.add_command(label='Lập BBBG theo trạm…',command=lambda:open_form(self))
        menu.add_command(label='Cấp 1 lượt thùng cho model (gồm ca trước)…',command=self.model_cartons)
        menu.add_command(label='Mở file ca trong Excel',command=self.show_excel)
        menu.add_command(label='Lấy dòng thùng Done ca trước…',command=self.previous_cartons)
        menu.add_command(label='Tra OB đang có của dòng chọn',command=self.check_line_obs)
        menu.add_command(label='Chốt lượt đã cấp ở ô ghép nhiều OB…',command=self.confirm_slot)
        from zone_cleanup import cleanup_dialog
        menu.add_command(label='Dọn OD theo ngày…',command=lambda:cleanup_dialog(self))
        menu.add_command(label='Đối soát dòng…',command=self.review)
        dropdown.configure(menu=menu)
        dropdown.pack(side='left',padx=(0,4))
        footer=self.footer=ttk.Frame(main)
        footer.pack(side='bottom',fill='x')
        ttk.Button(footer,text='Lập BBBG…',command=lambda:open_form(self)).pack(side='left')
        ttk.Button(footer,text='Dọn OD theo ngày…',command=lambda:cleanup_dialog(self)).pack(side='left')
        self.run_btn=ttk.Button(footer,text='Ra đơn các dòng đã chọn',command=self.submit)
        self.run_btn.pack(side='right')
        for label,var in [('Tiền tố số đơn',app.sodon_prefix_var),('Số bắt đầu',app.sodon_start_var)]:
            ttk.Label(numbered,text=label).pack(side='left')
            ttk.Entry(numbered,width=7,textvariable=var).pack(side='left',padx=(4,10))
        ttk.Checkbutton(numbered,text='Mô phỏng',variable=app.mock_mode_var,command=self.refresh_receipts).pack(side='left')
        actions.grid(row=0,column=2,sticky='e')
        numbered.grid(row=1,column=0,columnspan=2,sticky='w')
        def fit(event):
            wide=event.width>=bar.winfo_reqwidth()+numbered.winfo_reqwidth()+actions.winfo_reqwidth()+18
            numbered.grid_configure(row=0 if wide else 1,column=1 if wide else 0,columnspan=1 if wide else 2,sticky='w')
        toolbar.bind('<Configure>',fit)
        ttk.Label(main,textvariable=self.hint,wraplength=1020).pack(fill='x',pady=(4,0))
        requests=self.requests=ttk.Frame(main)
        requests.pack(fill='both',expand=True)
        self.result_window=tk.Toplevel(main)
        self.result_window.withdraw()
        self.result_window.title('Kết quả ra đơn')
        self.result_window.geometry('1050x430')
        self.result_window.protocol('WM_DELETE_WINDOW',self.result_window.withdraw)
        results=self.result_window
        ttk.Button(bar,text='Kết quả ra đơn…',command=self.result_window.deiconify).pack(side='left')
        from zone_stock import open_stock
        ttk.Button(bar,text='Check tồn',command=lambda:open_stock(self)).pack(side='left')
        from zone_result_grid import ResultGrid
        self.tree=ResultGrid(requests,[('Dòng',46),('Mã hàng',120),('Model',60),('Trạm',148),('SL ORDER',73),('Đã cấp',65),('Còn thiếu',67),('EA/thùng',65),('Thùng',52),('Số đơn',95),('OB',105),('Tình trạng',185)],toolbar=False)
        self.quick=tk.StringVar()
        self.team_filter=tk.StringVar(value='Tất cả')
        ttk.Label(numbered,text='Ca chạy').pack(side='left',padx=3)
        team_box=ttk.Combobox(numbered,width=6,textvariable=self.team_filter,values=('Tất cả','S1','S2','S3','S6','S7'),state='readonly')
        team_box.pack(side='left')
        team_box.bind('<<ComboboxSelected>>',lambda _:self.paint())
        self.sort_key=None
        self.desc=False
        self.status_filter=tk.StringVar(value='Tất cả')
        ttk.Label(numbered,text='Tình trạng').pack(side='left')
        self.status_box=ttk.Combobox(numbered,textvariable=self.status_filter,width=20,state='readonly')
        self.status_box.pack(side='left')
        self.status_box.bind('<<ComboboxSelected>>',lambda _:self.paint())
        ttk.Label(numbered,text='Mã / trạm / đơn / OB').pack(side='left',padx=4)
        ttk.Entry(numbered,textvariable=self.quick,width=18).pack(side='left')
        from zone_qty import open_editor
        ttk.Button(bar,text='Nhập SL…',command=lambda:open_editor(self,main)).pack(side='left',padx=3)
        self.quick.trace_add('write',lambda *_:self.paint())
        def sort_header(event):
            if self.cleanup:
                self.cleanup.sort_header(event)
                return
            x=self.tree.header.canvasx(event.x)
            for name,width in zip(self.tree.names,self.tree.widths):
                if x<width:
                    key=dict(zip([c for c,_ in self.tree.columns],('row','material','model','station','ordered','issued','remaining','pack','boxes','num','ob','status')))[name]
                    selected={self.lines[n]['line_id'] for n in self.tree.selection()}
                    self.desc=not self.desc if key==self.sort_key else False
                    self.sort_key=key
                    self.paint()
                    self.tree.selection_set({n for n,r in self.lines.items() if r['line_id'] in selected})
                    break
                x-=width
        self.tree.header.bind('<Button-1>',sort_header)
        def show_updated_odbs(event):
            if getattr(self,'odbs_repaint',False):
                self.odbs_repaint=False
                self.paint()
        self.tree.bind('<Map>',show_updated_odbs,add='+')
        self.tree.configure(height=180)
        resultbar=ttk.Frame(results)
        resultbar.pack(fill='x',pady=(5,0))
        ttk.Label(resultbar,text='Kết quả ra đơn').pack(side='left')
        self.order_progress=tk.StringVar()
        ttk.Label(resultbar,textvariable=self.order_progress,width=1).pack(side='left',fill='x',expand=True,padx=6)
        def progress(*args):
            if getattr(self,'posting',False):
                self.order_progress.set(app.status_text_var.get())
        app.status_text_var.trace_add('write',progress)
        ttk.Button(resultbar,text='Ghi OB và số đơn vào ORDER…',command=self.push).pack(side='right')
        ttk.Button(resultbar,text='Tra / in OB kết quả',command=self.open_result).pack(side='right',padx=4)
        self.result=ResultGrid(results,[('Dòng',50),('Mã hàng',135),('KHSX',90),('Model',70),('OB',155),('Số đơn',145),('Kết quả',220)],toolbar=False)
        self.result.enable_sort(lambda:self.result_items)
        self.result.configure(height=30)

        from zone_report_ui import ReportPage
        self.reporting=ReportPage(self,reports,grid)
        self.paint()
        self.reporting.paint()
        self.app.root.after(3000,self.watch_saved)

    def watch_saved(self):
        path=self.path
        editor_busy=self.qty_editor and (self.qty_editor.busy or self.qty_editor.dirty())
        if path and not editor_busy and not self.app.is_running and not getattr(self,'stat_busy',False) and self.app.root.state()!='iconic':
            self.stat_busy=True
            def ready(stamp):
                self.stat_busy=False
                if self.path!=path or self.app.is_running or stamp is None:return
                if self.qty_editor and self.qty_editor.dirty():return
                if stamp!=self.stamp and stamp==getattr(self,'pending_stamp',None) and stamp!=getattr(self,'attempted_stamp',None):
                    self.attempted_stamp=stamp
                    self.reload()
                self.pending_stamp=stamp
            def probe():
                try:stamp=shift.signature(path)
                except OSError:stamp=None
                self.app.post_ui(lambda:ready(stamp))
            threading.Thread(target=probe,daemon=True).start()
        self.app.root.after(3000,self.watch_saved)

    def task(self,label,fn,callback,on_error=None,report_only=False,read_only=False):
        if self.app.is_running:
            return
        self.app.is_running=True
        self.app.reading_order=read_only
        self.app.status_text_var.set(label)
        if not report_only:self.hint.set(label)
        self.report_hint.set(label)
        def finish(value,error):
            self.app.is_running=False
            self.app.reading_order=False
            try:
                if error:
                    if on_error and on_error(error):return
                    raise ValueError(error)
                callback(value)
                if self.app.status_text_var.get()==label:
                    self.app.status_text_var.set(self.report_hint.get() if report_only else self.hint.get())
            except Exception as exc:
                self.app.status_text_var.set(str(exc))
                if not report_only:self.hint.set(str(exc))
                self.report_hint.set(str(exc))
                messagebox.showwarning('ORDER',str(exc),parent=self.app.root)
        def worker():
            try:
                core.SapConnector.init_thread_com()
                try:
                    result=fn()
                finally:
                    core.SapConnector.uninit_thread_com()
                self.app.post_ui(lambda:finish(result,None))
            except Exception as exc:
                self.app.post_ui(lambda err=str(exc):finish(None,err))
        threading.Thread(target=worker,daemon=True).start()

    def choose(self):
        if self.app.is_running:
            return
        win=tk.Toplevel(self.app.root)
        win.title('Bắt đầu ca OUT NVL')
        win.transient(self.app.root)
        win.grab_set()
        box=ttk.Frame(win,padding=12)
        box.pack(fill='both',expand=True)
        dayvar=tk.StringVar(value=date.today().isoformat())
        team=tk.StringVar()
        folder=tk.StringVar(value=self.folder)
        for i,label in enumerate(('Thư mục ORDER','Ngày bắt đầu ca','Ca làm việc')):
            ttk.Label(box,text=label).grid(row=i,column=0,sticky='w',pady=4)
        ttk.Entry(box,textvariable=folder,width=48).grid(row=0,column=1,sticky='ew')
        def browse():
            p=filedialog.askdirectory(parent=win,initialdir=folder.get() or None)
            if p:
                folder.set(p)
        ttk.Button(box,text='Chọn…',command=browse).grid(row=0,column=2)
        ttk.Entry(box,textvariable=dayvar,width=15).grid(row=1,column=1,sticky='w')
        ttk.Combobox(box,textvariable=team,values=shift.TEAMS,width=12,state='readonly').grid(row=2,column=1,sticky='w')
        ttk.Label(box,text='Ca đêm dùng ngày bắt đầu ca. Chọn file đang dùng hoặc tạo từ file bàn giao.').grid(row=3,column=0,columnspan=3,pady=8)
        def choose_file(create):
            try:
                directory=Path(folder.get().strip())
                if not folder.get().strip() or not directory.is_dir():
                    raise ValueError('Chọn thư mục ORDER.')
                workday=date.fromisoformat(dayvar.get().strip())
                team_id=team.get()
                shift.target_name(workday,team_id,'.xlsb')
                found=shift.matches(directory,workday,team_id)
                if create and found:
                    raise ValueError('Ca này đã có file. Dùng Mở file ca đã có.')
                if not create and found:
                    source=found[0]
                    if len(found)>1:
                        source=choose_matching_order(win,found)
                        if source is None:return
                else:
                    prior=shift.previous_file(directory,workday,team_id) if create else None
                    if prior:
                        source=prior
                    else:
                        p=filedialog.askopenfilename(parent=win,initialdir=directory,title='Chọn file bàn giao ca trước' if create else 'Chọn file của ca',
                            filetypes=[('ORDER Excel','*.xlsb *.xlsm *.xlsx')])
                        if not p:return
                        source=Path(p)
                source_id=shift.parsed_name(source)
                if not create and (source_id!=(workday,team_id) or directory.resolve()!=source.parent.resolve()):
                    raise ValueError('Tên file/thư mục chưa khớp ngày và ca đang chọn.')
                if create and (not source_id or source_id==(workday,team_id) or source_id[0]>workday):
                    raise ValueError('Chọn file ca trước theo mẫu tên ORDER, kiểm tra ngày/ca nguồn.')
                dest=directory/shift.target_name(workday,team_id,source.suffix) if create else source
                win.destroy()
                def loaded(result):
                    password=self.passwords[order_result.file_key(source)]
                    if not create:
                        self.activate(dest,password,result)
                        return
                    table,stamp=result
                    done,part=shift.handover(table)
                    total=sum(1 for _ in shift.rows(table))
                    detail=(f'Nguồn: {source.name}\nĐích: {dest}\n\n'
                            f'{total} dòng ORDER · bỏ {len(done)} Done · giữ {total-len(done)} dòng.\n'
                            f'{len(part)} dòng cấp một phần sẽ có dấu bàn giao.\nTiếp tục tạo file ca mới?')
                    if messagebox.askyesno('Xác nhận bàn giao',detail,parent=self.app.root):
                        if password is None and shift.encrypted(source):
                            password=simpledialog.askstring('Bàn giao','Nhập mật khẩu để mở bản sao ca mới.',show='*',parent=self.app.root)
                            if password is None:return
                        def create_with(pw,retried=False):
                            def activated(result):
                                source_key=order_result.file_key(source)
                                self.pivots[order_result.file_key(dest)]=self.pivots.get(source_key)
                                self.auto_base=(dest,(source,table))
                                self.activate(dest,pw,result)
                            def retry(error):
                                if retried or not shift.open_password_error(error):
                                    return False
                                new=simpledialog.askstring('Mở bản sao bàn giao',
                                    f'{source.name} · Excel chưa mở được bản sao. Nhập lại mật khẩu để thử một lần.',
                                    show='*',parent=self.app.root)
                                if new is not None:create_with(new,True)
                                return True
                            def progress(msg):
                                self.app.post_ui(lambda:self.hint.set(msg))
                            self.task('Đang tạo và kiểm tra file ca…',
                                      lambda:shift.create(source,dest,pw,stamp,progress),activated,retry)
                        create_with(password)
                    else:
                        self.paint()
                        self.reporting.paint()
                self.read_order(source,loaded,with_baseline=not create)
            except Exception as exc:
                messagebox.showwarning('Bắt đầu ca',str(exc),parent=win if win.winfo_exists() else self.app.root)
        ttk.Button(box,text='Mở file ca đã có',command=lambda:choose_file(False)).grid(row=4,column=0)
        ttk.Button(box,text='Tạo file từ ca trước…',command=lambda:choose_file(True)).grid(row=4,column=1,columnspan=2,sticky='e')

    def choose_open(self):
        import zone_excel_live as live
        def list_files():
            return sorted({str(n) for n,_ in live.books() if shift.parsed_name(n)})
        def choose_path(path):
            path=Path(path)
            self.read_order(path,lambda data:self.activate(path,self.passwords.get(order_result.file_key(path)),data))
        def listed(paths):
            if not paths:
                messagebox.showinfo('ORDER','Chưa thấy file ca ORDER đang mở. Dùng Bắt đầu / đổi ca để chọn file.',parent=self.app.root)
                return
            if len(paths)==1:
                choose_path(paths[0])
                return
            win=tk.Toplevel(self.app.root)
            win.title('Chọn workbook ORDER đang mở')
            win.transient(self.app.root)
            win.grab_set()
            box=tk.Listbox(win,width=100,height=min(12,len(paths)),exportselection=False)
            box.pack(fill='both',expand=True,padx=8,pady=8)
            for path in paths:
                box.insert('end',path)
            box.select_set(0)
            def select(event=None):
                if box.curselection():
                    path=paths[box.curselection()[0]]
                    win.destroy()
                    choose_path(path)
            box.bind('<Double-1>',select)
            ttk.Button(win,text='Dùng file đã chọn',command=select).pack(pady=5)
        self.task('Đang tìm ORDER trong Excel…',list_files,listed)

    def read_order(self,path,callback,with_baseline=True):
        key=order_result.file_key(path)
        from zone_excel_live import shared_password
        password=self.passwords.get(key,self.password) or shared_password()
        def read(pw,remember=False):
            def fetch():
                from zone_qty import OrderTable
                raw,stamp,source,pivot=shift.read_order(path,pw)
                result=(OrderTable(raw),stamp,source,pivot)
                identity=shift.parsed_name(path)
                if identity and with_baseline:
                    expected=shift.previous_identity(*identity)
                    try:
                        candidates=shift.matches(path.parent,*expected) if expected else []
                        for candidate in candidates:
                            try:
                                data,prior_stamp,src,_=shift.read_order(candidate,pw,False)
                                if 'chưa lưu' not in src:
                                    shift.remember_handover(candidate,data,prior_stamp)
                                    return result,(candidate,data)
                            except Exception:
                                continue
                        if expected and not candidates:
                            return result,shift.saved_handover(path.parent,expected)
                    except (OSError,ValueError):
                        pass
                return result,None
            def ready(payload):
                result,baseline=payload
                self.auto_base=(path,baseline)
                if remember and result[2]=='File đã lưu':
                    try:shared_password(pw)
                    except OSError:pass
                self.passwords[key]=pw
                self.sources[key]=result[2]
                self.pivots[key]=result[3]
                callback(result[:2])
            def failed(err):
                if 'ORDER_PASSWORD_NEEDED' in err:
                    prompt('Nhập mật khẩu mở file '+path.name)
                    return True
                if shift.open_password_error(err) and not remember:
                    self.passwords.pop(key,None)
                    prompt('Excel chưa mở được '+path.name+'. Nhập lại mật khẩu để thử một lần.')
                    return True
                return False
            self.task('Đang đọc '+path.name+'…',fetch,ready,failed,read_only=True)
        def prompt(label):
            pw=simpledialog.askstring('ORDER',label,show='*',parent=self.app.root)
            if pw is not None:
                read(pw,True)
        read(password)

    @property
    def candidates(self):
        if self._candidates is None:
            self._candidates=shift.candidates(self.table,self.app.config)
        return self._candidates

    def notify_order_change(self):
        self.revision+=1
        for window in self.app.root.winfo_children():
            if hasattr(window,'order_stale'):window.order_stale()
        search=getattr(self.app,'search_page',None)
        if search and search.last_result:
            search.snapshot=search.last_result=None
            search.items={}
            search.tree.reset()
            search.hint.set('ORDER đã thay đổi · bấm Tra lại.')
        self.app.out_mail.schedule_audit()

    def apply_qty_table(self,result):
        self.table,self.stamp=result
        self._row_lookup=self.table.by_key
        self.set_odbs(self.odbs_saved,False)
        self._candidates=None
        self.notify_order_change()
        self.qty_view_changed=True
        self.attempted_stamp=None
        self.reporting.reset(self.path,(self.stamp,self.table))
        self.reporting.paint()
        if not self.qty_editor or not self.qty_editor.active:
            self.finish_qty_view()

    def finish_qty_view(self):
        if self.qty_view_changed:
            self.qty_view_changed=False
            self.filter_changed()

    def set_odbs(self,links,paint=True):
        import zone_mail
        origins={key for key,binding in zone_mail.order_bindings(self.table).values() if binding in links} if links and self.table else set()
        changed=origins!=self.odbs_origins
        self.odbs_origins,self.odbs_saved=origins,links
        if changed and paint:
            if self.tree.winfo_ismapped():self.paint()
            else:self.odbs_repaint=True

    def activate(self,path,password,result):
        if self.cleanup:self.cleanup.leave()
        from zone_qty import OrderTable
        if self.path!=path:
            if self.qty_editor:
                if not self.qty_editor.discard_ok():return
                self.qty_editor.dispose()
                self.qty_editor=None
            search=getattr(self.app,'search_page',None)
            if search:
                search.snapshot=search.last_result=None
                search.cache.clear()
                search.items={}
                search.tree.reset()
            self.order_progress.set('')
        changed_table=self.path!=path or self.stamp!=result[1] or self.table!=result[0]
        if self.path!=path:
            self.lines={}
            self.result_items={}
        self.path,self.password,self.folder=path,password,str(path.parent)
        self.passwords[order_result.file_key(path)]=password
        self.table,self.stamp=result
        self.attempted_stamp=None
        self.table=OrderTable(self.table)
        self._row_lookup=self.table.by_key
        if self.qty_editor and not self.qty_editor.dirty() and not self.qty_editor.editor:
            self.qty_editor.replace_table(self.table)
        from datetime import datetime
        source=self.sources.get(order_result.file_key(path),'File đã lưu')
        self.title.set(f'{path.name}  ·  {source}  ·  {datetime.now():%H:%M:%S}')
        self.app.status_text_var.set('Đã đọc '+path.name)
        out=self.app.out_mail
        changed=out.cfg.get('workbook')!=str(path)
        out.cfg=dict(out.cfg,workbook=str(path))
        out.password=password
        if changed:
            out.messages=[]
            out.groups.clear()
            out.expanded.clear()
            out.display.clear()
            out.tree.clear_rows()
            out.audit_table=None
            out.audit_path=None
            out.history_cache={}
            out.scan_generation=getattr(out,'scan_generation',0)+1
        if changed_table:
            import zone_mail
            self.set_odbs(zone_mail.odbs_links(path),False)
            self.notify_order_change()
        out.paint(notify=False)
        self.app.config.update(order_folder=self.folder,mail_out=out.cfg)
        core.ConfigManager.save_config(self.app.config)
        self._candidates=None
        self.reporting.reset(path,(self.stamp,self.table))
        auto=getattr(self,'auto_base',None)
        if auto and auto[0]==path and auto[1] and self.reporting.base_name in ('',auto[1][0].name):
            prev,self.reporting.base=auto[1]
            self.reporting.base_name=prev.name
        self.refresh_receipts(paint=False)
        self.filter_changed()
        self.reporting.paint()

    def reload(self):
        if self.app.is_running:return
        if self.path:
            self.read_order(self.path,lambda r:self.activate(self.path,self.passwords[order_result.file_key(self.path)],r))
        else:
            self.choose()

    def filter_changed(self,event=None):
        visible=[r for r in self.candidates if r['mode'] in ('Thường','Thùng')]
        dates=sorted({r['kh'] for r in visible if r['kh']})
        self.dates.configure(values=[*dates,'Cả file ca'])
        if self.kh.get() not in [*dates,'Cả file ca']:
            shiftdate=shift.parsed_name(self.path)[0].isoformat() if self.path else ''
            self.kh.set(next((d for d in dates if d>=shiftdate),dates[-1] if dates else ''))
        names=sorted({r['model'] for r in visible if self.kh.get()=='Cả file ca' or r['kh']==self.kh.get()})
        names=['Tất cả',*names]
        self.models.configure(values=names)
        if self.model.get() not in names:
            self.model.set(names[0] if names else '')
        available={r['kind'] for r in visible if (r['kh'],r['model'])==(self.kh.get(),self.model.get())}
        if self.kind.get() in ('Thường','Thùng') and len(available)==1:
            self.kind.set(next(iter(available)))
        self.paint()

    def refresh_receipts(self,summary=None,paint=True):
        if not self.path:
            return
        if summary and summary.get('is_mock') and summary.get('order_file'):
            self.demo_runs.setdefault(summary["order_file"],{})[summary["run_id"]]=summary
        hist=z.output_history(self.app.config)
        self.cached_receipts=order_result.receipts(hist,self.path)
        if self.app.mock_mode_var.get():
            self.cached_receipts+=order_result.receipts(list(reversed(self.demo_runs.get(order_result.file_key(self.path),{}).values())),self.path)
        if self.table:self.cached_receipts=[e for e in self.cached_receipts if e['source']['origin'] in self._row_lookup]
        if paint:self.paint()
        if summary and self.cached_receipts:self.result_window.deiconify()

    def paint(self):
        if self.cleanup:
            self.cleanup.paint()
            return
        selected={self.lines[k]['line_id'] for k in self.tree.selection() if k in self.lines}
        prior=getattr(self,'result_items',{})
        def receipt_key(e):return (e.get('run'),e['source']['line_id'],e['mock'])
        chosen={receipt_key(prior[k]) for k in self.result.selection() if k in prior}
        def active_key(grid,items,key):
            if grid.active and grid.active[0] in items:return key(items[grid.active[0]]),grid.names[grid.active[1]]
        active=active_key(self.tree,self.lines,lambda r:r['line_id'])
        result_active=active_key(self.result,prior,receipt_key)
        result_y=self.result.yview()[0]
        extra=self.kind.get() in (shift.EXTRA,shift.SHORT_BOX,shift.MODEL_ROUND)
        self.tree.show_columns([c for c,w in self.tree.columns if
            (self.model.get()=='Tất cả' or c!='Model') and (self.kind.get() not in ('Thường','Tất cả') or c not in ('EA/thùng','Thùng'))])
        if not getattr(self,'posting',False):
            self.run_btn.configure(text='Ra thêm một lượt thùng' if extra else 'Ra đơn các dòng đã chọn')
        self.lines={}
        self.result.reset()
        self.result.configure(height=26*(1+min(4,len(self.cached_receipts))))
        self.result_items={}
        if not getattr(self,'posting',False):
            self.order_progress.set('' if self.cached_receipts else 'Chưa có kết quả ra đơn từ app cho file ca này.')
        by_line={}
        for entry in self.cached_receipts:
            src=entry['source']
            obs='/'.join(ob for ob,num in entry['pairs'])
            nums=' · '.join(num or 'Chờ số' for ob,num in entry['pairs'])
            info='Mô phỏng' if entry['mock'] else 'Có thể ghi Excel' if entry['valid'] else 'Chờ đủ OB/số phiếu'
            if not entry['mock'] and entry['valid']:
                if not hasattr(self,'_row_lookup'):self._row_lookup={}
                row=self._row_lookup.get(src['origin'])
                if row and all(any(ob in shift.clean(row[i]).split('/') for i in (13,16,19)) for ob,_ in entry['pairs']):
                    info='Đã có OB trong ORDER' if all(any(ob in shift.clean(row[i]).split('/') and set(str(num or '').split('/'))<=set(shift.clean(row[i+1]).split('/')) for i in (13,16,19)) for ob,num in entry['pairs']) else 'OB đã có · kiểm tra số phiếu lệch' 
            node=self.result.add((src['row'],src['material'],src['kh'],src['model'],obs,nums,info))
            self.result_items[node]=entry
            if not entry['mock'] or src['line_id'] not in by_line:
                by_line.setdefault(src['line_id'],(obs,nums))
        def restore(grid,items,key,selected,active):
            grid.selection_set({n for n,item in items.items() if key(item) in selected})
            if active and active[1] in grid.names:
                node=next((n for n,item in items.items() if key(item)==active[0]),None)
                if node:grid.active=(node,grid.names.index(active[1]))
        restore(self.result,self.result_items,receipt_key,chosen,result_active)
        if prior and self.result_items:
            self.result.configure(scrollregion=(0,0,sum(self.result.widths),max(self.result.winfo_height(),len(self.result_items)*self.result.height_px)))
            self.result.yview_moveto(result_y)
        if not self.table:
            self.hint.set('Chọn Bắt đầu ca để đọc file ORDER.')
            return
        modes=('Thường','Thùng') if self.kind.get()=='Tất cả' else (self.kind.get(),)
        data=[r for r in self.candidates if (self.kh.get()=='Cả file ca' or r['kh']==self.kh.get()) and (self.model.get()=='Tất cả' or r['model']==self.model.get()) and r['mode'] in modes]
        def status(line):
            row=self._row_lookup[line['origin']]
            label={'done':'Đã cấp đủ',shift.PART:'Cấp một phần','pending':'Pending'}.get(line['source_state'],'Chưa rõ')
            note=shift.clean(row[27])
            if shift.norm(note)=='chocap':note='Đã ra đơn, chờ cấp'
            if shift.packing(row[2])[0] and shift.norm(note) in ('chuaradon','radoncaplai'):note=''
            if label=='Pending' and note:
                label,note=note,''
            if line['origin'] in self.odbs_origins:
                if line['source_state']=='pending' and shift.norm(row[27])=='chuaradon':label='Chưa ra đơn'
                label='ODBS · '+label
            if self.kh.get()=='Cả file ca':label=line['kh']+' · '+label
            return label+(' · '+note if note and note!=label else '')
        query=shift.norm(self.quick.get())
        data=[r for r in data if not query or query in shift.norm(' '.join((r['material'],r['station'],status(r),*by_line.get(r['line_id'],()),*r['slots'])))]
        if self.team_filter.get()!='Tất cả':
            data=[r for r in data if self.team_filter.get() in re.findall(r'S[12367]',shift.clean(self._row_lookup[r['origin']][11]).upper())]
        def category(line):
            row=self._row_lookup[line['origin']]
            note=shift.clean(row[27])
            if shift.norm(note)=='chocap':note='Đã ra đơn, chờ cấp'
            return note if line['source_state']=='pending' and note else {'done':'Đã cấp đủ',shift.PART:'Cấp một phần'}.get(line['source_state'],'Pending')
        choices=['Tất cả',*(['ODBS'] if any(r['origin'] in self.odbs_origins for r in data) else []),*sorted({category(line) for line in data})]
        self.status_box.configure(values=choices)
        if self.status_filter.get() not in choices:self.status_filter.set('Tất cả')
        if self.status_filter.get()=='ODBS':data=[r for r in data if r['origin'] in self.odbs_origins]
        elif self.status_filter.get()!='Tất cả':data=[line for line in data if category(line)==self.status_filter.get()]
        key=self.sort_key
        if key:
            def order(r):
                if key=='status':return status(r)
                if key=='remaining':return max(0,float(r['ordered'] or 0)-float(r['issued'] or 0))
                if key in ('ordered','issued','row','pack','boxes'):
                    try:return float(r[key] or 0)
                    except ValueError:return 0
                if key in ('ob','num'):
                    ob,num=by_line.get(r['line_id'],(display_obs(r['slots'][::2]),' / '.join(v for v in r['slots'][1::2] if v)))
                    return ob if key=='ob' else num
                return str(r.get(key,''))
            data.sort(key=order,reverse=self.desc)
        simulated={e['source']['line_id'] for e in self.cached_receipts if e['mock']}
        for line in data:
            ready=not line['problem']
            vals=[shift.clean(line[k]) for k in ('row','material','model','station','ordered','issued')]
            try:
                remaining=max(0,float(line['ordered'])-float(line['issued'] or 0))
            except (TypeError,ValueError):
                remaining=''
            state=status(line)
            if line['line_id'] in simulated:state+=' · Đã mô phỏng'
            vals+=[shift.clean(remaining)]+[shift.clean(line[k]) for k in ('pack','boxes')]
            old_ob=display_obs(line['slots'][::2])
            old_sp=' / '.join(v for v in line['slots'][1::2] if v)
            check=line['problem'] or ('OB chưa ghi SL cấp: '+', '.join(line['open_obs']) if extra and line['open_obs'] else '')
            ob,num=by_line.get(line['line_id'],(old_ob,old_sp))
            node=self.tree.add(vals+[num,ob,state],warning=line['source_state']==shift.PART)
            self.lines[node]=line
        restore(self.tree,self.lines,lambda r:r['line_id'],selected,active)
        ready=[r for r in data if not r['problem'] and r['line_id'] not in simulated]
        totals=Counter(r['source_state'] for r in data)
        def total(field):
            result=0.
            for r in data:
                try:result+=float(r[field] or 0)
                except (ValueError,TypeError):pass
            return result
        ordered,issued=total('ordered'),total('issued')
        self.hint.set(f"{len(data)} dòng · Đã cấp đủ {totals['done']} · Cấp một phần {totals[shift.PART]} · Pending {totals['pending']} · SL ORDER {ordered:g} · Đã cấp {issued:g} EA · Có thể ra đơn {len(ready)} dòng")

    def submit(self):
        if self.app.is_running:
            if getattr(self,'posting',False):self.app._request_stop()
            return
        try:
            chosen=[self.lines[k] for k in self.tree.selection()]
            if not chosen:raise ValueError('Bôi đen các dòng muốn ra đơn.')
            for r in chosen:
                if r['problem']:raise ValueError(f"Dòng {r['row']} · {r['material']} · {r['problem']}")
            if self.app.mock_mode_var.get():
                simulated={e['source']['line_id'] for e in self.cached_receipts if e['mock']}
                if any(r['line_id'] in simulated for r in chosen):
                    raise ValueError('Có dòng đã ra đơn mô phỏng trong phiên. Xem Kết quả hoặc chọn dòng khác.')
            if shift.signature(self.path)!=self.stamp:
                raise ValueError('File đã thay đổi. Tải lại ORDER.')
            plan=shift.plan(self.table,None if self.model.get()=='Tất cả' else self.model.get(),None if self.kh.get()=="Cả file ca" else date.fromisoformat(self.kh.get()),None if self.kind.get()=='Tất cả' else self.kind.get(),self.app.config)
            eligible={(r['line_id'],r['qty'],r['station']) for r in plan if not r['problem']}
            if any((r['line_id'],r['qty'],r['station']) not in eligible for r in chosen):
                raise ValueError('Cấu hình OUT đã đổi. Tải lại ORDER.')
            self.on_run([dict(r) for r in chosen],self.path,self.stamp)
        except Exception as exc:
            messagebox.showwarning('Ra đơn',str(exc),parent=self.app.root)

    def show_excel(self):
        if not self.path or self.app.is_running:return
        self.task('Mở ORDER trong Excel…',lambda:shift.show_excel(self.path,self.password),lambda _:self.reload())

    def model_cartons(self):
        if not self.path or self.app.is_running:return
        active=self.path
        prior=shift.previous_file(active.parent,*shift.parsed_name(active))
        def choose(previous,stamp):
            live=shift.plan(self.table,None,None,shift.MODEL_ROUND,self.app.config)
            archived=order_result.archived_cartons(previous,self.table,self.app.config) if previous else []
            choices=sorted({(r['kh'],r['model']) for r in live+archived if r['kh']})
            if not choices:
                self.hint.set('Không có hàng thùng trong phạm vi ca đã đọc.');return
            win=tk.Toplevel(self.app.root);win.title('Một lượt thùng theo model');win.transient(self.app.root);win.grab_set()
            labels=[day+' · '+model for day,model in choices]
            box=ttk.Combobox(win,values=labels,state='readonly',width=32)
            box.current(choices.index((self.kh.get(),self.model.get())) if (self.kh.get(),self.model.get()) in choices else 0)
            box.pack(padx=10,pady=8)
            ttk.Label(win,text=prior.name if prior else 'Chưa có file ca trước · chỉ dùng ORDER hiện tại').pack()
            def accept():
                kh,model=choices[box.current()]
                found={}
                for r in live+archived:
                    if (r['kh'],r['model'])!=(kh,model):continue
                    group=r['material'],shift.norm(r['station'])
                    if group not in found or found[group]['problem'] and not r['problem']:
                        found[group]=r
                blocked=[r for r in found.values() if r['problem']]
                if blocked:
                    messagebox.showinfo('Kiểm tra lượt thùng','\n'.join(r['material']+' · '+r['problem'] for r in blocked),parent=win)
                    return
                old=[r['origin'] for r in found.values() if r in archived]
                if old and self.app.mock_mode_var.get():
                    self.hint.set("Bỏ tích Mô phỏng để đưa dòng từ ca trước vào ORDER.");return
                if not messagebox.askyesno('Chuẩn bị lượt thùng',f'{model} · {kh} · {len(found)} mã/trạm · {sum(r["boxes"] for r in found.values())} thùng.\n'
                        f'Thêm {len(old)} dòng Done cũ vào ORDER hiện tại và mở bảng xem trước?',parent=win):return
                win.destroy()
                def show(data):
                    self.kind.set(shift.MODEL_ROUND);self.kh.set(kh);self.model.set(model)
                    self.activate(active,self.password,data)
                if old:
                    self.task('Đang chuẩn bị dòng ca trước…',lambda:order_result.import_cartons(active,self.password,self.table,
                              prior,self.passwords.get(order_result.file_key(prior)),stamp,old,self.app.config),show)
                else:show((self.table,self.stamp))
            ttk.Button(win,text='Chuẩn bị lượt thùng',command=accept).pack(pady=8)
        if prior:self.read_order(prior,lambda result:choose(*result))
        else:choose(None,None)

    def previous_cartons(self):
        if self.app.mock_mode_var.get():
            self.hint.set("Bỏ tích Mô phỏng để thêm dòng vào ORDER.");return
        if self.app.is_running:
            return
        if not self.path:
            self.choose()
            return
        current=self.path
        picked=filedialog.askopenfilename(parent=self.app.root,initialdir=current.parent,
            title='Chọn ORDER có dòng thùng đã Done',filetypes=[('ORDER Excel','*.xlsb *.xlsx *.xlsm')])
        if not picked:
            return
        prior=Path(picked)
        prev,now=shift.parsed_name(prior),shift.parsed_name(current)
        if not prev or not now or prev==now or prev[0]>now[0] or (prev[0]==now[0] and (prev[1],now[1])==('S7','S6')):
            messagebox.showinfo('Thùng Done ca trước','Chọn file bàn giao ca trước.',parent=self.app.root)
            return
        def ready(result):
            saved,stamp=result
            if 'chưa lưu' in self.sources.get(order_result.file_key(prior),''):
                raise ValueError('Lưu các thay đổi trong file bàn giao rồi chọn lại.')
            items=order_result.archived_cartons(saved,self.table,self.app.config)
            if not items:
                self.hint.set('Không có dòng thùng Done đủ packing cần lấy lại từ '+prior.name)
                return
            win=tk.Toplevel(self.app.root)
            win.title('Lượt thùng bổ sung từ ca trước')
            win.transient(self.app.root)
            win.grab_set()
            wrap=ttk.Frame(win,padding=8)
            wrap.pack(fill='both',expand=True)
            ttk.Label(wrap,text=f'{prior.name} → {current.name}').pack(anchor='w')
            ttk.Label(wrap,text='Chọn dòng cần thêm vào ORDER của ca này. Mỗi dòng sẽ có SL bằng một lượt thùng.').pack(anchor='w')
            gridbox=ttk.Frame(wrap)
            gridbox.pack(fill='both',expand=True)
            t=grid(gridbox,[('Dòng',46),('KHSX',90),('Model',70),('Mã hàng',130),('Trạm',160),
                ('Đã cấp',65),('OB cũ',140),('Thùng',45),('SL bổ sung',80)])
            t.configure(height=t.height_px*min(len(items),13))
            lines={}
            for r in sorted(items,key=lambda v:(v['kh'],v['model'],v['row'])):
                node=t.append_row((r['row'],r['kh'],r['model'],r['material'],r['station'],
                    r['issued'],' / '.join(v for v in r['slots'][::2] if v),r['boxes'],r['qty']))
                lines[node]=r
            def accept():
                chosen=[lines[node] for node in t.selection()]
                if not chosen:
                    return
                if not messagebox.askyesno('Thêm dòng ORDER',f'{len(chosen)} dòng · {sum(r["qty"] for r in chosen):g} EA.\n'
                        f'Ghi yêu cầu mới vào cuối {current.name}?',parent=win):
                    return
                win.destroy()
                def refreshed(data):
                    self.kind.set('Thùng')
                    self.kh.set(chosen[0]['kh'])
                    self.model.set(chosen[0]['model'])
                    self.activate(current,self.password,data)
                    imported={n for n,row in shift.rows(self.table) if len(row)>34 and
                              shift.tracking_origin(row) in {r['origin'] for r in chosen}}
                    self.tree.selection_set([node for node,r in self.lines.items() if r['row'] in imported])
                    self.hint.set(f'Đã thêm {len(chosen)} dòng. Kiểm tra các dòng đang chọn theo KHSX/model trước khi ra đơn.')
                prior_pwd=self.passwords.get(order_result.file_key(prior))
                self.task('Đang ghi yêu cầu thùng bổ sung…',lambda:order_result.import_cartons(
                    current,self.password,self.table,prior,prior_pwd,stamp,[r['origin'] for r in chosen],self.app.config),refreshed)
            ttk.Button(wrap,text='Thêm dòng đã chọn vào ORDER hiện tại…',command=accept).pack(anchor='e',pady=(5,0))
        self.read_order(prior,ready)

    def confirm_slot(self):
        if self.app.mock_mode_var.get():
            self.hint.set("Bỏ tích Mô phỏng để lưu xác nhận vào Excel.");return
        if self.app.is_running or not self.path:
            return
        chosen=[self.lines[k] for k in self.tree.selection()]
        if not chosen or any(not r['problem'].startswith('Đã ghi SL vào ô ghép') for r in chosen):
            self.hint.set('Chọn dòng bổ sung có đủ SL thực cấp ở ô ghép nhiều OB.')
            return
        if messagebox.askyesno('Chốt lượt thùng',f'{len(chosen)} dòng dùng ô SL chung cho nhiều OB.\n'
                'Đã đối chiếu đúng OB của lượt bổ sung và xác nhận đã cấp đủ?',parent=self.app.root):
            self.task('Đang ghi xác nhận lượt thùng…',lambda:order_result.confirm_shared_slots(
                self.path,self.password,self.table,{r['origin'] for r in chosen}),
                lambda data:self.activate(self.path,self.password,data))

    def check_line_obs(self):
        if self.app.is_running:
            return
        import re
        obs=list(dict.fromkeys(v for node in self.tree.selection() for stored in self.lines[node]['slots'][::2]
                               for v in re.findall(r'(?<!\d)10\d{8}(?!\d)',stored)))
        if obs:
            self.lookup_result(obs,self.app.mock_mode_var.get())
        else:
            self.hint.set('Chọn dòng có OB1, OB2 hoặc OB3 trong ORDER để tra.')

    def open_result(self):
        if self.app.is_running:return
        entries=[self.result_items[k] for k in self.result.selection()]
        if not entries or len({e['mock'] for e in entries})!=1:
            messagebox.showinfo('Tra / in OB','Chọn các dòng kết quả cùng loại SAP thật hoặc mô phỏng.')
            return
        self.lookup_result(list(dict.fromkeys(ob for e in entries for ob,num in e['pairs'])),entries[0]['mock'])

    def push(self):
        if self.app.mock_mode_var.get():
            self.hint.set("Bỏ tích Mô phỏng để ghi kết quả thật vào Excel.");return
        if self.app.is_running or not self.table:return
        try:
            items=[self.result_items[k] for k in self.result.selection()]
            if not items:raise ValueError('Chọn dòng ở bảng Kết quả ra đơn để ghi.')
            changes=order_result.edits(self.table,items)
            if not changes:
                self.hint.set('Các OB và số đơn đã có trong ORDER.');return
            import zone_order_result as receipt
            fields={14:'OB1',15:'SP1',17:'OB2',18:'SP2',20:'OB3',21:'SP3',28:'NOTE'}
            preview='\n'.join(f'Dòng {n}: '+', '.join(fields[c]+' '+v for c,v in vals if c not in (28,35)) for n,vals in list(changes.items())[:6])
            if not messagebox.askyesno('Ghi vào Excel',f'{self.path.name} · {len(changes)} dòng\n{preview}\nGhi kết quả và chuyển NOTE sang Đã ra đơn, chờ cấp?',parent=self.app.root):return
            def done(result):
                count,data=result
                self.activate(self.path,self.password,data)
                self.app.status_text_var.set(f'Đã cập nhật {count} dòng ORDER.')
            self.task('Đang ghi và kiểm tra ORDER…',lambda:receipt.write(self.path,self.password,items),done)
        except Exception as exc:
            messagebox.showwarning('Ghi ORDER',str(exc),parent=self.app.root)

    def review(self):
        import zone18
        if self.app.is_running:
            return
        try:
            chosen=[self.lines[k] for k in self.tree.selection()]
            with zone18.journal() as conn:
                hits=shift.reservations(conn,chosen)
            if not hits:
                messagebox.showinfo('Đối soát','Các dòng đang chọn chưa được giữ trong nhật ký trên máy này.',parent=self.app.root)
                return
            detail='\n'.join(f'Dòng {n} · lượt {job}' for n,job in hits[:15])
            if messagebox.askyesno('Mở lại dòng ORDER',detail+'\n\nĐã đối chiếu lịch sử MIGO/OB và xác nhận các dòng này cần ra lại?',parent=self.app.root):
                with zone18.journal() as conn:
                    if shift.reservations(conn,chosen,release=True)!=hits:
                        raise ValueError('Nhật ký vừa thay đổi. Đối soát lại.')
        except Exception as exc:
            messagebox.showwarning('Đối soát',str(exc),parent=self.app.root)

