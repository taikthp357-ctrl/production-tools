"""Build RC41 from the original RC31 executable using the matching CPython 3.12."""
import hashlib
import importlib.util
import marshal
from pathlib import Path
import struct
import sys
import zlib

HERE=Path(__file__).resolve().parent
BASE_SHA="f5eff05f26e36335d7c87ff91cf5af3ccb7ff7e85586332ae5a4680c0afee49d"
MAGIC=b"MEI\x0c\x0b\x0a\x0b\x0e"


def archive(exe):
    pos=exe.rfind(MAGIC)
    cookie=struct.unpack_from("!8sIIII64s",exe,pos)
    _,total,toc,length,ver,lib=cookie
    if ver!=312 or sys.version_info[:2]!=(3,12):
        raise ValueError("Windows and host archives must use Python 3.12.")
    start=pos+88-total
    p=start+toc
    results={}
    while p<start+toc+length:
        n,offset,size,ulen,flag,kind=struct.unpack_from("!iIIIBc",exe,p)
        name=exe[p+18:p+n].rstrip(b"\0").decode()
        results[name]=(exe[start+offset:start+offset+size],ulen,flag,kind)
        p+=n
    return exe[:start],results,lib


def payload(entry):
    return zlib.decompress(entry[0]) if entry[2] else entry[0]


def pyz_entries(data):
    assert data[:8]==b"PYZ\0"+importlib.util.MAGIC_NUMBER
    toc=struct.unpack_from("!I",data,8)[0]
    return {name:(kind,data[p:p+length]) for name,(kind,p,length) in dict(marshal.loads(data[toc:])).items()}


def compile_source(name,source):
    return zlib.compress(marshal.dumps(compile(source,name+".py","exec",dont_inherit=True)),9)


CHANGED = ("zone_mail","zone_daily","zone_cleanup", "zone_bbbg", "zone18", "zone_shift", "zone_shift_ui", "zone_qty", "zone_mail_ui",
           "zone_report_ui", "zone_result_grid", "zone_workspace", "zone_ui18",
           "zone_order_result", "zone_excel_live", "zone_search")


def build(source, destination):
    exe=source.read_bytes()
    if hashlib.sha256(exe).hexdigest()!=BASE_SHA:
        raise ValueError("Select the original RC31 MA_Logistics_Flow.exe.")
    prefix,original,lib=archive(exe)
    entries=dict(original)
    pyz_name=next(n for n,e in entries.items() if e[3]==b"z")
    modules=pyz_entries(payload(entries[pyz_name]))
    for name in CHANGED:
        kind,_=modules[name]
        modules[name]=(kind,compile_source(name,(HERE/(name+".py")).read_text(encoding="utf-8")))
    modules["zone_clipboard"]=(0,compile_source("zone_clipboard",(HERE/"zone_clipboard.py").read_text(encoding="utf-8")))
    new=bytearray(b"PYZ\0"+importlib.util.MAGIC_NUMBER+b"\0"*4)
    index=[]
    for name,(kind,blob) in modules.items():
        index.append((name,(kind,len(new),len(blob))))
        new.extend(blob)
    struct.pack_into("!I",new,8,len(new))
    new.extend(marshal.dumps(index))
    assert pyz_entries(new)==modules
    flag,kind=entries[pyz_name][2:]
    entries[pyz_name]=(zlib.compress(new,9) if flag else bytes(new),len(new),flag,kind)
    # Keep the PyInstaller bootloader, runtime hooks and Windows dependencies.
    data=bytearray()
    toc=bytearray()
    for name,(blob,ulen,flag,kind) in entries.items():
        encoded=name.encode()+b"\0"
        length=(18+len(encoded)+15)//16*16
        toc.extend(struct.pack("!iIIIBc",length,len(data),len(blob),ulen,flag,kind))
        toc.extend(encoded.ljust(length-18,b"\0"))
        data.extend(blob)
    cookie=struct.pack("!8sIIII64s",MAGIC,len(data)+len(toc)+88,len(data),len(toc),312,lib)
    result=bytes(prefix+data+toc+cookie)
    p,check,_=archive(result)
    assert p==prefix
    assert all(check[n]==original[n] for n in original if n not in (pyz_name,"main"))
    for raw,length,flag,_ in check.values():
        assert len(zlib.decompress(raw) if flag else raw)==length
    assert check==entries
    destination.write_bytes(result)
    print(hashlib.sha256(result).hexdigest(), destination)


if __name__=="__main__":
    build(Path(sys.argv[1]),Path(sys.argv[2]))
