"""Acceptance tests for MA Logistics Flow v1.8 RC43."""
from contextlib import ExitStack
from datetime import date, datetime
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as S
from unittest.mock import patch


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_mail as mail
    import zone_shift as sh
    import zone_ui18
    import zone_workspace as ws

    assert z.VERSION == '1.8 RC43', z.VERSION

    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, state, kh, note='Chưa ra đơn', qty=10, issued=0, ob1='', sp1='', tag=''):
        r = [None] * 35
        r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = mat, qty, 'ST1', '3093', 'P', 'L1', 'VF5', 'S6'
        r[13], r[14], r[15] = ob1, sp1, (issued if ob1 else None)
        r[22], r[24], r[26], r[27] = issued, state, kh, note
        r[28], r[29], r[30] = date(2026, 11, 26), 0.3, 'Trung'
        if tag:
            r[34] = json.dumps({'mail_row': 'tok', 'bbbg_only': False, 'tag': tag}, ensure_ascii=False)
        return r

    # 1. Natural ODBS detection: body keyword ("Em gửi ODBS"), mid-shift arrival (09:13 S6), image-only ODBS mail, vs prior-shift normal OD
    m_body_odbs = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>KHSX</td></tr>'
                 '<tr><td>VF89MAT1</td><td>5</td><td>P</td><td>27.11.2026</td></tr></table>',
        Body='Dear WH teams,\nEm gửi ODBS\nFrom: Old',
        Subject='OD KHSX VF89 27/11/2026',
        SenderName='Phuc',
        EntryID='m_body_odbs',
        ReceivedTime=datetime(2026, 11, 26, 5, 55),
    ), 'out')
    assert m_body_odbs and m_body_odbs['odbs_explicit']
    assert mail.is_natural_odbs(m_body_odbs, m_body_odbs['rows'][0], {'day_start': '06:00', 'night_start': '18:00'})

    m_midshift = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td><td>Ca</td></tr>'
                 '<tr><td>VF5MAT1</td><td>12</td><td>P</td><td>MG220</td><td>26.11.2026</td><td>S6</td></tr></table>',
        Body='Dear team WH\nSX gửi OD NVL VF5 cho KHSX ngày 26.11.2026 ca S6',
        Subject='OD NVL VF5 cho KHSX ngày 26.11.2026 ca S6',
        SenderName='Trung',
        EntryID='m_midshift',
        ReceivedTime=datetime(2026, 11, 26, 9, 13),
    ), 'out')
    assert mail.is_natural_odbs(m_midshift, m_midshift['rows'][0], {'day_start': '06:00', 'night_start': '18:00'})

    m_normal_overnight = mail.extract(S(
        HTMLBody='<table><tr><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td><td>Ca</td></tr>'
                 '<tr><td>VF5NORM</td><td>12</td><td>P</td><td>MG220</td><td>27.11.2026</td><td>S6</td></tr></table>',
        Body='Dear team WH\nSX gửi OD NVL VF5 cho KHSX ngày 27.11.2026 ca S6 theo plan',
        Subject='OD NVL VF5 cho KHSX ngày 27.11.2026 ca S6',
        SenderName='Trung',
        EntryID='m_normal',
        ReceivedTime=datetime(2026, 11, 26, 21, 10),
    ), 'out')
    assert not mail.is_natural_odbs(m_normal_overnight, m_normal_overnight['rows'][0], {'day_start': '06:00', 'night_start': '18:00'})

    m_img_only = mail.extract(S(
        HTMLBody='<div>SX gửi OD NVL VF5</div><img src="cid:img1">',
        Body='Dear team WH\nSX gửi OD NVL VF5 cho KHSX ngày 26.11.2026 ca S6 theo KHSX plan',
        Subject='OD NVL VF5 cho KHSX ngày 26.11.2026 ca S6',
        SenderName='Trung',
        EntryID='m_img',
        ReceivedTime=datetime(2026, 11, 26, 9, 13),
    ), 'out')
    assert m_img_only and m_img_only['has_image']
    assert any('ảnh chụp bảng' in issue for issue in m_img_only['issues'])
    assert mail.is_natural_odbs(m_img_only, None, {'day_start': '06:00', 'night_start': '18:00'})

    # 2. Special AFS mail without KHSX column -> auto plan date + special_note
    m_afs = mail.extract(S(
        HTMLBody='<table><tr><th>STT</th><th>Model</th><th>MÃ VẬT TƯ ORDER</th><th>Vị trí cấp hàng</th><th>KHO</th><th>SL OD</th><th>Người OD</th></tr>'
                 '<tr><td>1</td><td>Limo</td><td>BIW32026120AA</td><td>Bàn data Limo</td><td>P</td><td>32</td><td>Việt</td></tr></table>',
        Body='Dear Team WH\nEm gửi đơn OD chạy hàng AFS Limo.',
        Subject='OD chạy hàng AFS Limo',
        SenderName='Hoàng Văn Việt',
        EntryID='m_afs',
        ReceivedTime=datetime(2026, 11, 26, 11, 15),
    ), 'out')
    assert m_afs and len(m_afs['rows']) == 1
    r_afs = m_afs['rows'][0]
    assert r_afs['special_note'] == 'Hàng đặc biệt · AFS'
    assert r_afs['plan'] == '2026-11-26'
    assert mail.is_natural_odbs(m_afs, r_afs, {'day_start': '06:00', 'night_start': '18:00'})

    # 3. Cancel OD extraction and matching against ORDER lines that already have OBs
    m_cancel = mail.extract(S(
        HTMLBody='<table><tr><td>Model</td><td>Mã</td><td>SL OD</td><td>Kho</td><td>Trạm</td><td>KHSX</td></tr>'
                 '<tr><td>VF5</td><td>SUB72000114</td><td>70</td><td>P</td><td>KV03</td><td>26.11.2026</td></tr>'
                 '<tr><td>VF5</td><td>SUB72000105</td><td>170</td><td>P</td><td>KV03</td><td>26.11.2026</td></tr></table>',
        Body='Dear team Kho\nDo giảm KHSX 1 số mã VF5 nên sx CANCEL OD list mã này cho KHSX 26.11',
        Subject='RE: CANCEL OD NVL VF5 KHSX 26.11.2026 ca S7',
        SenderName='Trung',
        EntryID='m_cancel',
        ReceivedTime=datetime(2026, 11, 26, 13, 21),
    ), 'out')
    assert m_cancel and m_cancel['cancel_mail']
    tbl = [
        header,
        mk_row('SUB72000114', 'Pending', '2026-11-26', 'Đã ra đơn, chờ cấp', qty=70, ob1='1013308881', sp1='26-01'),
        mk_row('SUB72000105', 'Pending', '2026-11-26', 'Chưa ra đơn', qty=170),
        mk_row('OTHER_MAT', 'Pending', '2026-11-26', 'Đã ra đơn, chờ cấp', qty=20, ob1='1013308881', sp1='26-01'),
    ]
    cands = mail.cancel_matches(tbl, m_cancel['rows'])
    by_m = {c['material']: c for c in cands}
    assert by_m['SUB72000114']['obs'] == ['1013308881'] and by_m['SUB72000114']['shared_obs'] == ['1013308881']
    assert not by_m['SUB72000114']['untouched']
    assert by_m['SUB72000105']['obs'] == [] and by_m['SUB72000105']['untouched']

    # 4. Real Windows Tk UI parity checks: no Xác nhận ODBS button, no SearchPage Lọc kết quả, Ghi chú column in MailPage & ShiftPage
    import tkinter as tk
    from tkinter import ttk
    import tkinter.messagebox as mb

    def all_buttons(widget):
        res = []
        for c in widget.winfo_children():
            if isinstance(c, (ttk.Button, tk.Button)):
                res.append(str(c.cget('text')))
            res.extend(all_buttons(c))
        return res

    with tempfile.TemporaryDirectory() as tmp:
        z._SCHEMA_READY.clear()
        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': False}))
            stack.enter_context(patch.object(mb, 'showinfo'))
            os.environ['LOCALAPPDATA'] = tmp
            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                btns = all_buttons(root)
                assert 'Xác nhận ODBS…' not in btns, 'Manual ODBS button must be removed'
                assert not hasattr(app.search_page, 'filter_bar'), 'SearchPage Lọc kết quả bar must be removed'
                assert 'Ghi chú' in app.out_mail.tree.names
                assert 'Ghi chú' in app.shift_page.tree.names
                # Check ShiftPage renders special AFS tag from AI JSON into Ghi chú column
                wb_file = Path(tmp) / '261126_THEO DOI ORDER NVL_P_S6.xlsb'
                wb_file.write_bytes(b'x')
                row_afs = mk_row('BIW32026120AA', 'Pending', '2026-11-26', 'Chưa ra đơn', qty=32, tag='Hàng đặc biệt · AFS')
                row_afs[5] = 'Bàn data Limo'
                app.shift_page.activate(wb_file, None, ([header, row_afs], (1, 1, 0, 0)))
                root.update()
                assert app.shift_page.tree.rows and 'AFS' in app.shift_page.tree.rows[0][-1], app.shift_page.tree.rows[0]
                assert not errors, errors
            finally:
                root.destroy()
                z._SCHEMA_READY.clear()

    print('All RC43 acceptance tests (natural ODBS, image mail, AFS note & column, Cancel OD OB lookup, no manual ODBS btn & no SearchPage filter bar) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
