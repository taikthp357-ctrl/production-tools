"""OUT NVL shift handover, ORDER selection and shift reporting."""
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import sqlite3
import zlib
import tempfile

from zone_mail import norm, clean, day


TEAMS = ("S1", "S2", "S3", "S6", "S7")
SUFFIXES = ('.xlsb', '.xlsm', '.xlsx')
BASE_QTY = 'SL đã cấp đầu ca'
BASE_NOTE = 'Bàn giao đầu ca'
PART = 'partialfinished'
EXTRA = 'Thùng cấp thêm'
MODEL_ROUND = 'Cả model · 1 lượt'
SHORT_BOX = 'Thùng còn thiếu'
FIFO = 'Cấp bù FIFO'
TRACK = 'Theo dõi lượt thùng bổ sung'
CARRIED_DONE = 'Done ca trước · thùng bổ sung'


def tracking_origin(row):
    if len(row)>34 and row[34]:
        try:
            return json.loads(row[34]).get('from')
        except (ValueError,AttributeError,TypeError):
            pass


def round_open(row,quantity_only=False):
    if len(row)<35 or not clean(row[34]):
        return False
    try:
        marker=json.loads(row[34])
        if marker.get('confirmed') or ('from' in marker or 'mail_row' in marker) and 'slots' not in marker:
            return False
        received=0
        for slot,observed,obs in marker['slots']:
            if slot not in (13,16,19) or not set(obs)<=set(clean(row[slot]).split('/')):
                return True
            delta=float(row[slot+2] or 0)-observed
            if delta<=0:
                return True
            received+=delta
        return received<marker['qty'] or bool(marker.get('shared_slot') and not quantity_only)
    except (ValueError,KeyError,TypeError,IndexError):
        return True

FIELD_NAMES = {3:'manvl',4:'sloder',5:'tram',6:'plant',7:'slockho',8:'slocline',9:'model',
               11:'cachay',13:'ob1',14:'sp1',15:'sl1',16:'ob2',17:'sp2',18:'sl2',19:'ob3',20:'sp3',21:'sl3',22:'totalcap',24:'tinhtrangcapdon',
               26:'khsx',27:'note',31:'ca'}


def validate(table):
    if not table or len(table[0]) < 32:
        raise ValueError('ORDER thiếu các cột đến AF (Ca).')
    for col, title in FIELD_NAMES.items():
        if norm(table[0][col]) != title:
            raise ValueError(f'Tiêu đề ORDER cột {col+1} khác mẫu: {table[0][col]}')
    return table


def rows(table):
    validate(table)
    return ((n,r) for n,r in enumerate(table[1:],2) if clean(r[3]))


def state(r):
    return norm(r[24])


def handover(table):
    deleted, partial = [], []
    for index, row in rows(table):
        s=state(row)
        if s=='done':
            if not round_open(row):
                deleted.append(index)
        elif s==PART:
            partial.append(index)
        elif s!='pending':
            raise ValueError(f'Dòng {index}: cần kiểm tra trạng thái cấp "{clean(row[24])}" trước khi chuyển ca.')
    return deleted,partial


def signature(path):
    try:
        stat=Path(path).stat()
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Chưa thấy file {Path(path).name}. Chép xong bản thay thế rồi bấm Tải lại ORDER.") from exc
    return stat.st_size,stat.st_mtime_ns,stat.st_dev,stat.st_ino


def target_name(workday,shift,suffix):
    if not isinstance(workday,date) or shift not in TEAMS or suffix.lower() not in SUFFIXES:
        raise ValueError('Kiểm tra ngày nghiệp vụ, ca S1, S2, S3, S6 hoặc S7 và định dạng file.')
    return f'{workday:%y%m%d}_THEO DOI ORDER NVL_P_{shift}{suffix.lower()}'


def parsed_name(path):
    m=re.fullmatch(r'(\d{6})_THEO DOI ORDER NVL_P_\s*(S[12367])(?:[. ]*\(\d+\))?[. ]*', Path(path).stem,re.I)
    if m:
        try:
            return datetime.strptime(m[1],'%y%m%d').date(),m[2].upper()
        except ValueError:
            return None


def matches(folder,workday,shift):
    return sorted((p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in SUFFIXES
                  and parsed_name(p)==(workday,shift)), key=lambda p:(p.stat().st_mtime_ns,p.name),reverse=True)


class OrderOperationError(ValueError):
    pass


def record_order_error(path,operation,exc):
    from datetime import datetime
    import sap_zone_core as core
    detail=f'{Path(path).name} · {operation} · {exc}'
    try:
        log=Path(core.get_base_dir())/'data'/'order_errors.log'
        log.parent.mkdir(exist_ok=True,parents=True)
        with log.open('a',encoding='utf-8') as out:
            out.write(f'{datetime.now():%Y-%m-%d %H:%M:%S}  {detail}\n')
    except OSError:
        pass
    return detail


@contextmanager
def order_step(path,operation):
    try:
        yield
    except OrderOperationError:
        raise
    except Exception as exc:
        raise OrderOperationError(record_order_error(path,operation,exc)) from exc


def open_password_error(message):
    return ('ORDER_PASSWORD' in message or
            'Excel chưa mở được file có mật khẩu' in message)


def excel_1004(exc):
    info=getattr(exc,'excepinfo',None)
    return getattr(exc,'hresult',None)==-2146827284 or bool(info and info[-1]==-2146827284)


def open_workbook(app,path,secret,readonly):
    # Invoke Excel's Open method with explicit positional password arguments even on
    # machines without a generated Excel type library.
    import pythoncom
    from win32com.client import Dispatch
    books=app.Workbooks._oleobj_
    method=books.GetIDsOfNames('Open')
    # Format is only used for text imports. Use a concrete integer for binary workbooks.
    result=books.Invoke(method,0,pythoncom.DISPATCH_METHOD,True,str(Path(path).resolve()),
                        0,readonly,1,str(secret),str(secret),True)
    return Dispatch(result)


@contextmanager
def excel_book(path,password,write=False):
    import win32com.client
    app=win32com.client.DispatchEx('Excel.Application')
    book=None
    try:
        app.DisplayAlerts=False
        app.EnableEvents=False
        app.AskToUpdateLinks=False
        app.AutomationSecurity=3
        # An explicit BSTR prevents the Excel password dialog even with DisplayAlerts off.
        # A deliberately invalid password for encrypted files makes Excel raise a COM error.
        from zone_excel_live import shared_password
        secret=password or (shared_password() if encrypted(path) else '') or ''
        if not secret and encrypted(path):
            raise ValueError('ORDER_PASSWORD_NEEDED' if password is None else 'ORDER_PASSWORD_INVALID')
        try:
            book=open_workbook(app,path,secret,not write)
        except Exception as exc:
            if encrypted(path) and (not secret or any(term in norm(str(exc)) for term in ('password','matkhau','kennwort'))):
                raise ValueError('ORDER_PASSWORD_INVALID') from exc
            if encrypted(path) and excel_1004(exc):
                detail=record_order_error(path,'Excel Workbooks.Open',exc)
                raise OrderOperationError('Excel chưa mở được file có mật khẩu · '+detail) from exc
            raise OrderOperationError(record_order_error(path,'Excel Workbooks.Open',exc)) from exc
        if write and book.ReadOnly:
            raise ValueError('Workbook đang chỉ đọc hoặc đang được mở ở máy khác. Đóng file trước khi ghi.')
        yield book
    finally:
        try:
            if book is not None:
                book.Close(False)
        finally:
            app.Quit()


def order_sheet(book):
    try:
        return book.Worksheets('ORDER')
    except Exception as exc:
        if not (bad_index(exc) or excel_1004(exc)):
            raise
    sheets=book.Worksheets
    names=[]
    candidates=[]
    for i in range(1,int(sheets.Count)+1):
        sheet=sheets.Item(i)
        name=str(sheet.Name)
        names.append(name)
        if name.strip().casefold()=='order':
            candidates.append(sheet)
    if len(candidates)==1:
        return candidates[0]
    raise ValueError(f"{book.Name} · Không xác định được sheet ORDER. Các sheet hiện có: {', '.join(names)}")


def bad_index(exc):
    info=getattr(exc,'excepinfo',None)
    return getattr(exc,'hresult',None)==-2147352565 or bool(info and info[-1]==-2147352565)


@contextmanager
def excel(path,password,write=False):
    with excel_book(path,password,write) as book:
        with order_step(path,'Chọn sheet ORDER'):
            sheet=order_sheet(book)
        yield book,sheet


def check_tracking_space(sheet):
    header=sheet.Cells(1,35)
    if clean(header.Value2)!=TRACK and (header.HasFormula or clean(header.Value2) or
                                       int(sheet.Cells(sheet.Rows.Count,35).End(-4162).Row)>1):
        raise ValueError('Cột AI đang dùng cho dữ liệu khác. Không thể theo dõi lượt thùng bổ sung.')


def values(sheet):
    end=max(1,int(sheet.Cells(sheet.Rows.Count,4).End(-4162).Row))
    last_col='AI' if clean(sheet.Cells(1,35).Value2)==TRACK else 'AH'
    return validate(sheet.Range('A1:'+last_col+str(end)).Value2)


def encrypted(path):
    # Password-encrypted XLSX/XLSB/XLSM are stored in an OLE compound container.
    with open(path,'rb') as src:
        return src.read(8)==bytes.fromhex('D0CF11E0A1B11AE1')


def read_order(path,password,read_pivot=True,extra=False):
    import zone_excel_live as live
    with live.order_access(path):
        try:
            return _read_order(path,password,read_pivot,extra)
        except Exception as exc:
            if bad_index(exc):
                raise ValueError(f'{Path(path).name} · Excel báo chỉ mục không hợp lệ khi đọc ORDER ({exc}).') from exc
            raise


def _read_order(path,password,read_pivot,extra):
    import zone_excel_live as live
    before=signature(path)
    with order_step(path,'Tìm workbook trong Excel'):
        book=live.find(path)
    if book is not None:
        with order_step(path,'Chọn sheet ORDER đang mở'):
            sheet=order_sheet(book)
        if extra:check_tracking_space(sheet)
        with order_step(path,'Đọc vùng dữ liệu sheet ORDER'):
            data=values(sheet)
        pivot=live.pivot_options(book) if read_pivot else None
        source='Excel đang mở' if book.Saved else 'Excel đang mở · có sửa chưa lưu'
    else:
        with excel(path,password) as (opened,sheet):
            if extra:check_tracking_space(sheet)
            with order_step(path,'Đọc vùng dữ liệu sheet ORDER'):
                data=values(sheet)
            pivot=live.pivot_options(opened) if read_pivot else None
        source='File đã lưu'
    if before!=signature(path):
        raise ValueError('File đã thay đổi trong lúc đọc. Hãy tải lại ORDER.')
    return data,before,source,pivot


def historical_order(path,password,cache,transform=None,opened=None):
    import zone_excel_live as live
    stamp=signature(path)
    key=(live.key(path),transform)
    book=live.find(path) if opened is None else next((b for name,b in opened if live.same_path(name,path)),None)
    if book is not None:
        table=values(order_sheet(book))
        cache.pop(key,None)
        return transform(table) if transform else table
    if key not in cache or cache[key][0]!=stamp:
        table=history_snapshot(path)
        if table is None:
            with excel(path,password) as (_,sheet):
                table=values(sheet)
            if signature(path)!=stamp:raise ValueError('ORDER vừa thay đổi · '+Path(path).name)
            remember_handover(path,table,stamp)
        elif signature(path)!=stamp:
            raise ValueError('ORDER vừa thay đổi · '+Path(path).name)
        cache[key]=(stamp,transform(table) if transform else table)
    return cache[key][1]


def warm_history_cache(paths,password,passwords,cache,transform=None,opened=()):
    """Load multiple uncached history workbooks in one Excel COM instance and persist snapshots."""
    import zone_excel_live as live
    from zone_order_result import file_key
    missing=[]
    for p in paths:
        p=Path(p)
        try:stamp=signature(p)
        except OSError:continue
        if any(live.same_path(name,p) for name,_ in opened):continue
        key=(live.key(p),transform)
        if key in cache and cache[key][0]==stamp:continue
        if history_snapshot(p) is not None:continue
        missing.append((p,stamp,passwords.get(file_key(p)) or password))
    if len(missing)<=1:return
    import win32com.client as client
    from zone_excel_live import shared_password
    app=client.DispatchEx('Excel.Application')
    try:
        app.Visible=False
        app.DisplayAlerts=False
        app.AskToUpdateLinks=False
        app.AutomationSecurity=3
        fallback_pw=None
        for p,stamp,pw in missing:
            key=(live.key(p),transform)
            if fallback_pw is None and not pw and encrypted(p):
                fallback_pw=shared_password() or ''
            secret=pw or fallback_pw or ''
            if not secret and encrypted(p):continue
            book=None
            try:
                book=open_workbook(app,p,secret,True)
                table=values(order_sheet(book))
                if signature(p)==stamp:
                    remember_handover(p,table,stamp)
                    cache[key]=(stamp,transform(table) if transform else table)
            except Exception:
                continue
            finally:
                if book is not None:
                    try:book.Close(False)
                    except Exception:pass
    finally:
        try:app.Quit()
        except Exception:pass


def load(path,password):
    return read_order(path,password,False)[:2]


def verify_view(path,password,table,pivot=None,extra=False):
    try:
        current,_,_,options=read_order(path,password,pivot is not None,extra)
    except ValueError as exc:
        if 'ORDER_PASSWORD' in str(exc):
            raise ValueError('File có mật khẩu hiện đang đóng. Mở lại file trong Excel hoặc bấm Tải lại ORDER.') from exc
        raise
    if current!=table or (pivot is not None and options!=pivot):
        raise ValueError('Dữ liệu hoặc bộ lọc ORDER đã thay đổi từ lần tải trước. Tải lại để xem số mới.')


def blocks(indices):
    """Delete adjacent blocks from the bottom so row references stay valid."""
    if indices:
        low=high=indices[-1]
        for n in reversed(indices[:-1]):
            if n==low-1:
                low=n
            else:
                yield low,high
                low=high=n
        yield low,high


def gathered(note):
    return norm(note) in ('hangtapket','tapket','datapket','hangdatapket','tapketcatruoc','hangtapketcatruoc')


def opening_values(row):
    partial=state(row)==PART
    was_gathered=gathered(row[27])
    carried_done=state(row)=='done' and round_open(row)
    note=CARRIED_DONE if carried_done else 'Cấp 1 phần ca trước' if partial else ''
    if was_gathered:
        note=(note+' · ' if note else '')+'Hàng tập kết'
    quantity=row[22] or 0
    if not isinstance(quantity,(int,float)) or not math.isfinite(quantity) or quantity<0:
        raise ValueError('Cột Total cấp chứa giá trị không hợp lệ.')
    return (1 if partial or carried_done else None, quantity, note or None)


def history_snapshot(path, table=None, expected=None):
    """Reuse the saved ORDER from a successfully read handover file."""
    import zone18
    file_id=os.path.normcase(str(Path(path).resolve()))
    current=signature(path)
    if expected is not None and current!=expected:return
    stamp=json.dumps(current)
    with zone18.journal() as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS order_history(path TEXT PRIMARY KEY, stamp TEXT, data BLOB)')
        if table is not None:
            if expected is not None and conn.execute(
                    'SELECT 1 FROM order_history WHERE path=? AND stamp=?',(file_id,stamp)).fetchone():
                return
            data=zlib.compress(json.dumps(table,ensure_ascii=False).encode(),1)
            conn.execute('INSERT OR REPLACE INTO order_history VALUES(?,?,?)',(file_id,stamp,data))
        else:
            hit=conn.execute('SELECT data FROM order_history WHERE path=? AND stamp=?',(file_id,stamp)).fetchone()
            if hit:return tuple(tuple(row) for row in json.loads(zlib.decompress(hit[0])))


def remember_handover(path,table,stamp):
    try:
        history_snapshot(path,table,expected=stamp)
    except (OSError,sqlite3.Error,ValueError,TypeError):
        pass


def saved_handover(folder,expected):
    """Use a unique archived previous shift only when its workbook is absent."""
    import zone18
    directory=Path(folder).resolve()
    try:
        with zone18.journal() as conn:
            if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='order_history'").fetchone():
                return None
            candidates=[path for (path,) in conn.execute('SELECT path FROM order_history')
                        if Path(path).parent==directory and parsed_name(path)==expected]
            if len(candidates)!=1:return None
            name=candidates[0]
            blob=conn.execute('SELECT data FROM order_history WHERE path=?',(name,)).fetchone()[0]
            table=validate(tuple(tuple(row) for row in json.loads(zlib.decompress(blob))))
            return Path(name),table
    except (sqlite3.Error,OSError,zlib.error,ValueError,TypeError,IndexError):
        return None


def missing_history(folder,earliest,active,loaded):
    import zone18
    with zone18.journal() as conn:
        if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='order_history'").fetchone():return
        for name, in conn.execute('SELECT path FROM order_history ORDER BY rowid DESC'):
            path=Path(name)
            identity=parsed_name(path)
            if (not identity or identity in loaded or identity==active or path.exists() or
                    os.path.normcase(str(path.parent))!=os.path.normcase(str(folder.resolve())) or
                    not earliest<=identity[0]<=active[0]):continue
            blob=conn.execute('SELECT data FROM order_history WHERE path=?',(name,)).fetchone()[0]
            table=json.loads(zlib.decompress(blob))
            done=[r if clean(r[3]) and state(r)=='done' and not round_open(r) else [None]*len(r) for r in table[1:]]
            if any(clean(r[3]) for r in done):
                loaded.add(identity)
                yield path,[table[0],*done]


def create(source,dest,password,expected,progress=lambda text:None):
    source,dest=Path(source),Path(dest)
    if source.suffix.lower()!=dest.suffix.lower() or not parsed_name(dest):
        raise ValueError('File đích phải đúng mẫu ngày/ca và cùng định dạng nguồn.')
    import zone_excel_live as live
    with order_step(source,'Kiểm tra file bàn giao đang mở'):
        opened=live.find(source)
    if opened is not None and not opened.Saved:
        raise ValueError('Lưu file bàn giao trong Excel trước khi tạo ca từ bản trên đĩa.')
    date_shift=parsed_name(dest)
    if matches(dest.parent,*date_shift):
        raise FileExistsError('Đã có file cho ca đã chọn. Dùng Mở file ca.')
    if signature(source)!=expected:
        raise ValueError('File ca trước vừa thay đổi. Hãy xem lại số bàn giao.')
    fd,name=tempfile.mkstemp(prefix='ORDER_bangiao_',suffix=dest.suffix,dir=dest.parent)
    os.close(fd)
    stage=Path(name)
    try:
        progress("Đang sao chép file ca trước…")
        with order_step(dest,'Sao chép từ '+source.name):
            shutil.copyfile(source,stage)
        with excel(stage,password,True) as (book,sheet):
            with order_step(stage,'Đọc ORDER trên bản sao'):
                data=values(sheet)
            done,partial=handover(data)
            # Preserve occupied fields in customized versions of the workbook.
            headers=data[0][32:34]
            for offset,label in enumerate((BASE_QTY,BASE_NOTE)):
                current=headers[offset]
                if clean(current)!=label and (clean(current) or any(clean(r[32+offset]) for r in data[1:])):
                    raise ValueError('ORDER đang dùng cột AG/AH cho dữ liệu khác.')
            markers=[opening_values(r) if clean(r[3]) else tuple(r[31:34]) for r in data[1:]]
            if markers:
                address='AF2:AH'+str(len(data))
                with order_step(stage,'Ghi dấu bàn giao '+address):
                    sheet.Range(address).Value2=tuple(markers)
            with order_step(stage,'Ghi tiêu đề AG1:AH1'):
                sheet.Range('AG1:AH1').Value2=((BASE_QTY,BASE_NOTE),)
            ranges=list(blocks(done))
            for i,(low,high) in enumerate(ranges,1):
                if i==1 or i%10==0 or i==len(ranges):
                    progress(f'Xóa dòng Done · {i}/{len(ranges)} cụm')
                with order_step(stage,f'Xóa dòng Done {low}–{high}'):
                    sheet.Range(f'D{low}:D{high}').EntireRow.Delete()
            progress('Đang tính ORDER và kiểm tra số dòng bàn giao…')
            with order_step(stage,'Tính lại sheet ORDER'):
                sheet.Calculate()
            with order_step(stage,'Đọc lại ORDER sau khi xóa Done'):
                after=values(sheet)
            if any(state(r)=='done' and not round_open(r) for _,r in rows(after)) or sum(1 for _ in rows(after))!=sum(1 for _ in rows(data))-len(done):
                raise ValueError('Số dòng sau bàn giao không khớp.')
            if sum(1 for _,r in rows(after) if state(r)==PART and r[31]==1)!=len(partial):
                raise ValueError('Dấu bàn giao cấp một phần chưa khớp.')
            progress('Đang lưu file ca mới…')
            deleted=set(done)
            kept_markers=[marker for n,marker in enumerate(markers,2) if n not in deleted]
            if any(i>=len(after) or not any(tok in norm(after[i][33]) for tok in ('hangtapket','tapketcatruoc'))
                   for i,marker in enumerate(kept_markers,1) if any(tok in norm(marker[2]) for tok in ('hangtapket','tapketcatruoc'))):
                raise ValueError('Dấu hàng tập kết chưa được ghi đủ. Kiểm tra bản bàn giao.')
            with order_step(stage,'Lưu workbook ca mới'):
                book.Save()
            if not book.Saved:raise ValueError('Excel chưa xác nhận lưu file ca mới.')
        saved=after
        if expected!=signature(source) or matches(dest.parent,*date_shift):
            raise ValueError('Nguồn đã thay đổi hoặc ca đích vừa được tạo. Hãy kiểm tra lại.')
        with order_step(dest,'Đặt tên chính thức cho file ca'):
            if os.name=='nt':
                os.rename(stage,dest)  # same volume, fails if destination already exists
            else:
                os.link(stage,dest)
        remember_handover(source,data,expected)
        try:
            import zone_mail
            zone_mail.inherit_odbs(source,data,dest,saved)
        except Exception:
            pass
    except OrderOperationError as exc:
        detail=record_order_error(dest,'Tạo từ '+source.name,exc)
        raise OrderOperationError(detail) from exc
    finally:
        stage.unlink(missing_ok=True)
    return saved,signature(dest)


def order_pack(value):
    text=clean(value)
    if re.search(r'\d\s*[-–~×x/,;+.]\s*\d',text,re.I):
        return None
    numbers=re.findall(r'(?<![\w.,])(\d+)\s*(?:pcs|ea)\b',text,re.I)
    return int(numbers[0]) if len(numbers)==1 and 1<=int(numbers[0])<=999999 else None


def packing(value):
    """Use the same ORDER packing rules in issuing and reporting."""
    text=clean(value)
    if re.fullmatch(r'[0-9]{1,6}',text) and int(text)>0:
        return True,int(text)
    name=norm(value)
    boxed='thung' in name or 'thanhnhom' in name
    return boxed,order_pack(value) if boxed else None


def display_note(row):
    note=clean(row[27])
    if packing(row[2])[0] and norm(note) in ('','chuaradon','radoncaplai'):
        return 'Hàng thùng · cấp theo giờ/gọi'
    return note or 'Chưa ghi NOTE'


def row_identity(row):
    return tuple(clean(row[i]).casefold() for i in (3,4,5,6,7,8,9,11,26,28,29,30))


def indexed(table):
    cached = getattr(table, 'line_index', None)
    return iter(cached) if cached is not None else _index_rows(table)


def _index_rows(table):
    occurrence=Counter()
    for n,r in rows(table):
        identity=row_identity(r)
        occurrence[identity]+=1
        key=hashlib.sha256(json.dumps([identity,occurrence[identity]],ensure_ascii=False).encode()).hexdigest()
        yield n,r,key


def pending_order(row):
    for slot in (13,16,19):
        ob,number,qty=(clean(x) for x in row[slot:slot+3])
        if not (ob or number):
            continue
        if not qty:
            return 'Đã ra đơn, chờ cấp '+(number or ob)
        if '/' in ob and not (len(row)>34 and confirmed_shared(row)):
            return 'Cần đối soát ô ghép OB'
    return ''


def confirmed_shared(row):
    try:
        marker=json.loads(row[34] or '{}')
        return marker.get('confirmed') and not round_open(row)
    except (TypeError,ValueError,AttributeError):
        return False


def plan(table,model,kh,kind,config,review=False):
    result=[]
    for n,r,key in indexed(table):
        name=clean(r[9]).upper()
        dt=day(r[26])
        if (model and name!=model) or (kh and dt!=kh):
            continue
        boxed,pack=packing(r[2])
        special=kind in (EXTRA,MODEL_ROUND,SHORT_BOX,FIFO)
        extra=kind==EXTRA
        if kind and kind!=FIFO and (kind in ('Thùng',EXTRA,MODEL_ROUND,SHORT_BOX))!=bool(boxed):
            continue
        note=norm(r[27])
        if kind in (SHORT_BOX,FIFO):
            if state(r) not in (PART,'pending'):continue
        elif kind==MODEL_ROUND:
            if state(r) not in (PART,'pending','done'):continue
        elif extra:
            if state(r) not in (PART,'done'):
                continue
        eligible_note=note=='chuaradon' or boxed and note=='radoncaplai'
        if not special and not eligible_note and not review:
            continue
        slots=tuple(clean(r[i]) for i in (13,14,16,17,19,20))
        problem=''
        ordered=r[4]
        if name=='KEO' or note=='chilapbbbg' or len(r)>34 and '"bbbg_only": true' in clean(r[34]):
            problem='Chỉ lập BBBG'
        elif review and not special and not eligible_note:
            problem='Chỉ tra cứu · '+display_note(r)
        elif round_open(r):
            problem=('Đã ghi SL vào ô ghép nhiều OB · chốt lượt sau khi tra OB' if not round_open(r,True) else 'Lượt thùng bổ sung trước đang chờ cấp')
        elif kind in (FIFO,SHORT_BOX) and pending_order(r):
            problem=pending_order(r)
        elif special and note in ('hettonkhoma','huy','huydon'):
            problem='Kiểm tra NOTE '+clean(r[27])
        elif special and any(clean(r[i+1]) and not clean(r[i]) or
                           any(not re.fullmatch(r'10\d{8}',ob.strip()) for ob in clean(r[i]).split('/') if ob.strip())
                           for i in (13,16,19)):
            problem='Kiểm tra OB1–3 và số phiếu cũ'
        elif special and (r[22] not in ('',None) and (not isinstance(r[22],(float,int)) or r[22]<0)):
            problem='Kiểm tra Total cấp'
        elif not special and state(r) not in (('pending',PART) if boxed else ('pending',)):
            problem='Kiểm tra trạng thái đã cấp'
        elif not special and not boxed and (any(slots) or r[22] not in (None,0,'','0')):
            problem='Hàng thường đã có OB/SL cấp'
        elif not isinstance(ordered,(int,float)) or not math.isfinite(ordered) or ordered<=0:
            problem='SL ORDER không hợp lệ'
        elif not clean(r[5]):
            problem='Thiếu trạm'
        elif [clean(r[i]) for i in (6,7,8)]!=[clean(config.get(k)) for k in ('plant','sloc_from','sloc_to')]:
            problem='Plant/SLoc khác cấu hình OUT'
        elif boxed and not pack:
            problem='Thiếu EA/thùng trong cột Packing của ORDER'
        boxes=(3 if pack<=100 else 2 if pack<=200 else 1) if pack else 0
        qty=pack*boxes if pack else None if boxed else ordered
        if kind in (SHORT_BOX,FIFO) and not problem:
            remaining=ordered-float(r[22] or 0)
            if remaining<=0:continue
            if boxed:
                boxes=math.ceil(remaining/pack)
                qty=boxes*pack
            else:
                qty=remaining
        open_obs=[clean(r[i]) for i in (13,16,19) if clean(r[i]) and r[i+2] in (None,'',0,'0')]
        claim=key if not any(slots) else hashlib.sha256(json.dumps([key,slots]).encode()).hexdigest()
        result.append(dict(row=n,line_id=claim,origin=key,material=clean(r[3]).upper(),station=clean(r[5]),input_zone='',
                           ordered=ordered,pack=pack,boxes=boxes,qty=qty,problem=problem,source='ORDER',
                           slots=slots,mode=kind if special else 'Thùng' if boxed else 'Thường',
                           source_state=state(r),open_obs=open_obs,slot_qty=[clean(r[i]) for i in (15,18,21)],
                           packing_value=clean(r[2]),note=note,issued=clean(r[22]),model=name,kh=dt.isoformat() if dt else '',kind='Thùng' if boxed else 'Thường'))
    return result


def candidates(table,config):
    return [row for kind in (None,EXTRA,MODEL_ROUND,SHORT_BOX) for row in plan(table,None,None,kind,config,review=kind is None)]


def reports(table):
    result=defaultdict(Counter)
    cartons=defaultdict(set)
    baseline=len(table[0])>=34 and tuple(table[0][32:34])==(BASE_QTY,BASE_NOTE)
    for num,r in rows(table):
        kh=day(r[26])
        key=(kh.isoformat() if kh else 'Chưa có KHSX',clean(r[9]),clean(r[11]))
        c=result[key]
        c['order']+=1
        s,note=state(r),norm(r[27])
        boxed,_=packing(r[2])
        if boxed:
            cartons[key].add(clean(r[3]).upper())
            c['hourly']=len(cartons[key])
        if s=='done':
            bucket='done'
        elif s==PART:
            bucket='partial'
        elif note=='hangtapket':
            bucket='gathered'
        elif note=='hettonkhoma':
            bucket='empty'
        elif s=='pending' and boxed:
            bucket='pending_carton_rows'
        elif s=='pending':
            bucket='pending'
        else:
            bucket='review'
        c[bucket]+=1
        if bucket=='done' and (len(r)<=33 or CARRIED_DONE not in clean(r[33])):
            c['new_done']+=1
        if bucket=='partial':
            carried=clean(r[31])=='1'
            increased=baseline and isinstance(r[22],(int,float)) and isinstance(r[32],(int,float)) and r[22]>r[32]
            if not carried or increased:
                c['new_partial']+=1
        if bucket=='gathered' and baseline and not any(tok in norm(r[33]) for tok in ('tapketcatruoc','hangtapket')):
            c['new_gathered']+=1
    return result,baseline


def _run_post_evidence(conn, run_id, run_cache, group_cache):
    if run_id not in group_cache:
        rows_pg = conn.execute("SELECT state, snapshot, ob, material_doc FROM post_group WHERE run_id=?", (run_id,)).fetchall()
        by_group = {}
        any_states = []
        for state_val, snap_txt, ob_val, doc_val in rows_pg:
            any_states.append((state_val, ob_val or '', doc_val or ''))
            try:
                gid = json.loads(snap_txt).get('group', {}).get('group_id', '')
            except (TypeError, ValueError, AttributeError):
                gid = ''
            if gid:
                by_group[gid] = (state_val, ob_val or '', doc_val or '')
        group_cache[run_id] = (by_group, any_states)
    if run_id not in run_cache:
        row_res = conn.execute("SELECT document FROM run_result WHERE run_id=?", (run_id,)).fetchone()
        if row_res:
            try:
                doc = json.loads(row_res[0])
                groups = doc.get('groups') or []
                mapped = doc.get('order_groups') or []
                line_groups = defaultdict(list)
                for idx, owners in enumerate(mapped):
                    gid = groups[idx].get('group_id', f'GRP_{idx+1:03d}') if idx < len(groups) else ''
                    if gid:
                        for lid in owners:
                            line_groups[lid].append(gid)
                run_cache[run_id] = line_groups if mapped else None
            except (TypeError, ValueError, AttributeError):
                run_cache[run_id] = None
        else:
            run_cache[run_id] = None
    return group_cache[run_id], run_cache[run_id]


def claim_details(conn, lines):
    """Return claim state and MIGO post_group status for each claimed line."""
    import zone18
    zone18.ensure_schema(conn)
    run_cache, group_cache = {}, {}
    out = []
    for line in lines:
        match = conn.execute("SELECT run_id FROM order_line_claim WHERE line_id=?", (line['line_id'],)).fetchone()
        if not match:
            continue
        run_id = match[0]
        (by_group, any_states), line_groups = _run_post_evidence(conn, run_id, run_cache, group_cache)
        if not any_states:
            auto_release = True
            status_text = 'Chưa gửi MIGO (0 nhóm trong post_group)'
        elif line_groups is not None and line['line_id'] in line_groups:
            gids = line_groups[line['line_id']]
            posted = [by_group[g] for g in gids if g in by_group]
            if not posted:
                auto_release = True
                status_text = 'Chưa gửi MIGO cho các nhóm của dòng này'
            else:
                auto_release = False
                labels = [f"{s}{(' · OB ' + ob) if ob else (' · MIGO ' + md) if md else ''}" for s, ob, md in posted]
                status_text = ', '.join(dict.fromkeys(labels))
        else:
            auto_release = False
            labels = [f"{s}{(' · OB ' + ob) if ob else (' · MIGO ' + md) if md else ''}" for s, ob, md in any_states]
            status_text = ', '.join(dict.fromkeys(labels))
        out.append(dict(row=line['row'], line_id=line['line_id'], run_id=run_id,
                        auto_release=auto_release, status=status_text))
    return out


def reservations(conn,lines,run=None,release=False):
    import zone18
    zone18.ensure_schema(conn)
    if not conn.in_transaction:
        conn.execute("BEGIN IMMEDIATE")
    details = claim_details(conn, lines)
    if run and details:
        auto = [d['line_id'] for d in details if d['auto_release']]
        if auto:
            conn.executemany("DELETE FROM order_line_claim WHERE line_id=?", [(lid,) for lid in auto])
            details = [d for d in details if not d['auto_release']]
    hits = [(d['row'], d['run_id']) for d in details]
    if run and hits:
        raise ValueError('Dòng đã gửi trong lượt trước: '+', '.join(str(n) for n,_ in hits[:12])+'. Xem Lịch sử và Đối soát dòng.')
    if run:
        conn.executemany("INSERT INTO order_line_claim VALUES(?,?)",[(r['line_id'],run) for r in lines])
    if release:
        conn.executemany("DELETE FROM order_line_claim WHERE line_id=?",[(r['line_id'],) for r in lines])
    return hits

def check_allocated(requests,groups):
    requested=Counter()
    allocated=Counter()
    for r in requests:
        requested[r['material']]+=Decimal(str(r['qty']))
    for group in groups:
        for line in group['lines']:
            allocated[line['material']]+=Decimal(str(line['qty']))
    if allocated!=requested:
        raise ValueError('SL phân bổ theo mã khác bản xem trước ORDER. Kiểm tra tồn và định mức.')

def previous_identity(workday,team):
    from datetime import timedelta
    prev={'S1':(-1,'S3'),'S2':(0,'S1'),'S3':(0,'S2'),'S6':(-1,'S7'),'S7':(0,'S6')}.get(team)
    if not prev:return None
    return workday+timedelta(days=prev[0]),prev[1]


def previous_file(folder,workday,team):
    expected=previous_identity(workday,team)
    if not expected:return None
    choices=matches(folder,*expected)
    return choices[0] if choices else None


def show_excel(path,password):
    from zone_excel_live import find
    import win32com.client as client
    book=find(path)
    if book is None:
        app=client.DispatchEx('Excel.Application')
        from zone_excel_live import shared_password
        secret=password or (shared_password() if encrypted(path) else '') or ''
        try:
            if not secret and encrypted(path):raise ValueError('ORDER_PASSWORD_NEEDED')
            app.AutomationSecurity=3
            book=open_workbook(app,path,secret,False)
        except Exception:
            app.Quit()
            raise
    app=book.Application
    app.Visible=True
    book.Activate()
    # UserControl may be read-only depending on the Excel version. A visible workbook
    # remains owned by the user while the app holds its marshalled IDispatch.
    import pythoncom
    key=os.path.normcase(str(Path(path).resolve()))
    _visible_books[key]=pythoncom.CoMarshalInterThreadInterfaceInStream(pythoncom.IID_IDispatch,book._oleobj_)


_visible_books={}
