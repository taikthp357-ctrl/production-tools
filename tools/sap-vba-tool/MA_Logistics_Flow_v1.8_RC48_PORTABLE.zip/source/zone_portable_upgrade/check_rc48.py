"""Acceptance tests for MA Logistics Flow v1.8 RC48 (fast/safe S7->S6 handover + S6 Partial->Done pivot)."""
from contextlib import ExitStack, contextmanager
from datetime import date
import os
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace as S
from unittest.mock import patch


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import sap_zone_core as core
    import zone18 as z
    import zone_daily as daily
    import zone_excel_live as live
    import zone_shift as sh

    assert z.VERSION == '1.8 RC48', z.VERSION

    # 1. Real Excel COM test: handover create() with AutoFilter, hidden bottom rows, text-formatted AF (@), stale formulas, scattered Done blocks & merged C cells
    import win32com.client as client
    with tempfile.TemporaryDirectory() as tmp:
        z._SCHEMA_READY.clear()
        with ExitStack() as stack:
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(live, 'find', return_value=None))

            tmp_dir = Path(tmp)
            src_s7 = tmp_dir / '261126_THEO DOI ORDER NVL_P_S7.xlsb'
            dst_s6 = tmp_dir / '271126_THEO DOI ORDER NVL_P_S6.xlsb'

            app = client.DispatchEx('Excel.Application')
            try:
                app.DisplayAlerts = False
                app.EnableEvents = False
                wb = app.Workbooks.Add()
                ws = wb.Worksheets(1)
                ws.Name = 'ORDER'
                headers = [''] * 35
                for idx, name in sh.FIELD_NAMES.items():
                    headers[idx] = name
                headers[28:31] = ['Ngày order', 'Giờ order', 'Người order']
                ws.Range('A1:AI1').Value2 = (tuple(headers),)

                total_data_rows = 300
                rows_data = []
                # Row 2..301:
                # - Row 301 (bottom) is Pending & manually hidden + filtered out by AutoFilter!
                # - Row 300 is Done (visible under Pending? No, filtered out if Pending filter on!)
                # - Row 10 has stale formula cache: SL1=10 -> Total=10 -> Done after Calculate(), cached as 'Partial finished'!
                # - Text format '@' on column AF (32)
                for r in range(2, 2 + total_data_rows):
                    row = [None] * 35
                    row[3] = f'MAT_{r:04d}'
                    row[4] = 10
                    row[5] = 'ST1'
                    row[6], row[7], row[8], row[9], row[11] = '3093', 'P', 'L1', 'VF7', 'S7'
                    row[26] = 46354
                    row[22] = f'=SUM(P{r},S{r},V{r})'
                    row[24] = f'=IF(W{r}>=E{r},"Done",IF(W{r}>0,"Partial finished","Pending"))'
                    if r == 10:
                        # Seed SL1=0 first so Calculate() caches 'Partial finished', then update SL1=10 under Manual calc to leave a true stale formula cache
                        row[13], row[14], row[15] = '1013300010', '26-10', 0
                        row[27] = ''
                    elif r in (5, 9, 15, 21, 301):
                        # Kept Pending rows (with row 9 = Hang tap ket)
                        row[27] = 'Hàng tập kết' if r == 9 else 'Chưa ra đơn'
                    elif r in (7, 13, 19):
                        # Kept Partial finished rows
                        row[13], row[14], row[15] = '1013300002', '26-02', 4
                        row[27] = 'Đã ra đơn, chờ cấp'
                    elif r % 2 == 0:
                        # ~147 scattered Done rows (creating ~140+ separate blocks!)
                        row[13], row[14], row[15] = '1013300001', '26-01', 10
                        row[27] = ''
                    else:
                        row[27] = 'Chưa ra đơn'
                    rows_data.append(tuple(row))
                ws.Range(f'A2:AI{1 + total_data_rows}').Value2 = tuple(rows_data)
                ws.Columns(32).NumberFormat = '@'
                ws.Calculate()
                # Turn calc Manual and update SL1=10 (preserving the formula while Y10 still holds stale 'Pending'!)
                prev_calc = app.Calculation
                prev_cbs = app.CalculateBeforeSave
                app.Calculation = -4135
                app.CalculateBeforeSave = False
                ws.Cells(10, 16).Value2 = 10
                # Merge C4:C5 vertically (Done + Pending) and apply AutoFilter hiding Done + manually hide row 301 at bottom!
                ws.Range('C4:C5').Merge()
                ws.Range(f'A1:AI{1 + total_data_rows}').AutoFilter(Field=25, Criteria1='Pending')
                ws.Rows('301').Hidden = True
                wb.SaveAs(str(src_s7), FileFormat=50)
                app.CalculateBeforeSave = prev_cbs
                app.Calculation = prev_calc
                wb.Close(False)
            finally:
                app.Quit()

            # Check values(sheet) detects filtered/hidden bottom row 301 cleanly via Excel COM!
            with sh.excel(src_s7, None) as (_, check_sheet):
                raw_read = sh.values(check_sheet)
                assert len(raw_read) == 1 + total_data_rows, f'Expected {1 + total_data_rows} rows including filtered/hidden tail, got {len(raw_read)}'
                assert sh.clean(raw_read[9][24]) == 'Pending', raw_read[9][24]

            stamp = sh.signature(src_s7)
            steps_log = []
            t0 = time.perf_counter()
            saved, new_stamp = sh.create(src_s7, dst_s6, None, stamp, steps_log.append)
            elapsed = time.perf_counter() - t0
            assert dst_s6.is_file() and new_stamp == sh.signature(dst_s6)
            assert elapsed < 25.0, f'Handover create() took too long: {elapsed:.2f}s'

            kept_rows = list(sh.rows(saved))
            # Expected Done count: row 10 + all even r in 2..300 except kept rows -> calculate exactly:
            # Even r in [2..300] = 150. Excluded even r? None of (5,9,15,21,301,7,13,19) are even! Plus r=10 is already even!
            # Wait: r=10 was even, so total Done = 150! Remaining = 300 - 150 = 150!
            assert len(kept_rows) == 150, f'Expected 150 kept rows, got {len(kept_rows)}'
            assert not any(sh.state(r) == 'done' for _, r in kept_rows), 'No Done row may remain after handover'
            partials = [(n, r) for n, r in kept_rows if sh.state(r) == sh.PART]
            assert len(partials) == 3 and all(sh.clean(r[31]) == '1' for _, r in partials), partials
            gathered = [r for _, r in kept_rows if sh.clean(r[3]) == 'MAT_0009']
            assert len(gathered) == 1 and 'Hàng tập kết' in sh.clean(gathered[0][33]), gathered
            assert any(sh.clean(r[3]) == 'MAT_0301' for _, r in kept_rows), 'Hidden bottom row MAT_0301 must be preserved'

            # 2. Diagnostic mismatch error check in create() records to order_errors.log
            bad_after = [saved[0], list(kept_rows[0][1])]
            bad_after[1][24] = 'Done'  # Fake leftover Done row
            with patch.object(sh, 'values', side_effect=[raw_read, bad_after]):
                try:
                    sh.create(src_s7, tmp_dir / '271127_THEO DOI ORDER NVL_P_S6.xlsb', None, sh.signature(src_s7))
                except sh.OrderOperationError as exc:
                    msg = str(exc)
                    assert 'Số dòng sau bàn giao không khớp' in msg and 'còn 1 dòng Done' in msg, msg
                    assert (tmp_dir / 'data' / 'order_errors.log').is_file()
                else:
                    raise AssertionError('Expected diagnostic OrderOperationError on leftover Done')

    # 3. zone_daily.pivot: carried Partial finished (AF='1') completed to Done during S6 stays visible under Done!
    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, state, ca='', ah='', kh='2026-11-27', note='Chưa ra đơn'):
        r = [None] * 35
        r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = mat, 10, 'ST1', '3093', 'P', 'L1', 'LIMO', 'S6'
        r[22], r[24], r[26], r[27], r[31], r[33] = (10 if state == 'Done' else 4), state, kh, note, ca, ah
        return r

    tbl = [
        header,
        mk_row('P_CARRIED', 'Partial finished', ca='1', ah='Cấp 1 phần ca trước', note='Đã ra đơn, chờ cấp'),
        mk_row('P_FINISHED_NOW', 'Done', ca='1', ah='Cấp 1 phần ca trước', note=''),
        mk_row('D_CARRIED_CARTON', 'Done', ca='1', ah=sh.CARRIED_DONE, note=''),
        mk_row('G_PENDING', 'Pending', ca='', ah='Hàng tập kết', note='Hàng tập kết'),
    ]
    _, piv = daily.pivot(tbl, full=True, all_rows=False, options={'filters': {31: ['']}},
                         identity=(date(2026, 11, 27), 'S6'), include_gather=False)
    totals = {vals[0]: vals[-1] for vals, tag, _ in piv if tag in ('state', 'total')}
    assert totals == {'Done': 1, 'Partial finished': 1, 'Pending': 1, 'Tổng cộng': 3}, totals
    done_mats = {rec[1][3] for _, tag, recs in piv if tag == 'state' for rec in recs if sh.state(rec[1]) == 'done'}
    assert done_mats == {'P_FINISHED_NOW'}, done_mats

    print('All RC48 acceptance tests (fast Excel COM S7->S6 handover with AutoFilter/hidden tail/stale calc/text AF + carried Partial->Done Pivot reporting) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
