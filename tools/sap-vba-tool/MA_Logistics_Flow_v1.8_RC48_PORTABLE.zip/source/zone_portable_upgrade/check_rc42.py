"""Regression suite for RC42 requirements, bug fixes, performance and unified table UX."""
from contextlib import ExitStack
from datetime import date, datetime
from decimal import Decimal
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
from types import SimpleNamespace as S
from unittest.mock import patch

import check_portable as cp


def run(exe_path: Path):
    _, entries, _ = cp.archive(exe_path.read_bytes())
    mods = cp.pyz_entries(cp.payload(next(e for e in entries.values() if e[3] == b'z')))
    if not any(isinstance(f, cp.EmbeddedSource) for f in sys.meta_path):
        sys.meta_path.insert(0, cp.EmbeddedSource(mods))

    import sap_zone_core as core
    import sap_zone_gui as gui
    import zone18 as z
    import zone_daily as daily
    import zone_mail as mail
    import zone_arrival as arrival
    import zone_shift as sh
    from zone_order_result import file_key

    assert z.VERSION in ('1.8 RC42', '1.8 RC43', '1.8 RC44', '1.8 RC45', '1.8 RC46', '1.8 RC47', '1.8 RC48'), z.VERSION

    # 1. Decimal AllocationEngine + strict 1,500 paste guard
    class FakeZone:
        def resolve_zone_tl(self, *a):
            return 'Z1', 'TL1', True

    engine = core.AllocationEngine(FakeZone(), 5, 20)
    reqs = [{'material': 'MAT1', 'station': 'ST1', 'qty': 0.3, 'input_zone': ''}]
    stock = [
        {'material': 'MAT1', 'batch': 'B1', 'bin': 'L1', 'unit': 'EA', 'available_qty': 0.1, 'allocated_qty': 0, 'sort_key': '1'},
        {'material': 'MAT1', 'batch': 'B2', 'bin': 'L2', 'unit': 'EA', 'available_qty': 0.2, 'allocated_qty': 0, 'sort_key': '2'},
    ]
    groups, shortages, _ = engine.allocate(reqs, stock)
    assert not shortages
    assert [l['qty'] for g in groups for l in g['lines']] == [0.1, 0.2]
    sh.check_allocated(reqs, groups)

    try:
        core.parse_paste_data('MAT1\t1,500\tST1')
    except ValueError:
        pass
    else:
        raise AssertionError('Ambiguous 1,500 paste must fail closed')
    assert core.parse_paste_data('MAT1\t10\tST1')[0]['qty'] == 10

    # 2. Report rules #1 & #2: Hang tap ket handover marker + hidden detail still in Totals
    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, state, kh, note='Chưa ra đơn', ca='', qty=10, issued=0, ah=None):
        r = [None] * 35
        r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = mat, qty, 'ST1', '3093', 'P', 'L1', 'VF8', 'S7'
        r[22], r[24], r[26], r[27], r[31] = issued, state, kh, note, ca
        r[32], r[33] = (0 if issued == 0 else None), ah
        return r

    d_old, d_cur = '2026-11-19', '2026-11-21'
    # Verify opening_values writes 'Hàng tập kết' instead of 'Tập kết ca trước'
    src_gather = mk_row('G0', 'Pending', d_cur, 'Hàng tập kết')
    assert sh.opening_values(src_gather)[2] == 'Hàng tập kết'

    shift_id = (date(2026, 11, 21), 'S7')
    rows_tbl = [
        header,
        mk_row('P_CARRIED', 'Partial finished', d_cur, 'Đã ra đơn, chờ cấp', ca=1, issued=4),
        mk_row('P_NEW', 'Partial finished', d_cur, 'Đã ra đơn, chờ cấp', ca='', issued=2),
        mk_row('G_CARRIED', 'Pending', d_cur, 'Hàng tập kết', ah='Hàng tập kết'),
        mk_row('OLD_PEND', 'Pending', d_old, 'Chưa ra đơn'),
        mk_row('CUR_PEND', 'Pending', d_cur, 'Chưa ra đơn'),
    ]
    _, piv_lines = daily.pivot(rows_tbl, full=True, all_rows=False, options={'filters': {31: ['']}, 'pending_since': d_cur},
                               identity=shift_id, include_gather=False)
    detail_mats = {rec[1][3] for _, tag, recs in piv_lines if tag in ('detail', 'gathered') for rec in recs}
    assert 'P_NEW' in detail_mats and 'CUR_PEND' in detail_mats
    assert not ({'P_CARRIED', 'G_CARRIED', 'OLD_PEND'} & detail_mats), detail_mats
    totals = {v[0]: v[-1] for v, tag, _ in piv_lines if tag in ('state', 'total')}
    assert totals['Partial finished'] == 2 and totals['Pending'] == 3 and totals['Tổng cộng'] == 5, totals
    daily_pending_sum = sum(v[-1] for v, tag, recs in piv_lines if tag == 'date' and any(sh.state(r[1]) == 'pending' for r in recs))
    assert daily_pending_sum == 1 and totals['Pending'] == 3

    _, piv_gather = daily.pivot(rows_tbl, full=False, all_rows=False, identity=shift_id, include_gather=True)
    assert any(v[2] == 'Hàng tập kết' for v, tag, _ in piv_gather if tag == 'gathered')
    assert not any(v[2] == 'Tập kết ca trước' for v, _, _ in piv_gather)

    # 3. IN NVL per-row delivery date in multi-date email
    in_html = ('<table><tr><td>PO</td><td>Item</td><td>Mã hàng</td><td>SL</td><td>Delivery date</td></tr>'
               '<tr><td>4500001</td><td>10</td><td>IN1</td><td>5</td><td>28.11.2026</td></tr>'
               '<tr><td>4500002</td><td>10</td><td>IN2</td><td>6</td><td>05.12.2026</td></tr></table>')
    parsed_in = mail.extract(S(HTMLBody=in_html, Body='', Subject='Giao hang 28/11 va 05/12/2026', SenderName='S', EntryID='in1',
                                ReceivedTime=datetime(2026, 11, 26, 9, 0)), 'in')
    seen_dates = []
    with patch.object(arrival, 'master_at', side_effect=lambda s, m, u, dt: (seen_dates.append((m, dt)), ([], 'absent', ''))[1]), \
         patch.object(arrival.sap, 'vl06i', return_value=[]):
        arrival.check_plans(None, parsed_in['rows'], {'plant': '3093'}, {}, 10, 0)
    assert seen_dates == [('IN1', date(2026, 11, 28)), ('IN2', date(2026, 12, 5))], seen_dates

    # 4. SQLite shared DB schema + order_line_claim auto-release vs post_group + ODBS handover + OD_DA_DONG + MailPage Tk UI
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        shared_db = root / '261126_SQL_V19.sqlite'
        init_conn = sqlite3.connect(shared_db)
        try:
            init_conn.execute('CREATE TABLE run_result(run_id TEXT PRIMARY KEY, document TEXT NOT NULL, changed TEXT)')
            init_conn.commit()
        finally:
            init_conn.close()
        old_shared = getattr(core, '_shared_journal', None)
        try:
            core._shared_journal = str(shared_db)
            z._SCHEMA_READY.clear()
            with z.journal() as conn:
                tbls = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                assert {'post_group', 'post_request', 'run_result', 'order_line_claim', 'order_history', 'order_closed', 'mail_write', 'mail_odbs'} <= tbls

                # 4a. 0 post_group rows -> auto-release claim
                sh.reservations(conn, [{'row': 2, 'line_id': 'L_UNSENT'}], run='RUN_NONE')
                assert sh.reservations(conn, [{'row': 2, 'line_id': 'L_UNSENT'}], run='RUN_NEXT') == []

                # 4b. Multi-group partial run -> Group 1 POSTED stays locked, Group 2 unsent auto-releases
                conn.execute('INSERT INTO run_result(run_id, document) VALUES(?,?)',
                             ('RUN_PART', json.dumps({'groups': [{'group_id': 'GRP_001'}, {'group_id': 'GRP_002'}],
                                                      'order_groups': [['L_G1'], ['L_G2']]})))
                conn.execute('INSERT INTO post_group(token, run_id, state, snapshot, ob) VALUES(?,?,?,?,?)',
                             ('TOK_1', 'RUN_PART', 'POSTED', json.dumps({'group': {'group_id': 'GRP_001'}}), '1013309999'))
                sh.reservations(conn, [{'row': 3, 'line_id': 'L_G1'}, {'row': 4, 'line_id': 'L_G2'}], run='RUN_PART')
                assert sh.reservations(conn, [{'row': 4, 'line_id': 'L_G2'}], run='RUN_G2') == []
                try:
                    sh.reservations(conn, [{'row': 3, 'line_id': 'L_G1'}], run='RUN_G1_DUP')
                except ValueError as exc:
                    assert 'Lịch sử và Đối soát dòng' in str(exc)
                else:
                    raise AssertionError('Posted line in post_group must remain locked')

            # 4c. ODBS inheritance S7 -> S6 without changing Excel NOTE
            s7_path = root / '261125_THEO DOI ORDER NVL_P_S7.xlsb'
            s6_path = root / '261126_THEO DOI ORDER NVL_P_S6.xlsb'
            s7_path.write_bytes(b's7')
            s6_path.write_bytes(b's6')
            r_odbs = mk_row('MAT_BS', 'Pending', '2026-11-26', 'Chưa ra đơn')
            r_odbs[28], r_odbs[29], r_odbs[30] = date(2026, 11, 25), 0.5, 'An'
            r_odbs[34] = json.dumps({'mail_row': 'tok_bs_1', 'bbbg_only': False})
            tbl_s7 = [header, r_odbs]
            tbl_s6 = [header, list(r_odbs)]
            mail.odbs_links(s7_path, [('tok_bs_1', 'mail:tok_bs_1')])
            carried_links = mail.inherit_odbs(s7_path, tbl_s7, s6_path, tbl_s6)
            assert 'mail:tok_bs_1' in carried_links and tbl_s6[1][27] == 'Chưa ra đơn'

            # 4d. Closed OD_DA_DONG check blocks re-write & resolves Mail OD row
            r_closed = mk_row('MAT_CLOSED', 'Pending', '2026-11-26', 'Chưa ra đơn')
            r_closed[28], r_closed[29], r_closed[30] = date(2026, 11, 25), 0.5, 'An'
            mail.closed_snapshot(s6_path, [('Dọn OD cũ', 5, *r_closed)])
            msg_closed = {
                'id': 'MC1', 'received': '2026-11-25 12:00:00', 'issues': [], 'skipped': 0,
                'plan_counts': {'2026-11-26': {'H': 0}},
                'rows': [{'material': 'MAT_CLOSED', 'qty': '10', 'warehouse': 'P', 'model': 'VF8',
                          'plan': '2026-11-26', 'station': 'ST1', 'leader': '', 'person': 'An',
                          'production_shift': 'S7', 'mail_token_v2': 'tok_closed_1'}]
            }
            mail.reconcile_order([msg_closed], [header])
            entries_cl = mail.closed_entries(s6_path, None, {}, {})
            mail.apply_closed_od([msg_closed], entries_cl)
            assert msg_closed['rows'][0]['match_state'] == 'archived'
            assert 'OD_DA_DONG' in msg_closed['rows'][0]['status']
        finally:
            core._shared_journal = old_shared
            z._SCHEMA_READY.clear()

    # 5. Real Windows Tk tests: Mail OD unsaved observed -> Cần đối chiếu, unified Lưu cấu hình, grid parity
    import tkinter as tk
    from tkinter import ttk
    import tkinter.messagebox as mb
    import zone_workspace as ws

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        core.ConfigManager.save_config(dict(core.DEFAULT_CONFIG))
        with ExitStack() as stack:
            stack.enter_context(patch.object(ws, 'start_workspace'))
            stack.enter_context(patch.object(core, 'get_base_dir', return_value=tmp))
            stack.enter_context(patch.object(core.SapConnector, 'init_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'uninit_thread_com'))
            stack.enter_context(patch.object(core.SapConnector, 'test_connection', return_value={'ok': False}))
            stack.enter_context(patch.object(mb, 'showinfo'))
            os.environ['LOCALAPPDATA'] = tmp
            root = tk.Tk()
            errors = []
            root.report_callback_exception = lambda e, v, tb: errors.append(f'{e.__name__}: {v}')
            try:
                app = gui.SapZoneApp(root)
                root.update()
                # Verify unified Lưu cấu hình saves both OUT NVL (hsd_materials + sloc_from) AND Mail OD (lookback)
                app.hsd_materials = ['HSD001']
                app.cfg_sloc_from.delete(0, 'end')
                app.cfg_sloc_from.insert(0, '1099')
                cfg_book = next(w for w in app.tab_config.winfo_children() if isinstance(w, ttk.Notebook))
                mail_tab = cfg_book.winfo_children()[3]
                # Set lookback entry inside Mail OD tab
                for w in mail_tab.winfo_children():
                    for c in w.winfo_children():
                        if isinstance(c, ttk.Entry) and c.get() == '3':
                            c.delete(0, 'end')
                            c.insert(0, '7')
                cfg_book.select(3)  # Currently standing on Mail OD tab!
                app._save_config()
                saved_cfg = core.ConfigManager.load_config()
                assert saved_cfg['sloc_from'] == '1099' and saved_cfg['fefo_materials'] == ['HSD001']
                assert saved_cfg['mail_out']['lookback'] == '7'

                # Verify Mail OD unsaved observed -> Cần đối chiếu (not Done / green, not written to SQLite)
                wb_path = d / '261126_THEO DOI ORDER NVL_P_S6.xlsb'
                wb_path.write_bytes(b'x')
                app.shift_page.path = wb_path
                app.shift_page.sources[file_key(wb_path)] = 'Excel đang mở · có sửa chưa lưu'
                app.out_mail.cfg = dict(app.out_mail.cfg, workbook=str(wb_path))
                row_unsaved = mk_row('MAT_OBS', 'Pending', '2026-11-26', 'Chưa ra đơn')
                row_unsaved[28], row_unsaved[29], row_unsaved[30] = date(2026, 11, 25), 0.5, 'An'
                msg_obs = {
                    'id': 'MO1', 'received': '2026-11-25 12:00:00', 'sender': 'A', 'subject': 'OD 26/11 S6',
                    'issues': [], 'skipped': 0, 'plan_counts': {'2026-11-26': {'H': 0}},
                    'rows': [{'material': 'MAT_OBS', 'qty': '10', 'warehouse': 'P', 'model': 'VF8',
                              'plan': '2026-11-26', 'station': 'ST1', 'leader': '', 'person': 'An',
                              'production_shift': 'S6', 'mail_token_v2': 'tok_obs_1'}]
                }
                with patch('zone_excel_live.find', return_value=S(Saved=False)):
                    app.out_mail.audit([msg_obs], {}, app.out_mail.cfg, current=[header, row_unsaved])
                assert not mail.receipts(d), 'Unsaved Excel must not persist observed: into SQLite'
                app.shift_page.sources[file_key(wb_path)] = 'File đã lưu'
                with patch('zone_excel_live.find', return_value=None):
                    app.out_mail.audit([msg_obs], {}, app.out_mail.cfg, current=[header])
                assert msg_obs['rows'][0]['match_state'] == 'review'
                assert 'Cần đối chiếu' in msg_obs['rows'][0]['status']
                assert not app.out_mail.row_done(msg_obs['rows'][0]['status'])
                dates, choice, groups, summary, alerts = app.out_mail.build_view([msg_obs], 'Tất cả', [header], {})
                assert '0/1 dòng P' in summary or '0 mail đã copy đủ · 1 mail cần xem' in summary, summary
                assert groups['MO1'][4] == 'warn'

                # Verify grid parity and removed SearchPage filter_bar per RC43
                assert hasattr(app, 'out_filter_bar') and hasattr(app.inbound_page, 'filter_bar')
                assert hasattr(app.out_mail, 'filter_bar') and not hasattr(app.search_page, 'filter_bar')
                assert app.shift_page.tree.extra_menu and app.out_mail.tree.extra_menu
                assert app.inbound_page.tree.extra_menu and app.tree.extra_menu
                assert not errors, errors
            finally:
                root.destroy()

    print('All RC42 acceptance tests (Decimal allocation, 1,500 guard, Hang tap ket & hidden Pivot totals, IN NVL delivery, Mail OD unsaved/OD_DA_DONG/ODBS, claim auto-release, shared schema, unified save & grid parity) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
