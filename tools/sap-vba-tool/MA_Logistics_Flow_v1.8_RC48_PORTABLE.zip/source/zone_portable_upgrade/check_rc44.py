"""Acceptance tests for MA Logistics Flow v1.8 RC44 (partial multi-match & fast SearchPage lookup)."""
from contextlib import ExitStack
from datetime import date
from pathlib import Path
import sys
import tempfile
import tkinter as tk
from types import SimpleNamespace as S
from unittest.mock import patch


def run(exe_path: Path):
    here = Path(__file__).resolve().parent
    sys.path.insert(0, str(here))
    from build_portable import archive, payload, pyz_entries
    from check_portable import EmbeddedSource

    _, entries, _ = archive(exe_path.read_bytes())
    pyz = next(n for n, e in entries.items() if e[3] == b'z')
    modules = pyz_entries(payload(entries[pyz]))
    sys.meta_path.insert(0, EmbeddedSource(modules))

    import zone18 as z
    import zone_mail as mail
    import zone_qty as qty_mod
    import zone_search as search
    import zone_shift as sh
    from zone_order_result import file_key

    assert z.VERSION in ('1.8 RC44', '1.8 RC45', '1.8 RC46', '1.8 RC47', '1.8 RC48'), z.VERSION

    # 1. Partial token matching multiple full material codes returns ALL matching codes with full columns
    header = [None] * 35
    for col, name in sh.FIELD_NAMES.items():
        header[col] = name
    header[28:31] = ['Ngày order', 'Giờ order', 'Người order']
    header[32:34] = [sh.BASE_QTY, sh.BASE_NOTE]

    def mk_row(mat, qty, issued, kh='2026-11-26', ob1='1013301111', sp1='26-01', note='Đã ra đơn, chờ cấp'):
        r = [None] * 35
        r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[11] = mat, qty, 'ST1', '3093', 'P', 'L1', 'VF5', 'S6'
        r[13], r[14], r[15] = ob1, sp1, (issued if issued else None)
        r[22], r[24], r[26], r[27] = issued, ('done' if issued == qty else 'Partial finished' if issued else 'Pending'), kh, note
        return r

    r1 = mk_row('BIW35114418AB', 100, 60, sp1='26-01', note='Cấp một phần')
    r2 = mk_row('BIW70004418', 40, 0, ob1='', sp1='', note='Chưa ra đơn')
    table = [header, r1, r2]

    hits, rev = search.requested('4418', {'BIW35114418AB', 'BIW70004418', 'BIW99999999'})
    assert hits == {'BIW35114418AB', 'BIW70004418'} and not rev, (hits, rev)

    groups, _, review = search.lookup('4418', date(2026, 11, 26), [(Path('261126_THEO DOI ORDER NVL_P_S6.xlsb'), table)], [])
    assert not review and set(groups) == {('BIW35114418AB', date(2026, 11, 26)), ('BIW70004418', date(2026, 11, 26))}, groups

    # 2. SearchPage.search() skips redundant Excel COM read_order() when active table matches disk signature
    with tempfile.TemporaryDirectory() as tmp:
        wb = Path(tmp) / '261126_THEO DOI ORDER NVL_P_S6.xlsb'
        wb.write_bytes(b'order-data')
        stamp = sh.signature(wb)
        otable = qty_mod.OrderTable(table)
        app = S(is_running=False, out_mail=S(prior_selected={}, messages=[]))
        page = S(app=app, path=wb, table=otable, revision=1, password=None, stamp=stamp,
                 sources={file_key(wb): 'File đã lưu'}, pivots={})
        page.task = lambda label, work, done, *args, **kwargs: done(work())
        root = tk.Tk()
        try:
            screen = search.SearchPage(root, page, lambda: None)
            screen.anchor.set('2026-11-26')
            screen.input.insert('1.0', '4418')
            with ExitStack() as stack:
                read_mock = stack.enter_context(patch.object(sh, 'read_order', side_effect=AssertionError('Must reuse in-memory p.table instead of spawning Excel!')))
                stack.enter_context(patch.object(mail, 'prior_files', return_value=([], [])))
                stack.enter_context(patch.object(sh, 'missing_history', return_value=()))
                screen.search()
                root.update()
                assert not read_mock.called
                mats = {row[1]: row for row in screen.tree.rows}
                assert set(mats) == {'BIW35114418AB', 'BIW70004418'}, screen.tree.rows
                assert mats['BIW35114418AB'][2:6] == ('100', '60', '40', '26-01')
                assert mats['BIW70004418'][2] == '40' and 'Chưa ra đơn' in mats['BIW70004418'][-1]
                assert '2 nhóm mã/ngày' in screen.hint.get()
        finally:
            root.destroy()

    print('All RC44 acceptance tests (multi-match partial search & fast SearchPage in-memory reuse) passed.')


if __name__ == '__main__':
    exe = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / 'MA_Logistics_Flow.exe'
    run(exe)
